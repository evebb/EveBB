<?php

/**
 * Topic Tags - settings and curation page.
 *
 * Included by admin_plugins.php inside the admin chrome (and inside a POST
 * form that footer.php injects the CSRF token into). $db, $pun_config and
 * $plugin_slug are available here.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

// The addon normally creates the tables on first page view, but make sure
// they exist even if the settings page is visited before that
evebb_tags_ensure_schema();

$tags_back = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

//
// Repoint every use of tag $from_id to $into_id (deduping topics that had
// both), then drop $from_id
//
function evebb_tags_admin_merge($from_id, $into_id)
{
	global $db;

	$from_id = (int) $from_id;
	$into_id = (int) $into_id;

	// Drop rows that would collide after the repoint
	$db->query('DELETE FROM '.$db->prefix.'topic_tags WHERE tag_id='.$from_id.' AND topic_id IN (SELECT topic_id FROM (SELECT topic_id FROM '.$db->prefix.'topic_tags WHERE tag_id='.$into_id.') AS keep)') or error('Unable to merge tags', __FILE__, __LINE__, $db->error());
	$db->query('UPDATE '.$db->prefix.'topic_tags SET tag_id='.$into_id.' WHERE tag_id='.$from_id) or error('Unable to merge tags', __FILE__, __LINE__, $db->error());
	$db->query('DELETE FROM '.$db->prefix.'tags WHERE id='.$from_id) or error('Unable to merge tags', __FILE__, __LINE__, $db->error());
}

// Save settings
if (isset($_POST['save_tags']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	evebb_tags_save_conf('o_tags_listshow', isset($_POST['tags_listshow']) ? '1' : '0');

	$max = isset($_POST['tags_max']) ? (int) $_POST['tags_max'] : 5;
	if ($max < 1)
		$max = 1;
	else if ($max > 10)
		$max = 10;
	evebb_tags_save_conf('o_tags_max', (string) $max);

	// Forum list: keep only digits and commas, normalise
	$forums_raw = pun_trim($_POST['tags_forums'] ?? '');
	$forum_ids = array();
	foreach (explode(',', $forums_raw) as $part)
	{
		$part = (int) trim($part);
		if ($part > 0 && !in_array($part, $forum_ids))
			$forum_ids[] = $part;
	}
	evebb_tags_save_conf('o_tags_forums', implode(',', $forum_ids));

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect($tags_back, 'Settings saved. Redirecting …');
}

// Rename a tag (renaming onto an existing tag's name becomes a merge)
if (isset($_POST['rename_tag']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$tag_id = (int) ($_POST['rename_from'] ?? 0);
	$parsed = evebb_tags_parse($_POST['rename_to'] ?? '');

	if ($tag_id < 1 || empty($parsed))
		redirect($tags_back, 'Pick a tag and give a valid new name (2-30 characters; letters, numbers and hyphens). Redirecting …');

	$new_name = $parsed[0];

	$result = $db->query('SELECT id FROM '.$db->prefix.'tags WHERE name=\''.$db->escape($new_name).'\'') or error('Unable to fetch tag', __FILE__, __LINE__, $db->error());
	$existing_id = $db->has_rows($result) ? (int) $db->result($result) : 0;

	if ($existing_id == $tag_id)
		redirect($tags_back, 'That is already the tag\'s name. Redirecting …');

	if ($existing_id > 0)
	{
		evebb_tags_admin_merge($tag_id, $existing_id);
		redirect($tags_back, 'That name was already in use, so the tags were merged. Redirecting …');
	}

	$db->query('UPDATE '.$db->prefix.'tags SET name=\''.$db->escape($new_name).'\' WHERE id='.$tag_id) or error('Unable to rename tag', __FILE__, __LINE__, $db->error());
	redirect($tags_back, 'Tag renamed. Redirecting …');
}

// Merge one tag into another
if (isset($_POST['merge_tags']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$from_id = (int) ($_POST['merge_from'] ?? 0);
	$into_id = (int) ($_POST['merge_into'] ?? 0);

	if ($from_id < 1 || $into_id < 1 || $from_id == $into_id)
		redirect($tags_back, 'Pick two different tags to merge. Redirecting …');

	evebb_tags_admin_merge($from_id, $into_id);
	redirect($tags_back, 'Tags merged. Redirecting …');
}

// Delete a tag everywhere
if (isset($_POST['delete_tag']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$tag_id = (int) ($_POST['delete_which'] ?? 0);

	if ($tag_id > 0)
	{
		$db->query('DELETE FROM '.$db->prefix.'topic_tags WHERE tag_id='.$tag_id) or error('Unable to delete tag', __FILE__, __LINE__, $db->error());
		$db->query('DELETE FROM '.$db->prefix.'tags WHERE id='.$tag_id) or error('Unable to delete tag', __FILE__, __LINE__, $db->error());
	}

	redirect($tags_back, 'Tag deleted. Redirecting …');
}

// Remove tag rows whose topics no longer exist
if (isset($_POST['purge_tags']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DELETE FROM '.$db->prefix.'topic_tags WHERE topic_id NOT IN (SELECT id FROM '.$db->prefix.'topics)') or error('Unable to purge tag rows', __FILE__, __LINE__, $db->error());
	evebb_tags_gc($db);

	redirect($tags_back, 'Orphaned tag rows purged. Redirecting …');
}

// Remove ALL plugin data (before uninstalling)
if (isset($_POST['nuke_tags']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect($tags_back, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('topic_tags');
	$db->drop_table('tags');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN (\'o_tags_db_rev\', \'o_tags_max\', \'o_tags_listshow\', \'o_tags_forums\')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());

	unset($pun_config['o_tags_db_rev'], $pun_config['o_tags_max'], $pun_config['o_tags_listshow'], $pun_config['o_tags_forums']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Topic Tags data removed. You can now deactivate and delete the plugin. Redirecting …');
}

$tags_listshow = evebb_tags_conf('o_tags_listshow', '1') == '1';
$tags_max      = (int) evebb_tags_conf('o_tags_max', '5');
$tags_forums   = evebb_tags_conf('o_tags_forums', '');

// The vocabulary with global topic counts (the admin sees everything)
$result = $db->query('SELECT t.id, t.name, COUNT(tt.topic_id) AS n FROM '.$db->prefix.'tags AS t LEFT JOIN '.$db->prefix.'topic_tags AS tt ON tt.tag_id=t.id GROUP BY t.id, t.name ORDER BY t.name') or error('Unable to fetch tags', __FILE__, __LINE__, $db->error());
$vocab = array();
$tagged_rows = 0;
while ($row = $db->fetch_assoc($result))
{
	$vocab[] = $row;
	$tagged_rows += (int) $row['n'];
}

// Forum reference list for the restriction field
$result = $db->query('SELECT f.id, f.forum_name, c.cat_name FROM '.$db->prefix.'forums AS f INNER JOIN '.$db->prefix.'categories AS c ON c.id=f.cat_id ORDER BY c.disp_position, c.id, f.disp_position') or error('Unable to fetch forum list', __FILE__, __LINE__, $db->error());
$forum_list = array();
while ($cur_forum = $db->fetch_assoc($result))
	$forum_list[] = $cur_forum;

function evebb_tags_select($name, $vocab)
{
	$html = '<select name="'.$name.'">';
	foreach ($vocab as $cur_tag)
		$html .= '<option value="'.(int) $cur_tag['id'].'">'.pun_htmlspecialchars($cur_tag['name']).' ('.(int) $cur_tag['n'].')</option>';

	return $html.'</select>';
}

?>
		<div class="inform">
			<fieldset>
				<legend>Topic Tags settings</legend>
				<div class="infldset">
					<p>Tags in use: <strong><?php echo count($vocab) ?></strong> across <strong><?php echo $tagged_rows ?></strong> topic taggings. Members tag their own new topics; the topic starter and forum staff can retag a topic from its page. Browse page: <strong>plugins/tags/</strong>.</p>
					<label><input type="checkbox" name="tags_listshow" value="1"<?php if ($tags_listshow) echo ' checked="checked"' ?> /> Show tag pills under topic titles in forum topic lists</label>
					<label>Maximum tags per topic (1&ndash;10)
						<br /><input type="text" name="tags_max" size="4" maxlength="2" value="<?php echo $tags_max ?>" />
					</label>
					<label>Only enable in these forums (comma-separated forum IDs; leave blank for all forums)
						<br /><input type="text" name="tags_forums" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($tags_forums) ?>" />
					</label>
<?php if (count($forum_list)): ?>
					<p>For reference, your forums are:</p>
					<ul>
<?php foreach ($forum_list as $cur_forum): ?>
						<li><span><strong><?php echo (int) $cur_forum['id'] ?></strong> &mdash; <?php echo pun_htmlspecialchars($cur_forum['cat_name']) ?> / <?php echo pun_htmlspecialchars($cur_forum['forum_name']) ?></span></li>
<?php endforeach; ?>
					</ul>
<?php endif; ?>
					<p class="topspace"><input type="submit" name="save_tags" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Curate the vocabulary</legend>
				<div class="infldset">
<?php if (empty($vocab)): ?>
					<p>No tags yet. Once members start tagging topics you can rename, merge and delete tags here.</p>
<?php else: ?>
					<p>Keep freeform tagging tidy: fix typos with rename, fold duplicates together with merge, and delete anything unwanted. Renaming a tag to a name that already exists merges the two.</p>
					<p>Rename <?php echo evebb_tags_select('rename_from', $vocab) ?> to <input type="text" name="rename_to" size="20" maxlength="30" /> <input type="submit" name="rename_tag" value="Rename" /></p>
					<p>Merge <?php echo evebb_tags_select('merge_from', $vocab) ?> into <?php echo evebb_tags_select('merge_into', $vocab) ?> <input type="submit" name="merge_tags" value="Merge" /></p>
					<p>Delete <?php echo evebb_tags_select('delete_which', $vocab) ?> from every topic <input type="submit" name="delete_tag" value="Delete" /></p>
<?php endif; ?>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Maintenance</legend>
				<div class="infldset">
					<p>Deleting a topic does not remove its tag rows (they are simply never shown again). Purging clears those leftovers and drops any tag that no longer has topics.</p>
					<p><input type="submit" name="purge_tags" value="Purge orphaned tag rows" /></p>
					<p class="topspace">To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the tags and topic_tags tables and all of this plugin's settings.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently deletes every tag</label></p>
					<p><input type="submit" name="nuke_tags" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
