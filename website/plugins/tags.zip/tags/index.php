<?php

/**
 * Topic Tags - the browse page.
 *
 *   <board>/plugins/tags/            the tag directory (every tag with a
 *                                    topic count the viewer can see)
 *   <board>/plugins/tags/?tag=name   the permission-filtered topic list
 *                                    for one tag, paginated
 *
 * Standalone page rendered inside the full forum chrome (the showcase
 * pattern: relative asset/nav URLs are absolutized on the way out because
 * this file lives under plugins/).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

//
// Absolutize relative href/src so forum chrome works from /plugins/tags/
//
function tags_absolutize($html)
{
	$base = get_base_url(true).'/';

	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('tags_absolutize');

if (!in_array('tags', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

evebb_tags_ensure_schema();

$tags_base = get_base_url(true);

// Which tag, if any?
$tag_name = '';
if (isset($_GET['tag']))
{
	$parsed = evebb_tags_parse($_GET['tag']);
	$tag_name = empty($parsed) ? '' : $parsed[0];
}

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), $tag_name !== '' ? 'Tag: '.$tag_name : 'Tags');
define('PUN_ACTIVE_PAGE', 'index');
define('PUN_ALLOW_INDEX', 1);
require PUN_ROOT.'header.php';

?>
<style>
.tagdir .tagpill { font-size: 1em; margin: 0 .4em .45em 0; }
.tagdir .tagpill span { opacity: .65; font-size: .85em; margin-left: .35em; }
.taglist table { width: 100%; border-collapse: collapse; }
.taglist th, .taglist td { text-align: left; padding: .45em .6em; border-bottom: 1px solid rgba(128,128,128,.25); font-size: .95em; }
.taglist th { font-size: .85em; text-transform: uppercase; letter-spacing: .04em; opacity: .75; }
.taglist td.tnum { text-align: right; white-space: nowrap; }
.tagback { font-size: .9em; }
</style>
<?php

if ($tag_name === '')
{
	// ---- Directory: every tag with a permission-filtered topic count ----
	$result = $db->query('SELECT t.name, COUNT(tt.topic_id) AS n FROM '.$db->prefix.'tags AS t INNER JOIN '.$db->prefix.'topic_tags AS tt ON tt.tag_id=t.id'.evebb_tags_visible_join().' WHERE'.evebb_tags_visible_where().' GROUP BY t.id, t.name ORDER BY n DESC, t.name') or error('Unable to fetch tags', __FILE__, __LINE__, $db->error());

	$all_tags = array();
	while ($row = $db->fetch_assoc($result))
		$all_tags[] = $row;

?>
<div class="block">
	<h2><span>Tags</span></h2>
	<div class="box">
		<div class="inbox tagdir">
<?php

	if (empty($all_tags))
		echo "\t\t\t".'<p>No tags yet — tags appear here once topics are tagged.</p>'."\n";
	else
	{
		echo "\t\t\t".'<p>Every tag in use, most-used first. Click a tag to see its topics.</p>'."\n\t\t\t".'<p>'."\n";
		foreach ($all_tags as $cur_tag)
			echo "\t\t\t\t".'<a class="tagpill" href="'.$tags_base.'/plugins/tags/?tag='.urlencode($cur_tag['name']).'">'.pun_htmlspecialchars($cur_tag['name']).'<span>'.(int) $cur_tag['n'].'</span></a>'."\n";
		echo "\t\t\t".'</p>'."\n";
	}

?>
		</div>
	</div>
</div>
<?php

}
else
{
	// ---- One tag: its visible topics, newest activity first, paginated ----
	$result = $db->query('SELECT COUNT(tt.topic_id) FROM '.$db->prefix.'topic_tags AS tt INNER JOIN '.$db->prefix.'tags AS t ON t.id=tt.tag_id'.evebb_tags_visible_join().' WHERE'.evebb_tags_visible_where().' AND t.name=\''.$db->escape($tag_name).'\'') or error('Unable to count tagged topics', __FILE__, __LINE__, $db->error());
	$num_topics = (int) $db->result($result);

	$disp = max(10, (int) $pun_user['disp_topics']);
	$num_pages = (int) ceil($num_topics / $disp);
	$p = (isset($_GET['p']) && (int) $_GET['p'] > 0) ? (int) $_GET['p'] : 1;
	if ($num_pages > 0 && $p > $num_pages)
		$p = $num_pages;
	$start_from = $disp * ($p - 1);

	$paging_links = '<span class="pages-label">'.$lang_common['Pages'].' </span>'.paginate(max(1, $num_pages), $p, $tags_base.'/plugins/tags/?tag='.urlencode($tag_name));

	$rows = array();
	if ($num_topics > 0)
	{
		$result = $db->query('SELECT tp.id, tp.subject, tp.poster, tp.num_replies, tp.last_post, f.id AS forum_id, f.forum_name FROM '.$db->prefix.'topic_tags AS tt INNER JOIN '.$db->prefix.'tags AS t ON t.id=tt.tag_id'.evebb_tags_visible_join().' WHERE'.evebb_tags_visible_where().' AND t.name=\''.$db->escape($tag_name).'\' ORDER BY tp.last_post DESC LIMIT '.$disp.' OFFSET '.$start_from) or error('Unable to fetch tagged topics', __FILE__, __LINE__, $db->error());
		while ($row = $db->fetch_assoc($result))
			$rows[] = $row;
	}

?>
<div class="linkst">
	<div class="inbox">
		<?php echo $paging_links."\n" ?>
		<p class="tagback"><a href="<?php echo $tags_base ?>/plugins/tags/">&laquo; All tags</a></p>
	</div>
</div>
<div class="block">
	<h2><span>Tag: <?php echo pun_htmlspecialchars($tag_name) ?> (<?php echo $num_topics ?>)</span></h2>
	<div class="box">
		<div class="inbox taglist">
<?php

	if (empty($rows))
		echo "\t\t\t".'<p>No topics carry this tag.</p>'."\n";
	else
	{
		echo "\t\t\t".'<table>'."\n\t\t\t\t".'<tr><th>Topic</th><th>Forum</th><th>Started by</th><th class="tnum">Replies</th><th>Last post</th></tr>'."\n";
		foreach ($rows as $row)
		{
			echo "\t\t\t\t".'<tr>'
				.'<td><a href="'.$tags_base.'/viewtopic.php?id='.(int) $row['id'].'">'.pun_htmlspecialchars($row['subject']).'</a></td>'
				.'<td><a href="'.$tags_base.'/viewforum.php?id='.(int) $row['forum_id'].'">'.pun_htmlspecialchars($row['forum_name']).'</a></td>'
				.'<td>'.pun_htmlspecialchars($row['poster']).'</td>'
				.'<td class="tnum">'.(int) $row['num_replies'].'</td>'
				.'<td>'.format_time($row['last_post']).'</td>'
				.'</tr>'."\n";
		}
		echo "\t\t\t".'</table>'."\n";
	}

?>
		</div>
	</div>
</div>
<div class="linksb">
	<div class="inbox">
		<?php echo $paging_links."\n" ?>
	</div>
</div>
<?php

}

require PUN_ROOT.'footer.php';
