<?php

/**
 * Topic Tags - shared library.
 *
 * Schema management, tag-name normalisation and query helpers used by the
 * addon (tags.php), the browse page (index.php) and the settings page
 * (admin.php).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


//
// Create the tag tables on first use. Guarded by the o_tags_db_rev config
// key so the check is free on every later request.
//
function evebb_tags_ensure_schema()
{
	global $db, $pun_config;

	if (isset($pun_config['o_tags_db_rev']))
		return;

	if (!$db->table_exists('tags'))
	{
		$schema = array(
			'FIELDS' => array(
				'id' => array(
					'datatype'   => 'SERIAL',
					'allow_null' => false
				),
				'name' => array(
					'datatype'   => 'VARCHAR(30)',
					'allow_null' => false,
					'default'    => '\'\''
				)
			),
			'PRIMARY KEY' => array('id'),
			'UNIQUE KEYS' => array(
				'name_idx' => array('name')
			)
		);

		$db->create_table('tags', $schema) or error('Unable to create the tags table', __FILE__, __LINE__, $db->error());
	}

	if (!$db->table_exists('topic_tags'))
	{
		$schema = array(
			'FIELDS' => array(
				'topic_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'tag_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('topic_id', 'tag_id'),
			'INDEXES' => array(
				'tag_id_idx' => array('tag_id')
			)
		);

		$db->create_table('topic_tags', $schema) or error('Unable to create the topic_tags table', __FILE__, __LINE__, $db->error());
	}

	// Record the schema revision. No or-error here: if two requests race,
	// the loser's duplicate insert may fail and that is fine.
	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_tags_db_rev\', \'1\')');
	$pun_config['o_tags_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Read a plugin config value with a default
//
function evebb_tags_conf($name, $default)
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Insert or update a config value and refresh the config cache
//
function evebb_tags_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


//
// Is the plugin enabled in this forum? o_tags_forums holds a
// comma-separated list of forum IDs; blank means every forum.
//
function evebb_tags_forum_enabled($forum_id)
{
	$list = trim(evebb_tags_conf('o_tags_forums', ''));

	if ($list === '')
		return true;

	$ids = array_map('intval', explode(',', $list));

	return in_array((int) $forum_id, $ids, true);
}


//
// Parse a comma-separated tag string into a normalised, deduplicated list.
// Normalisation: lowercase, whitespace/underscores collapsed to single
// hyphens, charset [a-z0-9-], 2-30 characters. Anything that fails the
// charset or length rules lands in $bad (for the error message).
//
function evebb_tags_parse($raw, &$bad = null)
{
	$bad = array();
	$tags = array();

	foreach (explode(',', (string) $raw) as $part)
	{
		$name = utf8_strtolower(pun_trim($part));
		if ($name === '')
			continue;

		$name = preg_replace('%[\s_]+%u', '-', $name);
		$name = preg_replace('%-{2,}%', '-', $name);
		$name = trim($name, '-');

		if ($name === '')
			continue;

		if (!preg_match('%^[a-z0-9-]{2,30}$%', $name))
		{
			$bad[] = $name;
			continue;
		}

		if (!in_array($name, $tags, true))
			$tags[] = $name;
	}

	return $tags;
}


//
// Resolve a normalised tag name to its id, creating it if needed. Takes the
// DB handle explicitly so the shutdown-time save (which opens a fresh
// connection) can use it too. The insert-then-reselect covers the rare race
// where two requests create the same new tag at once.
//
function evebb_tags_resolve($db, $name)
{
	$result = $db->query('SELECT id FROM '.$db->prefix.'tags WHERE name=\''.$db->escape($name).'\'');
	if ($result && $db->has_rows($result))
		return (int) $db->result($result);

	$db->query('INSERT INTO '.$db->prefix.'tags (name) VALUES(\''.$db->escape($name).'\')');

	$result = $db->query('SELECT id FROM '.$db->prefix.'tags WHERE name=\''.$db->escape($name).'\'');

	return ($result && $db->has_rows($result)) ? (int) $db->result($result) : 0;
}


//
// Replace a topic's tags with the given (already normalised) list
//
function evebb_tags_set_topic($db, $topic_id, $tags)
{
	$topic_id = (int) $topic_id;

	$db->query('DELETE FROM '.$db->prefix.'topic_tags WHERE topic_id='.$topic_id);

	foreach ($tags as $name)
	{
		$tag_id = evebb_tags_resolve($db, $name);
		if ($tag_id > 0)
			$db->query('INSERT INTO '.$db->prefix.'topic_tags (topic_id, tag_id) VALUES('.$topic_id.', '.$tag_id.')');
	}
}


//
// Remove tags that no longer belong to any topic
//
function evebb_tags_gc($db)
{
	$db->query('DELETE FROM '.$db->prefix.'tags WHERE id NOT IN (SELECT tag_id FROM '.$db->prefix.'topic_tags)');
}


//
// Fetch a topic's tag names, ordered alphabetically
//
function evebb_tags_for_topic($topic_id)
{
	global $db;

	$result = $db->query('SELECT t.name FROM '.$db->prefix.'topic_tags AS tt INNER JOIN '.$db->prefix.'tags AS t ON t.id=tt.tag_id WHERE tt.topic_id='.(int) $topic_id.' ORDER BY t.name') or error('Unable to fetch topic tags', __FILE__, __LINE__, $db->error());

	$tags = array();
	while ($row = $db->fetch_row($result))
		$tags[] = $row[0];

	return $tags;
}


//
// The SQL fragment joining topic_tags rows to topics the current viewer is
// allowed to see (search.php's own permission pattern). Usage:
//   'FROM '.$db->prefix.'topic_tags AS tt'.evebb_tags_visible_join().' WHERE ...'
//
function evebb_tags_visible_join()
{
	global $db, $pun_user;

	return ' INNER JOIN '.$db->prefix.'topics AS tp ON tp.id=tt.topic_id'
		.' INNER JOIN '.$db->prefix.'forums AS f ON f.id=tp.forum_id'
		.' LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.(int) $pun_user['g_id'].')';
}

function evebb_tags_visible_where()
{
	return ' (fp.read_forum IS NULL OR fp.read_forum=\'1\') AND tp.moved_to IS NULL';
}
