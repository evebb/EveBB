# Topic Tags

An unofficial [eveBB](https://evebb.net) plugin that lets members tag their
topics with keywords, and everyone browse the board by tag.

## Features

- Up to 5 (configurable 1–10) comma-separated tags when starting a topic,
  with live suggestions from the existing vocabulary as you type.
- Tags render as small pills under the topic title in forum topic lists
  and on the topic page.
- Every pill links to a permission-filtered topic list for that tag, and
  a directory page at `plugins/tags/` lists the whole vocabulary with
  topic counts (counts only ever include topics the viewer can see).
- The topic starter can retag their own topic from its page; moderators
  and administrators can retag anything. Tags that lose their last topic
  disappear automatically.
- Freeform tagging with admin curation: rename (typo fixes), merge
  (duplicate folding — renaming onto an existing name also merges), and
  delete, all from the settings page.

## Installation

Upload `tags.zip` through **Administration → Plugins → Upload plugin**,
then activate it. The plugin creates its two database tables (`tags`,
`topic_tags`) automatically on first use.

## Settings

**Administration → Plugins → Topic Tags → Settings**

- Show tag pills in forum topic lists (default on)
- Maximum tags per topic, 1–10 (default 5)
- Only enable in certain forums (comma-separated forum IDs; blank = all)
- Curation: rename / merge / delete tags
- Maintenance: purge rows for deleted topics; full data removal for a
  clean uninstall

## Notes

- Tag names are normalised automatically: lowercase, spaces become
  hyphens, 2–30 characters, letters/numbers/hyphens only.
- Tagging and retagging require an account; guests see tags and can
  browse by them.
- Without JavaScript nothing breaks: the tags field still accepts typed
  input (no suggestions), and tag browsing is plain server-rendered HTML.

## License

GPL version 2 or higher, like eveBB itself.
