<?php

/**
 * Topic Tags - the addon.
 *
 * Members add up to N comma-separated keyword tags when starting a topic,
 * with live suggestions from the existing vocabulary as they type. Tags
 * render as pills in forum topic lists and on the topic page (linking to
 * the browse page at plugins/tags/), and the topic starter or forum staff
 * can retag a topic afterwards.
 *
 * Wiring (all patterns proven by earlier plugins in this series):
 *  - Creation fields render server-side into the new-topic form through
 *    post_before_submit; validation joins the core error list through
 *    post_after_validation; the tag rows are written by a shutdown
 *    callback with a fresh DB handle once post.php has created the topic
 *    (the polls plugin's technique - post.php has no post-insert hook).
 *  - The autocomplete endpoint rides the composer URL
 *    (post.php?fid=N&tags_q=...) and is handled at header_head_end:
 *    discard output buffers, end the transaction, emit pure JSON, exit
 *    (the simtopics technique).
 *  - viewtopic/viewforum decoration is DOM-built by JS emitted into
 *    <head> (the solved technique); retagging is a POST covered by the
 *    board's global CSRF gate.
 *
 * State: two tables, tags (id, name UNIQUE) and topic_tags (topic_id,
 * tag_id), created automatically on first use. Tags that lose their last
 * topic are garbage-collected on the spot.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_tags extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
		$manager->bind('post_before_submit', array($this, 'post_form'));
		$manager->bind('post_after_validation', array($this, 'post_validate'));
	}

	function head()
	{
		// The hook can fire twice in one request when core re-includes
		// header.php (e.g. message() rendering an error page). Act once.
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		evebb_tags_ensure_schema();

		$page = isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : '';

		if ($page == 'post.php')
			$this->head_post();
		else if ($page == 'viewtopic.php')
			$this->head_viewtopic();
		else if ($page == 'viewforum.php')
			$this->head_viewforum();
	}


	//
	// post.php: serve the autocomplete endpoint, or emit the suggestion UI
	// script for the composer (new topics by members in enabled forums)
	//
	function head_post()
	{
		global $fid, $pun_user;

		if (empty($fid) || $pun_user['is_guest'] || !evebb_tags_forum_enabled($fid))
			return;

		if (isset($_GET['tags_q']))
			$this->serve_suggestions($_GET['tags_q']);   // exits

		$this->emit(array(
			'page' => 'compose',
			'fid'  => (int) $fid,
			'max'  => (int) evebb_tags_conf('o_tags_max', '5')
		));
	}


	//
	// Emit tag suggestions as pure JSON and exit. The query is folded to
	// the tag charset first, so no LIKE metacharacters survive. Counts are
	// permission-filtered: a tag only ever suggests with the number of
	// topics THIS viewer could open, and invisible-only tags not at all.
	//
	function serve_suggestions($q)
	{
		global $db;

		$q = preg_replace('%[^a-z0-9-]%', '', utf8_strtolower((string) $q));

		while (ob_get_level() > 0)
			ob_end_clean();

		$db->end_transaction();

		header('Content-Type: application/json; charset=utf-8');

		if (strlen($q) < 1)
			exit('[]');

		$result = $db->query('SELECT t.name, COUNT(tt.topic_id) AS n, (CASE WHEN t.name LIKE \''.$db->escape($q).'%\' THEN 0 ELSE 1 END) AS rank FROM '.$db->prefix.'tags AS t INNER JOIN '.$db->prefix.'topic_tags AS tt ON tt.tag_id=t.id'.evebb_tags_visible_join().' WHERE'.evebb_tags_visible_where().' AND t.name LIKE \'%'.$db->escape($q).'%\' GROUP BY t.id, t.name ORDER BY rank, n DESC, t.name LIMIT 8');

		$out = array();
		if ($result)
		{
			while ($row = $db->fetch_assoc($result))
				$out[] = array('name' => $row['name'], 'n' => (int) $row['n']);
		}

		exit(json_encode($out, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
	}


	//
	// post.php (new topic only): render the tags field inside the form.
	// Values re-fill from $_POST on preview or validation errors.
	//
	function post_form()
	{
		global $fid, $pun_user;

		if (empty($fid) || $pun_user['is_guest'] || !evebb_tags_forum_enabled($fid))
			return;

		$max = (int) evebb_tags_conf('o_tags_max', '5');
		$value = isset($_POST['tags_input']) ? pun_htmlspecialchars($_POST['tags_input']) : '';

?>
				<div class="inform">
					<fieldset>
						<legend>Tags (optional)</legend>
						<div class="infldset">
							<p>Up to <?php echo $max ?> keywords, separated by commas, to help others find this topic. Letters, numbers and hyphens; existing tags are suggested as you type.</p>
							<label>Tags<br /><input class="longinput" type="text" name="tags_input" value="<?php echo $value ?>" size="80" maxlength="255" autocomplete="off" /><br /></label>
						</div>
					</fieldset>
				</div>
<?php
	}


	//
	// post.php: validate the tags on submit/preview; stash for the
	// shutdown-time save on a valid, non-preview new topic
	//
	function post_validate()
	{
		global $errors, $fid, $pun_user;

		if (empty($fid) || $pun_user['is_guest'] || !evebb_tags_forum_enabled($fid))
			return;

		$raw = isset($_POST['tags_input']) ? (string) $_POST['tags_input'] : '';
		if (pun_trim($raw) === '')
			return;

		$bad = array();
		$tags = evebb_tags_parse($raw, $bad);
		$max = (int) evebb_tags_conf('o_tags_max', '5');

		if (!empty($bad))
			$errors[] = 'These tags are not valid (2-30 characters; letters, numbers and hyphens only): '.pun_htmlspecialchars(implode(', ', $bad));

		if (count($tags) > $max)
			$errors[] = 'A topic may have at most '.$max.' tags.';

		if (empty($tags) || !empty($errors) || isset($_POST['preview']))
			return;

		evebb_tags_ensure_schema();

		$GLOBALS['evebb_tags_pending'] = $tags;

		register_shutdown_function(array('plugin_tags', 'save_pending'));
	}


	//
	// Shutdown callback: post.php has created the topic ($new_tid, global
	// scope) and exited through redirect(), which closed the request's DB
	// handle - open a fresh one and write the tag rows. If the post failed
	// $new_tid is never set and nothing happens. (See the polls plugin for
	// the full story on this technique.)
	//
	static function save_pending()
	{
		if (!isset($GLOBALS['evebb_tags_pending']) || !isset($GLOBALS['new_tid']))
			return;

		$tid = (int) $GLOBALS['new_tid'];
		$tags = $GLOBALS['evebb_tags_pending'];

		if ($tid < 1 || !is_array($tags) || empty($tags))
			return;

		global $db_type, $db_host, $db_username, $db_password, $db_name, $db_prefix, $p_connect;
		$db = null;
		require PUN_ROOT.'include/dblayer/common_db.php';

		if (!is_object($db))
			return;

		$db->start_transaction();
		evebb_tags_set_topic($db, $tid, $tags);
		$db->end_transaction();
		$db->close();
	}


	//
	// viewtopic.php: handle a retag, then describe the topic's tags (and
	// the viewer's powers) to the page JS
	//
	function head_viewtopic()
	{
		global $db, $pun_user, $cur_topic, $id, $is_admmod;

		// Defensive: these are set by viewtopic.php before header.php runs
		if (!isset($cur_topic) || !isset($id))
			return;

		if (!evebb_tags_forum_enabled($cur_topic['forum_id']))
			return;

		// Who may retag? Forum moderators/admins always; the topic starter
		// (registered users only) for their own topic
		$can_edit = !empty($is_admmod);

		if (!$can_edit && !$pun_user['is_guest'])
		{
			$result = $db->query('SELECT poster_id FROM '.$db->prefix.'posts WHERE id='.(int) $cur_topic['first_post_id']) or error('Unable to fetch topic starter', __FILE__, __LINE__, $db->error());
			$starter_id = $db->has_rows($result) ? (int) $db->result($result) : 0;

			if ($starter_id > 1 && $starter_id == (int) $pun_user['id'])
				$can_edit = true;
		}

		// A retag? (POST - the global CSRF gate has already validated the
		// token.) Exits on every well-formed request.
		if ($can_edit && isset($_POST['tags_action']) && $_POST['tags_action'] === 'save')
			$this->handle_save((int) $id);

		$tags = evebb_tags_for_topic($id);

		if (empty($tags) && !$can_edit)
			return;

		$this->emit(array(
			'page'    => 'topic',
			'topic'   => (int) $id,
			'first'   => (int) $cur_topic['first_post_id'],
			'tags'    => $tags,
			'canEdit' => $can_edit,
			'max'     => (int) evebb_tags_conf('o_tags_max', '5'),
			'token'   => $can_edit ? pun_csrf_token() : ''
		));
	}


	//
	// Validate and apply a retag, then redirect. Every path exits. Output
	// so far is still buffered, so it is safe to throw away; no message()
	// from here (it would re-include header.php and re-fire the hook).
	//
	function handle_save($tid)
	{
		global $db;

		while (ob_get_level() > 0)
			ob_end_clean();

		$bad = array();
		$tags = evebb_tags_parse(isset($_POST['tags_input']) ? (string) $_POST['tags_input'] : '', $bad);
		$max = (int) evebb_tags_conf('o_tags_max', '5');

		if (!empty($bad) || count($tags) > $max)
			redirect('viewtopic.php?id='.$tid, 'Those tags are not valid. Redirecting …');

		$db->start_transaction();
		evebb_tags_set_topic($db, $tid, $tags);
		evebb_tags_gc($db);
		$db->end_transaction();

		redirect('viewtopic.php?id='.$tid, 'Tags saved. Redirecting …');
	}


	//
	// viewforum.php: emit a topic-id => tag-names map for this forum's
	// tagged topics (recent topics first, defensively bounded)
	//
	function head_viewforum()
	{
		global $db, $id;

		if (!isset($id))
			return;

		if (evebb_tags_conf('o_tags_listshow', '1') != '1')
			return;

		if (!evebb_tags_forum_enabled($id))
			return;

		$result = $db->query('SELECT tt.topic_id, t.name FROM '.$db->prefix.'topic_tags AS tt INNER JOIN '.$db->prefix.'topics AS tp ON tp.id=tt.topic_id INNER JOIN '.$db->prefix.'tags AS t ON t.id=tt.tag_id WHERE tp.forum_id='.(int) $id.' ORDER BY tp.last_post DESC, t.name LIMIT 1500') or error('Unable to fetch forum tags', __FILE__, __LINE__, $db->error());

		$map = array();
		while ($row = $db->fetch_assoc($result))
			$map[(int) $row['topic_id']][] = $row['name'];

		if (empty($map))
			return;

		$this->emit(array(
			'page' => 'forum',
			'map'  => $map
		));
	}


	//
	// Emit the shared CSS plus the page JS with its config blob into <head>
	//
	function emit($cfg)
	{
		$json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

		echo '<style>'
			.'.tagpill{display:inline-block;padding:0 .55em;margin:0 .25em .15em 0;border:1px solid rgba(110,130,150,.5);border-radius:9px;background:rgba(110,130,150,.12);font-size:.85em;text-decoration:none;white-space:nowrap}'
			.'a.tagpill:hover{border-color:rgba(82,126,180,.9)}'
			.'.tagsrow{margin:.6em 0;font-size:.95em}'
			.'.tagsrow .tagslabel{font-weight:bold;margin-right:.4em}'
			.'.tagsrow a.tagsedit{font-size:.9em;margin-left:.4em}'
			.'.tagsrow form{display:inline}'
			.'.tagsrow input[type=text]{width:22em;max-width:60%}'
			.'span.tclcon-tags{display:block;margin-top:.1em}'
			.'.tagsuggest{position:absolute;z-index:50;border:1px solid rgba(110,130,150,.6);background:#fff;color:#333;min-width:14em;box-shadow:0 2px 6px rgba(0,0,0,.25)}'
			.'.tagsuggest button{display:block;width:100%;text-align:left;border:0;background:none;padding:.3em .6em;cursor:pointer;font:inherit;color:inherit}'
			.'.tagsuggest button:hover,.tagsuggest button:focus{background:rgba(82,126,180,.18)}'
			.'.tagsuggest button span{opacity:.6;font-size:.85em;margin-left:.5em}'
			.'</style>'."\n";

		echo '<script>/* Topic Tags plugin */'."\n".'(function(){'."\n"
			.'var cfg = '.$json.';'."\n"
			.<<<'EOJS'
function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

function el(tag, cls, text) {
	var e = document.createElement(tag);
	if (cls) e.className = cls;
	if (text) e.textContent = text;
	return e;
}

function pill(name) {
	var a = el('a', 'tagpill', name);
	a.href = 'plugins/tags/?tag=' + encodeURIComponent(name);
	return a;
}

// ---- viewforum: pills under each tagged topic's title ----------------------
function forumPage() {
	var links = document.querySelectorAll('#vf div.tclcon a');
	for (var j = 0; j < links.length; j++) {
		var m = /^viewtopic\.php\?id=(\d+)$/.exec(links[j].getAttribute('href') || '');
		if (!m || !cfg.map[m[1]]) continue;
		var names = cfg.map[m[1]];
		var wrap = el('span', 'tclcon-tags');
		for (var i = 0; i < names.length; i++) wrap.appendChild(pill(names[i]));
		links[j].parentNode.appendChild(wrap);
		delete cfg.map[m[1]]; // once per topic (skips same-row pagination links anyway)
	}
}

// ---- viewtopic: pill row under the first post, with in-place editing -------
function topicPage() {
	var row = el('div', 'tagsrow');
	row.id = 'tagsrow';

	function view() {
		row.textContent = '';
		row.appendChild(el('span', 'tagslabel', 'Tags:'));
		if (cfg.tags.length === 0) row.appendChild(document.createTextNode(' none yet'));
		for (var i = 0; i < cfg.tags.length; i++) row.appendChild(pill(cfg.tags[i]));
		if (cfg.canEdit) {
			var edit = document.createElement('a');
			edit.href = '#';
			edit.className = 'tagsedit';
			edit.textContent = cfg.tags.length ? 'edit tags' : 'add tags';
			edit.addEventListener('click', function (e) { e.preventDefault(); form(); });
			row.appendChild(edit);
		}
	}

	function form() {
		row.textContent = '';
		row.appendChild(el('span', 'tagslabel', 'Tags:'));
		var f = document.createElement('form');
		f.method = 'post';
		f.action = 'viewtopic.php?id=' + cfg.topic;
		var h1 = document.createElement('input');
		h1.type = 'hidden'; h1.name = 'tags_action'; h1.value = 'save';
		f.appendChild(h1);
		var h2 = document.createElement('input');
		h2.type = 'hidden'; h2.name = 'csrf_token'; h2.value = cfg.token;
		f.appendChild(h2);
		var input = document.createElement('input');
		input.type = 'text'; input.name = 'tags_input';
		input.maxLength = 255;
		input.value = cfg.tags.join(', ');
		input.setAttribute('autocomplete', 'off');
		f.appendChild(input);
		f.appendChild(document.createTextNode(' '));
		var save = document.createElement('input');
		save.type = 'submit'; save.value = 'Save';
		f.appendChild(save);
		var cancel = document.createElement('a');
		cancel.href = '#';
		cancel.className = 'tagsedit';
		cancel.textContent = 'cancel';
		cancel.addEventListener('click', function (e) { e.preventDefault(); view(); });
		f.appendChild(document.createTextNode(' '));
		f.appendChild(cancel);
		row.appendChild(f);
		input.focus();
	}

	view();

	var first = document.getElementById('p' + cfg.first);
	if (first)
		first.parentNode.insertBefore(row, first.nextSibling);
	else {
		var top = document.querySelector('div.blockpost');
		if (top) top.parentNode.insertBefore(row, top);
	}
}

// ---- composer: live suggestions for the tags field -------------------------
function composePage() {
	var input = document.querySelector('input[name="tags_input"]');
	if (!input) return;

	var box = el('div', 'tagsuggest');
	box.style.display = 'none';
	input.parentNode.style.position = 'relative';
	input.parentNode.appendChild(box);

	var timer = null, seq = 0;

	function segment() {
		var parts = input.value.split(',');
		return parts[parts.length - 1].trim().toLowerCase();
	}

	function apply(name) {
		var parts = input.value.split(',');
		parts[parts.length - 1] = ' ' + name;
		input.value = parts.join(',').replace(/^\s+/, '') + ', ';
		hide();
		input.focus();
	}

	function hide() { box.style.display = 'none'; box.textContent = ''; }

	function show(items) {
		box.textContent = '';
		if (!items.length) { hide(); return; }
		for (var i = 0; i < items.length; i++) (function (it) {
			var b = document.createElement('button');
			b.type = 'button';
			b.textContent = it.name;
			var n = el('span', null, String(it.n));
			b.appendChild(n);
			b.addEventListener('mousedown', function (e) { e.preventDefault(); apply(it.name); });
			box.appendChild(b);
		})(items[i]);
		box.style.left = input.offsetLeft + 'px';
		box.style.top = (input.offsetTop + input.offsetHeight) + 'px';
		box.style.display = '';
	}

	input.addEventListener('input', function () {
		if (timer) clearTimeout(timer);
		var q = segment();
		if (q.length < 2) { hide(); return; }
		timer = setTimeout(function () {
			var mine = ++seq;
			fetch('post.php?fid=' + cfg.fid + '&tags_q=' + encodeURIComponent(q), { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (items) { if (mine === seq && segment() === q) show(items); })
				.catch(function () { hide(); });
		}, 350);
	});
	input.addEventListener('blur', function () { setTimeout(hide, 200); });
	input.addEventListener('keydown', function (e) { if (e.key === 'Escape') hide(); });
}

ready(function () {
	if (cfg.page === 'forum') forumPage();
	else if (cfg.page === 'topic') topicPage();
	else composePage();
});
EOJS
			."\n".'})();</script>'."\n";
	}
}
