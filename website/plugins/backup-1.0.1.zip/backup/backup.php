<?php

/**
 * Scheduled Backup - the addon.
 *
 * A single hook: header_head_end fires on every page. It bootstraps the
 * plugin config on first use, then runs the interval-gated sweep. The gate
 * is a cheap in-memory check on almost every request; only when a backup is
 * actually due does one request (claimed via compare-and-set) do the work.
 *
 * This is the WordPress-style pseudo-cron model - no system cron required.
 * When eveBB 2.1's core task scheduler lands, this plugin can hand the
 * schedule over to it.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

class plugin_backup extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'tick'));
	}

	function tick()
	{
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		evebb_backup_bootstrap();
		evebb_backup_sweep();
	}
}
