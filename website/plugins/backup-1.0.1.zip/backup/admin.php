<?php

/**
 * Scheduled Backup - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome and inside a single
 * POST form (footer.php injects the CSRF token). $db, $pun_config and
 * $plugin_slug are available.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

evebb_backup_bootstrap();

$redir = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

if (isset($_POST['save_backup']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$interval = isset($_POST['bk_interval']) ? (int) $_POST['bk_interval'] : 86400;
	if ($interval < 300) $interval = 300;
	if ($interval > 2592000) $interval = 2592000;
	evebb_backup_save_conf('o_backup_interval', (string) $interval);

	$retention = isset($_POST['bk_retention']) ? (int) $_POST['bk_retention'] : 7;
	if ($retention < 1) $retention = 1;
	if ($retention > 365) $retention = 365;
	evebb_backup_save_conf('o_backup_retention', (string) $retention);

	evebb_backup_save_conf('o_backup_gzip', isset($_POST['bk_gzip']) ? '1' : '0');

	$dir = pun_trim($_POST['bk_dir'] ?? 'cache/backups');
	if ($dir === '')
		$dir = 'cache/backups';
	evebb_backup_save_conf('o_backup_dir', $dir);

	evebb_backup_save_conf('o_backup_mysqldump', pun_trim($_POST['bk_mysqldump'] ?? 'mysqldump'));
	evebb_backup_save_conf('o_backup_pgdump', pun_trim($_POST['bk_pgdump'] ?? 'pg_dump'));

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect($redir, 'Settings saved. Redirecting …');
}

if (isset($_POST['run_backup']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	list($ok, $file, $status) = evebb_backup_sweep(true);
	redirect($redir, ($ok ? 'Backup created: '.$file : 'Backup failed: '.$status).'. Redirecting …');
}

if (isset($_POST['del_backup']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$name = basename((string) $_POST['del_backup']);
	$dir = evebb_backup_dir();
	if ($dir !== false && preg_match(EVEBB_BACKUP_RE, $name) && is_file($dir.'/'.$name))
		@unlink($dir.'/'.$name);

	redirect($redir, 'Backup deleted. Redirecting …');
}

if (isset($_POST['nuke_backup']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name LIKE \'o_backup_%\'') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());
	foreach (array_keys($pun_config) as $k)
		if (strpos($k, 'o_backup_') === 0)
			unset($pun_config[$k]);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Scheduled Backup settings removed (backup files on disk are left in place). Redirecting …');
}

$interval   = (int) evebb_backup_conf('o_backup_interval', '86400');
$retention  = (int) evebb_backup_conf('o_backup_retention', '7');
$gzip       = evebb_backup_conf('o_backup_gzip', '1') == '1';
$dir_conf   = evebb_backup_conf('o_backup_dir', 'cache/backups');
$mysqldump  = evebb_backup_conf('o_backup_mysqldump', 'mysqldump');
$pgdump     = evebb_backup_conf('o_backup_pgdump', 'pg_dump');
$last_run   = (int) evebb_backup_conf('o_backup_last_run', '0');
$last_ok    = evebb_backup_conf('o_backup_last_ok', '0') == '1';
$last_file  = evebb_backup_conf('o_backup_last_status', '');
$last_status= evebb_backup_conf('o_backup_last_status', '');

$dir_ok = evebb_backup_dir();
$backups = evebb_backup_list();
$token = pun_csrf_token();

function evebb_backup_human_size($bytes)
{
	$units = array('B', 'KB', 'MB', 'GB');
	$i = 0;
	$n = (float) $bytes;
	while ($n >= 1024 && $i < count($units) - 1) { $n /= 1024; $i++; }
	return round($n, ($i === 0) ? 0 : 1).' '.$units[$i];
}

?>
		<div class="inform">
			<fieldset>
				<legend>Status</legend>
				<div class="infldset">
<?php if ($dir_ok === false): ?>
					<p class="warntext"><strong>The backup directory is not writable.</strong> Set a writable path below before backups can run.</p>
<?php endif; ?>
					<p>Last run: <?php echo $last_run > 0 ? pun_htmlspecialchars(format_time($last_run)) : 'never'; ?>.
<?php if ($last_run > 0): ?> Result: <strong><?php echo $last_ok ? 'success' : 'failed'; ?></strong><?php if (!$last_ok && $last_status !== ''): ?> &mdash; <?php echo pun_htmlspecialchars($last_status); ?><?php endif; ?>.<?php endif; ?></p>
					<p><?php echo count($backups) ?> backup file(s) stored<?php if ($dir_ok !== false): ?> in <code><?php echo pun_htmlspecialchars($dir_ok) ?></code><?php endif; ?>.</p>
					<p><input type="submit" name="run_backup" value="Back up now" /></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Stored backups</legend>
				<div class="infldset">
<?php if (empty($backups)): ?>
					<p>No backups yet.</p>
<?php else: ?>
					<table>
						<thead><tr><th>File</th><th>Size</th><th>Created</th><th>Actions</th></tr></thead>
						<tbody>
<?php foreach ($backups as $b): ?>
							<tr>
								<td><code><?php echo pun_htmlspecialchars($b['name']) ?></code></td>
								<td><?php echo evebb_backup_human_size($b['size']) ?></td>
								<td><?php echo pun_htmlspecialchars(format_time($b['mtime'])) ?></td>
								<td>
									<a href="<?php echo pun_htmlspecialchars(get_base_url().'/plugins/backup/download.php?file='.urlencode($b['name']).'&csrf_token='.urlencode($token)) ?>">download</a>
									&nbsp;<button type="submit" name="del_backup" value="<?php echo pun_htmlspecialchars($b['name']) ?>" onclick="return confirm('Delete this backup file?')">delete</button>
								</td>
							</tr>
<?php endforeach; ?>
						</tbody>
					</table>
					<p>Downloads are restricted to administrators. Keep these files safe &mdash; each one contains the whole database.</p>
<?php endif; ?>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Schedule &amp; retention</legend>
				<div class="infldset">
					<label>Back up at most once every this many seconds (300&ndash;2592000; 86400 = daily)
						<br /><input type="text" name="bk_interval" size="8" maxlength="7" value="<?php echo $interval ?>" />
					</label>
					<label>Keep this many most-recent backups (older are deleted; 1&ndash;365)
						<br /><input type="text" name="bk_retention" size="5" maxlength="3" value="<?php echo $retention ?>" />
					</label>
					<label><input type="checkbox" name="bk_gzip" value="1"<?php if ($gzip) echo ' checked="checked"' ?> /> Compress backups with gzip</label>
					<label>Backup directory (relative to the forum root, or an absolute path)
						<br /><input type="text" name="bk_dir" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($dir_conf) ?>" />
					</label>
					<p>Choose a directory the web server cannot serve if you can &mdash; the plugin drops deny rules in it, but a path outside the web root is safest.</p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>External dump tools (MySQL / PostgreSQL only)</legend>
				<div class="infldset">
					<p>SQLite boards are backed up by copying the database file &mdash; nothing to configure. MySQL and PostgreSQL use these command-line tools; give a full path if they are not on the web server's PATH.</p>
					<label>mysqldump path<br /><input type="text" name="bk_mysqldump" size="40" maxlength="255" value="<?php echo pun_htmlspecialchars($mysqldump) ?>" /></label>
					<label>pg_dump path<br /><input type="text" name="bk_pgdump" size="40" maxlength="255" value="<?php echo pun_htmlspecialchars($pgdump) ?>" /></label>
					<p class="topspace"><input type="submit" name="save_backup" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Uninstall</legend>
				<div class="infldset">
					<p>This plugin stores no tables of its own. Removing its data clears the settings below; <strong>backup files already written to disk are left in place</strong> for you to keep or delete yourself. Then deactivate and delete the plugin.</p>
					<p><input type="submit" name="nuke_backup" value="Remove all plugin settings" /></p>
				</div>
			</fieldset>
		</div>
<?php
