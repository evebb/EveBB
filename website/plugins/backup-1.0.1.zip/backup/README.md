# Scheduled Backup

An unofficial eveBB plugin that takes regular backups of your forum database
into a protected folder, keeps the newest few, and lets you download or delete
them from the admin panel.

## How it runs — no cron needed

Like the other eveBB schedulers, it uses the **WordPress-style pseudo-cron**
model: the board's own traffic drives it. Almost every page view does nothing
but a cheap time check; only when a backup is actually due does one request
(claimed with a compare-and-set) run it. There is also a **Back up now** button
on the settings page.

When eveBB 2.1's core task scheduler arrives, this plugin can hand its schedule
over to it.

## How each database is backed up

- **SQLite** — the database file is copied directly. Nothing to configure.
- **MySQL** — via `mysqldump` (`--single-transaction`), if available.
- **PostgreSQL** — via `pg_dump`, if available.

For MySQL/PostgreSQL the command-line tool must be present on the web server;
give a full path on the settings page if it is not on the `PATH`. If the tool
can't be run, the attempt is recorded as failed (visible on the settings page)
rather than producing a broken file. Backups are gzip-compressed by default.

## Where backups go — and safety

Backups contain the **entire database**, including password hashes and email
addresses. Treat them as secrets.

- They are written to `cache/backups` by default (configurable). The plugin
  drops `.htaccess` / `web.config` deny rules and a blank `index.html` in that
  folder, but a path **outside the web root** is safest if you can use one.
- Downloads go through an endpoint that only serves the **Administrators**
  group, requires a valid CSRF token, and strictly validates the filename (no
  path traversal).

## Settings

- **Interval** — the minimum seconds between backups (default 86400 = daily).
- **Retention** — how many recent backups to keep; older ones are deleted.
- **Compress** — gzip backups (on by default).
- **Directory** — where to store them.
- **mysqldump / pg_dump paths** — for MySQL/PostgreSQL boards.

## Uninstall

This plugin stores **no tables of its own**. **Remove all plugin settings** on
the settings page clears its configuration; backup files already written to
disk are deliberately left in place for you to keep or delete yourself. Then
deactivate and delete the plugin.

## License

GPL version 2 or higher — http://www.gnu.org/licenses/gpl.html
