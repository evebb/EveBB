<?php

/**
 * Scheduled Backup - protected download endpoint.
 *
 * Streams a backup file to an administrator. Backups contain the entire
 * database (including password hashes and emails), so access is limited to
 * the Administrators group and the filename is strictly validated against
 * the plugin's own naming pattern (no path traversal).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

if (!in_array('backup', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

// Administrators only
if ($pun_user['is_guest'] || $pun_user['g_id'] != PUN_ADMIN)
	message($lang_common['No permission'], false, '403 Forbidden');

// CSRF: require a valid token on the request (link carries it)
$token = isset($_GET['csrf_token']) ? $_GET['csrf_token'] : '';
if (!is_string($token) || !hash_equals(pun_csrf_token(), $token))
	message($lang_common['Bad request'], false, '400 Bad Request');

$name = isset($_GET['file']) ? (string) $_GET['file'] : '';
$name = basename($name); // defence in depth
if (!preg_match(EVEBB_BACKUP_RE, $name))
	message($lang_common['Bad request'], false, '404 Not Found');

$dir = evebb_backup_dir();
if ($dir === false)
	message('The backup directory is not available.');

$path = $dir.'/'.$name;
if (!is_file($path))
	message($lang_common['Bad request'], false, '404 Not Found');

// Close the request's DB work before streaming
$db->end_transaction();
$db->close();

while (ob_get_level() > 0)
	ob_end_clean();

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.$name.'"');
header('Content-Length: '.filesize($path));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');

readfile($path);
exit;
