<?php

/**
 * Scheduled Backup - shared library.
 *
 * Config bootstrap, the protected backup directory, the backup itself, the
 * retention prune, and the interval-gated sweep (WordPress-style pseudo-cron:
 * driven by page views, claimed with a compare-and-set so only one request
 * per interval runs it).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

// A backup filename this plugin produced: backup-YYYYMMDD-HHMMSS.<ext>[.gz]
define('EVEBB_BACKUP_RE', '%^backup-[0-9]{8}-[0-9]{6}\.(sqlite|sql)(\.gz)?$%');


function evebb_backup_conf($name, $default)
{
	global $pun_config;
	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}

function evebb_backup_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


//
// One-time config bootstrap (no DB tables of its own). Guarded by
// o_backup_db_rev; the o_backup_last_run row is created here for the sweep's
// compare-and-set claim.
//
function evebb_backup_bootstrap()
{
	global $db, $pun_config;

	if (isset($pun_config['o_backup_db_rev']))
		return;

	$defaults = array(
		'o_backup_interval'    => '86400',   // daily
		'o_backup_retention'   => '7',
		'o_backup_gzip'        => '1',
		'o_backup_dir'         => 'cache/backups',
		'o_backup_mysqldump'   => 'mysqldump',
		'o_backup_pgdump'      => 'pg_dump',
		'o_backup_last_run'    => '0',
		'o_backup_last_status' => '',
		'o_backup_last_file'   => '',
		'o_backup_last_ok'     => '0'
	);
	foreach ($defaults as $name => $value)
	{
		if (!isset($pun_config[$name]))
			$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')');
		if (!isset($pun_config[$name]))
			$pun_config[$name] = $value;
	}

	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_backup_db_rev\', \'1\')');
	$pun_config['o_backup_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Absolute path to the (protected) backup directory, created on demand with
// deny rules. Returns the path, or false if it cannot be made writable.
//
function evebb_backup_dir()
{
	$rel = trim(evebb_backup_conf('o_backup_dir', 'cache/backups'));
	if ($rel === '')
		$rel = 'cache/backups';

	// Absolute paths are honoured; relative ones sit under the forum root.
	$dir = (preg_match('%^(/|[A-Za-z]:\\\\)%', $rel)) ? $rel : PUN_ROOT.$rel;
	$dir = rtrim($dir, '/\\');

	if (!is_dir($dir))
	{
		if (!@mkdir($dir, 0700, true) && !is_dir($dir))
			return false;
	}
	if (!is_writable($dir))
		return false;

	// Best-effort web protection (Apache old/new + IIS). A leading index
	// stops directory listing where the denies are ignored.
	if (!file_exists($dir.'/.htaccess'))
		@file_put_contents($dir.'/.htaccess', "Order allow,deny\nDeny from all\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n");
	if (!file_exists($dir.'/index.html'))
		@file_put_contents($dir.'/index.html', '');
	if (!file_exists($dir.'/web.config'))
		@file_put_contents($dir.'/web.config', "<?xml version=\"1.0\"?>\n<configuration><system.webServer><authorization><deny users=\"*\"/></authorization></system.webServer></configuration>\n");

	return $dir;
}


//
// gzip a file in place (path -> path.gz), returning the new path. On any
// failure the original path is returned unchanged.
//
function evebb_backup_gzip($path)
{
	if (!function_exists('gzencode'))
		return $path;

	$data = @file_get_contents($path);
	if ($data === false)
		return $path;

	$gz = @gzencode($data, 6);
	if ($gz === false)
		return $path;

	if (@file_put_contents($path.'.gz', $gz) === false)
		return $path;

	@unlink($path);
	return $path.'.gz';
}


//
// Perform one backup. Returns array(ok(bool), filename, status).
//
function evebb_backup_run()
{
	global $db, $db_type, $db_host, $db_username, $db_password, $db_name;

	$dir = evebb_backup_dir();
	if ($dir === false)
		return array(false, '', 'backup directory is not writable');

	$stamp = date('Ymd-His');
	$gzip = evebb_backup_conf('o_backup_gzip', '1') == '1';

	// --- SQLite: copy the committed database file --------------------------
	if (strpos($db_type, 'sqlite') !== false)
	{
		if (!is_file($db_name))
			return array(false, '', 'database file not found');

		$target = $dir.'/backup-'.$stamp.'.sqlite';
		if (!@copy($db_name, $target))
			return array(false, '', 'could not copy the database file');

		if ($gzip)
			$target = evebb_backup_gzip($target);

		return array(true, basename($target), 'ok');
	}

	// --- MySQL / PostgreSQL: external dump tool ----------------------------
	$is_mysql = (strpos($db_type, 'mysql') !== false);
	$is_pgsql = (strpos($db_type, 'pgsql') !== false);
	if (!$is_mysql && !$is_pgsql)
		return array(false, '', 'unsupported database driver: '.$db_type);

	if (!function_exists('proc_open'))
		return array(false, '', 'PHP proc_open is disabled - external dump not possible');

	$target = $dir.'/backup-'.$stamp.'.sql';

	list($host, $port) = evebb_backup_split_host($db_host);

	if ($is_mysql)
	{
		$bin = trim(evebb_backup_conf('o_backup_mysqldump', 'mysqldump'));
		$cmd = escapeshellarg($bin).' --host='.escapeshellarg($host);
		if ($port !== '')
			$cmd .= ' --port='.escapeshellarg($port);
		$cmd .= ' --user='.escapeshellarg($db_username);
		if ($db_password !== '')
			$cmd .= ' --password='.escapeshellarg($db_password);
		$cmd .= ' --skip-lock-tables --single-transaction '.escapeshellarg($db_name);
	}
	else
	{
		$bin = trim(evebb_backup_conf('o_backup_pgdump', 'pg_dump'));
		$cmd = 'PGPASSWORD='.escapeshellarg($db_password).' '.escapeshellarg($bin).' --host='.escapeshellarg($host);
		if ($port !== '')
			$cmd .= ' --port='.escapeshellarg($port);
		$cmd .= ' --username='.escapeshellarg($db_username).' --no-owner '.escapeshellarg($db_name);
	}

	$ok = evebb_backup_exec_to_file($cmd, $target);
	if (!$ok)
	{
		@unlink($target);
		return array(false, '', 'the dump command failed (check the tool path and credentials)');
	}

	if ($gzip)
		$target = evebb_backup_gzip($target);

	return array(true, basename($target), 'ok');
}

//
// Split "host:port" (or "host;port" / "host,port") into array(host, port).
//
function evebb_backup_split_host($host)
{
	$host = (string) $host;
	if (preg_match('%^(.*?)[:;,](\d+)$%', $host, $m))
		return array($m[1], $m[2]);
	return array($host, '');
}

//
// Run $cmd, writing stdout to $file. Returns true on exit code 0 with a
// non-empty file.
//
function evebb_backup_exec_to_file($cmd, $file)
{
	$fh = @fopen($file, 'wb');
	if (!$fh)
		return false;

	$descriptors = array(0 => array('pipe', 'r'), 1 => $fh, 2 => array('pipe', 'w'));
	$proc = @proc_open($cmd, $descriptors, $pipes);
	if (!is_resource($proc))
	{
		fclose($fh);
		return false;
	}
	fclose($pipes[0]);
	stream_get_contents($pipes[2]);
	fclose($pipes[2]);
	$code = proc_close($proc);
	fclose($fh);

	return ($code === 0 && filesize($file) > 0);
}


//
// List existing backups, newest first: array of array(name, size, mtime).
//
function evebb_backup_list()
{
	$dir = evebb_backup_dir();
	if ($dir === false)
		return array();

	$out = array();
	foreach ((array) @scandir($dir) as $f)
	{
		if (!preg_match(EVEBB_BACKUP_RE, $f))
			continue;
		$path = $dir.'/'.$f;
		$out[] = array('name' => $f, 'size' => (int) @filesize($path), 'mtime' => (int) @filemtime($path));
	}

	usort($out, function ($a, $b) { return strcmp($b['name'], $a['name']); });
	return $out;
}

//
// Keep the newest $retention backups, delete the rest. Returns the number
// deleted.
//
function evebb_backup_prune($retention)
{
	$retention = max(1, (int) $retention);
	$list = evebb_backup_list();
	$dir = evebb_backup_dir();
	if ($dir === false)
		return 0;

	$deleted = 0;
	for ($i = $retention; $i < count($list); $i++)
	{
		if (@unlink($dir.'/'.$list[$i]['name']))
			$deleted++;
	}
	return $deleted;
}


//
// Record the outcome of the most recent backup attempt.
//
function evebb_backup_record($ok, $file, $status)
{
	evebb_backup_save_conf('o_backup_last_run', (string) time());
	evebb_backup_save_conf('o_backup_last_ok', $ok ? '1' : '0');
	evebb_backup_save_conf('o_backup_last_file', (string) $file);
	evebb_backup_save_conf('o_backup_last_status', (string) $status);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// The sweep: interval-gated backup + prune. $force skips the gate (admin
// "back up now"). Returns array(ok, file, status) or null when the gate held.
//
function evebb_backup_sweep($force = false)
{
	global $db, $pun_config;

	$now = time();
	$interval = max(300, (int) evebb_backup_conf('o_backup_interval', '86400'));
	$last = (int) evebb_backup_conf('o_backup_last_run', '0');

	if (!$force && $now - $last < $interval)
		return null;

	// Claim the slot (compare-and-set on the bootstrapped row).
	if ($force)
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$now.'\' WHERE conf_name=\'o_backup_last_run\'') or error('Unable to stamp backup sweep', __FILE__, __LINE__, $db->error());
	else
	{
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$now.'\' WHERE conf_name=\'o_backup_last_run\' AND conf_value=\''.$db->escape((string) $last).'\'') or error('Unable to claim backup sweep', __FILE__, __LINE__, $db->error());
		if ($db->affected_rows() != 1)
			return null;
	}
	$pun_config['o_backup_last_run'] = (string) $now;
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	list($ok, $file, $status) = evebb_backup_run();
	evebb_backup_record($ok, $file, $status);

	if ($ok)
		evebb_backup_prune(evebb_backup_conf('o_backup_retention', '7'));

	return array($ok, $file, $status);
}
