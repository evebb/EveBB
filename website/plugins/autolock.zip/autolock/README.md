# Auto-lock Stale Topics

An unofficial eveBB plugin that automatically closes topics which have gone
quiet for a set number of days, in the forums you choose.

## How it runs — no cron needed

It uses the **WordPress-style pseudo-cron** model: the sweep is driven by your
board's own traffic. On almost every page view the plugin does nothing but a
cheap in-memory time check; only once your configured interval has elapsed
does one page view actually run a sweep, and it processes a bounded batch so
that request never stalls. A compare-and-set on a config row guarantees only
one visitor's request runs each sweep, even under concurrent traffic.

If you prefer an exact schedule, the admin page has a **Run a sweep now**
button, and this plugin will happily adopt the dedicated task scheduler
planned for eveBB 2.1 when it lands.

## Settings

- **Days** — close topics with no reply for this many days (0 disables the
  plugin entirely).
- **Forums** — restrict to a list of forum IDs, or leave blank for all.
- **Skip stickies** — on by default; sticky topics are never auto-locked.
- **Closing notice** — optionally post a short message on each topic as it is
  locked, attributed to your first administrator account. Off = lock silently.
- **Batch size** — the most topics one sweep will lock (default 50).
- **Interval** — the minimum seconds between sweeps (default 3600 = hourly).

The settings page also shows how many open topics currently match the rule and
when the last sweep ran.

## Notes

- Moved-topic redirects and already-closed topics are left alone.
- Locking a topic only sets its "closed" flag — nothing is deleted, and a
  moderator can reopen any topic normally.
- When the closing notice is enabled, forum post/topic counters are kept
  consistent (the same way a normal reply would).

## Uninstall

This plugin creates **no tables of its own**. Use **Remove all plugin data**
on the settings page to clear its settings (topics already locked stay
locked), then deactivate and delete the plugin.

## License

GPL version 2 or higher — http://www.gnu.org/licenses/gpl.html
