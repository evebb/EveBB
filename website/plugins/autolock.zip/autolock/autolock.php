<?php

/**
 * Auto-lock Stale Topics - the addon.
 *
 * A single hook: header_head_end fires on every page. On first use it
 * bootstraps the plugin's config, then runs the (interval-gated) sweep. The
 * gate check is a cheap in-memory comparison on almost every request; only
 * when the interval has elapsed does a request touch the database, and the
 * compare-and-set claim means just one request per interval does the work.
 *
 * This is the WordPress-style pseudo-cron model: no system cron required,
 * the board's own traffic drives the schedule.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

class plugin_autolock extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'tick'));
	}

	function tick()
	{
		// header.php can be re-included in one request (message()); act once.
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		evebb_autolock_bootstrap();
		evebb_autolock_sweep();
	}
}
