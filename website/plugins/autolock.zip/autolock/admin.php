<?php

/**
 * Auto-lock Stale Topics - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome and inside a single
 * POST form (footer.php injects the CSRF token). $db, $pun_config and
 * $plugin_slug are available.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

evebb_autolock_bootstrap();

$redir = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

if (isset($_POST['save_autolock']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$days = isset($_POST['al_days']) ? (int) $_POST['al_days'] : 60;
	if ($days < 0)
		$days = 0;
	if ($days > 3650)
		$days = 3650;
	evebb_autolock_save_conf('o_autolock_days', (string) $days);

	$batch = isset($_POST['al_batch']) ? (int) $_POST['al_batch'] : 50;
	if ($batch < 1) $batch = 1;
	if ($batch > 500) $batch = 500;
	evebb_autolock_save_conf('o_autolock_batch', (string) $batch);

	$interval = isset($_POST['al_interval']) ? (int) $_POST['al_interval'] : 3600;
	if ($interval < 60) $interval = 60;
	if ($interval > 604800) $interval = 604800;
	evebb_autolock_save_conf('o_autolock_interval', (string) $interval);

	evebb_autolock_save_conf('o_autolock_exclude_sticky', isset($_POST['al_exclude_sticky']) ? '1' : '0');
	evebb_autolock_save_conf('o_autolock_notice', isset($_POST['al_notice']) ? '1' : '0');

	$text = pun_trim($_POST['al_notice_text'] ?? '');
	if (pun_strlen($text) > 1000)
		$text = pun_substr($text, 0, 1000);
	evebb_autolock_save_conf('o_autolock_notice_text', $text);

	$forums_raw = pun_trim($_POST['al_forums'] ?? '');
	$forum_ids = array();
	foreach (explode(',', $forums_raw) as $part)
	{
		$part = (int) trim($part);
		if ($part > 0 && !in_array($part, $forum_ids))
			$forum_ids[] = $part;
	}
	evebb_autolock_save_conf('o_autolock_forums', implode(',', $forum_ids));

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect($redir, 'Settings saved. Redirecting …');
}

if (isset($_POST['run_autolock']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$n = evebb_autolock_sweep(true);
	redirect($redir, $n.' topic(s) locked. Redirecting …');
}

if (isset($_POST['nuke_autolock']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name LIKE \'o_autolock_%\'') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());
	foreach (array_keys($pun_config) as $k)
		if (strpos($k, 'o_autolock_') === 0)
			unset($pun_config[$k]);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Auto-lock data removed. You can now deactivate and delete the plugin. Redirecting …');
}

$days           = (int) evebb_autolock_conf('o_autolock_days', '60');
$forums         = evebb_autolock_conf('o_autolock_forums', '');
$exclude_sticky = evebb_autolock_conf('o_autolock_exclude_sticky', '1') == '1';
$notice         = evebb_autolock_conf('o_autolock_notice', '0') == '1';
$notice_text    = evebb_autolock_conf('o_autolock_notice_text', '');
$batch          = (int) evebb_autolock_conf('o_autolock_batch', '50');
$interval       = (int) evebb_autolock_conf('o_autolock_interval', '3600');
$last_run       = (int) evebb_autolock_conf('o_autolock_last_run', '0');

// How many open topics currently match the rule?
$pending = 0;
if ($days >= 1)
{
	$cutoff = time() - $days * 86400;
	$where = 'closed=0 AND moved_to IS NULL AND last_post>0 AND last_post<'.$cutoff;
	if ($exclude_sticky)
		$where .= ' AND sticky=0';
	if (trim($forums) !== '')
	{
		$ids = array_filter(array_map('intval', explode(',', $forums)), function ($v) { return $v > 0; });
		if (!empty($ids))
			$where .= ' AND forum_id IN ('.implode(',', $ids).')';
	}
	$r = $db->query('SELECT COUNT(*) FROM '.$db->prefix.'topics WHERE '.$where) or error('Unable to count stale topics', __FILE__, __LINE__, $db->error());
	$pending = (int) $db->result($r);
}

$result = $db->query('SELECT f.id, f.forum_name, c.cat_name FROM '.$db->prefix.'forums AS f INNER JOIN '.$db->prefix.'categories AS c ON c.id=f.cat_id ORDER BY c.disp_position, c.id, f.disp_position') or error('Unable to fetch forum list', __FILE__, __LINE__, $db->error());
$forum_list = array();
while ($cur = $db->fetch_assoc($result))
	$forum_list[] = $cur;

?>
		<div class="inform">
			<fieldset>
				<legend>Auto-lock settings</legend>
				<div class="infldset">
					<p>Topics with no new post for the chosen number of days are closed automatically. The check runs as an occasional page-view sweep &mdash; no system cron needed &mdash; processing a small batch each time.</p>
					<p><strong><?php echo $pending ?></strong> open topic(s) currently match the rule. Last sweep: <?php echo $last_run > 0 ? pun_htmlspecialchars(format_time($last_run)) : 'never'; ?>.</p>
					<label>Close topics with no reply for this many days (0 disables auto-locking)
						<br /><input type="text" name="al_days" size="6" maxlength="4" value="<?php echo $days ?>" />
					</label>
					<label><input type="checkbox" name="al_exclude_sticky" value="1"<?php if ($exclude_sticky) echo ' checked="checked"' ?> /> Never auto-lock sticky topics</label>
					<label>Only in these forums (comma-separated forum IDs; leave blank for all forums)
						<br /><input type="text" name="al_forums" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($forums) ?>" />
					</label>
<?php if (count($forum_list)): ?>
					<p>For reference, your forums are:</p>
					<ul>
<?php foreach ($forum_list as $cur): ?>
						<li><span><strong><?php echo (int) $cur['id'] ?></strong> &mdash; <?php echo pun_htmlspecialchars($cur['cat_name']) ?> / <?php echo pun_htmlspecialchars($cur['forum_name']) ?></span></li>
<?php endforeach; ?>
					</ul>
<?php endif; ?>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Closing notice</legend>
				<div class="infldset">
					<label><input type="checkbox" name="al_notice" value="1"<?php if ($notice) echo ' checked="checked"' ?> /> Post a short closing notice on each topic as it is locked (attributed to the first administrator account)</label>
					<label>Closing notice text
						<br /><textarea name="al_notice_text" rows="3" cols="60"><?php echo pun_htmlspecialchars($notice_text) ?></textarea>
					</label>
					<p>Leaving the notice off simply locks the topic silently.</p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Sweep tuning</legend>
				<div class="infldset">
					<label>Maximum topics to lock per sweep (1&ndash;500)
						<br /><input type="text" name="al_batch" size="6" maxlength="3" value="<?php echo $batch ?>" />
					</label>
					<label>Minimum seconds between sweeps (60&ndash;604800)
						<br /><input type="text" name="al_interval" size="8" maxlength="6" value="<?php echo $interval ?>" />
					</label>
					<p class="topspace"><input type="submit" name="save_autolock" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Run now</legend>
				<div class="infldset">
					<p>Process one batch immediately (ignores the interval), useful for a first pass over a backlog.</p>
					<p><input type="submit" name="run_autolock" value="Run a sweep now" /></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Uninstall</legend>
				<div class="infldset">
					<p>This plugin stores no tables of its own &mdash; it only sets a few config values and closes core topics. Removing the data below clears those settings (already-locked topics stay locked). Then deactivate and delete the plugin.</p>
					<p><input type="submit" name="nuke_autolock" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
