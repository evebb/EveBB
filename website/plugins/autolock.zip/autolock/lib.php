<?php

/**
 * Auto-lock Stale Topics - shared library.
 *
 * Config bootstrap, helpers, and the sweep itself. The sweep is a
 * WordPress-style pseudo-cron: it is invoked on ordinary page views and
 * gated to run at most once per configured interval, claiming its slot with
 * a compare-and-set on the o_autolock_last_run config row so concurrent
 * requests never double-run it.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


function evebb_autolock_conf($name, $default)
{
	global $pun_config;
	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}

function evebb_autolock_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


//
// One-time config bootstrap (no tables needed - the plugin acts on the core
// topics table). Guarded by o_autolock_db_rev. The o_autolock_last_run row
// is created here because the sweep's compare-and-set depends on it existing.
//
function evebb_autolock_bootstrap()
{
	global $db, $pun_config;

	if (isset($pun_config['o_autolock_db_rev']))
		return;

	$defaults = array(
		'o_autolock_days'           => '60',
		'o_autolock_forums'         => '',
		'o_autolock_exclude_sticky' => '1',
		'o_autolock_notice'         => '0',
		'o_autolock_notice_text'    => 'This topic has been automatically closed after a long period of inactivity. If you have something to add, please start a new topic or contact a moderator.',
		'o_autolock_batch'          => '50',
		'o_autolock_interval'       => '3600',
		'o_autolock_last_run'       => '0'
	);
	foreach ($defaults as $name => $value)
	{
		if (!isset($pun_config[$name]))
			$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')');
		$pun_config[$name] = isset($pun_config[$name]) ? $pun_config[$name] : $value;
	}

	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_autolock_db_rev\', \'1\')');
	$pun_config['o_autolock_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Is a forum in scope? o_autolock_forums is a comma list of ids; blank = all.
//
function evebb_autolock_forum_enabled($forum_id)
{
	$list = trim(evebb_autolock_conf('o_autolock_forums', ''));
	if ($list === '')
		return true;
	return in_array((int) $forum_id, array_map('intval', explode(',', $list)), true);
}


//
// The sweep. Locks up to o_autolock_batch stale topics and (optionally)
// leaves a closing notice on each. $force skips the interval gate (used by
// the admin "run now" button). Returns the number of topics locked.
//
function evebb_autolock_sweep($force = false)
{
	global $db, $pun_config;

	$days = (int) evebb_autolock_conf('o_autolock_days', '60');
	if ($days < 1)
		return 0; // disabled

	$now = time();
	$interval = max(60, (int) evebb_autolock_conf('o_autolock_interval', '3600'));
	$last = (int) evebb_autolock_conf('o_autolock_last_run', '0');

	if (!$force && $now - $last < $interval)
		return 0;

	// Claim the slot (compare-and-set). The row is bootstrapped, so this is
	// always an UPDATE; the loser of a race simply skips.
	if ($force)
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$now.'\' WHERE conf_name=\'o_autolock_last_run\'') or error('Unable to stamp autolock sweep', __FILE__, __LINE__, $db->error());
	else
	{
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$now.'\' WHERE conf_name=\'o_autolock_last_run\' AND conf_value=\''.$db->escape((string) $last).'\'') or error('Unable to claim autolock sweep', __FILE__, __LINE__, $db->error());
		if ($db->affected_rows() != 1)
			return 0;
	}
	$pun_config['o_autolock_last_run'] = (string) $now;
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	$cutoff = $now - $days * 86400;
	$batch = max(1, min(500, (int) evebb_autolock_conf('o_autolock_batch', '50')));

	$where = 'closed=0 AND moved_to IS NULL AND last_post>0 AND last_post<'.$cutoff;
	if (evebb_autolock_conf('o_autolock_exclude_sticky', '1') == '1')
		$where .= ' AND sticky=0';

	$forums = trim(evebb_autolock_conf('o_autolock_forums', ''));
	if ($forums !== '')
	{
		$ids = array_filter(array_map('intval', explode(',', $forums)), function ($v) { return $v > 0; });
		if (empty($ids))
			return 0;
		$where .= ' AND forum_id IN ('.implode(',', $ids).')';
	}

	$result = $db->query('SELECT id, forum_id, subject FROM '.$db->prefix.'topics WHERE '.$where.' ORDER BY id LIMIT '.$batch) or error('Unable to fetch stale topics', __FILE__, __LINE__, $db->error());

	$topics = array();
	while ($row = $db->fetch_assoc($result))
		$topics[] = $row;

	if (empty($topics))
		return 0;

	$notice = evebb_autolock_conf('o_autolock_notice', '0') == '1';
	$poster = null;
	if ($notice)
	{
		$r = $db->query('SELECT id, username FROM '.$db->prefix.'users WHERE group_id='.PUN_ADMIN.' ORDER BY id LIMIT 1') or error('Unable to find an administrator', __FILE__, __LINE__, $db->error());
		if ($db->has_rows($r))
			$poster = $db->fetch_assoc($r);
		else
			$notice = false; // no admin to attribute the notice to; lock only
	}

	$locked_ids = array();
	$touched_forums = array();

	if ($notice)
	{
		require_once PUN_ROOT.'include/search_idx.php';
		$message = pun_trim((string) evebb_autolock_conf('o_autolock_notice_text', ''));
		if ($message === '')
			$message = 'This topic has been automatically closed after a long period of inactivity.';

		foreach ($topics as $t)
		{
			$tid = (int) $t['id'];

			$db->query('INSERT INTO '.$db->prefix.'posts (poster, poster_id, poster_ip, message, hide_smilies, posted, topic_id) VALUES(\''.$db->escape($poster['username']).'\', '.(int) $poster['id'].', \'127.0.0.1\', \''.$db->escape($message).'\', 0, '.$now.', '.$tid.')') or error('Unable to post closing notice', __FILE__, __LINE__, $db->error());
			$new_pid = (int) $db->insert_id();

			$db->query('UPDATE '.$db->prefix.'topics SET num_replies=num_replies+1, last_post='.$now.', last_post_id='.$new_pid.', last_poster=\''.$db->escape($poster['username']).'\', closed=1 WHERE id='.$tid) or error('Unable to lock topic', __FILE__, __LINE__, $db->error());

			update_search_index('post', $new_pid, $message);

			$locked_ids[] = $tid;
			$touched_forums[(int) $t['forum_id']] = true;
		}
	}
	else
	{
		foreach ($topics as $t)
		{
			$locked_ids[] = (int) $t['id'];
			$touched_forums[(int) $t['forum_id']] = true;
		}
		$db->query('UPDATE '.$db->prefix.'topics SET closed=1 WHERE id IN ('.implode(',', $locked_ids).')') or error('Unable to lock topics', __FILE__, __LINE__, $db->error());
	}

	// Keep forum last-post/counters consistent when a notice was posted
	foreach (array_keys($touched_forums) as $fid)
		update_forum($fid);

	return count($locked_ids);
}
