# Social Sign-in

An unofficial eveBB plugin that adds **Sign in with Google / Discord /
Microsoft / GitHub** buttons to the login and registration pages. Configure
only the providers you want — unconfigured ones simply don't appear. It works
*alongside* the normal password login rather than replacing it.

## What it does

- New visitors sign in with a provider and get a forum account created from
  their profile — username from the account's name (deconflicted if taken),
  email from a **verified** address the provider vouches for.
- If the provider gives no usable verified email, the visitor confirms one
  before the account is created.
- Existing members can be matched automatically: if one of the provider
  account's **verified** emails equals a member's forum email, the sign-in is
  linked to that account and logs them in. (Optional — can be turned off.)
- Returning users are recognised by their provider account id and logged
  straight in. A member can hold one link per provider — Google *and*
  Discord at once, for example.

## Setup

Every provider uses the **same callback URL**, shown on the plugin's settings
page:

```
https://your-board/plugins/socialauth/auth.php
```

Create an OAuth app with each provider you want, set that callback URL, and
paste the Client ID + Secret into the settings page:

| Provider  | Where to create the app |
|-----------|-------------------------|
| Google    | Google Cloud Console → APIs & Services → Credentials → OAuth client ID (Web application) |
| Discord   | Discord Developer Portal → New Application → OAuth2 |
| Microsoft | Microsoft Entra admin center → App registrations → New registration (any-org + personal accounts) |
| GitHub    | GitHub → Settings → Developer settings → OAuth Apps → New OAuth App |

All scopes requested are read-only profile + email.

## Security

- The OAuth `state` parameter is an HMAC-signed token (keyed with the board's
  cookie seed) *and* cross-checked against a short-lived nonce cookie, so a
  forged or replayed callback is rejected. The provider identity also rides
  inside the signed state — it cannot be swapped.
- Only **verified** emails are ever used to match or create accounts. Google's
  `email_verified` flag and Discord's `verified` flag are honoured; GitHub's
  per-address verified list is filtered; a Microsoft account's email is the
  account credential itself.
- Accounts created through a provider get a random, unusable password. A
  member who also wants a password login can set one through the normal
  "forgotten password" flow.

## Note for boards using the GitHub Sign-in plugin

This plugin includes GitHub as a provider, so new boards only need this one.
The standalone `githubauth` plugin keeps working — but don't run both with
GitHub configured in each, or the login page will show two GitHub buttons.
(Links made by the standalone plugin live in its own table and are not
migrated automatically.)

## Uninstall

Use **Remove all plugin data** on the settings page (drops the
`socialauth_users` link table — the forum accounts themselves are untouched —
and this plugin's settings), then deactivate and delete the plugin.

## License

GPL version 2 or higher — http://www.gnu.org/licenses/gpl.html
