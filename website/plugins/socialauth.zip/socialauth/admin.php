<?php

/**
 * Social Sign-in - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome and inside a single
 * POST form (footer.php injects the CSRF token). $db, $pun_config and
 * $plugin_slug are available.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

evebb_socialauth_bootstrap();

$redir = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;
$providers = evebb_socialauth_providers();

if (isset($_POST['save_socialauth']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	foreach ($providers as $key => $p)
	{
		evebb_socialauth_save_config('o_socialauth_'.$key.'_id', pun_trim($_POST['sa_'.$key.'_id'] ?? ''));
		evebb_socialauth_save_config('o_socialauth_'.$key.'_secret', pun_trim($_POST['sa_'.$key.'_secret'] ?? ''));
	}
	evebb_socialauth_save_config('o_socialauth_link_by_email', isset($_POST['sa_link_by_email']) ? '1' : '0');

	redirect($redir, 'Settings saved. Redirecting …');
}

if (isset($_POST['nuke_socialauth']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect($redir, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('socialauth_users');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name LIKE \'o_socialauth_%\'') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());
	foreach (array_keys($pun_config) as $k)
		if (strpos($k, 'o_socialauth_') === 0)
			unset($pun_config[$k]);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Social Sign-in data removed. You can now deactivate and delete the plugin. Redirecting …');
}

$link_by_email = evebb_socialauth_conf('o_socialauth_link_by_email', '1') == '1';
$callback = evebb_socialauth_callback_url();

// Linked-account counts per provider
$counts = array();
$result = $db->query('SELECT provider, COUNT(*) AS n FROM '.$db->prefix.'socialauth_users GROUP BY provider') or error('Unable to count linked accounts', __FILE__, __LINE__, $db->error());
while ($row = $db->fetch_assoc($result))
	$counts[$row['provider']] = (int) $row['n'];

?>
		<div class="inform">
			<fieldset>
				<legend>Callback URL (the same for every provider)</legend>
				<div class="infldset">
					<p>When creating each provider's OAuth application, set its redirect / callback URL to exactly:</p>
					<p><code><?php echo pun_htmlspecialchars($callback) ?></code></p>
					<p>Only providers with both a Client ID and a Client Secret filled in are offered to visitors — configure as many or as few as you like.</p>
				</div>
			</fieldset>
		</div>

<?php foreach ($providers as $key => $p): ?>
		<div class="inform">
			<fieldset>
				<legend><?php echo pun_htmlspecialchars($p['label']) ?><?php if (evebb_socialauth_configured($key)) echo ' — active'; ?></legend>
				<div class="infldset">
					<p>Create the app at: <?php echo $p['setup'] /* trusted static string, contains an entity */ ?>.</p>
					<label>Client ID<br /><input type="text" name="sa_<?php echo $key ?>_id" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars(evebb_socialauth_conf('o_socialauth_'.$key.'_id', '')) ?>" /></label>
					<label>Client Secret<br /><input type="text" name="sa_<?php echo $key ?>_secret" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars(evebb_socialauth_conf('o_socialauth_'.$key.'_secret', '')) ?>" /></label>
					<p>Linked accounts: <strong><?php echo isset($counts[$key]) ? $counts[$key] : 0 ?></strong></p>
				</div>
			</fieldset>
		</div>
<?php endforeach; ?>

		<div class="inform">
			<fieldset>
				<legend>Account matching</legend>
				<div class="infldset">
					<label><input type="checkbox" name="sa_link_by_email" value="1"<?php if ($link_by_email) echo ' checked="checked"' ?> /> Link a sign-in to an existing member when one of the provider account's <em>verified</em> email addresses matches that member's email</label>
					<p>With this off, sign-ins only ever log in accounts already linked, or create brand-new ones. Only email addresses the provider has verified are ever used for matching. A member can hold one link per provider (e.g. Google AND Discord at once).</p>
					<p class="topspace"><input type="submit" name="save_socialauth" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>How it works</legend>
				<div class="infldset">
					<p>New sign-ins take the provider account's name as the forum username (deconflicted if taken) and a verified email as the account email. If the provider gives no usable verified email, the visitor confirms one before the account is created. Accounts made this way get a random unusable password; members who also want a password login can set one through the normal &quot;forgotten password&quot; flow. The classic password form always remains available.</p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Uninstall</legend>
				<div class="infldset">
					<p>To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the socialauth_users table (the account links, not the accounts) and this plugin's settings.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently removes all provider account links</label></p>
					<p><input type="submit" name="nuke_socialauth" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
