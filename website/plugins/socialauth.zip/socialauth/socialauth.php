<?php

/**
 * Social Sign-in - the addon.
 *
 * Adds a "Sign in with ..." panel (one button per configured provider) to
 * the login and registration pages, guests only, leaving the normal
 * password form in place as an equal option. The OAuth flow itself lives
 * in auth.php (the shared callback URL).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_socialauth extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		global $pun_user;

		// message() re-includes header.php - never run twice
		static $busy;
		if ($busy)
			return;
		$busy = true;

		require_once dirname(__FILE__).'/lib.php';

		evebb_socialauth_bootstrap();

		$active = evebb_socialauth_active_providers();

		if (!empty($active) && $pun_user['is_guest'])
		{
			$page = basename($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '');
			if ($page == 'login.php')
				$this->inject($active, '#login', 'Sign in with one of these accounts, or use the password form below.', 'login', true);
			else if ($page == 'register.php')
				$this->inject($active, '#regform', 'Create your account by signing in with one of these - no separate password needed. You can also register with the form below.', 'register', false);
		}

		$busy = false;
	}

	//
	// Emit a script that builds the provider-button panel at the top of the
	// target form's box. All dynamic strings go through json_encode; the DOM
	// is built with createElement.
	//
	function inject($active, $host_selector, $blurb, $intent, $inside_login)
	{
		$providers = evebb_socialauth_providers();
		$callback = evebb_socialauth_callback_url();

		$buttons = array();
		foreach ($active as $key)
		{
			$buttons[] = array(
				'go'    => $callback.'?a=go&p='.$key.'&intent='.$intent,
				'label' => 'Sign in with '.$providers[$key]['label'],
				'color' => $providers[$key]['color']
			);
		}

		$data = array('blurb' => $blurb, 'buttons' => $buttons);

		echo '<script>/* Social Sign-in */'."\n"
			.'document.addEventListener("DOMContentLoaded",function(){'
			.'var d='.json_encode($data, JSON_UNESCAPED_SLASHES).';'
			.'var host=document.querySelector('.json_encode($host_selector).');if(!host)return;'
			.'var box=host.querySelector(".box")||host;'
			.'var wrap=document.createElement("div");wrap.className="inform";'
			.'var fs=document.createElement("fieldset");'
			.'var lg=document.createElement("legend");lg.textContent="Quick sign-in";fs.appendChild(lg);'
			.'var inner=document.createElement("div");inner.className="infldset";'
			.'var p=document.createElement("p");p.textContent=d.blurb;inner.appendChild(p);'
			.'var row=document.createElement("p");row.style.cssText="clear:both;";'
			.'for(var i=0;i<d.buttons.length;i++){(function(b){'
			.'var a=document.createElement("a");a.href=b.go;a.textContent=b.label;'
			.'a.style.cssText="display:inline-block;margin:6px 8px 4px 0;padding:9px 16px;background:"+b.color+";color:#fff;border:1px solid rgba(0,0,0,.25);border-radius:6px;font-weight:bold;text-decoration:none;";'
			.'row.appendChild(a);'
			.'})(d.buttons[i]);}'
			.'inner.appendChild(row);'
			.'fs.appendChild(inner);wrap.appendChild(fs);'
			.($inside_login
				? 'var f=host.querySelector("form");if(f){f.insertBefore(wrap,f.firstChild);}else{box.insertBefore(wrap,box.firstChild);}'
				: 'box.insertBefore(wrap,box.firstChild);')
			.'});</script>'."\n";
	}
}
