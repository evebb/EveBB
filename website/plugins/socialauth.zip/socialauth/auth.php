<?php

/**
 * Social Sign-in - the OAuth endpoint.
 *
 * ONE callback URL serves every provider:
 *   <board>/plugins/socialauth/auth.php
 * Register that exact URL with each provider you configure.
 *
 * Actions:
 *   ?a=go&p=<provider>   redirect the guest to the provider's authorize page
 *   ?code=...&state=...  OAuth callback - the provider key rides inside the
 *                        sealed state; linked accounts log in, verified-email
 *                        matches are linked and logged in, otherwise a new
 *                        account is created (an email is requested first when
 *                        the provider gave no usable verified address)
 *   ?a=create            POST from the email confirmation form
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

//
// This page lives under plugins/socialauth/ but the forum chrome links its
// assets relative to the forum root - absolutize on the way out.
//
function socialauth_absolutize($html)
{
	$base = get_base_url().'/';
	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('socialauth_absolutize');

if (!in_array('socialauth', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

evebb_socialauth_bootstrap();

if (!$pun_user['is_guest'])
{
	$db->end_transaction();
	header('Location: '.get_base_url().'/index.php');
	exit;
}

$action = isset($_GET['a']) ? $_GET['a'] : null;


// ---------------------------------------------------------------------------
// go: hand the guest to the chosen provider
// ---------------------------------------------------------------------------
if ($action == 'go')
{
	$provider = evebb_socialauth_provider($_GET['p'] ?? null);
	if ($provider === null || !evebb_socialauth_configured($provider))
		message('This sign-in provider is not available on this board.');

	$intent = (isset($_GET['intent']) && $_GET['intent'] == 'login') ? 'login' : 'register';
	$url = evebb_socialauth_authorize_url($provider, $intent);

	$db->end_transaction();
	header('Location: '.$url);
	exit;
}


// ---------------------------------------------------------------------------
// create: POST from the email confirmation form
// ---------------------------------------------------------------------------
else if ($action == 'create')
{
	if (!isset($_POST['form_sent']))
		message($lang_common['Bad request'], false, '404 Not Found');

	check_csrf($_POST['csrf_token'] ?? null);

	$ident = evebb_socialauth_unseal($_POST['socialauth_tok'] ?? '');
	if ($ident === false || empty($ident['provider']) || empty($ident['id']) || evebb_socialauth_provider($ident['provider']) === null)
		message('Your sign-in has expired. Please start again from the <a href="'.pun_htmlspecialchars(get_base_url().'/login.php').'">login page</a>.');

	// They may have completed sign-in in another tab meanwhile
	$existing = evebb_socialauth_user_by_ext($ident['provider'], $ident['id']);
	if ($existing !== null)
	{
		evebb_socialauth_login_user($existing);
		redirect('index.php', $lang_common['Redirecting']);
	}

	$result = evebb_socialauth_create_user($ident, $_POST['req_email'] ?? '');

	if (is_int($result))
	{
		$new_user = evebb_socialauth_user_by_ext($ident['provider'], $ident['id']);
		if ($new_user !== null)
			evebb_socialauth_login_user($new_user);

		redirect('index.php', 'Welcome to '.pun_htmlspecialchars($pun_config['o_board_title']).'. Registration complete.');
	}

	$errmap = array(
		'closed'       => 'This board is not accepting new registrations at the moment.',
		'email'        => 'The email address you entered is invalid.',
		'banned_email' => 'The email address you entered is not allowed on this board.',
		'dupe_email'   => 'Someone has already registered with that email address.',
		'username'     => 'A usable username could not be derived from your account. Please contact the board administrator.'
	);
	$socialauth_error = isset($errmap[$result]) ? $errmap[$result] : 'Registration failed. Please try again.';

	if ($result == 'closed' || $result == 'username')
		message($socialauth_error);

	// Re-render the form
	$socialauth_ident = $ident;
	$socialauth_tok = evebb_socialauth_seal(array_diff_key($ident, array('_t' => 1)));
	$socialauth_email = pun_trim($_POST['req_email'] ?? '');
}


// ---------------------------------------------------------------------------
// callback: ?code=...&state=...
// ---------------------------------------------------------------------------
else if (isset($_GET['code']))
{
	$state = evebb_socialauth_unseal($_GET['state'] ?? '', 900);
	if ($state === false || empty($state['n']) || empty($state['p']) || !isset($_COOKIE['socialauth_state']) || !hash_equals($state['n'], (string) $_COOKIE['socialauth_state']))
		message('Your sign-in could not be verified (the state check failed). Please try again from the <a href="'.pun_htmlspecialchars(get_base_url().'/login.php').'">login page</a>.');

	forum_setcookie('socialauth_state', '', 1); // spend the nonce

	$provider = evebb_socialauth_provider($state['p']);
	if ($provider === null || !evebb_socialauth_configured($provider))
		message('This sign-in provider is not available on this board.');

	$token = evebb_socialauth_exchange_code($provider, $_GET['code']);
	if ($token === false)
		message(evebb_socialauth_providers()[$provider]['label'].' did not confirm your sign-in. Please try again in a moment.');

	$ident = evebb_socialauth_identity($provider, $token);
	if ($ident === false)
		message('Could not read your '.evebb_socialauth_providers()[$provider]['label'].' profile. Please try again in a moment.');

	// 1) Already linked -> log in.
	$existing = evebb_socialauth_user_by_ext($provider, $ident['id']);
	if ($existing !== null)
	{
		evebb_socialauth_login_user($existing);
		redirect('index.php', $lang_common['Redirecting']);
	}

	// 2) Match an existing account by a verified email (opt-out setting).
	if (evebb_socialauth_conf('o_socialauth_link_by_email', '1') == '1' && !empty($ident['verified_emails']))
	{
		foreach ($ident['verified_emails'] as $addr)
		{
			$match = evebb_socialauth_user_by_email($provider, $addr);
			if ($match !== null)
			{
				evebb_socialauth_link($match['id'], $ident);
				evebb_socialauth_login_user($match);
				redirect('index.php', 'Your '.evebb_socialauth_providers()[$provider]['label'].' account has been linked. '.$lang_common['Redirecting']);
			}
		}
	}

	// 3) New account.
	if ($pun_config['o_regs_allow'] == '0')
		message('This board is not accepting new registrations at the moment.');

	if ($ident['email'] !== '')
	{
		$result = evebb_socialauth_create_user($ident, $ident['email']);
		if (is_int($result))
		{
			$new_user = evebb_socialauth_user_by_ext($provider, $ident['id']);
			if ($new_user !== null)
				evebb_socialauth_login_user($new_user);
			redirect('index.php', 'Welcome to '.pun_htmlspecialchars($pun_config['o_board_title']).'. Registration complete.');
		}
		$socialauth_prefill_error = ($result == 'dupe_email') ? 'An account already uses that email address. Enter a different address to finish, or contact the administrator to link your existing account.' : null;
	}

	$socialauth_ident = $ident;
	$socialauth_tok = evebb_socialauth_seal($ident);
	$socialauth_email = ($ident['email'] !== '' && empty($socialauth_prefill_error)) ? $ident['email'] : '';
	$socialauth_error = isset($socialauth_prefill_error) ? $socialauth_prefill_error : null;
}

else
{
	$db->end_transaction();
	header('Location: '.get_base_url().'/login.php');
	exit;
}


// ---------------------------------------------------------------------------
// Render the email confirmation form
// ---------------------------------------------------------------------------
$provider_label = evebb_socialauth_providers()[$socialauth_ident['provider']]['label'];

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), $provider_label.' registration');
$required_fields = array('req_email' => $lang_common['Email']);
$focus_element = array('socialauth_confirm', 'req_email');

define('PUN_ACTIVE_PAGE', 'register');
require PUN_ROOT.'header.php';

$avatar = $socialauth_ident['avatar_url'];
$display = pun_trim($socialauth_ident['login']) !== '' ? $socialauth_ident['login'] : $socialauth_ident['name'];

if (!empty($socialauth_error))
{
?>
<div id="posterror" class="block">
	<h2><span>Registration errors</span></h2>
	<div class="box">
		<div class="inbox error-info">
			<ul class="error-list">
				<li><strong><?php echo $socialauth_error ?></strong></li>
			</ul>
		</div>
	</div>
</div>
<?php
}
?>
<div id="regform" class="blockform">
	<h2><span><?php echo pun_htmlspecialchars($provider_label) ?> registration</span></h2>
	<div class="box">
		<form id="socialauth_confirm" method="post" action="<?php echo pun_htmlspecialchars(evebb_socialauth_callback_url()) ?>?a=create" onsubmit="return process_form(this)">
			<div class="inform">
				<div class="forminfo">
					<h3>Account verified</h3>
					<p>You have signed in with <?php echo pun_htmlspecialchars($provider_label) ?> as the account below. Confirm an email address to finish creating your forum account.</p>
				</div>
				<fieldset>
					<legend>Your <?php echo pun_htmlspecialchars($provider_label) ?> account</legend>
					<div class="infldset">
						<input type="hidden" name="form_sent" value="1" />
						<input type="hidden" name="socialauth_tok" value="<?php echo pun_htmlspecialchars($socialauth_tok) ?>" />
						<p id="socialauth-acct">
							<?php if ($avatar != ''): ?><img src="<?php echo pun_htmlspecialchars($avatar) ?>" width="64" height="64" alt="" style="float: left; margin: 0 12px 8px 0; border-radius: 4px;" /><?php endif; ?>
							<strong><?php echo pun_htmlspecialchars($display) ?></strong>
							<?php if ($socialauth_ident['name'] != '' && $socialauth_ident['name'] != $display): ?><br /><?php echo pun_htmlspecialchars($socialauth_ident['name']) ?><?php endif; ?>
						</p>
						<p class="clearb">Your forum username will be based on this account's name.</p>
					</div>
				</fieldset>
			</div>
			<div class="inform">
				<fieldset>
					<legend>Enter a valid email address</legend>
					<div class="infldset">
						<p>The board uses your email only for password recovery and any notifications you opt into. It is never shown publicly.</p>
						<label class="required"><strong><?php echo $lang_common['Email'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br />
						<input type="text" name="req_email" value="<?php echo pun_htmlspecialchars($socialauth_email) ?>" size="50" maxlength="80" /><br /></label>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="register" value="Complete registration" /></p>
		</form>
	</div>
</div>
<?php

require PUN_ROOT.'footer.php';
