<?php

/**
 * Cookie Consent - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome (and inside a POST
 * form that footer.php injects the CSRF token into). $db, $pun_config and
 * $plugin_slug are available here.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

// Save settings
if (isset($_POST['save_cconsent']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$mode = (isset($_POST['cconsent_mode']) && $_POST['cconsent_mode'] == 'consent') ? 'consent' : 'notice';
	$message = pun_trim($_POST['cconsent_message'] ?? '');
	if ($message == '')
		$message = 'This forum stores cookies on your device to keep you logged in and remember your preferences. Optional cookies (such as analytics) are only set with your permission.';

	// The policy link may be absolute (http/https) or board-relative
	$url = pun_trim($_POST['cconsent_url'] ?? '');
	if ($url != '' && preg_match('%^(https?://|[a-z0-9_\-]+\.php)%i', $url) !== 1)
		$url = '';

	evebb_cconsent_save_conf('o_cconsent_mode', $mode);
	evebb_cconsent_save_conf('o_cconsent_message', $message);
	evebb_cconsent_save_conf('o_cconsent_url', $url);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}

// Bump the policy version: every visitor is asked again
if (isset($_POST['bump_cconsent']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$ver = intval(evebb_cconsent_conf('o_cconsent_ver', '1')) + 1;
	evebb_cconsent_save_conf('o_cconsent_ver', (string) $ver);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Policy version bumped - everyone will be asked again. Redirecting …');
}

$cconsent_mode    = evebb_cconsent_conf('o_cconsent_mode', 'notice');
$cconsent_message = evebb_cconsent_conf('o_cconsent_message', 'This forum stores cookies on your device to keep you logged in and remember your preferences. Optional cookies (such as analytics) are only set with your permission.');
$cconsent_url     = evebb_cconsent_conf('o_cconsent_url', '');
$cconsent_ver     = intval(evebb_cconsent_conf('o_cconsent_ver', '1'));

$ga_active = function_exists('evebb_plugin_is_active') && evebb_plugin_is_active('ganalytics');

?>
		<div class="inform">
			<fieldset>
				<legend>Cookie Consent settings</legend>
				<div class="infldset">
					<p>The banner is shown once per visitor (per policy version) and their choice is kept in a cookie for a year. eveBB itself only sets functional cookies (login session, tracked topics), which do not require consent.</p>
					<label><input type="radio" name="cconsent_mode" value="notice"<?php if ($cconsent_mode != 'consent') echo ' checked="checked"' ?> /> <strong>Notice</strong> — informational bar with an OK button. Right when the board sets functional cookies only.</label>
					<label><input type="radio" name="cconsent_mode" value="consent"<?php if ($cconsent_mode == 'consent') echo ' checked="checked"' ?> /> <strong>Consent</strong> — Accept all / Essential only choice, plus a permanent “Cookie preferences” footer link. Required when optional cookies (e.g. the Google Analytics plugin) are in use. Plugins that respect the choice will not set optional cookies without an “Accept all”.</label>
<?php if ($ga_active && $cconsent_mode != 'consent'): ?>
					<p><strong>Note:</strong> the Google Analytics plugin is active. In notice mode its cookies are set without asking — switch to consent mode to comply with UK PECR / GDPR-style rules.</p>
<?php endif; ?>
					<label>Banner message
						<br /><textarea name="cconsent_message" rows="3" cols="70"><?php echo pun_htmlspecialchars($cconsent_message) ?></textarea>
					</label>
					<label>Privacy/cookie policy link (optional; absolute URL or a board page like <code>misc.php?action=rules</code>)
						<br /><input type="text" name="cconsent_url" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($cconsent_url) ?>" />
					</label>
					<p class="topspace"><input type="submit" name="save_cconsent" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Re-ask everyone</legend>
				<div class="infldset">
					<p>Current policy version: <strong><?php echo $cconsent_ver ?></strong>. If your cookie usage changes (say, you enable analytics), bump the version and every visitor sees the banner again, regardless of an earlier choice.</p>
					<p><input type="submit" name="bump_cconsent" value="Bump policy version" /></p>
				</div>
			</fieldset>
		</div>
<?php
