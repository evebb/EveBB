# Cookie Consent — official eveBB plugin

Shows a cookie banner to visitors who haven't yet made a choice. Two modes:

- **Notice** (default): an informational bar with an OK button. The right
  choice when the board only sets eveBB's own functional cookies (login
  session, tracked topics) — those don't require consent.
- **Consent**: an *Accept all / Essential only* choice, plus a permanent
  "Cookie preferences" link in the board footer so visitors can change
  their mind at any time. Use this whenever optional cookies are in play —
  for example the Google Analytics plugin.

The choice is stored client-side in the `evebb_consent` cookie for one
year, tagged with a policy version. Bumping the version from the settings
page re-asks every visitor — do that whenever your cookie usage changes.

## Installation

1. Administration → Plugins → upload `cookieconsent.zip`.
2. Activate **Cookie Consent**.
3. Open **Settings**: pick the mode, adjust the banner text, and (ideally)
   link your privacy/cookie policy — an absolute URL or a board page such
   as `misc.php?action=rules`.

No database changes; everything lives in board config values
(`o_cconsent_mode`, `o_cconsent_message`, `o_cconsent_url`,
`o_cconsent_ver`).

## Integration with other plugins

Plugins that set optional cookies should respect the visitor's choice:

- **PHP** (server-side): `evebb_cconsent_optional_allowed()` — true when
  optional cookies may be set on this request (notice mode, or the visitor
  accepted all). Guard with `function_exists()` in case this plugin is
  inactive.
- **JavaScript** (live reaction, no reload):
  `window.evebbConsent.subscribe(fn)` — `fn(status)` fires immediately if
  a choice already exists and again on every change (`'all'`,
  `'essential'`, `'ack'`). If your script might run before this plugin's,
  push your callback onto `window.evebbConsentQ` instead; the queue is
  adopted automatically.

The bundled Google Analytics plugin uses exactly this contract: with
consent mode on, the GA tag is only loaded after "Accept all" — including
live in the same page view where the visitor accepts.

## Behaviour notes

- In notice mode, pages carry zero extra bytes once the visitor has
  clicked OK. In consent mode a small script is always present so the
  footer link can reopen the banner.
- The banner is not shown in the admin console.
- With JavaScript disabled the banner simply doesn't appear and no
  optional cookies are set by integrated plugins (fail-safe).
- Uninstalling: deactivate and delete — the plugin stores no data beyond
  its config values and the visitor-side cookie.

## License

GPL v2 or later, same as eveBB.
