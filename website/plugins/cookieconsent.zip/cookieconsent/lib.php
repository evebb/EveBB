<?php

/**
 * Cookie Consent - shared library.
 *
 * Small helpers used by the addon (cookieconsent.php), the settings page
 * (admin.php), and by OTHER plugins that want to respect the visitor's
 * choice (see evebb_cconsent_status below).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


//
// Read a plugin config value with a default
//
function evebb_cconsent_conf($name, $default)
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Insert or update a config value (caller regenerates the config cache)
//
function evebb_cconsent_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


//
// The visitor's current choice, parsed from the evebb_consent cookie:
//   'all'       - accepted optional cookies (consent mode)
//   'essential' - declined optional cookies (consent mode)
//   'ack'       - acknowledged the notice (notice mode)
//   'unknown'   - no valid choice for the current policy version
//
// The cookie value is "<version>:<choice>"; a choice made under an older
// policy version does not count (bumping the version re-asks everyone).
//
function evebb_cconsent_status()
{
	if (!isset($_COOKIE['evebb_consent']))
		return 'unknown';

	$parts = explode(':', $_COOKIE['evebb_consent'], 2);
	if (count($parts) != 2)
		return 'unknown';

	if ($parts[0] !== (string) intval(evebb_cconsent_conf('o_cconsent_ver', '1')))
		return 'unknown';

	return in_array($parts[1], array('all', 'essential', 'ack'), true) ? $parts[1] : 'unknown';
}


//
// Convenience for other plugins: may optional (analytics etc.) cookies be
// set for this visitor right now? True when the banner runs in notice mode
// (informational only) or the visitor accepted all cookies.
//
function evebb_cconsent_optional_allowed()
{
	if (evebb_cconsent_conf('o_cconsent_mode', 'notice') != 'consent')
		return true;

	return evebb_cconsent_status() == 'all';
}
