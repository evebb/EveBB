<?php

/**
 * Cookie Consent - the addon.
 *
 * Shows a banner to visitors who have not yet made a choice for the
 * current policy version. Two modes:
 *
 *   notice  - informational bar with an OK button (for boards that only
 *             set eveBB's own functional cookies)
 *   consent - Accept all / Essential only choice, for boards that also
 *             run optional cookies (analytics and the like)
 *
 * The choice is stored client-side in the evebb_consent cookie as
 * "<version>:<choice>" for a year. In consent mode a small "Cookie
 * preferences" link is added to the board footer so the choice can be
 * changed at any time (consent must be as easy to withdraw as to give).
 *
 * Integration contract for other plugins:
 *   PHP: evebb_cconsent_optional_allowed() (lib.php) says whether optional
 *        cookies may be set server-side on this request.
 *   JS:  window.evebbConsent.subscribe(fn) fires fn(status) on every
 *        choice ('all'/'essential'/'ack'). If this plugin's script has not
 *        run yet, push fn onto window.evebbConsentQ instead - the queue is
 *        adopted when the script runs. In consent mode the script is
 *        emitted on every page, so live reactions (loading an analytics
 *        tag the moment consent is given) work without a reload.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_cookieconsent extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		// One emission per request (message() can re-include header.php)
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		// Keep the admin console clean; the banner is shown on the board
		// itself, which admins also browse
		if (defined('PUN_ADMIN_CONSOLE'))
			return;

		$mode = evebb_cconsent_conf('o_cconsent_mode', 'notice');
		$status = evebb_cconsent_status();

		// Notice mode: once acknowledged there is nothing left to do, so
		// pages carry zero extra bytes. Consent mode always emits (the
		// footer link must be able to reopen the banner).
		if ($mode != 'consent' && $status != 'unknown')
			return;

		$cfg = array(
			'ver'     => (string) intval(evebb_cconsent_conf('o_cconsent_ver', '1')),
			'mode'    => ($mode == 'consent') ? 'consent' : 'notice',
			'status'  => $status,
			'message' => evebb_cconsent_conf('o_cconsent_message', 'This forum stores cookies on your device to keep you logged in and remember your preferences. Optional cookies (such as analytics) are only set with your permission.'),
			'url'     => evebb_cconsent_conf('o_cconsent_url', ''),
			'text'    => array(
				'more'      => 'Learn more',
				'ok'        => 'OK',
				'accept'    => 'Accept all',
				'essential' => 'Essential only',
				'prefs'     => 'Cookie preferences'
			)
		);

		$json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

		echo '<style type="text/css">'
			.'#evebb-cconsent{position:fixed;left:0;right:0;bottom:0;z-index:9999;background:rgba(24,26,27,.97);color:#eee;padding:.9em 1.2em;font-size:.95em;box-shadow:0 -2px 8px rgba(0,0,0,.35)}'
			.'#evebb-cconsent .cc-inner{max-width:64em;margin:0 auto;display:flex;flex-wrap:wrap;align-items:center;gap:.9em}'
			.'#evebb-cconsent p{margin:0;flex:1 1 22em;color:#eee}'
			.'#evebb-cconsent a{color:#8fd3a8}'
			.'#evebb-cconsent button{cursor:pointer;border:1px solid #666;border-radius:4px;padding:.45em 1em;background:#3a3d3f;color:#eee;font-size:1em}'
			.'#evebb-cconsent button.cc-primary{background:#2f9e5f;border-color:#2f9e5f;color:#fff}'
			.'#evebb-cconsent button:hover{filter:brightness(1.15)}'
			.'.cc-prefs-link{text-align:center;font-size:.9em;padding:.4em 0}'
			.'</style>'."\n";

		echo '<script type="text/javascript">/* Cookie Consent plugin */'."\n".'(function(){'."\n"
			.'var cfg = '.$json.';'."\n"
			.<<<'EOJS'
function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

var api = window.evebbConsent = window.evebbConsent || {};
api.status = cfg.status;
api.listeners = api.listeners || [];
api.subscribe = function (fn) {
	api.listeners.push(fn);
	if (api.status && api.status !== 'unknown') fn(api.status);
};
api.set = function (s) {
	document.cookie = 'evebb_consent=' + cfg.ver + ':' + s + '; max-age=31536000; path=/; SameSite=Lax';
	api.status = s;
	for (var i = 0; i < api.listeners.length; i++) api.listeners[i](s);
	hide();
};
api.open = function () { ready(show); };

// Adopt callbacks registered before this script ran
var q = window.evebbConsentQ;
window.evebbConsentQ = null;
if (q) for (var i = 0; i < q.length; i++) api.subscribe(q[i]);

var banner = null;

function el(tag, cls, text) {
	var e = document.createElement(tag);
	if (cls) e.className = cls;
	if (text) e.textContent = text;
	return e;
}

function button(label, primary, choice) {
	var b = el('button', primary ? 'cc-primary' : null, label);
	b.type = 'button';
	b.addEventListener('click', function () { api.set(choice); });
	return b;
}

function hide() { if (banner) { banner.parentNode.removeChild(banner); banner = null; } }

function show() {
	if (banner) return;
	banner = el('div');
	banner.id = 'evebb-cconsent';
	banner.setAttribute('role', 'dialog');
	banner.setAttribute('aria-label', 'Cookies');
	var inner = el('div', 'cc-inner');

	var p = el('p', null, cfg.message + ' ');
	if (cfg.url) {
		var a = el('a', null, cfg.text.more);
		a.href = cfg.url;
		p.appendChild(a);
	}
	inner.appendChild(p);

	if (cfg.mode === 'consent') {
		inner.appendChild(button(cfg.text.essential, false, 'essential'));
		inner.appendChild(button(cfg.text.accept, true, 'all'));
	} else
		inner.appendChild(button(cfg.text.ok, true, 'ack'));

	banner.appendChild(inner);
	document.body.appendChild(banner);
}

ready(function () {
	if (cfg.status === 'unknown') show();

	// Consent must be changeable later: a small footer link (consent mode)
	if (cfg.mode === 'consent') {
		var footer = document.getElementById('brdfooter');
		if (footer) {
			var p = el('p', 'cc-prefs-link');
			var a = el('a', null, cfg.text.prefs);
			a.href = '#';
			a.addEventListener('click', function (e) { e.preventDefault(); show(); });
			p.appendChild(a);
			footer.appendChild(p);
		}
	}
});
EOJS
			."\n".'})();</script>'."\n";
	}
}
