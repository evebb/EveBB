<?php

/**
 * Similar Topics - the addon.
 *
 * On the new-topic form (post.php?fid=N), watches the subject field and
 * suggests existing topics whose subjects share words with what's being
 * typed, using the board's own search index (subject-match words only).
 * Results respect forum read permissions for the current user's group.
 *
 * The lookup endpoint is the same page with &simtopics_q=... - handled
 * server-side from the header hook (output still buffered), returning
 * JSON and exiting.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_simtopics extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		global $pun_config;

		static $busy;
		if ($busy)
			return;
		$busy = true;

		$page = basename($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '');
		$fid = intval($_GET['fid'] ?? 0);

		if ($page == 'post.php' && $fid > 0 && $this->forum_enabled($fid))
		{
			if (isset($_GET['simtopics_q']))
				$this->answer_query($fid);   // exits
			else
				$this->inject_ui($fid);
		}

		$busy = false;
	}

	//
	// Is the plugin active for this forum? (o_simtopics_forums: comma-
	// separated forum IDs, blank/unset = all forums)
	//
	function forum_enabled($fid)
	{
		global $pun_config;

		$list = trim($pun_config['o_simtopics_forums'] ?? '');
		if ($list == '')
			return true;

		return in_array((string) $fid, array_map('trim', explode(',', $list)), true);
	}

	//
	// JSON endpoint: top similar topics for the typed subject
	//
	function answer_query($fid)
	{
		global $db, $pun_user, $pun_config;

		require_once PUN_ROOT.'include/search_idx.php';

		$max = max(1, min(10, intval($pun_config['o_simtopics_max'] ?? 5)));

		// Tokenize exactly like the indexer, so we only look for words
		// that can actually be in the index
		$words = array();
		foreach (split_words(utf8_strtolower(pun_trim($_GET['simtopics_q'])), true) as $word)
			$words[] = '\''.$db->escape($word).'\'';

		$topics = array();
		if (!empty($words))
		{
			$result = $db->query(
				'SELECT t.id, t.subject, t.num_replies, t.last_post, f.forum_name, COUNT(DISTINCT w.id) AS score'
				.' FROM '.$db->prefix.'search_words AS w'
				.' INNER JOIN '.$db->prefix.'search_matches AS m ON m.word_id=w.id AND m.subject_match=1'
				.' INNER JOIN '.$db->prefix.'posts AS p ON p.id=m.post_id'
				.' INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id'
				.' INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id'
				.' LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=t.forum_id AND fp.group_id='.$pun_user['g_id'].')'
				.' WHERE w.word IN('.implode(',', $words).') AND t.moved_to IS NULL AND (fp.read_forum IS NULL OR fp.read_forum=1)'
				.' GROUP BY t.id, t.subject, t.num_replies, t.last_post, f.forum_name'
				.' ORDER BY score DESC, t.last_post DESC'
			) or error('Unable to fetch similar topics', __FILE__, __LINE__, $db->error());

			while (count($topics) < $max && ($row = $db->fetch_assoc($result)))
			{
				$topics[] = array(
					'url'		=> get_base_url(true).'/viewtopic.php?id='.$row['id'],
					'subject'	=> $row['subject'],
					'replies'	=> (int) $row['num_replies'],
					'forum'		=> $row['forum_name'],
					'last'		=> format_time($row['last_post'], true),
				);
			}
		}

		$db->end_transaction();

		// The hook fires mid-page with the header already buffered -
		// throw all of that away so the response is pure JSON
		while (ob_get_level())
			ob_end_clean();

		header('Content-Type: application/json; charset=utf-8');
		header('Cache-Control: no-store');
		echo json_encode(array('topics' => $topics), JSON_UNESCAPED_SLASHES);
		exit;
	}

	//
	// The watcher: debounced subject-field lookups, suggestions panel
	// rendered under the subject input. DOM-built, degrades to nothing
	// without JS.
	//
	function inject_ui($fid)
	{
		global $pun_config;

		$data = array(
			'endpoint'	=> get_base_url(true).'/post.php?fid='.$fid.'&simtopics_q=',
			'minchars'	=> max(2, min(30, intval($pun_config['o_simtopics_minchars'] ?? 4))),
			'heading'	=> 'Similar topics already on the board - your answer may be waiting:',
			'replies1'	=> 'reply',
			'replies'	=> 'replies',
		);

		echo '<script>'."\n"
			.'document.addEventListener("DOMContentLoaded",function(){'
			.'var d='.json_encode($data, JSON_UNESCAPED_SLASHES).';'
			.'var inp=document.querySelector("input[name=\"req_subject\"]");if(!inp)return;'
			.'var panel=document.createElement("div");panel.id="simtopics";panel.style.cssText="display:none;margin:8px 0;padding:8px 12px;border:1px solid rgba(128,128,128,.4);border-radius:3px;";'
			.'var head=document.createElement("p");head.style.cssText="margin:0 0 6px;font-weight:bold;";head.textContent=d.heading;panel.appendChild(head);'
			.'var list=document.createElement("ul");list.style.cssText="margin:0;padding-left:18px;";panel.appendChild(list);'
			.'inp.parentNode.appendChild(panel);'
			.'var timer=null,seq=0;'
			.'function render(topics){'
			.'list.textContent="";'
			.'if(!topics.length){panel.style.display="none";return;}'
			.'topics.forEach(function(t){'
			.'var li=document.createElement("li");li.style.margin="2px 0";'
			.'var a=document.createElement("a");a.href=t.url;a.target="_blank";a.rel="noopener";a.textContent=t.subject;li.appendChild(a);'
			.'var meta=document.createElement("span");meta.style.cssText="opacity:.75;font-size:.92em;";'
			.'meta.textContent=" - "+t.replies+" "+(t.replies==1?d.replies1:d.replies)+", "+t.forum+", "+t.last;li.appendChild(meta);'
			.'list.appendChild(li);});'
			.'panel.style.display="block";}'
			.'function lookup(){'
			.'var q=inp.value.trim();'
			.'if(q.length<d.minchars){render([]);return;}'
			.'var my=++seq;'
			.'fetch(d.endpoint+encodeURIComponent(q),{credentials:"same-origin"})'
			.'.then(function(r){return r.json();})'
			.'.then(function(j){if(my===seq)render(j.topics||[]);})'
			.'.catch(function(){});}'
			.'inp.addEventListener("input",function(){clearTimeout(timer);timer=setTimeout(lookup,350);});'
			.'if(inp.value.trim().length>=d.minchars)lookup();'
			.'});</script>'."\n";
	}
}
