<?php

/**
 * Similar Topics - settings page (shown inside the plugin manager).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

//
// Upsert helper (config + cache refresh)
//
if (!function_exists('simtopics_save_config'))
{
function simtopics_save_config($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}
}

if (isset($_POST['save_simtopics']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	simtopics_save_config('o_simtopics_max', (string) max(1, min(10, intval($_POST['max_results'] ?? 5))));
	simtopics_save_config('o_simtopics_minchars', (string) max(2, min(30, intval($_POST['min_chars'] ?? 4))));

	// Forum list: keep only numeric IDs, comma-separated; blank = all
	$forums = array();
	foreach (explode(',', $_POST['forums'] ?? '') as $bit)
	{
		if (intval(trim($bit)) > 0)
			$forums[] = intval(trim($bit));
	}
	simtopics_save_config('o_simtopics_forums', implode(',', array_unique($forums)));

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}

$st_max = intval($pun_config['o_simtopics_max'] ?? 5);
$st_minchars = intval($pun_config['o_simtopics_minchars'] ?? 4);
$st_forums = $pun_config['o_simtopics_forums'] ?? '';

$result = $db->query('SELECT id, forum_name FROM '.$db->prefix.'forums ORDER BY id') or error('Unable to fetch forums', __FILE__, __LINE__, $db->error());
$forum_legend = array();
while ($row = $db->fetch_assoc($result))
	$forum_legend[] = $row['id'].' = '.pun_htmlspecialchars($row['forum_name']);

?>
	<div class="inform">
		<fieldset>
			<legend>How it works</legend>
			<div class="infldset">
				<p>While a member types a new topic's subject, the plugin looks the words up in the board's own search index and suggests existing threads with matching subjects — before the duplicate gets posted. Suggestions only ever include forums the member is allowed to read. No external services, nothing new to index.</p>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Similar Topics settings</legend>
			<div class="infldset">
				<label>Maximum suggestions (1–10)
					<br /><input type="text" name="max_results" size="4" maxlength="2" value="<?php echo $st_max ?>" />
				</label>
				<label>Start suggesting after this many characters (2–30)
					<br /><input type="text" name="min_chars" size="4" maxlength="2" value="<?php echo $st_minchars ?>" />
				</label>
				<label>Only in these forums (comma-separated forum IDs; leave blank for all forums)
					<br /><input type="text" name="forums" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($st_forums) ?>" />
				</label>
<?php if (!empty($forum_legend)): ?>				<p><?php echo implode('; &#160; ', $forum_legend) ?></p>
<?php endif; ?>				<p class="topspace"><input type="submit" name="save_simtopics" value="Save settings" /></p>
			</div>
		</fieldset>
	</div>
<?php
