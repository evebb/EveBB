# Similar Topics for eveBB

Suggests existing threads while a member types a new topic's subject —
so the answer gets found *before* the duplicate gets posted.

## What it does

On the new-topic form, once the subject reaches a few characters, a
quiet panel appears under the field: "Similar topics already on the
board", listing the closest-matching existing threads with their reply
counts, forum and last-activity date. Each opens in a new tab so the
half-written post isn't lost. If nothing matches, nothing is shown.

- Uses the board's **own search index** (subject words only) — nothing
  new to build or maintain, no external services, and results are ranked
  by how many subject words match.
- **Permission-aware**: members are only ever shown topics from forums
  their group can read.
- Degrades cleanly: without JavaScript the form is simply unchanged.

## Settings

Administration → Plugins → Similar Topics:

- Maximum suggestions (default 5)
- Minimum characters before suggesting (default 4)
- Restrict to specific forums (default: all)

## Install

Upload the zip through Administration → Plugins, activate, done. No
database changes; a handful of config values, removed by deactivating.

License: GPL v2 or higher, same as eveBB.
