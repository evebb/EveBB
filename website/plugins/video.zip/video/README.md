# Video Embeds for eveBB

Turns YouTube links in posts into click-to-load video players — the
privacy-friendly way.

## What it does

Paste a YouTube link on its own into a post and readers see a video
card with a play button. Click it and the video plays right there, with
start-times honoured (`?t=1m30s` works). Supported link forms:
`youtube.com/watch`, `youtu.be/…`, `shorts`, `live` and `embed` URLs.

The details that make it well-behaved:

- **Two-click privacy.** Nothing is requested from Google until the
  reader clicks play; the player then loads from the cookie-less
  `youtube-nocookie.com` embed domain. Optional preview thumbnails
  (from YouTube's image server) can be disabled entirely — and when the
  Cookie Consent plugin is active, they're automatically shown only to
  visitors who chose *Accept all*.
- **Only bare links transform.** A URL pasted on its own becomes a
  player; a link written with custom text (`[url=…]like this[/url]`)
  stays a link, because that's what the author wanted. Quotes and
  signatures are never touched.
- **Degrades cleanly.** Without JavaScript, posts simply show their
  links as before. A "Watch on YouTube" link accompanies every embed.
- **Bounded.** A per-page embed limit (default 10) keeps huge threads
  fast; links past the limit stay links.

## Install

Upload the zip through Administration → Plugins, activate, done.
Settings: maximum embeds per page and the thumbnails toggle. No
database changes at all — two config values, gone on deactivation.

## Looking ahead

This plugin is the try-it-now version of a planned core feature: a
`[video]` BBCode plus a toolbar button in the visual editor are on the
eveBB 2.1 roadmap. When that lands, this plugin retires gracefully.

License: GPL v2 or higher, same as eveBB.
