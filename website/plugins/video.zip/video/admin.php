<?php

/**
 * Video Embeds - settings page (shown inside the plugin manager).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

if (!function_exists('video_save_config'))
{
function video_save_config($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}
}

if (isset($_POST['save_video']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	video_save_config('o_video_max', (string) max(1, min(50, intval($_POST['max_embeds'] ?? 10))));
	video_save_config('o_video_thumbs', isset($_POST['thumbs']) ? '1' : '0');

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}

$v_max = intval($pun_config['o_video_max'] ?? 10);
$v_thumbs = ($pun_config['o_video_thumbs'] ?? '1') == '1';

// Is the cookieconsent plugin active? (informational note only)
$v_consent = function_exists('evebb_active_plugins') && in_array('cookieconsent', evebb_active_plugins());

?>
	<div class="inform">
		<fieldset>
			<legend>How it works</legend>
			<div class="infldset">
				<p>A YouTube link pasted on its own into a post becomes a click-to-load player. Nothing is requested from Google until a reader actually clicks play (the player then loads from the cookie-less <code>youtube-nocookie.com</code> embed domain), links written with custom text are left alone, quotes and signatures are never touched, and with JavaScript off posts simply show their links as before.</p>
<?php if ($v_consent): ?>				<p><strong>Cookie Consent integration is active:</strong> preview thumbnails (which load from YouTube's image server) are only shown to visitors who chose <em>Accept all</em>; everyone else sees a neutral placeholder until they click play.</p>
<?php else: ?>				<p>If the Cookie Consent plugin is activated in consent mode, preview thumbnails are automatically limited to visitors who accepted optional cookies.</p>
<?php endif; ?>			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Video Embeds settings</legend>
			<div class="infldset">
				<label>Maximum embeds per page (1–50)
					<br /><input type="text" name="max_embeds" size="4" maxlength="2" value="<?php echo $v_max ?>" />
				</label>
				<p>Further video links beyond the limit stay as normal links — keeps huge threads fast.</p>
				<div class="rbox">
					<label><input type="checkbox" name="thumbs" value="1"<?php if ($v_thumbs) echo ' checked="checked"' ?> />Show video preview thumbnails (loaded from YouTube's image server, subject to consent as described above). Unticked: neutral placeholders only, zero third-party requests before play.<br /></label>
				</div>
				<p class="topspace"><input type="submit" name="save_video" value="Save settings" /></p>
			</div>
		</fieldset>
	</div>
<?php
