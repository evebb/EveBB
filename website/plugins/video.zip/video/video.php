<?php

/**
 * Video Embeds - the addon.
 *
 * On viewtopic pages, bare YouTube links inside post bodies become
 * click-to-load embeds. Everything happens client-side: the server
 * emits one script + stylesheet into <head>, the DOM is rewritten
 * after load, and without JavaScript posts simply show their links.
 *
 * Privacy model (the "two-click" pattern):
 *   - Nothing is requested from Google until the reader clicks play;
 *     the card is a local placeholder (optionally with a thumbnail
 *     from YouTube's image CDN, see below).
 *   - The player itself is the youtube-nocookie.com embed domain.
 *   - When the Cookie Consent plugin is active (window.evebbConsent),
 *     thumbnails only load for visitors who chose "Accept all";
 *     everyone else gets the no-external-request placeholder. Clicking
 *     play is always allowed - an explicit user action.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_video extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		global $pun_config;

		static $busy;
		if ($busy)
			return;
		$busy = true;

		$page = basename($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '');
		if ($page == 'viewtopic.php')
			$this->inject($pun_config);

		$busy = false;
	}

	function inject($pun_config)
	{
		$data = array(
			'max'		=> max(1, min(50, intval($pun_config['o_video_max'] ?? 10))),
			'thumbs'	=> (($pun_config['o_video_thumbs'] ?? '1') == '1'),
			'watch'		=> 'Watch on YouTube',
			'load'		=> 'Click to load the video from YouTube',
		);

		echo '<style>
.evebb-video{position:relative;max-width:640px;aspect-ratio:16/9;background:#1b1e21 center/cover no-repeat;border:1px solid rgba(128,128,128,.35);border-radius:4px;overflow:hidden;margin:8px 0 4px;cursor:pointer}
.evebb-video:focus-visible{outline:2px solid #e67300}
.evebb-video .evebb-video-play{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:64px;height:44px;background:rgba(20,20,20,.85);border-radius:10px;display:flex;align-items:center;justify-content:center;pointer-events:none}
.evebb-video .evebb-video-play::after{content:"";display:block;border-style:solid;border-width:10px 0 10px 17px;border-color:transparent transparent transparent #fff;margin-left:3px}
.evebb-video:hover .evebb-video-play{background:rgba(230,115,0,.9)}
.evebb-video .evebb-video-note{position:absolute;left:0;right:0;bottom:0;padding:5px 9px;font-size:11px;color:#cfd3d7;background:rgba(20,20,20,.7);pointer-events:none}
.evebb-video iframe{position:absolute;inset:0;width:100%;height:100%;border:0}
.evebb-video-caption{font-size:12px;margin:0 0 8px}
</style>'."\n"
			.'<script>'."\n"
			.'document.addEventListener("DOMContentLoaded",function(){'
			.'var d='.json_encode($data, JSON_UNESCAPED_SLASHES).';'

			// href -> {id, start} or null
			.'function parseYT(href){'
			.'var m,u;try{u=new URL(href);}catch(e){return null;}'
			.'var host=u.hostname.replace(/^www\.|^m\./,"");'
			.'var id=null;'
			.'if(host==="youtu.be"){m=u.pathname.match(/^\/([A-Za-z0-9_-]{11})$/);if(m)id=m[1];}'
			.'else if(host==="youtube.com"||host==="youtube-nocookie.com"){'
			.'if(u.pathname==="/watch"){var v=u.searchParams.get("v")||"";if(/^[A-Za-z0-9_-]{11}$/.test(v))id=v;}'
			.'else{m=u.pathname.match(/^\/(?:shorts|embed|live)\/([A-Za-z0-9_-]{11})$/);if(m)id=m[1];}}'
			.'if(!id)return null;'
			.'var start=0,t=u.searchParams.get("t")||u.searchParams.get("start");'
			.'if(t){m=String(t).match(/^(?:(\d+)h)?(?:(\d+)m)?(\d+)s?$/);'
			.'if(m)start=(parseInt(m[1]||0)*3600)+(parseInt(m[2]||0)*60)+parseInt(m[3]||0);}'
			.'return {id:id,start:start};}'

			// is this link a bare pasted URL (not authored link text)?
			// (the parser truncates long bare URLs to "start … end")
			.'function isBare(a){var t=a.textContent.trim();if(t===a.href)return true;'
			.'var i=t.indexOf(" … ");'
			.'if(i>0){var p=t.slice(0,i),s=t.slice(i+3);'
			.'return a.href.indexOf(p)===0&&a.href.slice(-s.length)===s;}'
			.'return false;}'

			.'var thumbsOK=null;'  // null = undecided; true/false once known
			.'var cards=[];'
			.'function applyThumbs(){cards.forEach(function(c){'
			.'c.el.style.backgroundImage=(thumbsOK===true&&d.thumbs)?"url(https://i.ytimg.com/vi/"+c.id+"/hqdefault.jpg)":"";});}'

			.'function activate(card,info){'
			.'card.textContent="";card.style.cursor="default";'
			.'var f=document.createElement("iframe");'
			.'f.src="https://www.youtube-nocookie.com/embed/"+info.id+"?autoplay=1"+(info.start?"&start="+info.start:"");'
			.'f.allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share";'
			.'f.allowFullscreen=true;f.referrerPolicy="strict-origin-when-cross-origin";f.title="YouTube video";'
			.'card.appendChild(f);}'

			.'function build(a,info){'
			.'var card=document.createElement("div");card.className="evebb-video";card.tabIndex=0;'
			.'card.setAttribute("role","button");card.setAttribute("aria-label",d.load);card.title=d.load;'
			.'var play=document.createElement("div");play.className="evebb-video-play";card.appendChild(play);'
			.'var note=document.createElement("div");note.className="evebb-video-note";note.textContent=d.load;card.appendChild(note);'
			.'function go(){activate(card,info);}'
			.'card.addEventListener("click",go,{once:true});'
			.'card.addEventListener("keydown",function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();go();}},{once:true});'
			.'var cap=document.createElement("p");cap.className="evebb-video-caption";'
			.'var link=document.createElement("a");link.href=a.href;link.target="_blank";link.rel="noopener";link.textContent=d.watch;cap.appendChild(link);'
			.'a.parentNode.insertBefore(card,a);a.parentNode.insertBefore(cap,a);a.remove();'
			.'cards.push({el:card,id:info.id});}'

			.'var count=0;'
			.'document.querySelectorAll(".blockpost div.postmsg a[href]").forEach(function(a){'
			.'if(count>=d.max)return;'
			.'if(a.closest(".postsignature")||a.closest("blockquote"))return;'
			.'if(!isBare(a))return;'
			.'var info=parseYT(a.href);if(!info)return;'
			.'count++;build(a,info);});'

			.'if(!cards.length)return;'
			// consent contract: thumbnails only for "all"; absent plugin = allowed
			.'function onStatus(s){thumbsOK=(s==="all");applyThumbs();}'
			.'if(window.evebbConsent&&window.evebbConsent.subscribe){window.evebbConsent.subscribe(onStatus);}'
			.'else if(window.evebbConsentQ){window.evebbConsentQ.push(onStatus);}'
			.'else{thumbsOK=true;applyThumbs();}'
			.'});</script>'."\n";
	}
}
