<?php

/**
 * Code Highlighting - an eveBB plugin.
 *
 * eveBB renders [code] blocks as <div class="codebox"><pre><code> - the
 * exact shape highlight.js targets. This plugin ships its own copy of
 * highlight.js (v11 common-languages build, auto-detection) and injects
 * it, plus a colour theme, on the pages that display posts: topics,
 * post/edit previews and search results. Nothing loads anywhere else,
 * nothing is fetched from a CDN, and nothing about your visitors leaves
 * your server.
 *
 * The theme is chosen in the settings page (Administration -> Plugins);
 * themes are the stock highlight.js styles bundled under assets/themes.
 *
 * highlight.js is (c) its contributors, BSD-3-Clause - see
 * assets/LICENSE-highlightjs.txt.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_codehl extends flux_addon
{
	// Pages that can render post content
	var $pages = array('viewtopic', 'post', 'edit', 'search', 'misc');

	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'inject'));
	}

	//
	// The bundled themes (filename without .css)
	//
	static function themes()
	{
		$themes = array();
		foreach (glob(dirname(__FILE__).'/assets/themes/*.css') ?: array() as $file)
			$themes[] = basename($file, '.css');
		sort($themes);

		return $themes;
	}

	function inject()
	{
		global $pun_config;

		if (!in_array(basename($_SERVER['SCRIPT_NAME'], '.php'), $this->pages, true))
			return;

		$theme = isset($pun_config['o_codehl_theme']) ? $pun_config['o_codehl_theme'] : 'github-dark';
		if (!in_array($theme, self::themes(), true))
			$theme = 'github-dark';

		$base = rtrim($pun_config['o_base_url'], '/').'/plugins/codehl/assets';
		$v = '?v=1.0.0';

		echo "\n".'<link rel="stylesheet" type="text/css" href="'.pun_htmlspecialchars($base.'/themes/'.$theme.'.css'.$v).'" />'."\n";
		echo '<script src="'.pun_htmlspecialchars($base.'/highlight.min.js'.$v).'" defer></script>'."\n";
		echo '<script>document.addEventListener("DOMContentLoaded",function(){if(window.hljs){hljs.highlightAll();}});</script>'."\n";
		// Let the theme own the code box interior; keep comfortable padding
		echo '<style>.pun div[class*=codebox] pre code.hljs{display:block;padding:0.75em 1em;overflow-x:auto}</style>'."\n";
	}
}
