<?php

/**
 * Code Highlighting - settings page (theme picker).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

$codehl_themes = plugin_codehl::themes();

if (isset($_POST['save_codehl']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$theme = pun_trim($_POST['codehl_theme'] ?? 'github-dark');
	if (!in_array($theme, $codehl_themes, true))
		$theme = 'github-dark';

	if (isset($pun_config['o_codehl_theme']))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($theme).'\' WHERE conf_name=\'o_codehl_theme\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_codehl_theme\', \''.$db->escape($theme).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Code highlighting settings saved. Redirecting …');
}

$cur_theme = isset($pun_config['o_codehl_theme']) ? $pun_config['o_codehl_theme'] : 'github-dark';

?>
<div class="blockform">
	<h2><span>Code Highlighting</span></h2>
	<div class="box">
		<form method="post" action="admin_plugins.php?action=settings&amp;plugin=<?php echo pun_htmlspecialchars($plugin_slug) ?>">
			<input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token() ?>" />
			<div class="inform">
				<fieldset>
					<legend>Colour theme</legend>
					<div class="infldset">
						<label>Theme for highlighted code blocks<br />
						<select name="codehl_theme">
<?php foreach ($codehl_themes as $theme): ?>
							<option value="<?php echo pun_htmlspecialchars($theme) ?>"<?php if ($theme == $cur_theme) echo ' selected="selected"' ?>><?php echo pun_htmlspecialchars($theme) ?></option>
<?php endforeach; ?>
						</select><br /></label>
						<p>Dark themes (github-dark, atom-one-dark, monokai) match eveBB's dark code boxes and dark styles; the light themes suit boards that restyle their code boxes light. The language of each block is auto-detected. Highlighting loads only on pages that display posts.</p>
					</div>
				</fieldset>
			</div>
			<p class="submitend"><input type="submit" name="save_codehl" value="Save settings" /></p>
		</form>
	</div>
</div>
