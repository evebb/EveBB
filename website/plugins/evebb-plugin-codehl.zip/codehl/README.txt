Code Highlighting - an eveBB plugin
===================================

Syntax-highlights [code] blocks using highlight.js v11 (bundled, ~190
languages, auto-detected). Entirely self-hosted: no CDN, no external
requests, nothing about your visitors leaves your server.

INSTALL
  Administration -> Plugins -> upload this zip -> Activate.
  Pick a colour theme behind the plugin's "Settings" link (six stock
  highlight.js themes are bundled; github-dark is the default).

The scripts load only on pages that display posts (topics, previews,
search results); every other page is untouched. Deactivate and all
pages are exactly stock again.

highlight.js is (c) its contributors, BSD-3-Clause - the license ships
in assets/LICENSE-highlightjs.txt.

Plugin license: GPL v2 or later, same as eveBB. Built for eveBB
2.0.0-beta.1+.
