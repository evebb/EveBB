<?php

/**
 * Two-Factor Authentication - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome (and inside a POST
 * form that footer.php injects the CSRF token into). $db, $pun_config and
 * $plugin_slug are available here.
 *
 * This is an official eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

// The addon normally creates the tables on first page view, but make sure
// they exist even if the settings page is visited before that
evebb_tfa_ensure_schema();

$tfa_back = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

// Staff reset: switch 2FA off for a locked-out member
if (isset($_POST['tfa_reset']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$username = pun_trim($_POST['tfa_reset_user'] ?? '');
	$result = $db->query('SELECT id FROM '.$db->prefix.'users WHERE id>1 AND username=\''.$db->escape($username).'\'') or error('Unable to fetch user', __FILE__, __LINE__, $db->error());

	if (!$db->has_rows($result))
		redirect($tfa_back, 'No member with that exact username. Redirecting …');

	$user_id = (int) $db->result($result);

	if (evebb_tfa_row($user_id) === null)
		redirect($tfa_back, 'That member does not have two-factor authentication enabled. Redirecting …');

	evebb_tfa_disable($user_id);

	redirect($tfa_back, 'Two-factor authentication switched off for that member - they can log in with just their password and re-enable it from their profile. Redirecting …');
}

// Settings
if (isset($_POST['save_tfa']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	evebb_tfa_save_conf('o_tfa_hint', isset($_POST['tfa_hint']) ? '1' : '0');

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect($tfa_back, 'Settings saved. Redirecting …');
}

// Remove rows whose users no longer exist
if (isset($_POST['purge_tfa']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DELETE FROM '.$db->prefix.'tfa_backup WHERE user_id NOT IN (SELECT id FROM '.$db->prefix.'users)') or error('Unable to purge 2FA rows', __FILE__, __LINE__, $db->error());
	$db->query('DELETE FROM '.$db->prefix.'tfa_users WHERE user_id NOT IN (SELECT id FROM '.$db->prefix.'users)') or error('Unable to purge 2FA rows', __FILE__, __LINE__, $db->error());

	redirect($tfa_back, 'Orphaned 2FA rows purged. Redirecting …');
}

// Remove ALL plugin data (before uninstalling)
if (isset($_POST['nuke_tfa']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect($tfa_back, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('tfa_backup');
	$db->drop_table('tfa_users');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN (\'o_tfa_db_rev\', \'o_tfa_hint\')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());

	unset($pun_config['o_tfa_db_rev'], $pun_config['o_tfa_hint']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Two-Factor Authentication data removed. Members affected can log in with just their passwords. You can now deactivate and delete the plugin. Redirecting …');
}

$result = $db->query('SELECT COUNT(user_id) FROM '.$db->prefix.'tfa_users') or error('Unable to count 2FA members', __FILE__, __LINE__, $db->error());
$tfa_count = (int) $db->result($result);

$tfa_hint = evebb_tfa_conf('o_tfa_hint', '1') == '1';

?>
		<div class="inform">
			<fieldset>
				<legend>Two-Factor Authentication</legend>
				<div class="infldset">
					<p>Members with two-factor authentication enabled: <strong><?php echo $tfa_count ?></strong>. Members set it up themselves at <strong>plugins/tfa/</strong> (linked from their profile); secrets and backup codes are never visible to staff.</p>
					<label><input type="checkbox" name="tfa_hint" value="1"<?php if ($tfa_hint) echo ' checked="checked"' ?> /> Show new members a dismissible &quot;set up two-factor authentication&quot; prompt on their first day</label>
					<p class="topspace"><input type="submit" name="save_tfa" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Locked-out member</legend>
				<div class="infldset">
					<p>If a member has lost both their authenticator and their backup codes, switch two-factor authentication off for their account (verify it is really them first!). They can then log in with their password and re-enable it.</p>
					<p>Member <input type="text" name="tfa_reset_user" size="20" maxlength="25" /> <input type="submit" name="tfa_reset" value="Switch their 2FA off" /> <em>(exact username)</em></p>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Maintenance</legend>
				<div class="infldset">
					<p>Deleting a member does not remove their 2FA rows. Purging clears rows for deleted members.</p>
					<p><input type="submit" name="purge_tfa" value="Purge orphaned rows" /></p>
					<p class="topspace">To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops both tables - every member affected goes back to password-only login.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this switches two-factor authentication off for every member</label></p>
					<p><input type="submit" name="nuke_tfa" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
