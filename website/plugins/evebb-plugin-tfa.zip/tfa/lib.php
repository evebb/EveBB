<?php

/**
 * Two-Factor Authentication - shared library.
 *
 * Schema management plus the pure crypto pieces: RFC 4648 base32, RFC 6238
 * TOTP (SHA-1, 6 digits, 30 s), sealed setup tokens (HMAC, cookie_seed
 * keyed - the eveauth pattern) and single-use backup codes (stored as
 * HMACs, consumed atomically). Everything compares with hash_equals.
 *
 * The pure functions take no globals, so the test suites can require this
 * file standalone to compute expected codes.
 *
 * This is an official eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


//
// Create the tfa tables on first use. Guarded by the o_tfa_db_rev config
// key so the check is free on every later request.
//
function evebb_tfa_ensure_schema()
{
	global $db, $pun_config;

	if (isset($pun_config['o_tfa_db_rev']))
		return;

	if (!$db->table_exists('tfa_users'))
	{
		$schema = array(
			'FIELDS' => array(
				'user_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'secret' => array(
					'datatype'   => 'VARCHAR(32)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'last_slot' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'enabled_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('user_id')
		);

		$db->create_table('tfa_users', $schema) or error('Unable to create the tfa_users table', __FILE__, __LINE__, $db->error());
	}

	if (!$db->table_exists('tfa_backup'))
	{
		$schema = array(
			'FIELDS' => array(
				'user_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'code_hash' => array(
					'datatype'   => 'VARCHAR(64)',
					'allow_null' => false,
					'default'    => '\'\''
				)
			),
			'PRIMARY KEY' => array('user_id', 'code_hash')
		);

		$db->create_table('tfa_backup', $schema) or error('Unable to create the tfa_backup table', __FILE__, __LINE__, $db->error());
	}

	// Record the schema revision. No or-error here: if two requests race,
	// the loser's duplicate insert may fail and that is fine.
	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_tfa_db_rev\', \'1\')');
	$pun_config['o_tfa_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Read a plugin config value with a default
//
function evebb_tfa_conf($name, $default)
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Insert or update a config value and refresh the config cache
//
function evebb_tfa_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


// ---------------------------------------------------------------------
// Pure crypto helpers (no globals - requireable standalone by tests)
// ---------------------------------------------------------------------

//
// RFC 4648 base32 (A-Z, 2-7), no padding
//
function evebb_tfa_base32_encode($bin)
{
	$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
	$out = '';
	$buffer = 0;
	$bits = 0;

	for ($i = 0, $len = strlen($bin); $i < $len; $i++)
	{
		$buffer = ($buffer << 8) | ord($bin[$i]);
		$bits += 8;
		while ($bits >= 5)
		{
			$bits -= 5;
			$out .= $alphabet[($buffer >> $bits) & 31];
		}
	}
	if ($bits > 0)
		$out .= $alphabet[($buffer << (5 - $bits)) & 31];

	return $out;
}

function evebb_tfa_base32_decode($s)
{
	$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
	$s = strtoupper($s);
	$out = '';
	$buffer = 0;
	$bits = 0;

	for ($i = 0, $len = strlen($s); $i < $len; $i++)
	{
		$v = strpos($alphabet, $s[$i]);
		if ($v === false)
			continue;
		$buffer = ($buffer << 5) | $v;
		$bits += 5;
		if ($bits >= 8)
		{
			$bits -= 8;
			$out .= chr(($buffer >> $bits) & 255);
		}
	}

	return $out;
}


//
// A fresh 160-bit secret (32 base32 characters)
//
function evebb_tfa_new_secret()
{
	return evebb_tfa_base32_encode(random_bytes(20));
}


//
// The 6-digit TOTP code for one 30-second time slot
//
function evebb_tfa_code($secret, $slot)
{
	$key = evebb_tfa_base32_decode($secret);
	$msg = pack('N2', 0, $slot);
	$hash = hash_hmac('sha1', $msg, $key, true);
	$offset = ord($hash[19]) & 0xf;
	$value = ((ord($hash[$offset]) & 0x7f) << 24)
		| (ord($hash[$offset + 1]) << 16)
		| (ord($hash[$offset + 2]) << 8)
		| ord($hash[$offset + 3]);

	return str_pad((string) ($value % 1000000), 6, '0', STR_PAD_LEFT);
}


//
// Verify a 6-digit code against the current slot +/- 1 (90 s of clock
// drift). Slots at or before $last_slot are refused - a code can never be
// replayed. On success $used_slot carries the accepted slot, which the
// caller must persist as the new last_slot.
//
function evebb_tfa_verify($secret, $code, $last_slot, &$used_slot = null)
{
	$code = preg_replace('%\D%', '', (string) $code);
	if (strlen($code) != 6)
		return false;

	$now_slot = (int) floor(time() / 30);

	foreach (array(0, -1, 1) as $delta)
	{
		$slot = $now_slot + $delta;
		if ($slot <= (int) $last_slot)
			continue;
		if (hash_equals(evebb_tfa_code($secret, $slot), $code))
		{
			$used_slot = $slot;
			return true;
		}
	}

	return false;
}


//
// Sealed setup token: carries the not-yet-confirmed secret between the
// QR page and the confirm POST without any server-side session. Bound to
// the user id, HMAC'd with the board's cookie_seed, 15-minute TTL.
//
function evebb_tfa_seal($user_id, $secret)
{
	global $cookie_seed;

	$payload = (int) $user_id.':'.$secret.':'.(time() + 900);
	$mac = hash_hmac('sha256', $payload, $cookie_seed.'|evebb_tfa');

	return base64_encode($payload).'-'.$mac;
}

function evebb_tfa_unseal($token, $user_id)
{
	global $cookie_seed;

	$pos = strrpos((string) $token, '-');
	if ($pos === false)
		return false;

	$payload = base64_decode(substr($token, 0, $pos), true);
	$mac = substr($token, $pos + 1);
	if ($payload === false || !is_string($mac))
		return false;

	if (!hash_equals(hash_hmac('sha256', $payload, $cookie_seed.'|evebb_tfa'), $mac))
		return false;

	$parts = explode(':', $payload);
	if (count($parts) != 3)
		return false;

	list($uid, $secret, $expires) = $parts;
	if ((int) $uid != (int) $user_id || (int) $expires < time())
		return false;

	if (!preg_match('%^[A-Z2-7]{32}$%', $secret))
		return false;

	return $secret;
}


// ---------------------------------------------------------------------
// Per-user state
// ---------------------------------------------------------------------

//
// The member's 2FA row, or null when 2FA is off for them
//
function evebb_tfa_row($user_id)
{
	global $db;

	$result = $db->query('SELECT user_id, secret, last_slot, enabled_at FROM '.$db->prefix.'tfa_users WHERE user_id='.(int) $user_id) or error('Unable to fetch 2FA state', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? $db->fetch_assoc($result) : null;
}


//
// Normalise a typed backup code (case/spacing/dash insensitive)
//
function evebb_tfa_backup_normalize($code)
{
	return strtoupper(preg_replace('%[^0-9a-zA-Z]%', '', (string) $code));
}

function evebb_tfa_backup_hash($code)
{
	global $cookie_seed;

	return hash_hmac('sha256', evebb_tfa_backup_normalize($code), $cookie_seed.'|evebb_tfa_backup');
}


//
// Replace the member's backup codes with 8 fresh single-use codes and
// return the plain codes (shown exactly once)
//
function evebb_tfa_gen_backup($user_id)
{
	global $db;

	$user_id = (int) $user_id;
	$alphabet = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';   // no 0/O, 1/I/L
	$codes = array();

	$db->query('DELETE FROM '.$db->prefix.'tfa_backup WHERE user_id='.$user_id) or error('Unable to reset backup codes', __FILE__, __LINE__, $db->error());

	for ($i = 0; $i < 8; $i++)
	{
		$code = '';
		for ($j = 0; $j < 8; $j++)
			$code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
		$code = substr($code, 0, 4).'-'.substr($code, 4);
		$codes[] = $code;

		$db->query('INSERT INTO '.$db->prefix.'tfa_backup (user_id, code_hash) VALUES('.$user_id.', \''.$db->escape(evebb_tfa_backup_hash($code)).'\')') or error('Unable to store backup code', __FILE__, __LINE__, $db->error());
	}

	return $codes;
}


//
// Consume a backup code. The DELETE is the check - affected_rows()==1
// means the code existed and can never be used again (atomic even when
// two requests race the same code).
//
function evebb_tfa_use_backup($user_id, $code)
{
	global $db;

	$normalized = evebb_tfa_backup_normalize($code);
	if (strlen($normalized) != 8)
		return false;

	$db->query('DELETE FROM '.$db->prefix.'tfa_backup WHERE user_id='.(int) $user_id.' AND code_hash=\''.$db->escape(evebb_tfa_backup_hash($code)).'\'') or error('Unable to check backup code', __FILE__, __LINE__, $db->error());

	return $db->affected_rows() == 1;
}


//
// Accept either a 6-digit TOTP code (updating last_slot) or a backup
// code. The single entry point used by login and by the manage page.
//
function evebb_tfa_check_code($row, $code)
{
	global $db;

	$used_slot = null;
	if (evebb_tfa_verify($row['secret'], $code, (int) $row['last_slot'], $used_slot))
	{
		$db->query('UPDATE '.$db->prefix.'tfa_users SET last_slot='.(int) $used_slot.' WHERE user_id='.(int) $row['user_id']) or error('Unable to update 2FA state', __FILE__, __LINE__, $db->error());
		return true;
	}

	return evebb_tfa_use_backup($row['user_id'], $code);
}


//
// Switch 2FA off for a member (their own request, or a staff reset)
//
function evebb_tfa_disable($user_id)
{
	global $db;

	$db->query('DELETE FROM '.$db->prefix.'tfa_backup WHERE user_id='.(int) $user_id) or error('Unable to disable 2FA', __FILE__, __LINE__, $db->error());
	$db->query('DELETE FROM '.$db->prefix.'tfa_users WHERE user_id='.(int) $user_id) or error('Unable to disable 2FA', __FILE__, __LINE__, $db->error());
}
