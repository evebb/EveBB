# Two-Factor Authentication

An official [eveBB](https://evebb.net) plugin adding optional
app-based two-factor authentication (TOTP) to member accounts.

## Features

- Standard TOTP: 6-digit rotating codes from any authenticator app
  (Google Authenticator, Authy, 1Password, Aegis, Microsoft
  Authenticator …). SHA-1, 6 digits, 30-second period, ±1 step of clock
  drift.
- Entirely opt-in per member. Setup lives at `plugins/tfa/`, linked from
  a "Two-factor authentication" section on the member's own profile.
- The QR code is rendered locally with a bundled generator (`qr.js`,
  MIT, by Kazuhiko Arase) — the secret is never sent to any third-party
  QR service.
- Eight single-use backup codes, shown exactly once at setup (and
  regenerable with a current code). Codes are stored only as keyed
  hashes and are consumed atomically.
- Login stays one step: an optional "one-time code" field sits on the
  login form. Wrong or missing codes re-render the form with a clear
  message — and count against the board's per-IP login throttle, so
  codes can't be brute-forced.
- Replay-proof: each accepted code's time slot is recorded and can never
  be accepted again.
- New members see a dismissible "secure your account" prompt on their
  first day (setting to turn off).
- Staff can switch 2FA off for a locked-out member from the settings
  page; secrets and backup codes are never visible to staff.

## Installation

Upload `evebb-plugin-tfa.zip` through **Administration → Plugins → Upload plugin**,
then activate it. The plugin creates its two database tables
(`tfa_users`, `tfa_backup`) automatically on first use.

## Notes

- Deactivating the plugin (or removing its data) simply returns every
  member to password-only login — nobody gets locked out.
- The setup secret travels between the QR page and the confirm step in a
  sealed HMAC token (keyed with the board's `cookie_seed`, 15-minute
  expiry) — nothing is stored until the member proves their app pairs.
- TOTP secrets are stored server-side as required by the algorithm;
  protect your database and `config.php` accordingly.

## License

GPL version 2 or higher, like eveBB itself. Bundled `qr.js` is MIT
(Copyright Kazuhiko Arase).
