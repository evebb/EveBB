<?php

/**
 * Two-Factor Authentication - the setup and management page.
 *
 *   <board>/plugins/tfa/
 *
 * Logged-in members only. Setup: generate a secret, show it as a
 * locally-rendered QR code (bundled qr.js - the secret never leaves the
 * server except inside the QR the member scans), confirm with a first
 * valid code, then display the eight single-use backup codes exactly
 * once. Enabled members can regenerate backup codes or disable 2FA, both
 * gated by a current code. The not-yet-confirmed secret travels between
 * the QR page and the confirm POST inside a sealed HMAC token (15-minute
 * TTL, bound to the member) - no server-side session state.
 *
 * This is an official eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

//
// Absolutize relative href/src so forum chrome works from /plugins/tfa/
//
function tfa_absolutize($html)
{
	$base = get_base_url(true).'/';

	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('tfa_absolutize');

if (!in_array('tfa', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

if ($pun_user['is_guest'])
	message($lang_common['No permission'], false, '403 Forbidden');

evebb_tfa_ensure_schema();

$tfa_uid = (int) $pun_user['id'];
$tfa_row = evebb_tfa_row($tfa_uid);
$tfa_self = get_base_url(true).'/plugins/tfa/';
$tfa_issuer = $pun_config['o_board_title'];

$tfa_view = ($tfa_row !== null) ? 'enabled' : 'disabled';
$tfa_error = '';
$tfa_secret = '';
$tfa_sealed = '';
$tfa_codes = array();

$tfa_action = isset($_POST['tfa_action']) ? (string) $_POST['tfa_action'] : '';

// Start setup: fresh secret, sealed for the confirm round trip
if ($tfa_action === 'start' && $tfa_row === null)
{
	$tfa_secret = evebb_tfa_new_secret();
	$tfa_sealed = evebb_tfa_seal($tfa_uid, $tfa_secret);
	$tfa_view = 'qr';
}

// Confirm setup: unseal, verify the first code, enable + backup codes
else if ($tfa_action === 'confirm' && $tfa_row === null)
{
	$tfa_secret = evebb_tfa_unseal($_POST['tfa_seal'] ?? '', $tfa_uid);

	if ($tfa_secret === false)
		redirect($tfa_self, 'That setup session has expired - start again. Redirecting …');

	$used_slot = null;
	if (evebb_tfa_verify($tfa_secret, $_POST['tfa_code'] ?? '', 0, $used_slot))
	{
		$db->query('INSERT INTO '.$db->prefix.'tfa_users (user_id, secret, last_slot, enabled_at) VALUES('.$tfa_uid.', \''.$db->escape($tfa_secret).'\', '.(int) $used_slot.', '.time().')') or error('Unable to enable 2FA', __FILE__, __LINE__, $db->error());
		$tfa_codes = evebb_tfa_gen_backup($tfa_uid);
		$tfa_row = evebb_tfa_row($tfa_uid);
		$tfa_view = 'codes';
	}
	else
	{
		// Same sealed secret back so the member can simply try the next code
		$tfa_sealed = evebb_tfa_seal($tfa_uid, $tfa_secret);
		$tfa_error = 'That code was not right. Check the app and enter the current 6-digit code.';
		$tfa_view = 'qr';
	}
}

// Disable: requires a current code (TOTP or backup)
else if ($tfa_action === 'disable' && $tfa_row !== null)
{
	if (evebb_tfa_check_code($tfa_row, $_POST['tfa_code'] ?? ''))
	{
		evebb_tfa_disable($tfa_uid);
		redirect($tfa_self, 'Two-factor authentication is now disabled for your account. Redirecting …');
	}

	redirect($tfa_self, 'That code was not valid - nothing was changed. Redirecting …');
}

// Regenerate backup codes: requires a current code
else if ($tfa_action === 'regen' && $tfa_row !== null)
{
	if (evebb_tfa_check_code($tfa_row, $_POST['tfa_code'] ?? ''))
	{
		$tfa_codes = evebb_tfa_gen_backup($tfa_uid);
		$tfa_view = 'codes';
	}
	else
		redirect($tfa_self, 'That code was not valid - your backup codes are unchanged. Redirecting …');
}

$tfa_otpauth = 'otpauth://totp/'.rawurlencode($tfa_issuer.':'.$pun_user['username'])
	.'?secret='.$tfa_secret.'&issuer='.rawurlencode($tfa_issuer).'&digits=6&period=30';

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), 'Two-factor authentication');
define('PUN_ACTIVE_PAGE', 'index');
require PUN_ROOT.'header.php';

?>
<style>
.tfa-wrap p { margin: .6em 0; }
.tfa-wrap label { display: block; margin: .6em 0; }
#tfa-qr { margin: .8em 0; }
#tfa-qr img, #tfa-qr svg { border: 8px solid #fff; }
.tfa-secret { font-family: monospace; font-size: 1.15em; letter-spacing: .12em; background: rgba(128,128,128,.12); padding: .3em .6em; border-radius: 4px; display: inline-block; }
.tfa-codes { columns: 2; max-width: 24em; margin: .8em 0; padding: 0; list-style: none; }
.tfa-codes li { font-family: monospace; font-size: 1.15em; padding: .2em 0; }
.tfa-error { color: #b5443c; font-weight: bold; }
.tfa-on { color: #2f9e5f; font-weight: bold; }
</style>
<div class="block">
	<h2><span>Two-factor authentication</span></h2>
	<div class="box">
		<div class="inbox tfa-wrap">
<?php

if ($tfa_view == 'disabled')
{

?>
			<p>Two-factor authentication adds a second lock to your account: as well as your password, logging in needs a 6-digit code from an authenticator app on your phone (Google Authenticator, Authy, 1Password, Aegis and friends all work).</p>
			<p>You will get eight single-use backup codes in case you lose your phone, and the board staff can switch it off for you as a last resort.</p>
			<form method="post" action="<?php echo $tfa_self ?>">
				<input type="hidden" name="tfa_action" value="start" />
				<p><input type="submit" value="Start setup" /></p>
			</form>
<?php

}
else if ($tfa_view == 'qr')
{

?>
<?php if ($tfa_error != ''): ?>
			<p class="tfa-error"><?php echo pun_htmlspecialchars($tfa_error) ?></p>
<?php endif; ?>
			<p><strong>Step 1.</strong> Scan this QR code with your authenticator app:</p>
			<div id="tfa-qr"></div>
			<p>No camera? Add the account manually with this secret key:</p>
			<p><span class="tfa-secret"><?php echo pun_htmlspecialchars(trim(chunk_split($tfa_secret, 4, ' '))) ?></span></p>
			<p><strong>Step 2.</strong> Enter the 6-digit code the app shows, to prove the pairing worked:</p>
			<form method="post" action="<?php echo $tfa_self ?>">
				<input type="hidden" name="tfa_action" value="confirm" />
				<input type="hidden" name="tfa_seal" value="<?php echo pun_htmlspecialchars($tfa_sealed) ?>" />
				<label><input type="text" name="tfa_code" size="10" maxlength="8" autocomplete="one-time-code" inputmode="numeric" autofocus="autofocus" />
				<input type="submit" value="Confirm and enable" /></label>
			</form>
			<p><a href="<?php echo $tfa_self ?>">Cancel</a> — nothing is enabled until you confirm.</p>
			<script src="<?php echo $tfa_self ?>qr.js"></script>
			<script>
			(function () {
				var target = document.getElementById('tfa-qr');
				try {
					var qr = qrcode(0, 'M');
					qr.addData(<?php echo json_encode($tfa_otpauth, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES) ?>);
					qr.make();
					target.innerHTML = qr.createImgTag(4, 8);
				} catch (e) {
					target.textContent = 'QR rendering unavailable - use the manual key below.';
				}
			})();
			</script>
<?php

}
else if ($tfa_view == 'codes')
{

?>
			<p class="tfa-on">✓ Two-factor authentication is enabled for your account.</p>
			<p><strong>Your backup codes.</strong> Each works exactly once in place of an app code, and this is the only time they will be shown. Store them somewhere safe (a password manager, or print them):</p>
			<ul class="tfa-codes">
<?php foreach ($tfa_codes as $tfa_code_line): ?>
				<li><?php echo pun_htmlspecialchars($tfa_code_line) ?></li>
<?php endforeach; ?>
			</ul>
			<p>If you ever regenerate your backup codes, these ones stop working.</p>
			<p><a href="<?php echo $tfa_self ?>">Done</a></p>
<?php

}
else   // enabled
{

?>
			<p class="tfa-on">✓ Two-factor authentication is enabled for your account<?php if ((int) $tfa_row['enabled_at'] > 0) echo ' (since '.format_time($tfa_row['enabled_at']).')' ?>.</p>
			<p>Logging in needs your password plus a 6-digit code from your authenticator app, or one of your single-use backup codes.</p>
			<form method="post" action="<?php echo $tfa_self ?>">
				<input type="hidden" name="tfa_action" value="regen" />
				<label>Regenerate backup codes (invalidates the old ones) — confirm with a current code:<br />
				<input type="text" name="tfa_code" size="10" maxlength="12" autocomplete="one-time-code" />
				<input type="submit" value="Regenerate backup codes" /></label>
			</form>
			<form method="post" action="<?php echo $tfa_self ?>">
				<input type="hidden" name="tfa_action" value="disable" />
				<label>Switch two-factor authentication off — confirm with a current code:<br />
				<input type="text" name="tfa_code" size="10" maxlength="12" autocomplete="one-time-code" />
				<input type="submit" value="Disable two-factor authentication" /></label>
			</form>
			<p>Lost your phone and your backup codes? Contact the board staff, who can switch 2FA off for your account.</p>
<?php

}

?>
		</div>
	</div>
</div>
<?php

require PUN_ROOT.'footer.php';
