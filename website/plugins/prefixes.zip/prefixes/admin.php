<?php

/**
 * Topic Prefixes - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome (and inside a POST
 * form that footer.php injects the CSRF token into). $db, $pun_config and
 * $plugin_slug are available here.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

// The addon normally creates the tables on first page view, but make sure
// they exist even if the settings page is visited before that
evebb_prefixes_ensure_schema();

$pfx_back = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

//
// Normalise a comma-separated forum-id list
//
function evebb_prefixes_forum_list($raw)
{
	$forum_ids = array();
	foreach (explode(',', pun_trim((string) $raw)) as $part)
	{
		$part = (int) trim($part);
		if ($part > 0 && !in_array($part, $forum_ids))
			$forum_ids[] = $part;
	}

	return implode(',', $forum_ids);
}

// Add a new prefix
if (isset($_POST['add_prefix']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$name = pun_trim($_POST['pfx_new_name'] ?? '');
	if ($name === '' || pun_strlen($name) > 30)
		redirect($pfx_back, 'Give the new prefix a name of 1-30 characters. Redirecting …');

	$color = evebb_prefixes_color($_POST['pfx_new_color'] ?? '');
	$forums = evebb_prefixes_forum_list($_POST['pfx_new_forums'] ?? '');
	$pos = (int) ($_POST['pfx_new_pos'] ?? 0);

	$db->query('INSERT INTO '.$db->prefix.'prefixes (name, color, forums, disp_position) VALUES(\''.$db->escape($name).'\', \''.$db->escape($color).'\', \''.$db->escape($forums).'\', '.$pos.')') or error('Unable to add prefix', __FILE__, __LINE__, $db->error());

	redirect($pfx_back, 'Prefix added. Redirecting …');
}

// Save changes to the existing prefixes
if (isset($_POST['save_prefixes']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	foreach (evebb_prefixes_all() as $cur_prefix)
	{
		$pid = (int) $cur_prefix['id'];
		if (!isset($_POST['pfx_name_'.$pid]))
			continue;

		$name = pun_trim($_POST['pfx_name_'.$pid]);
		if ($name === '' || pun_strlen($name) > 30)
			$name = $cur_prefix['name'];

		$color = evebb_prefixes_color($_POST['pfx_color_'.$pid] ?? $cur_prefix['color']);
		$forums = evebb_prefixes_forum_list($_POST['pfx_forums_'.$pid] ?? $cur_prefix['forums']);
		$pos = (int) ($_POST['pfx_pos_'.$pid] ?? $cur_prefix['disp_position']);

		$db->query('UPDATE '.$db->prefix.'prefixes SET name=\''.$db->escape($name).'\', color=\''.$db->escape($color).'\', forums=\''.$db->escape($forums).'\', disp_position='.$pos.' WHERE id='.$pid) or error('Unable to update prefix', __FILE__, __LINE__, $db->error());
	}

	redirect($pfx_back, 'Prefixes saved. Redirecting …');
}

// Delete one prefix (buttons named pfxdel_<id>)
foreach ($_POST as $pfx_key => $pfx_unused)
{
	if (strpos($pfx_key, 'pfxdel_') === 0)
	{
		confirm_referrer('admin_plugins.php');
		check_csrf($_POST['csrf_token'] ?? null);

		$pid = (int) substr($pfx_key, 7);
		if ($pid > 0)
		{
			$db->query('DELETE FROM '.$db->prefix.'topic_prefixes WHERE prefix_id='.$pid) or error('Unable to delete prefix', __FILE__, __LINE__, $db->error());
			$db->query('DELETE FROM '.$db->prefix.'prefixes WHERE id='.$pid) or error('Unable to delete prefix', __FILE__, __LINE__, $db->error());
		}

		redirect($pfx_back, 'Prefix deleted. Redirecting …');
	}
}

// Remove prefix rows whose topics no longer exist
if (isset($_POST['purge_prefixes']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DELETE FROM '.$db->prefix.'topic_prefixes WHERE topic_id NOT IN (SELECT id FROM '.$db->prefix.'topics)') or error('Unable to purge prefix rows', __FILE__, __LINE__, $db->error());

	redirect($pfx_back, 'Orphaned prefix rows purged. Redirecting …');
}

// Remove ALL plugin data (before uninstalling)
if (isset($_POST['nuke_prefixes']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect($pfx_back, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('topic_prefixes');
	$db->drop_table('prefixes');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name=\'o_prefixes_db_rev\'') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());

	unset($pun_config['o_prefixes_db_rev']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Topic Prefixes data removed. You can now deactivate and delete the plugin. Redirecting …');
}

$all_prefixes = evebb_prefixes_all();

// Per-prefix topic counts
$counts = array();
$result = $db->query('SELECT prefix_id, COUNT(topic_id) AS n FROM '.$db->prefix.'topic_prefixes GROUP BY prefix_id') or error('Unable to count prefixed topics', __FILE__, __LINE__, $db->error());
while ($row = $db->fetch_assoc($result))
	$counts[(int) $row['prefix_id']] = (int) $row['n'];

// Forum reference list
$result = $db->query('SELECT f.id, f.forum_name, c.cat_name FROM '.$db->prefix.'forums AS f INNER JOIN '.$db->prefix.'categories AS c ON c.id=f.cat_id ORDER BY c.disp_position, c.id, f.disp_position') or error('Unable to fetch forum list', __FILE__, __LINE__, $db->error());
$forum_list = array();
while ($cur_forum = $db->fetch_assoc($result))
	$forum_list[] = $cur_forum;

?>
		<div class="inform">
			<fieldset>
				<legend>Your prefixes</legend>
				<div class="infldset">
					<p>Prefixes are defined once and mapped to forums (leave a prefix's forum list blank for every forum). Members pick one when starting a topic in a mapped forum; the topic starter and staff can change it later from the topic page. Forums with prefixes get a filter tab row above their topic list.</p>
<?php if (empty($all_prefixes)): ?>
					<p><em>No prefixes yet — add the first one below.</em></p>
<?php else: ?>
<?php foreach ($all_prefixes as $cur_prefix): $pid = (int) $cur_prefix['id']; ?>
					<p>
						<span style="display:inline-block;padding:0 .55em;border-radius:3px;color:#fff;font-weight:bold;background-color:<?php echo pun_htmlspecialchars(evebb_prefixes_color($cur_prefix['color'])) ?>;"><?php echo pun_htmlspecialchars($cur_prefix['name']) ?></span>
						(<?php echo isset($counts[$pid]) ? $counts[$pid] : 0 ?> topics) &mdash;
						name <input type="text" name="pfx_name_<?php echo $pid ?>" size="14" maxlength="30" value="<?php echo pun_htmlspecialchars($cur_prefix['name']) ?>" />
						colour <input type="color" name="pfx_color_<?php echo $pid ?>" value="<?php echo pun_htmlspecialchars(evebb_prefixes_color($cur_prefix['color'])) ?>" />
						forums <input type="text" name="pfx_forums_<?php echo $pid ?>" size="12" maxlength="255" value="<?php echo pun_htmlspecialchars($cur_prefix['forums']) ?>" />
						position <input type="text" name="pfx_pos_<?php echo $pid ?>" size="3" maxlength="4" value="<?php echo (int) $cur_prefix['disp_position'] ?>" />
						<input type="submit" name="pfxdel_<?php echo $pid ?>" value="Delete" />
					</p>
<?php endforeach; ?>
					<p class="topspace"><input type="submit" name="save_prefixes" value="Save prefix changes" /></p>
<?php endif; ?>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Add a prefix</legend>
				<div class="infldset">
					<p>
						name <input type="text" name="pfx_new_name" size="14" maxlength="30" value="" />
						colour <input type="color" name="pfx_new_color" value="#4a6d8c" />
						forums <input type="text" name="pfx_new_forums" size="12" maxlength="255" value="" />
						position <input type="text" name="pfx_new_pos" size="3" maxlength="4" value="0" />
						<input type="submit" name="add_prefix" value="Add prefix" />
					</p>
					<p>Forums is a comma-separated list of forum IDs; blank means the prefix is available everywhere. Lower positions sort first in dropdowns and tab rows.</p>
<?php if (count($forum_list)): ?>
					<p>For reference, your forums are:</p>
					<ul>
<?php foreach ($forum_list as $cur_forum): ?>
						<li><span><strong><?php echo (int) $cur_forum['id'] ?></strong> &mdash; <?php echo pun_htmlspecialchars($cur_forum['cat_name']) ?> / <?php echo pun_htmlspecialchars($cur_forum['forum_name']) ?></span></li>
<?php endforeach; ?>
					</ul>
<?php endif; ?>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Maintenance</legend>
				<div class="infldset">
					<p>Deleting a topic does not remove its prefix row (it is simply never shown again). Purging clears those leftovers.</p>
					<p><input type="submit" name="purge_prefixes" value="Purge orphaned prefix rows" /></p>
					<p class="topspace">To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the prefixes and topic_prefixes tables and the plugin's settings.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently deletes every prefix</label></p>
					<p><input type="submit" name="nuke_prefixes" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
