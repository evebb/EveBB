# Topic Prefixes

An unofficial [eveBB](https://evebb.net) plugin that adds admin-defined
coloured prefixes — like **[Bug]**, **[Question]** or **[Release]** — to
topics.

## Features

- Administrators define prefixes once (name + colour + display position)
  and map each to one or more forums (blank = every forum).
- Members starting a topic in a mapped forum pick a prefix — or none —
  from a dropdown on the new-topic form.
- The prefix renders as a coloured pill before the topic title in forum
  topic lists and in the topic page breadcrumbs.
- Forums with prefixes get an "All | Bug | Question | …" filter tab row
  above the topic list; tabs (and pills) open a paginated, filtered topic
  list at `plugins/prefixes/?forum=N&prefix=X` in full forum chrome.
- The topic starter can change (or remove) their topic's prefix from its
  page; moderators and administrators can change any topic's prefix.
- Deleting a prefix removes it from every topic that carried it.

## Installation

Upload `prefixes.zip` through **Administration → Plugins → Upload
plugin**, then activate it. The plugin creates its two database tables
(`prefixes`, `topic_prefixes`) automatically on first use. Then add your
prefixes on the settings page.

## Settings

**Administration → Plugins → Topic Prefixes → Settings**

- Add, edit (name/colour/forums/position) and delete prefixes, with live
  topic counts per prefix
- Maintenance: purge rows for deleted topics; full data removal for a
  clean uninstall

## Notes

- Prefixes are optional everywhere; a topic carries at most one.
- Picking and changing prefixes requires an account; guests see the pills
  and can use the filter pages.
- Filter pages respect forum permissions — an unreadable forum's filter
  page is a 404 for that viewer.
- Without JavaScript nothing breaks: the dropdown on the composer is
  server-rendered, and the filter pages are plain server-rendered HTML
  (the tab row on viewforum itself and the pills are JS decoration).

## License

GPL version 2 or higher, like eveBB itself.
