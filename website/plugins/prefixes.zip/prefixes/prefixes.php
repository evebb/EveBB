<?php

/**
 * Topic Prefixes - the addon.
 *
 * Administrators define a global list of coloured prefixes (name + colour)
 * and map each to one or more forums. Members starting a topic in a mapped
 * forum pick a prefix (or none) from a dropdown rendered server-side into
 * the new-topic form; the topic starter and forum staff can change it later
 * from the topic page. Prefix pills render before topic titles in forum
 * lists and in the topic-page breadcrumbs, and forums with prefixes get an
 * "All | Bug | Question | ..." tab row that filters through the standalone
 * list page at plugins/prefixes/ (viewforum's topic query has no hook, so
 * filtering gets its own page in full forum chrome instead - the tags
 * browse-page pattern).
 *
 * Wiring is the series' standard kit: post_before_submit renders the
 * field, post_after_validation validates it, a shutdown callback with a
 * fresh DB handle saves it once the topic id exists, and header_head_end
 * drives all page decoration and action handling.
 *
 * State: prefixes (id, name, color, forums, disp_position) and
 * topic_prefixes (topic_id PK, prefix_id), created automatically.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_prefixes extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
		$manager->bind('post_before_submit', array($this, 'post_form'));
		$manager->bind('post_after_validation', array($this, 'post_validate'));
	}

	function head()
	{
		// The hook can fire twice in one request when core re-includes
		// header.php (e.g. message() rendering an error page). Act once.
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		evebb_prefixes_ensure_schema();

		$page = isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : '';

		if ($page == 'viewtopic.php')
			$this->head_viewtopic();
		else if ($page == 'viewforum.php')
			$this->head_viewforum();
	}


	//
	// post.php (new topic only): render the prefix dropdown inside the
	// form when this forum has prefixes. Re-selects from $_POST on
	// preview or validation errors.
	//
	function post_form()
	{
		global $fid, $pun_user;

		if (empty($fid) || $pun_user['is_guest'])
			return;

		$choices = evebb_prefixes_for_forum($fid);
		if (empty($choices))
			return;

		$selected = isset($_POST['prefixes_id']) ? (int) $_POST['prefixes_id'] : 0;

?>
				<div class="inform" id="pfxcompose">
					<fieldset>
						<legend>Topic prefix (optional)</legend>
						<div class="infldset">
							<label>Prefix shown before this topic's title<br />
							<select name="prefixes_id">
								<option value="0"<?php if ($selected == 0) echo ' selected="selected"' ?>>&mdash; none &mdash;</option>
<?php foreach ($choices as $cur_prefix): ?>
								<option value="<?php echo (int) $cur_prefix['id'] ?>"<?php if ($selected == (int) $cur_prefix['id']) echo ' selected="selected"' ?>><?php echo pun_htmlspecialchars($cur_prefix['name']) ?></option>
<?php endforeach; ?>
							</select>
							<br /></label>
						</div>
					</fieldset>
				</div>
				<script>/* A prefix belongs before the title: move this block above
				the message box once the DOM is ready (no JS = it simply stays here) */
				document.addEventListener('DOMContentLoaded', function () {
					var block = document.getElementById('pfxcompose');
					var form = document.getElementById('post');
					if (!block || !form) return;
					var first = form.querySelector('div.inform');
					if (first && first !== block)
						first.parentNode.insertBefore(block, first);
				});</script>
<?php
	}


	//
	// post.php: validate the choice on submit/preview; stash for the
	// shutdown-time save on a valid, non-preview new topic
	//
	function post_validate()
	{
		global $errors, $fid, $pun_user;

		if (empty($fid) || $pun_user['is_guest'] || !isset($_POST['prefixes_id']))
			return;

		$prefix_id = (int) $_POST['prefixes_id'];
		if ($prefix_id == 0)
			return;

		if (!evebb_prefixes_valid_choice($prefix_id, $fid))
		{
			$errors[] = 'The chosen topic prefix is not available in this forum.';
			return;
		}

		if (!empty($errors) || isset($_POST['preview']))
			return;

		evebb_prefixes_ensure_schema();

		$GLOBALS['evebb_prefixes_pending'] = $prefix_id;

		register_shutdown_function(array('plugin_prefixes', 'save_pending'));
	}


	//
	// Shutdown callback: post.php has created the topic ($new_tid, global
	// scope) and exited through redirect(), which closed the request's DB
	// handle - open a fresh one and write the prefix row. (See the polls
	// plugin for the full story on this technique.)
	//
	static function save_pending()
	{
		if (!isset($GLOBALS['evebb_prefixes_pending']) || !isset($GLOBALS['new_tid']))
			return;

		$tid = (int) $GLOBALS['new_tid'];
		$prefix_id = (int) $GLOBALS['evebb_prefixes_pending'];

		if ($tid < 1 || $prefix_id < 1)
			return;

		global $db_type, $db_host, $db_username, $db_password, $db_name, $db_prefix, $p_connect;
		$db = null;
		require PUN_ROOT.'include/dblayer/common_db.php';

		if (!is_object($db))
			return;

		$db->start_transaction();
		evebb_prefixes_set_topic($db, $tid, $prefix_id);
		$db->end_transaction();
		$db->close();
	}


	//
	// viewtopic.php: handle a prefix change, then describe the topic's
	// prefix (and the viewer's powers) to the page JS
	//
	function head_viewtopic()
	{
		global $db, $pun_user, $cur_topic, $id, $is_admmod;

		// Defensive: these are set by viewtopic.php before header.php runs
		if (!isset($cur_topic) || !isset($id))
			return;

		// Who may change the prefix? Forum moderators/admins always; the
		// topic starter (registered users only) for their own topic
		$can_edit = !empty($is_admmod);

		if (!$can_edit && !$pun_user['is_guest'])
		{
			$result = $db->query('SELECT poster_id FROM '.$db->prefix.'posts WHERE id='.(int) $cur_topic['first_post_id']) or error('Unable to fetch topic starter', __FILE__, __LINE__, $db->error());
			$starter_id = $db->has_rows($result) ? (int) $db->result($result) : 0;

			if ($starter_id > 1 && $starter_id == (int) $pun_user['id'])
				$can_edit = true;
		}

		// A change request? (POST - the global CSRF gate has already
		// validated the token.) Exits on every well-formed request.
		if ($can_edit && isset($_POST['prefixes_action']) && $_POST['prefixes_action'] === 'save')
			$this->handle_save((int) $id, (int) $cur_topic['forum_id']);

		$prefix = evebb_prefixes_topic($id);
		$choices = $can_edit ? evebb_prefixes_for_forum($cur_topic['forum_id']) : array();

		if ($prefix === null && empty($choices))
			return;

		$options = array();
		foreach ($choices as $cur_prefix)
			$options[] = array('id' => (int) $cur_prefix['id'], 'name' => $cur_prefix['name']);

		$this->emit(array(
			'page'    => 'topic',
			'topic'   => (int) $id,
			'prefix'  => ($prefix !== null) ? array('id' => (int) $prefix['id'], 'name' => $prefix['name'], 'color' => $prefix['color']) : null,
			'canEdit' => $can_edit && !empty($options),
			'options' => $options,
			'token'   => $can_edit ? pun_csrf_token() : ''
		));
	}


	//
	// Validate and apply a prefix change, then redirect. Every path exits.
	//
	function handle_save($tid, $forum_id)
	{
		global $db;

		while (ob_get_level() > 0)
			ob_end_clean();

		$prefix_id = isset($_POST['prefixes_id']) ? (int) $_POST['prefixes_id'] : -1;

		if ($prefix_id < 0 || !evebb_prefixes_valid_choice($prefix_id, $forum_id))
			redirect('viewtopic.php?id='.$tid, 'That prefix is not available here. Redirecting …');

		$db->start_transaction();
		evebb_prefixes_set_topic($db, $tid, $prefix_id);
		$db->end_transaction();

		redirect('viewtopic.php?id='.$tid, 'Prefix saved. Redirecting …');
	}


	//
	// viewforum.php: emit the filter tabs and this forum's topic => prefix
	// map (recent topics first, defensively bounded)
	//
	function head_viewforum()
	{
		global $db, $id;

		if (!isset($id))
			return;

		$choices = evebb_prefixes_for_forum($id);
		if (empty($choices))
			return;

		$tabs = array();
		foreach ($choices as $cur_prefix)
			$tabs[] = array('id' => (int) $cur_prefix['id'], 'name' => $cur_prefix['name'], 'color' => $cur_prefix['color']);

		$result = $db->query('SELECT tp.topic_id, p.name, p.color FROM '.$db->prefix.'topic_prefixes AS tp INNER JOIN '.$db->prefix.'topics AS t ON t.id=tp.topic_id INNER JOIN '.$db->prefix.'prefixes AS p ON p.id=tp.prefix_id WHERE t.forum_id='.(int) $id.' ORDER BY t.last_post DESC LIMIT 1500') or error('Unable to fetch forum prefixes', __FILE__, __LINE__, $db->error());

		$map = array();
		while ($row = $db->fetch_assoc($result))
			$map[(int) $row['topic_id']] = array('n' => $row['name'], 'c' => $row['color']);

		$this->emit(array(
			'page'  => 'forum',
			'forum' => (int) $id,
			'tabs'  => $tabs,
			'map'   => $map
		));
	}


	//
	// Emit the shared CSS plus the page JS with its config blob into <head>
	//
	function emit($cfg)
	{
		$json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

		echo '<style>'
			.'.pfxpill{display:inline-block;padding:0 .55em;border-radius:3px;color:#fff;font-size:.85em;font-weight:bold;margin-right:.45em;white-space:nowrap;vertical-align:baseline}'
			.'a.pfxpill{text-decoration:none}'
			.'.pfxtabs{margin:0 0 .5em}'
			.'.pfxtabs a{display:inline-block;padding:.2em .8em;border:1px solid rgba(110,130,150,.5);border-radius:4px;margin:0 .3em .3em 0;text-decoration:none;font-size:.95em}'
			.'.pfxtabs a.pfxcurrent{font-weight:bold;border-color:rgba(82,126,180,.9);background:rgba(82,126,180,.15)}'
			.'.pfxtabs .pfxswatch{display:inline-block;width:.65em;height:.65em;border-radius:2px;margin-right:.35em}'
			.'.pfxchange{font-size:.85em;font-weight:normal;margin-left:.5em}'
			.'.pfxform{display:inline;font-size:.85em;font-weight:normal;margin-left:.5em}'
			.'</style>'."\n";

		echo '<script>/* Topic Prefixes plugin */'."\n".'(function(){'."\n"
			.'var cfg = '.$json.';'."\n"
			.<<<'EOJS'
function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

function el(tag, cls, text) {
	var e = document.createElement(tag);
	if (cls) e.className = cls;
	if (text) e.textContent = text;
	return e;
}

function pill(name, color, href) {
	var e = href ? document.createElement('a') : document.createElement('span');
	if (href) e.href = href;
	e.className = 'pfxpill';
	e.textContent = name;
	e.style.backgroundColor = color;
	return e;
}

function filterUrl(forum, prefixId) {
	return 'plugins/prefixes/?forum=' + forum + '&prefix=' + prefixId;
}

// ---- viewforum: tab row above the list + pills before topic titles ---------
function forumPage() {
	var vf = document.getElementById('vf');
	if (vf) {
		var tabs = el('div', 'pfxtabs');
		tabs.id = 'pfxtabs';
		var all = document.createElement('a');
		all.href = 'viewforum.php?id=' + cfg.forum;
		all.className = 'pfxcurrent';
		all.textContent = 'All';
		tabs.appendChild(all);
		for (var i = 0; i < cfg.tabs.length; i++) {
			var t = cfg.tabs[i];
			var a = document.createElement('a');
			a.href = filterUrl(cfg.forum, t.id);
			var sw = el('span', 'pfxswatch');
			sw.style.backgroundColor = t.color;
			a.appendChild(sw);
			a.appendChild(document.createTextNode(t.name));
			tabs.appendChild(a);
		}
		vf.parentNode.insertBefore(tabs, vf);
	}

	var links = document.querySelectorAll('#vf div.tclcon a');
	for (var j = 0; j < links.length; j++) {
		var m = /^viewtopic\.php\?id=(\d+)$/.exec(links[j].getAttribute('href') || '');
		if (!m || !cfg.map[m[1]]) continue;
		var info = cfg.map[m[1]];
		var pfxId = null;
		for (var k = 0; k < cfg.tabs.length; k++) if (cfg.tabs[k].name === info.n) pfxId = cfg.tabs[k].id;
		links[j].parentNode.insertBefore(pill(info.n, info.c, pfxId !== null ? filterUrl(cfg.forum, pfxId) : null), links[j]);
		delete cfg.map[m[1]]; // once per topic (skips same-row pagination links anyway)
	}
}

// ---- viewtopic: pill in the breadcrumbs + in-place change control ----------
function topicPage() {
	var crumb = document.querySelector('.linkst .crumbs li strong');
	if (!crumb) return;

	var holder = el('span');
	holder.id = 'pfxholder';
	crumb.parentNode.insertBefore(holder, crumb);

	function view() {
		holder.textContent = '';
		if (cfg.prefix) holder.appendChild(pill(cfg.prefix.name, cfg.prefix.color, null));
		if (cfg.canEdit) {
			var change = document.createElement('a');
			change.href = '#';
			change.className = 'pfxchange';
			change.textContent = cfg.prefix ? 'change prefix' : 'set prefix';
			change.addEventListener('click', function (e) { e.preventDefault(); form(); });
			// The link reads better after the title, so hang it off the crumb
			crumb.parentNode.appendChild(change);
			holder.changeLink = change;
		}
	}

	function form() {
		if (holder.changeLink) holder.changeLink.style.display = 'none';
		var f = document.createElement('form');
		f.className = 'pfxform';
		f.method = 'post';
		f.action = 'viewtopic.php?id=' + cfg.topic;
		var h1 = document.createElement('input');
		h1.type = 'hidden'; h1.name = 'prefixes_action'; h1.value = 'save';
		f.appendChild(h1);
		var h2 = document.createElement('input');
		h2.type = 'hidden'; h2.name = 'csrf_token'; h2.value = cfg.token;
		f.appendChild(h2);
		var sel = document.createElement('select');
		sel.name = 'prefixes_id';
		var none = document.createElement('option');
		none.value = '0';
		none.textContent = '— none —';
		sel.appendChild(none);
		for (var i = 0; i < cfg.options.length; i++) {
			var o = document.createElement('option');
			o.value = String(cfg.options[i].id);
			o.textContent = cfg.options[i].name;
			if (cfg.prefix && cfg.prefix.id === cfg.options[i].id) o.selected = true;
			sel.appendChild(o);
		}
		f.appendChild(sel);
		f.appendChild(document.createTextNode(' '));
		var save = document.createElement('input');
		save.type = 'submit'; save.value = 'Save';
		f.appendChild(save);
		crumb.parentNode.appendChild(f);
	}

	view();
}

ready(function () { if (cfg.page === 'forum') forumPage(); else topicPage(); });
EOJS
			."\n".'})();</script>'."\n";
	}
}
