<?php

/**
 * Topic Prefixes - shared library.
 *
 * Schema management and helpers used by the addon (prefixes.php), the
 * filtered-list page (index.php) and the settings page (admin.php).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


//
// Create the prefix tables on first use. Guarded by the o_prefixes_db_rev
// config key so the check is free on every later request.
//
function evebb_prefixes_ensure_schema()
{
	global $db, $pun_config;

	if (isset($pun_config['o_prefixes_db_rev']))
		return;

	if (!$db->table_exists('prefixes'))
	{
		$schema = array(
			'FIELDS' => array(
				'id' => array(
					'datatype'   => 'SERIAL',
					'allow_null' => false
				),
				'name' => array(
					'datatype'   => 'VARCHAR(30)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'color' => array(
					'datatype'   => 'VARCHAR(7)',
					'allow_null' => false,
					'default'    => '\'#4a6d8c\''
				),
				'forums' => array(
					'datatype'   => 'VARCHAR(255)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'disp_position' => array(
					'datatype'   => 'INT(10)',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('id')
		);

		$db->create_table('prefixes', $schema) or error('Unable to create the prefixes table', __FILE__, __LINE__, $db->error());
	}

	if (!$db->table_exists('topic_prefixes'))
	{
		$schema = array(
			'FIELDS' => array(
				'topic_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'prefix_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('topic_id'),
			'INDEXES' => array(
				'prefix_id_idx' => array('prefix_id')
			)
		);

		$db->create_table('topic_prefixes', $schema) or error('Unable to create the topic_prefixes table', __FILE__, __LINE__, $db->error());
	}

	// Record the schema revision. No or-error here: if two requests race,
	// the loser's duplicate insert may fail and that is fine.
	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_prefixes_db_rev\', \'1\')');
	$pun_config['o_prefixes_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Every prefix, in display order
//
function evebb_prefixes_all()
{
	global $db;

	$result = $db->query('SELECT id, name, color, forums, disp_position FROM '.$db->prefix.'prefixes ORDER BY disp_position, name') or error('Unable to fetch prefixes', __FILE__, __LINE__, $db->error());

	$prefixes = array();
	while ($row = $db->fetch_assoc($result))
		$prefixes[] = $row;

	return $prefixes;
}


//
// The prefixes available in one forum (a prefix's blank forum list means
// it appears in every forum)
//
function evebb_prefixes_for_forum($forum_id)
{
	$forum_id = (int) $forum_id;
	$out = array();

	foreach (evebb_prefixes_all() as $prefix)
	{
		$list = trim($prefix['forums']);
		if ($list === '' || in_array($forum_id, array_map('intval', explode(',', $list)), true))
			$out[] = $prefix;
	}

	return $out;
}


//
// One prefix by id, or null
//
function evebb_prefixes_get($id)
{
	global $db;

	$result = $db->query('SELECT id, name, color, forums, disp_position FROM '.$db->prefix.'prefixes WHERE id='.(int) $id) or error('Unable to fetch prefix', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? $db->fetch_assoc($result) : null;
}


//
// A topic's prefix (id, name, color), or null
//
function evebb_prefixes_topic($topic_id)
{
	global $db;

	$result = $db->query('SELECT p.id, p.name, p.color FROM '.$db->prefix.'topic_prefixes AS tp INNER JOIN '.$db->prefix.'prefixes AS p ON p.id=tp.prefix_id WHERE tp.topic_id='.(int) $topic_id) or error('Unable to fetch topic prefix', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? $db->fetch_assoc($result) : null;
}


//
// Set (or clear, with 0) a topic's prefix
//
function evebb_prefixes_set_topic($db, $topic_id, $prefix_id)
{
	$topic_id = (int) $topic_id;
	$prefix_id = (int) $prefix_id;

	$db->query('DELETE FROM '.$db->prefix.'topic_prefixes WHERE topic_id='.$topic_id);

	if ($prefix_id > 0)
		$db->query('INSERT INTO '.$db->prefix.'topic_prefixes (topic_id, prefix_id) VALUES('.$topic_id.', '.$prefix_id.')');
}


//
// Normalise a colour value to #rrggbb, or fall back to the default
//
function evebb_prefixes_color($raw)
{
	$raw = pun_trim((string) $raw);

	return preg_match('%^#[0-9a-fA-F]{6}$%', $raw) ? strtolower($raw) : '#4a6d8c';
}


//
// Is the given prefix id valid for this forum? (0 = "no prefix" is always
// allowed)
//
function evebb_prefixes_valid_choice($prefix_id, $forum_id)
{
	$prefix_id = (int) $prefix_id;

	if ($prefix_id == 0)
		return true;

	foreach (evebb_prefixes_for_forum($forum_id) as $prefix)
	{
		if ((int) $prefix['id'] == $prefix_id)
			return true;
	}

	return false;
}
