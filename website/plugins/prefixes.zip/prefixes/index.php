<?php

/**
 * Topic Prefixes - the filtered topic list.
 *
 *   <board>/plugins/prefixes/?forum=N&prefix=X
 *
 * One forum's topics carrying one prefix, in full forum chrome, paginated,
 * with the same All/prefix tab row viewforum shows. viewforum's own topic
 * query has no hook, so filtering lives here (the tags browse-page
 * pattern). Viewer permissions are enforced: an unreadable forum is a 404.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

//
// Absolutize relative href/src so forum chrome works from /plugins/prefixes/
//
function prefixes_absolutize($html)
{
	$base = get_base_url(true).'/';

	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('prefixes_absolutize');

if (!in_array('prefixes', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

evebb_prefixes_ensure_schema();

$pfx_base = get_base_url(true);

// The forum must exist, not be a redirect, and be readable by this viewer
$forum_id = isset($_GET['forum']) ? (int) $_GET['forum'] : 0;
$result = $db->query('SELECT f.id, f.forum_name FROM '.$db->prefix.'forums AS f LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.(int) $pun_user['g_id'].') WHERE (fp.read_forum IS NULL OR fp.read_forum=\'1\') AND f.redirect_url IS NULL AND f.id='.$forum_id) or error('Unable to fetch forum info', __FILE__, __LINE__, $db->error());
if (!$db->has_rows($result))
	message($lang_common['Bad request'], false, '404 Not Found');
$cur_forum = $db->fetch_assoc($result);

// The prefix must exist and be mapped to this forum
$prefix_id = isset($_GET['prefix']) ? (int) $_GET['prefix'] : 0;
$cur_prefix = null;
foreach (evebb_prefixes_for_forum($forum_id) as $checked)
{
	if ((int) $checked['id'] == $prefix_id)
		$cur_prefix = $checked;
}
if ($cur_prefix === null)
	message($lang_common['Bad request'], false, '404 Not Found');

// Count and fetch the filtered topics
$result = $db->query('SELECT COUNT(t.id) FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'topic_prefixes AS tp ON tp.topic_id=t.id WHERE t.forum_id='.$forum_id.' AND tp.prefix_id='.$prefix_id.' AND t.moved_to IS NULL') or error('Unable to count topics', __FILE__, __LINE__, $db->error());
$num_topics = (int) $db->result($result);

$disp = max(10, (int) $pun_user['disp_topics']);
$num_pages = (int) ceil($num_topics / $disp);
$p = (isset($_GET['p']) && (int) $_GET['p'] > 0) ? (int) $_GET['p'] : 1;
if ($num_pages > 0 && $p > $num_pages)
	$p = $num_pages;
$start_from = $disp * ($p - 1);

$paging_links = '<span class="pages-label">'.$lang_common['Pages'].' </span>'.paginate(max(1, $num_pages), $p, $pfx_base.'/plugins/prefixes/?forum='.$forum_id.'&amp;prefix='.$prefix_id);

$rows = array();
if ($num_topics > 0)
{
	$result = $db->query('SELECT t.id, t.subject, t.poster, t.num_replies, t.last_post, t.sticky FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'topic_prefixes AS tp ON tp.topic_id=t.id WHERE t.forum_id='.$forum_id.' AND tp.prefix_id='.$prefix_id.' AND t.moved_to IS NULL ORDER BY t.sticky DESC, t.last_post DESC LIMIT '.$disp.' OFFSET '.$start_from) or error('Unable to fetch topics', __FILE__, __LINE__, $db->error());
	while ($row = $db->fetch_assoc($result))
		$rows[] = $row;
}

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), pun_htmlspecialchars($cur_forum['forum_name']), pun_htmlspecialchars($cur_prefix['name']));
define('PUN_ACTIVE_PAGE', 'index');
define('PUN_ALLOW_INDEX', 1);
require PUN_ROOT.'header.php';

?>
<style>
.pfxpill { display: inline-block; padding: 0 .55em; border-radius: 3px; color: #fff; font-size: .85em; font-weight: bold; margin-right: .45em; white-space: nowrap; }
.pfxtabs { margin: 0 0 .5em; }
.pfxtabs a { display: inline-block; padding: .2em .8em; border: 1px solid rgba(110,130,150,.5); border-radius: 4px; margin: 0 .3em .3em 0; text-decoration: none; font-size: .95em; }
.pfxtabs a.pfxcurrent { font-weight: bold; border-color: rgba(82,126,180,.9); background: rgba(82,126,180,.15); }
.pfxtabs .pfxswatch { display: inline-block; width: .65em; height: .65em; border-radius: 2px; margin-right: .35em; }
.pfxlist table { width: 100%; border-collapse: collapse; }
.pfxlist th, .pfxlist td { text-align: left; padding: .45em .6em; border-bottom: 1px solid rgba(128,128,128,.25); font-size: .95em; }
.pfxlist th { font-size: .85em; text-transform: uppercase; letter-spacing: .04em; opacity: .75; }
.pfxlist td.tnum { text-align: right; white-space: nowrap; }
</style>
<div class="linkst">
	<div class="inbox">
		<?php echo $paging_links."\n" ?>
	</div>
</div>
<div class="block">
	<h2><span><?php echo pun_htmlspecialchars($cur_forum['forum_name']) ?> &mdash; <?php echo pun_htmlspecialchars($cur_prefix['name']) ?> (<?php echo $num_topics ?>)</span></h2>
	<div class="box">
		<div class="inbox pfxlist">
			<div class="pfxtabs">
				<a href="<?php echo $pfx_base ?>/viewforum.php?id=<?php echo $forum_id ?>">All</a>
<?php foreach (evebb_prefixes_for_forum($forum_id) as $tab): ?>
				<a<?php if ((int) $tab['id'] == $prefix_id) echo ' class="pfxcurrent"' ?> href="<?php echo $pfx_base ?>/plugins/prefixes/?forum=<?php echo $forum_id ?>&amp;prefix=<?php echo (int) $tab['id'] ?>"><span class="pfxswatch" style="background-color: <?php echo pun_htmlspecialchars(evebb_prefixes_color($tab['color'])) ?>;"></span><?php echo pun_htmlspecialchars($tab['name']) ?></a>
<?php endforeach; ?>
			</div>
<?php

if (empty($rows))
	echo "\t\t\t".'<p>No topics carry this prefix yet.</p>'."\n";
else
{
	echo "\t\t\t".'<table>'."\n\t\t\t\t".'<tr><th>Topic</th><th>Started by</th><th class="tnum">Replies</th><th>Last post</th></tr>'."\n";
	foreach ($rows as $row)
	{
		echo "\t\t\t\t".'<tr>'
			.'<td><span class="pfxpill" style="background-color: '.pun_htmlspecialchars(evebb_prefixes_color($cur_prefix['color'])).';">'.pun_htmlspecialchars($cur_prefix['name']).'</span><a href="'.$pfx_base.'/viewtopic.php?id='.(int) $row['id'].'">'.pun_htmlspecialchars($row['subject']).'</a>'.($row['sticky'] == '1' ? ' <em>(sticky)</em>' : '').'</td>'
			.'<td>'.pun_htmlspecialchars($row['poster']).'</td>'
			.'<td class="tnum">'.(int) $row['num_replies'].'</td>'
			.'<td>'.format_time($row['last_post']).'</td>'
			.'</tr>'."\n";
	}
	echo "\t\t\t".'</table>'."\n";
}

?>
		</div>
	</div>
</div>
<div class="linksb">
	<div class="inbox">
		<?php echo $paging_links."\n" ?>
	</div>
</div>
<?php

require PUN_ROOT.'footer.php';
