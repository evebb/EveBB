<?php

/**
 * Solved Topics (Best Answer) - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome (and inside a POST
 * form that footer.php injects the CSRF token into). $db, $pun_config and
 * $plugin_slug are available here.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

// The addon normally creates the table on first page view, but make sure it
// exists even if the settings page is visited before the plugin is activated
evebb_solved_ensure_schema();

// Save settings
if (isset($_POST['save_solved']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	evebb_solved_save_conf('o_solved_starter', isset($_POST['solved_starter']) ? '1' : '0');
	evebb_solved_save_conf('o_solved_listmark', isset($_POST['solved_listmark']) ? '1' : '0');
	evebb_solved_save_conf('o_solved_pin', isset($_POST['solved_pin']) ? '1' : '0');

	// Forum list: keep only digits and commas, normalise
	$forums_raw = pun_trim($_POST['solved_forums'] ?? '');
	$forum_ids = array();
	foreach (explode(',', $forums_raw) as $part)
	{
		$part = (int) trim($part);
		if ($part > 0 && !in_array($part, $forum_ids))
			$forum_ids[] = $part;
	}
	evebb_solved_save_conf('o_solved_forums', implode(',', $forum_ids));

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}

// Remove solved marks whose topics no longer exist
if (isset($_POST['purge_solved']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DELETE FROM '.$db->prefix.'solved_topics WHERE topic_id NOT IN (SELECT id FROM '.$db->prefix.'topics)') or error('Unable to purge solved marks', __FILE__, __LINE__, $db->error());

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Orphaned solved marks purged. Redirecting …');
}

// Remove ALL plugin data (before uninstalling)
if (isset($_POST['nuke_solved']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('solved_topics');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN (\'o_solved_db_rev\', \'o_solved_starter\', \'o_solved_listmark\', \'o_solved_pin\', \'o_solved_forums\')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());

	unset($pun_config['o_solved_db_rev'], $pun_config['o_solved_starter'], $pun_config['o_solved_listmark'], $pun_config['o_solved_pin'], $pun_config['o_solved_forums']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Solved Topics data removed. You can now deactivate and delete the plugin. Redirecting …');
}

$solved_starter  = evebb_solved_conf('o_solved_starter', '1') == '1';
$solved_listmark = evebb_solved_conf('o_solved_listmark', '1') == '1';
$solved_pin      = evebb_solved_conf('o_solved_pin', '1') == '1';
$solved_forums   = evebb_solved_conf('o_solved_forums', '');

// How many topics are currently marked solved?
$result = $db->query('SELECT COUNT(*) FROM '.$db->prefix.'solved_topics') or error('Unable to count solved topics', __FILE__, __LINE__, $db->error());
$solved_count = (int) $db->result($result);

// Forum reference list for the restriction field
$result = $db->query('SELECT f.id, f.forum_name, c.cat_name FROM '.$db->prefix.'forums AS f INNER JOIN '.$db->prefix.'categories AS c ON c.id=f.cat_id ORDER BY c.disp_position, c.id, f.disp_position') or error('Unable to fetch forum list', __FILE__, __LINE__, $db->error());
$forum_list = array();
while ($cur_forum = $db->fetch_assoc($result))
	$forum_list[] = $cur_forum;

?>
		<div class="inform">
			<fieldset>
				<legend>Solved Topics settings</legend>
				<div class="infldset">
					<p>Topics currently marked solved: <strong><?php echo $solved_count ?></strong>. Moderators and administrators can always mark and unmark a best answer in the forums where the plugin is enabled.</p>
					<label><input type="checkbox" name="solved_starter" value="1"<?php if ($solved_starter) echo ' checked="checked"' ?> /> Let the topic starter mark a best answer in their own topics</label>
					<label><input type="checkbox" name="solved_listmark" value="1"<?php if ($solved_listmark) echo ' checked="checked"' ?> /> Show a green ✓ before solved topics in forum topic lists</label>
					<label><input type="checkbox" name="solved_pin" value="1"<?php if ($solved_pin) echo ' checked="checked"' ?> /> Pin a copy of the best answer directly under the first post</label>
					<label>Only enable in these forums (comma-separated forum IDs; leave blank for all forums)
						<br /><input type="text" name="solved_forums" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($solved_forums) ?>" />
					</label>
<?php if (count($forum_list)): ?>
					<p>For reference, your forums are:</p>
					<ul>
<?php foreach ($forum_list as $cur_forum): ?>
						<li><span><strong><?php echo (int) $cur_forum['id'] ?></strong> — <?php echo pun_htmlspecialchars($cur_forum['cat_name']) ?> / <?php echo pun_htmlspecialchars($cur_forum['forum_name']) ?></span></li>
<?php endforeach; ?>
					</ul>
<?php endif; ?>
					<p class="topspace"><input type="submit" name="save_solved" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Maintenance</legend>
				<div class="infldset">
					<p>Deleting a topic does not remove its solved mark (the mark is simply never shown again). Purging clears those leftover rows.</p>
					<p><input type="submit" name="purge_solved" value="Purge orphaned solved marks" /></p>
					<p class="topspace">To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the solved_topics table and all of this plugin's settings.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently deletes every solved mark</label></p>
					<p><input type="submit" name="nuke_solved" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
