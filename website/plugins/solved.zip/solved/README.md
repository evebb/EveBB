# Solved Topics (Best Answer) — unofficial eveBB plugin

Lets the topic starter or a moderator mark one reply as the accepted answer
of a topic. Ideal for support forums.

When a topic is solved:

- a green banner appears under the first post naming the answerer, with a
  jump link to the answer (wherever it is, even on another page),
- a copy of the best answer is pinned directly under the first post
  (optional, on by default),
- the answering post itself is highlighted with a green outline and a
  "✓ Best answer" badge,
- the topic gets a green ✓ before its title in the forum's topic list
  (optional, on by default).

Marking is done with a "Mark as best answer" link in the footer of every
reply (never the first post — a question can't answer itself). The link is
shown to moderators/administrators of the forum, and — unless disabled in
the settings — to the topic's starter in their own topics. Marking a
different reply simply moves the mark; "Unmark best answer" removes it.
All actions are CSRF-protected and re-validated server-side.

## Requirements

- eveBB 2.0 or later (built and tested against 2.0.0-beta.1).
- No external services, no additional libraries. Works with all supported
  database drivers (SQLite, MySQL/MariaDB, PostgreSQL).

## Installation

1. Administration → Plugins → upload `solved.zip` (or unzip it so the
   `solved/` folder sits inside your board's `plugins/` directory).
2. Activate **Solved Topics (Best Answer)**.
3. (Optional) Open its **Settings** page to restrict it to specific forums
   (e.g. your support forums), disable the topic-list tick, disable the
   pinned copy, or forbid topic starters from marking.

The plugin creates its one database table (`solved_topics`) automatically
on the first page view after activation.

## Settings

- **Topic starter may mark** (default on) — whether the person who opened
  the topic can pick the best answer themselves. Moderators and admins
  always can.
- **Topic-list tick** (default on) — the green ✓ before solved topics in
  viewforum.
- **Pin the answer** (default on) — show a copy of the best answer under
  the first post. With this off you still get the banner + jump link.
- **Forum restriction** (default: all forums) — comma-separated forum IDs;
  the settings page lists your forums with their IDs for reference.

## Behaviour notes

- Topic starters can mark a best answer even in a closed topic (moderators
  often close a topic precisely because it was solved). If you don't want
  that, turn off starter marking.
- If the best-answer post is deleted (or split into another topic), the
  solved mark quietly removes itself the next time the topic is viewed.
- Deleting a whole topic leaves an invisible leftover row; the settings
  page has a one-click purge for those.
- The topic-page decorations are applied by a small piece of JavaScript
  emitted into the page head; with JavaScript disabled the forum works
  exactly as before (the solved state is simply not shown).

## Uninstalling

Use **Remove all plugin data** on the settings page first (drops the
`solved_topics` table and the plugin's config values), then deactivate and
delete the plugin from the plugins page. If you skip the first step the
data stays put and reappears if you ever reinstall the plugin — which is
also handy for reinstalls/upgrades: deleting and re-uploading the plugin
never loses your solved marks.

## License

GPL v2 or later, same as eveBB. This is an unofficial plugin, maintained
personally by Alan Paynter — it is not part of the eveBB core distribution.
