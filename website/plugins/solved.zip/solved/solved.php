<?php

/**
 * Solved Topics (Best Answer) - the addon.
 *
 * Lets the topic starter or a moderator mark one reply as the accepted
 * answer. The answer is pinned under the first post, the answering post is
 * highlighted, and solved topics get a green tick in the topic list.
 *
 * How it works: everything hangs off the header_head_end hook, which fires
 * on every page while output is still buffered (so redirects are safe).
 * On viewtopic.php the plugin handles mark/unmark actions server-side and
 * emits a small config blob plus CSS/JS into <head>; the JS decorates the
 * rendered page (banner, highlight, pinned copy, footer links). On
 * viewforum.php it emits the list of solved topic IDs for the tick marks.
 *
 * State lives in one extra table, solved_topics (topic_id PK, post_id,
 * marked_by, marked_at), created automatically on first use.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_solved extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		// The hook can fire twice in one request when core re-includes
		// header.php (e.g. message() rendering an error page). Act once.
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		evebb_solved_ensure_schema();

		$page = isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : '';

		if ($page == 'viewtopic.php')
			$this->head_viewtopic();
		else if ($page == 'viewforum.php')
			$this->head_viewforum();
	}


	//
	// viewtopic.php: handle mark/unmark actions, then describe the topic's
	// solved state (and the viewer's powers) to the page JS
	//
	function head_viewtopic()
	{
		global $db, $pun_user, $cur_topic, $id, $is_admmod;

		// Defensive: these are set by viewtopic.php before header.php runs
		if (!isset($cur_topic) || !isset($id))
			return;

		if (!evebb_solved_forum_enabled($cur_topic['forum_id']))
			return;

		$first_post_id = (int) $cur_topic['first_post_id'];

		// Who may mark? Moderators/admins of this forum always; the topic
		// starter when the setting allows it (registered users only)
		$can_mark = !empty($is_admmod);

		if (!$can_mark && !$pun_user['is_guest'] && evebb_solved_conf('o_solved_starter', '1') == '1')
		{
			$result = $db->query('SELECT poster_id FROM '.$db->prefix.'posts WHERE id='.$first_post_id) or error('Unable to fetch topic starter', __FILE__, __LINE__, $db->error());
			$starter_id = $db->has_rows($result) ? (int) $db->result($result) : 0;

			if ($starter_id > 1 && $starter_id == (int) $pun_user['id'])
				$can_mark = true;
		}

		// A mark/unmark request? (Only ever reachable through links we
		// rendered, but re-checked fully here.) Exits on success.
		if ($can_mark && isset($_GET['solved_action']))
			$this->handle_action((int) $id, $first_post_id);

		// Current solved state; self-heal if the answer post was deleted
		// or split away into another topic
		$solved = null;
		$result = $db->query('SELECT s.post_id, p.poster, p.posted, p.topic_id FROM '.$db->prefix.'solved_topics AS s LEFT JOIN '.$db->prefix.'posts AS p ON p.id=s.post_id WHERE s.topic_id='.(int) $id) or error('Unable to fetch solved state', __FILE__, __LINE__, $db->error());

		if ($db->has_rows($result))
		{
			$row = $db->fetch_assoc($result);

			if ($row['topic_id'] === null || (int) $row['topic_id'] != (int) $id)
				$db->query('DELETE FROM '.$db->prefix.'solved_topics WHERE topic_id='.(int) $id) or error('Unable to clean up solved state', __FILE__, __LINE__, $db->error());
			else
				$solved = $row;
		}

		// Nothing to show and nothing the viewer can do
		if ($solved === null && !$can_mark)
			return;

		$cfg = array(
			'page'    => 'topic',
			'topic'   => (int) $id,
			'first'   => $first_post_id,
			'canMark' => $can_mark,
			'token'   => $can_mark ? pun_csrf_token() : '',
			'pin'     => evebb_solved_conf('o_solved_pin', '1') == '1',
			'solved'  => ($solved !== null) ? array(
				'pid'    => (int) $solved['post_id'],
				'by'     => $solved['poster'],
				'posted' => format_time($solved['posted'])
			) : null,
			'text'    => array(
				'mark'   => 'Mark as best answer',
				'unmark' => 'Unmark best answer',
				'badge'  => 'Best answer',
				'by'     => 'Best answer by',
				'jump'   => 'Jump to best answer',
				'solvedTick' => 'Solved'
			)
		);

		$this->emit($cfg);
	}


	//
	// Validate and perform a mark/unmark, then redirect. Never returns on a
	// well-formed request. Output so far is still buffered (we are inside
	// header.php's <pun_head> substitution), so it is safe to throw it away
	// and redirect - both redirect() and message() end the DB transaction.
	//
	function handle_action($tid, $first_post_id)
	{
		global $db, $pun_user;

		$action = $_GET['solved_action'];
		if ($action != 'mark' && $action != 'unmark')
			return;

		// From here on every path exits, so pending page output is discarded
		while (ob_get_level() > 0)
			ob_end_clean();

		// No message() here: header.php has already begun rendering, and
		// message() would re-include it (re-firing this hook). A bad token
		// or target simply bounces back to the topic with nothing done -
		// redirect() is self-contained and safe at this point.
		$token = isset($_GET['csrf_token']) ? $_GET['csrf_token'] : null;
		if (!is_string($token) || !hash_equals(pun_csrf_token(), $token))
			redirect('viewtopic.php?id='.$tid, 'Bad request. Redirecting …');

		if ($action == 'mark')
		{
			$spid = isset($_GET['spid']) ? intval($_GET['spid']) : 0;

			// The post must exist, belong to this topic, and not be the question itself
			$valid = ($spid > 0 && $spid != $first_post_id);

			if ($valid)
			{
				$result = $db->query('SELECT id FROM '.$db->prefix.'posts WHERE id='.$spid.' AND topic_id='.$tid) or error('Unable to fetch post info', __FILE__, __LINE__, $db->error());
				$valid = $db->has_rows($result);
			}

			if (!$valid)
				redirect('viewtopic.php?id='.$tid, 'Bad request. Redirecting …');

			$db->query('DELETE FROM '.$db->prefix.'solved_topics WHERE topic_id='.$tid) or error('Unable to update solved state', __FILE__, __LINE__, $db->error());
			$db->query('INSERT INTO '.$db->prefix.'solved_topics (topic_id, post_id, marked_by, marked_at) VALUES('.$tid.', '.$spid.', '.(int) $pun_user['id'].', '.time().')') or error('Unable to update solved state', __FILE__, __LINE__, $db->error());

			redirect('viewtopic.php?pid='.$spid.'#p'.$spid, 'Marked as best answer. Redirecting …');
		}

		// unmark
		$db->query('DELETE FROM '.$db->prefix.'solved_topics WHERE topic_id='.$tid) or error('Unable to update solved state', __FILE__, __LINE__, $db->error());

		redirect('viewtopic.php?id='.$tid, 'Best-answer mark removed. Redirecting …');
	}


	//
	// viewforum.php: emit the forum's solved topic IDs for the tick marks
	//
	function head_viewforum()
	{
		global $db, $id;

		if (!isset($id))
			return;

		if (evebb_solved_conf('o_solved_listmark', '1') != '1')
			return;

		if (!evebb_solved_forum_enabled($id))
			return;

		$result = $db->query('SELECT s.topic_id FROM '.$db->prefix.'solved_topics AS s INNER JOIN '.$db->prefix.'topics AS t ON t.id=s.topic_id WHERE t.forum_id='.(int) $id) or error('Unable to fetch solved topics', __FILE__, __LINE__, $db->error());

		$ids = array();
		while ($row = $db->fetch_row($result))
			$ids[] = (int) $row[0];

		if (empty($ids))
			return;

		$this->emit(array(
			'page' => 'forum',
			'ids'  => $ids,
			'text' => array('solvedTick' => 'Solved')
		));
	}


	//
	// Emit the shared CSS plus the page JS with its config blob into <head>
	//
	function emit($cfg)
	{
		$json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

		echo '<style>'
			.'.solvedtext{color:#2f9e5f;font-weight:bold}'
			.'.solvedbanner{margin:1em 0;padding:.6em .9em;border:1px solid rgba(47,158,95,.55);background:rgba(47,158,95,.12);border-radius:4px}'
			.'.solvedbanner .conr{float:right}'
			.'.blockpost.bestanswer .box{box-shadow:0 0 0 2px rgba(47,158,95,.55)}'
			.'.bestanswerbadge{color:#2f9e5f;font-weight:bold;margin-left:.6em}'
			.'li.postsolved a{font-weight:bold}'
			.'</style>'."\n";

		echo '<script>/* Solved Topics plugin */'."\n".'(function(){'."\n"
			.'var cfg = '.$json.';'."\n"
			.<<<'EOJS'
function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

function el(tag, cls, text) {
	var e = document.createElement(tag);
	if (cls) e.className = cls;
	if (text) e.textContent = text;
	return e;
}

function actionUrl(action, spid) {
	var url = 'viewtopic.php?id=' + cfg.topic + '&solved_action=' + action;
	if (spid) url += '&spid=' + spid;
	return url + '&csrf_token=' + encodeURIComponent(cfg.token);
}

function forumPage() {
	var ids = {};
	for (var i = 0; i < cfg.ids.length; i++) ids[cfg.ids[i]] = true;

	var links = document.querySelectorAll('#vf div.tclcon a');
	for (var j = 0; j < links.length; j++) {
		var m = /^viewtopic\.php\?id=(\d+)$/.exec(links[j].getAttribute('href') || '');
		if (!m || !ids[m[1]]) continue;
		var tick = el('span', 'solvedtext', '✓ ');
		tick.title = cfg.text.solvedTick;
		links[j].parentNode.insertBefore(tick, links[j]);
		delete ids[m[1]]; // one tick per topic (skips same-row pagination links by exact href match anyway)
	}
}

function addFootLink(post, isAnswer) {
	var ul = post.querySelector('.postfootright ul');
	if (!ul) {
		var foot = post.querySelector('.postfoot');
		if (!foot) return;
		var div = el('div', 'postfootright');
		ul = document.createElement('ul');
		div.appendChild(ul);
		foot.appendChild(div);
	}
	var li = el('li', 'postsolved');
	var span = document.createElement('span');
	var a = document.createElement('a');
	var pid = parseInt(post.id.substring(1), 10);
	a.href = isAnswer ? actionUrl('unmark') : actionUrl('mark', pid);
	a.textContent = isAnswer ? cfg.text.unmark : cfg.text.mark;
	span.appendChild(a);
	li.appendChild(span);
	ul.appendChild(li);
}

function topicPage() {
	var answer = cfg.solved ? document.getElementById('p' + cfg.solved.pid) : null;
	var first = document.getElementById('p' + cfg.first);

	// Footer links on every reply (never the question post)
	if (cfg.canMark) {
		var posts = document.querySelectorAll('div.blockpost');
		for (var i = 0; i < posts.length; i++) {
			if (posts[i].id === 'p' + cfg.first) continue;
			addFootLink(posts[i], !!(cfg.solved && posts[i].id === 'p' + cfg.solved.pid));
		}
	}

	if (!cfg.solved) return;

	// Banner under the question (or atop the page when the question is on
	// an earlier page)
	var banner = el('div', 'solvedbanner');
	banner.appendChild(el('strong', 'solvedtext', '✓ '));
	banner.appendChild(document.createTextNode(cfg.text.by + ' '));
	banner.appendChild(el('strong', null, cfg.solved.by));
	banner.appendChild(document.createTextNode(' (' + cfg.solved.posted + ') — '));
	var jump = document.createElement('a');
	jump.href = answer ? '#p' + cfg.solved.pid : 'viewtopic.php?pid=' + cfg.solved.pid + '#p' + cfg.solved.pid;
	jump.textContent = cfg.text.jump;
	banner.appendChild(jump);
	if (cfg.canMark) {
		var right = el('span', 'conr');
		var un = document.createElement('a');
		un.href = actionUrl('unmark');
		un.textContent = cfg.text.unmark;
		right.appendChild(un);
		banner.appendChild(right);
	}

	if (first)
		first.parentNode.insertBefore(banner, first.nextSibling);
	else {
		var top = document.querySelector('div.blockpost');
		if (top) top.parentNode.insertBefore(banner, top);
	}

	// Highlight + badge on the answering post
	if (answer) {
		answer.className += ' bestanswer';
		var h2span = answer.querySelector('h2 span');
		if (h2span) h2span.appendChild(el('span', 'bestanswerbadge', '✓ ' + cfg.text.badge));

		// Pin a copy of the answer right under the banner (unless the
		// answer already sits immediately below it)
		if (cfg.pin && banner.nextElementSibling !== answer) {
			var clone = answer.cloneNode(true);
			clone.id = 'solved-pin';
			var foot = clone.querySelector('.postfootright');
			if (foot) foot.parentNode.removeChild(foot);
			banner.parentNode.insertBefore(clone, banner.nextSibling);
		}
	}
}

ready(function() { if (cfg.page === 'forum') forumPage(); else topicPage(); });
EOJS
			."\n".'})();</script>'."\n";
	}
}
