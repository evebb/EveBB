<?php

/**
 * Solved Topics (Best Answer) - shared library.
 *
 * Schema management and small helpers used by both the addon (solved.php)
 * and the settings page (admin.php).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


//
// Create the solved_topics table on first use. Guarded by the
// o_solved_db_rev config key so the check is free on every later request.
//
function evebb_solved_ensure_schema()
{
	global $db, $pun_config;

	if (isset($pun_config['o_solved_db_rev']))
		return;

	if (!$db->table_exists('solved_topics'))
	{
		$schema = array(
			'FIELDS' => array(
				'topic_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'post_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'marked_by' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'marked_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('topic_id')
		);

		$db->create_table('solved_topics', $schema) or error('Unable to create the solved_topics table', __FILE__, __LINE__, $db->error());
	}

	// Record the schema revision. No or-error here: if two requests race,
	// the loser's duplicate insert may fail and that is fine.
	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_solved_db_rev\', \'1\')');
	$pun_config['o_solved_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Read a plugin config value with a default
//
function evebb_solved_conf($name, $default)
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Insert or update a config value and refresh the config cache
//
function evebb_solved_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


//
// Is the plugin enabled in this forum? o_solved_forums holds a
// comma-separated list of forum IDs; blank means every forum.
//
function evebb_solved_forum_enabled($forum_id)
{
	$list = trim(evebb_solved_conf('o_solved_forums', ''));

	if ($list === '')
		return true;

	$ids = array_map('intval', explode(',', $list));

	return in_array((int) $forum_id, $ids, true);
}
