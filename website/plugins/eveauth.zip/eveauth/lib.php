<?php

/**
 * EVE Online SSO - shared library.
 *
 * Everything the addon (eveauth.php), the standalone SSO endpoint
 * (sso.php) and the settings page (admin.php) have in common: HTTP,
 * SSO/ESI helpers, sealed tokens, bootstrap (table + groups), account
 * creation, group placement and the periodic membership recheck.
 *
 * config.php may define EVEAUTH_SSO_BASE, EVEAUTH_ESI_BASE and
 * EVEAUTH_IMG_BASE to point the plugin at different endpoints - used by
 * the test suite (mirrors the FORUM_UPDATE_API convention).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

define('EVEAUTH_DB_REV', 1);


//
// Endpoint bases (no trailing slash)
//
function eveauth_sso_base()
{
	return defined('EVEAUTH_SSO_BASE') ? EVEAUTH_SSO_BASE : 'https://login.eveonline.com';
}

function eveauth_esi_base()
{
	return defined('EVEAUTH_ESI_BASE') ? EVEAUTH_ESI_BASE : 'https://esi.evetech.net';
}

function eveauth_img_base()
{
	return defined('EVEAUTH_IMG_BASE') ? EVEAUTH_IMG_BASE : 'https://images.evetech.net';
}


//
// Is the plugin fully configured (SSO app + target entity)?
//
function eveauth_configured()
{
	global $pun_config;

	return !empty($pun_config['o_eveauth_client_id'])
		&& !empty($pun_config['o_eveauth_client_secret'])
		&& !empty($pun_config['o_eveauth_entity_id'])
		&& !empty($pun_config['o_eveauth_group_member'])
		&& !empty($pun_config['o_eveauth_group_guest']);
}


//
// The callback URL to register at developers.eveonline.com
//
function eveauth_callback_url()
{
	return get_base_url().'/plugins/eveauth/sso.php';
}


//
// Fetch a URL. HTTPS-only for remote hosts (loopback may be plain HTTP,
// which is what the test suite's mock endpoints use). $post may be a
// string (sent as application/x-www-form-urlencoded unless a
// Content-Type header is supplied in $headers). Returns body or false.
//
function eveauth_http($url, $post = null, $headers = array(), $timeout = 15)
{
	$host = parse_url($url, PHP_URL_HOST);
	$is_loopback = in_array($host, array('127.0.0.1', '::1', 'localhost'), true);
	if (!$is_loopback && stripos($url, 'https://') !== 0)
		return false;

	$headers[] = 'User-Agent: eveBB-eveauth/1.0 (+'.get_base_url().')';

	if (function_exists('curl_init'))
	{
		$ch = curl_init($url);
		curl_setopt_array($ch, array(
			CURLOPT_RETURNTRANSFER	=> true,
			CURLOPT_FOLLOWLOCATION	=> true,
			CURLOPT_MAXREDIRS		=> 3,
			CURLOPT_TIMEOUT			=> $timeout,
			CURLOPT_CONNECTTIMEOUT	=> 10,
			CURLOPT_HTTPHEADER		=> $headers,
			CURLOPT_SSL_VERIFYPEER	=> true,
			CURLOPT_SSL_VERIFYHOST	=> 2,
			CURLOPT_PROTOCOLS		=> CURLPROTO_HTTPS | CURLPROTO_HTTP,
			CURLOPT_REDIR_PROTOCOLS	=> CURLPROTO_HTTPS,
		));
		if ($post !== null)
		{
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		$body = curl_exec($ch);
		$status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
		unset($ch);

		return ($body !== false && $status >= 200 && $status < 300) ? $body : false;
	}

	if (ini_get('allow_url_fopen'))
	{
		$http = array(
			'timeout'			=> $timeout,
			'follow_location'	=> 1,
			'max_redirects'		=> 3,
			'protocol_version'	=> 1.1,
			'ignore_errors'		=> false,
			'header'			=> implode("\r\n", $headers)."\r\n",
		);
		if ($post !== null)
		{
			$http['method'] = 'POST';
			$http['content'] = $post;
		}
		$context = stream_context_create(array(
			'http' => $http,
			'ssl' => array(
				'verify_peer'		=> true,
				'verify_peer_name'	=> true,
				'allow_self_signed'	=> false,
			),
		));
		$body = @file_get_contents($url, false, $context);

		return ($body !== false) ? $body : false;
	}

	return false;
}


//
// Fetch + JSON-decode. Returns array or false.
//
function eveauth_http_json($url, $post = null, $headers = array(), $timeout = 15)
{
	$body = eveauth_http($url, $post, $headers, $timeout);
	if ($body === false)
		return false;

	$data = json_decode($body, true);

	return is_array($data) ? $data : false;
}


// ---------------------------------------------------------------------------
// Sealed tokens (stateless, HMAC-signed with the board's cookie seed)
// ---------------------------------------------------------------------------

function eveauth_b64url_encode($data)
{
	return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function eveauth_b64url_decode($data)
{
	return base64_decode(strtr($data, '-_', '+/'));
}

//
// Seal an array into an HMAC-signed token (includes a timestamp)
//
function eveauth_seal($data)
{
	global $cookie_seed;

	$data['_t'] = time();
	$payload = eveauth_b64url_encode(json_encode($data));

	return $payload.'.'.forum_hmac($payload, $cookie_seed.'_eveauth');
}

//
// Verify + open a sealed token. Returns the array or false (bad
// signature or older than $max_age seconds).
//
function eveauth_unseal($token, $max_age = 1800)
{
	global $cookie_seed;

	if (!is_string($token) || substr_count($token, '.') != 1)
		return false;

	list($payload, $mac) = explode('.', $token);
	if (!hash_equals(forum_hmac($payload, $cookie_seed.'_eveauth'), $mac))
		return false;

	$data = json_decode(eveauth_b64url_decode($payload), true);
	if (!is_array($data) || !isset($data['_t']))
		return false;

	$age = time() - (int) $data['_t'];
	if ($age < 0 || $age > $max_age)
		return false;

	return $data;
}


// ---------------------------------------------------------------------------
// SSO flow
// ---------------------------------------------------------------------------

//
// The EVE SSO authorize URL for this board. $intent is carried through
// the state token ('login' or 'register' - only used for messages).
// The state nonce is also dropped in a short-lived cookie so the
// callback can verify the flow started in this same browser (login-CSRF
// protection on top of the HMAC).
//
function eveauth_authorize_url($intent)
{
	global $pun_config;

	$nonce = random_key(12, true);
	forum_setcookie('eveauth_state', $nonce, time() + 900);

	$state = eveauth_seal(array('n' => $nonce, 'i' => $intent));

	return eveauth_sso_base().'/v2/oauth/authorize/?'.http_build_query(array(
		'response_type'	=> 'code',
		'redirect_uri'	=> eveauth_callback_url(),
		'client_id'		=> $pun_config['o_eveauth_client_id'],
		'scope'			=> '',
		'state'			=> $state,
	));
}

//
// Exchange an authorization code for the verified character behind it.
// Returns array(character_id, character_name) or false.
//
function eveauth_exchange_code($code)
{
	global $pun_config;

	$auth = base64_encode($pun_config['o_eveauth_client_id'].':'.$pun_config['o_eveauth_client_secret']);
	$data = eveauth_http_json(eveauth_sso_base().'/v2/oauth/token',
		http_build_query(array('grant_type' => 'authorization_code', 'code' => $code)),
		array(
			'Authorization: Basic '.$auth,
			'Content-Type: application/x-www-form-urlencoded',
			'Host: '.parse_url(eveauth_sso_base(), PHP_URL_HOST),
		));

	if ($data === false || empty($data['access_token']))
		return false;

	// The token came to us first-hand from the SSO over a verified
	// transport, so decoding the JWT payload is sufficient - there is no
	// user-supplied signature to distrust.
	$parts = explode('.', $data['access_token']);
	if (count($parts) != 3)
		return false;

	$claims = json_decode(eveauth_b64url_decode($parts[1]), true);
	if (!is_array($claims) || empty($claims['sub']) || empty($claims['name']))
		return false;

	// sub is "CHARACTER:EVE:<id>"
	$sub = explode(':', $claims['sub']);
	$character_id = (int) end($sub);
	if ($character_id < 1)
		return false;

	return array($character_id, (string) $claims['name']);
}


// ---------------------------------------------------------------------------
// ESI (all public endpoints - no scopes, no tokens)
// ---------------------------------------------------------------------------

//
// Corporation + alliance for a set of character IDs.
// Returns array(character_id => array('corporation_id' =>, 'alliance_id' =>)) or false.
//
function eveauth_affiliation($character_ids)
{
	$character_ids = array_values(array_map('intval', $character_ids));
	if (empty($character_ids))
		return array();

	$data = eveauth_http_json(eveauth_esi_base().'/latest/characters/affiliation/',
		json_encode($character_ids),
		array('Content-Type: application/json', 'Accept: application/json'));

	if ($data === false)
		return false;

	$map = array();
	foreach ($data as $row)
	{
		if (isset($row['character_id'], $row['corporation_id']))
			$map[(int) $row['character_id']] = array(
				'corporation_id'	=> (int) $row['corporation_id'],
				'alliance_id'		=> isset($row['alliance_id']) ? (int) $row['alliance_id'] : 0,
			);
	}

	return $map;
}

//
// Public info for one corporation: array('name' =>, 'ticker' =>, 'alliance_id' =>) or false.
//
function eveauth_corp_info($corp_id)
{
	$data = eveauth_http_json(eveauth_esi_base().'/latest/corporations/'.intval($corp_id).'/', null,
		array('Accept: application/json'));

	if ($data === false || !isset($data['name']))
		return false;

	return array(
		'name'			=> (string) $data['name'],
		'ticker'		=> isset($data['ticker']) ? (string) $data['ticker'] : '',
		'alliance_id'	=> isset($data['alliance_id']) ? (int) $data['alliance_id'] : 0,
	);
}

//
// Public info for one alliance: array('name' =>, 'ticker' =>) or false.
//
function eveauth_alliance_info($alliance_id)
{
	$data = eveauth_http_json(eveauth_esi_base().'/latest/alliances/'.intval($alliance_id).'/', null,
		array('Accept: application/json'));

	if ($data === false || !isset($data['name']))
		return false;

	return array(
		'name'		=> (string) $data['name'],
		'ticker'	=> isset($data['ticker']) ? (string) $data['ticker'] : '',
	);
}

//
// Resolve an exact corporation or alliance name to an ID via
// /universe/ids/. Returns array('type' =>, 'id' =>, 'name' =>) or false.
//
function eveauth_resolve_entity($name, $want = 'auto')
{
	$data = eveauth_http_json(eveauth_esi_base().'/latest/universe/ids/',
		json_encode(array($name)),
		array('Content-Type: application/json', 'Accept: application/json'));

	if ($data === false)
		return false;

	$kinds = array('alliances' => 'alliance', 'corporations' => 'corporation');
	if ($want == 'corporation')
		$kinds = array('corporations' => 'corporation');
	else if ($want == 'alliance')
		$kinds = array('alliances' => 'alliance');

	foreach ($kinds as $key => $type)
	{
		if (!empty($data[$key]) && is_array($data[$key]))
		{
			$hit = reset($data[$key]);
			if (isset($hit['id'], $hit['name']))
				return array('type' => $type, 'id' => (int) $hit['id'], 'name' => (string) $hit['name']);
		}
	}

	return false;
}

//
// Image-server URLs (public, designed for hotlinking)
//
function eveauth_portrait_url($character_id, $size = 128)
{
	return eveauth_img_base().'/characters/'.intval($character_id).'/portrait?size='.intval($size);
}

function eveauth_logo_url($type, $id, $size = 64)
{
	$path = ($type == 'alliance') ? 'alliances' : 'corporations';

	return eveauth_img_base().'/'.$path.'/'.intval($id).'/logo?size='.intval($size);
}


// ---------------------------------------------------------------------------
// Config + bootstrap
// ---------------------------------------------------------------------------

//
// Insert or update a config value and refresh the config cache
//
function eveauth_save_config($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}

//
// First-run bootstrap: create the eveauth_users table and the two
// managed groups. Guarded by the o_eveauth_db_rev config key so it only
// ever runs once (same pattern the core db updater uses).
//
function eveauth_bootstrap()
{
	global $db, $pun_config;

	if (isset($pun_config['o_eveauth_db_rev']) && intval($pun_config['o_eveauth_db_rev']) >= EVEAUTH_DB_REV)
		return;

	// Character registry (types kept portable across mysql/pgsql/sqlite)
	$db->query('CREATE TABLE IF NOT EXISTS '.$db->prefix.'eveauth_users (
		user_id INT NOT NULL,
		character_id BIGINT NOT NULL,
		character_name VARCHAR(64) NOT NULL,
		corp_id BIGINT NOT NULL DEFAULT 0,
		corp_name VARCHAR(255) NOT NULL DEFAULT \'\',
		corp_ticker VARCHAR(10) NOT NULL DEFAULT \'\',
		alliance_id BIGINT NOT NULL DEFAULT 0,
		alliance_name VARCHAR(255) NOT NULL DEFAULT \'\',
		is_member SMALLINT NOT NULL DEFAULT 0,
		checked INT NOT NULL DEFAULT 0,
		PRIMARY KEY (user_id)
	)') or error('Unable to create eveauth_users table', __FILE__, __LINE__, $db->error());

	// The two managed groups, cloned from the board's default user group
	// so their permissions start sensible. Reuse by title if they exist
	// (e.g. after a reinstall).
	if (empty($pun_config['o_eveauth_group_member']))
		eveauth_save_config('o_eveauth_group_member', eveauth_create_group('EVE Members'));
	if (empty($pun_config['o_eveauth_group_guest']))
		eveauth_save_config('o_eveauth_group_guest', eveauth_create_group('EVE Non-Members'));

	foreach (array('o_eveauth_settitle' => '1', 'o_eveauth_recheck_hours' => '6', 'o_eveauth_last_check' => '0') as $name => $value)
	{
		if (!isset($pun_config[$name]))
			eveauth_save_config($name, $value);
	}

	eveauth_save_config('o_eveauth_db_rev', (string) EVEAUTH_DB_REV);
}

//
// Create (or find) a group with the given title, cloning permissions
// from the default user group. Returns its g_id.
//
function eveauth_create_group($title)
{
	global $db, $pun_config;

	$result = $db->query('SELECT g_id FROM '.$db->prefix.'groups WHERE g_title=\''.$db->escape($title).'\'') or error('Unable to fetch group', __FILE__, __LINE__, $db->error());
	if ($db->has_rows($result))
		return (string) $db->result($result);

	$result = $db->query('SELECT * FROM '.$db->prefix.'groups WHERE g_id='.intval($pun_config['o_default_user_group'])) or error('Unable to fetch default group', __FILE__, __LINE__, $db->error());
	$base = $db->fetch_assoc($result);
	if (!$base)
		return '';

	unset($base['g_id']);
	$base['g_title'] = $title;
	$base['g_user_title'] = '';
	$base['g_moderator'] = 0;

	$fields = $values = array();
	foreach ($base as $field => $value)
	{
		$fields[] = $field;
		$values[] = ($value === null || $value === '') && !is_numeric($value) ? 'NULL' : '\''.$db->escape($value).'\'';
	}

	$db->query('INSERT INTO '.$db->prefix.'groups ('.implode(', ', $fields).') VALUES('.implode(', ', $values).')') or error('Unable to create group', __FILE__, __LINE__, $db->error());

	return (string) $db->insert_id();
}


// ---------------------------------------------------------------------------
// Membership + accounts
// ---------------------------------------------------------------------------

//
// Does this affiliation make the character a member of the configured entity?
//
function eveauth_is_member($corp_id, $alliance_id)
{
	global $pun_config;

	if ($pun_config['o_eveauth_entity_type'] == 'alliance')
		return $alliance_id == intval($pun_config['o_eveauth_entity_id']);

	return $corp_id == intval($pun_config['o_eveauth_entity_id']);
}

//
// The full EVE picture for one character: affiliation + names.
// Returns array(corp_id, corp_name, corp_ticker, alliance_id,
// alliance_name, is_member) or false on ESI failure.
//
function eveauth_lookup_character($character_id)
{
	$aff = eveauth_affiliation(array($character_id));
	if ($aff === false || !isset($aff[$character_id]))
		return false;

	$corp_id = $aff[$character_id]['corporation_id'];
	$alliance_id = $aff[$character_id]['alliance_id'];

	$corp = eveauth_corp_info($corp_id);
	if ($corp === false)
		return false;

	$alliance_name = '';
	if ($alliance_id > 0)
	{
		$alliance = eveauth_alliance_info($alliance_id);
		if ($alliance !== false)
			$alliance_name = $alliance['name'];
	}

	return array(
		'corp_id'		=> $corp_id,
		'corp_name'		=> $corp['name'],
		'corp_ticker'	=> $corp['ticker'],
		'alliance_id'	=> $alliance_id,
		'alliance_name'	=> $alliance_name,
		'is_member'		=> eveauth_is_member($corp_id, $alliance_id) ? 1 : 0,
	);
}

//
// The user title we set ("Corp Name [TICK]")
//
function eveauth_title($corp_name, $corp_ticker)
{
	$title = $corp_name;
	if ($corp_ticker != '')
		$title .= ' ['.$corp_ticker.']';

	return pun_trim($title);
}

//
// Look up the forum account bound to a character. Returns the users row
// joined with eveauth data, or null.
//
function eveauth_user_by_character($character_id)
{
	global $db;

	$result = $db->query('SELECT u.*, e.character_id FROM '.$db->prefix.'eveauth_users AS e INNER JOIN '.$db->prefix.'users AS u ON u.id=e.user_id WHERE e.character_id='.intval($character_id)) or error('Unable to fetch EVE user', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? $db->fetch_assoc($result) : null;
}

//
// Create the forum account for a verified character. $char is the array
// from eveauth_lookup_character() plus character_id/character_name.
// Returns the new user ID, or a string error key:
//   'closed', 'email', 'banned_email', 'dupe_email', 'username'
//
function eveauth_create_user($char, $email)
{
	global $db, $pun_config;

	if ($pun_config['o_regs_allow'] == '0')
		return 'closed';

	require_once PUN_ROOT.'include/email.php';

	$email = strtolower(pun_trim($email));
	if (!is_valid_email($email))
		return 'email';

	if (is_banned_email($email) && $pun_config['p_allow_banned_email'] == '0')
		return 'banned_email';

	if ($pun_config['p_allow_dupe_email'] == '0')
	{
		$result = $db->query('SELECT 1 FROM '.$db->prefix.'users WHERE email=\''.$db->escape($email).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
		if ($db->has_rows($result))
			return 'dupe_email';
	}

	// Character names fit forum rules almost by construction, but the
	// column is 25 chars and a legacy non-SSO account could clash
	$username = pun_trim(preg_replace('%\s+%s', ' ', $char['character_name']));
	if (pun_strlen($username) > 25)
		$username = pun_trim(utf8_substr($username, 0, 25));

	$result = $db->query('SELECT 1 FROM '.$db->prefix.'users WHERE UPPER(username)=UPPER(\''.$db->escape($username).'\') AND id>1') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
	if ($db->has_rows($result))
		return 'username';

	$now = time();
	$group_id = $char['is_member'] ? intval($pun_config['o_eveauth_group_member']) : intval($pun_config['o_eveauth_group_guest']);
	$password_hash = flux_password_hash(random_pass(24));
	$title = ($pun_config['o_eveauth_settitle'] == '1') ? eveauth_title($char['corp_name'], $char['corp_ticker']) : '';
	$title_sql = ($title != '') ? '\''.$db->escape($title).'\'' : 'NULL';

	$db->query('INSERT INTO '.$db->prefix.'users (username, group_id, password, email, email_setting, timezone, dst, language, style, title, registered, registration_ip, last_visit) VALUES(\''.$db->escape($username).'\', '.$group_id.', \''.$db->escape($password_hash).'\', \''.$db->escape($email).'\', '.intval($pun_config['o_default_email_setting']).', '.floatval($pun_config['o_default_timezone']).', '.intval($pun_config['o_default_dst']).', \''.$db->escape($pun_config['o_default_lang']).'\', \''.$db->escape($pun_config['o_default_style']).'\', '.$title_sql.', '.$now.', \''.$db->escape(get_remote_address()).'\', '.$now.')') or error('Unable to create user', __FILE__, __LINE__, $db->error());
	$new_uid = $db->insert_id();

	$db->query('INSERT INTO '.$db->prefix.'eveauth_users (user_id, character_id, character_name, corp_id, corp_name, corp_ticker, alliance_id, alliance_name, is_member, checked) VALUES('.intval($new_uid).', '.intval($char['character_id']).', \''.$db->escape($char['character_name']).'\', '.intval($char['corp_id']).', \''.$db->escape($char['corp_name']).'\', \''.$db->escape($char['corp_ticker']).'\', '.intval($char['alliance_id']).', \''.$db->escape($char['alliance_name']).'\', '.intval($char['is_member']).', '.$now.')') or error('Unable to create EVE user', __FILE__, __LINE__, $db->error());

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_users_info_cache();

	// Portrait as forum avatar (best effort - never fatal)
	eveauth_set_avatar($new_uid, $char['character_id']);

	return (int) $new_uid;
}

//
// Download a character portrait and install it as the user's forum
// avatar, run through the same GD re-encode the upload path uses.
// Best effort: returns true/false, never errors out.
//
function eveauth_set_avatar($user_id, $character_id)
{
	global $pun_config;

	$avatar_dir = PUN_ROOT.$pun_config['o_avatars_dir'].'/';
	if (!is_dir($avatar_dir) || !is_writable($avatar_dir))
		return false;

	$body = eveauth_http(eveauth_portrait_url($character_id, 128));
	if ($body === false || strlen($body) > intval($pun_config['o_avatars_size']) * 4)
		return false;

	$tmp_path = $avatar_dir.$user_id.'.tmp';
	if (@file_put_contents($tmp_path, $body) === false)
		return false;

	$info = @getimagesize($tmp_path);
	$extensions = array(IMAGETYPE_GIF => '.gif', IMAGETYPE_JPEG => '.jpg', IMAGETYPE_PNG => '.png');
	if (empty($info) || !isset($extensions[$info[2]]))
	{
		@unlink($tmp_path);
		return false;
	}

	delete_avatar($user_id);

	$ok = resize_avatar($tmp_path, $avatar_dir.$user_id.$extensions[$info[2]], $info[2], $pun_config['o_avatars_width'], $pun_config['o_avatars_height']);
	@unlink($tmp_path);

	return (bool) $ok;
}

//
// Log a user row in (mirrors login.php's success path)
//
function eveauth_login_user($cur_user)
{
	global $db, $pun_config;

	$db->query('DELETE FROM '.$db->prefix.'online WHERE ident=\''.$db->escape(get_remote_address()).'\'') or error('Unable to delete from online list', __FILE__, __LINE__, $db->error());

	pun_setcookie($cur_user['id'], $cur_user['password'], time() + $pun_config['o_timeout_visit']);
	set_tracked_topics(null);
}

//
// Apply a (possibly changed) affiliation to an existing bound account:
// update the registry row, move between the two managed groups, refresh
// the title. Never touches accounts whose group is not one of the two
// managed groups (admins, moderators, manual assignments).
//
function eveauth_apply_affiliation($user_id, $char)
{
	global $db, $pun_config;

	$db->query('UPDATE '.$db->prefix.'eveauth_users SET corp_id='.intval($char['corp_id']).', corp_name=\''.$db->escape($char['corp_name']).'\', corp_ticker=\''.$db->escape($char['corp_ticker']).'\', alliance_id='.intval($char['alliance_id']).', alliance_name=\''.$db->escape($char['alliance_name']).'\', is_member='.intval($char['is_member']).', checked='.time().' WHERE user_id='.intval($user_id)) or error('Unable to update EVE user', __FILE__, __LINE__, $db->error());

	$member_group = intval($pun_config['o_eveauth_group_member']);
	$guest_group = intval($pun_config['o_eveauth_group_guest']);
	$target = $char['is_member'] ? $member_group : $guest_group;
	$other = $char['is_member'] ? $guest_group : $member_group;

	$db->query('UPDATE '.$db->prefix.'users SET group_id='.$target.' WHERE id='.intval($user_id).' AND group_id='.$other) or error('Unable to update user group', __FILE__, __LINE__, $db->error());

	if ($pun_config['o_eveauth_settitle'] == '1')
		$db->query('UPDATE '.$db->prefix.'users SET title=\''.$db->escape(eveauth_title($char['corp_name'], $char['corp_ticker'])).'\' WHERE id='.intval($user_id)) or error('Unable to update user title', __FILE__, __LINE__, $db->error());

	if ($db->affected_rows())
	{
		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PUN_ROOT.'include/cache.php';
		generate_users_info_cache();
	}
}


// ---------------------------------------------------------------------------
// Periodic membership recheck (page-view time-gated, like relpost)
// ---------------------------------------------------------------------------

//
// Re-verify a batch of bound characters against ESI and move anyone who
// joined/left. $force skips the time gate (admin "check now" button).
// Fails open: any network trouble just means we try again next gate.
// Returns the number of accounts whose membership changed, or false if
// the check could not run.
//
function eveauth_recheck($force = false, $batch = 200)
{
	global $db, $pun_config;

	if (!eveauth_configured())
		return false;

	$gate = intval($pun_config['o_eveauth_recheck_hours']) * 3600;
	if (!$force && ($gate < 1 || time() - intval($pun_config['o_eveauth_last_check']) < $gate))
		return false;

	// Claim the gate first so parallel page views don't double-run
	eveauth_save_config('o_eveauth_last_check', (string) time());

	$result = $db->query('SELECT user_id, character_id, corp_id, alliance_id, is_member FROM '.$db->prefix.'eveauth_users ORDER BY checked ASC LIMIT '.intval($batch)) or error('Unable to fetch EVE users', __FILE__, __LINE__, $db->error());

	$rows = array();
	while ($row = $db->fetch_assoc($result))
		$rows[(int) $row['character_id']] = $row;

	if (empty($rows))
		return 0;

	$aff = eveauth_affiliation(array_keys($rows));
	if ($aff === false)
		return false;

	$now = time();
	$moved = 0;
	$corp_cache = array();
	$alliance_cache = array();

	foreach ($rows as $character_id => $row)
	{
		if (!isset($aff[$character_id]))
			continue;

		$corp_id = $aff[$character_id]['corporation_id'];
		$alliance_id = $aff[$character_id]['alliance_id'];
		$is_member = eveauth_is_member($corp_id, $alliance_id) ? 1 : 0;

		// Unchanged: just stamp the check time
		if ($corp_id == $row['corp_id'] && $alliance_id == $row['alliance_id'])
		{
			$db->query('UPDATE '.$db->prefix.'eveauth_users SET checked='.$now.', is_member='.$is_member.' WHERE user_id='.intval($row['user_id'])) or error('Unable to update EVE user', __FILE__, __LINE__, $db->error());
			continue;
		}

		// Corp/alliance changed: fetch fresh names (cached per entity)
		if (!isset($corp_cache[$corp_id]))
		{
			$info = eveauth_corp_info($corp_id);
			$corp_cache[$corp_id] = ($info !== false) ? $info : array('name' => '', 'ticker' => '', 'alliance_id' => $alliance_id);
		}
		if ($alliance_id > 0 && !isset($alliance_cache[$alliance_id]))
		{
			$info = eveauth_alliance_info($alliance_id);
			$alliance_cache[$alliance_id] = ($info !== false) ? $info['name'] : '';
		}

		$was_member = intval($row['is_member']);
		eveauth_apply_affiliation($row['user_id'], array(
			'corp_id'		=> $corp_id,
			'corp_name'		=> $corp_cache[$corp_id]['name'],
			'corp_ticker'	=> $corp_cache[$corp_id]['ticker'],
			'alliance_id'	=> $alliance_id,
			'alliance_name'	=> ($alliance_id > 0) ? $alliance_cache[$alliance_id] : '',
			'is_member'		=> $is_member,
		));

		if ($was_member != $is_member)
			$moved++;
	}

	return $moved;
}
