<?php

/**
 * EVE Online SSO - settings page (shown inside the plugin manager).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

eveauth_bootstrap();

$eveauth_notice = '';

// ---------------------------------------------------------------------------
// Save settings
// ---------------------------------------------------------------------------
if (isset($_POST['save_eveauth']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	eveauth_save_config('o_eveauth_client_id', pun_trim($_POST['client_id'] ?? ''));

	// Leave the stored secret alone unless a new one was typed
	$secret = pun_trim($_POST['client_secret'] ?? '');
	if ($secret != '')
		eveauth_save_config('o_eveauth_client_secret', $secret);

	$member_group = intval($_POST['group_member'] ?? 0);
	$guest_group = intval($_POST['group_guest'] ?? 0);
	if ($member_group > 0 && $guest_group > 0 && $member_group != $guest_group)
	{
		eveauth_save_config('o_eveauth_group_member', (string) $member_group);
		eveauth_save_config('o_eveauth_group_guest', (string) $guest_group);
	}

	eveauth_save_config('o_eveauth_settitle', isset($_POST['settitle']) ? '1' : '0');
	eveauth_save_config('o_eveauth_recheck_hours', (string) max(1, min(168, intval($_POST['recheck_hours'] ?? 6))));

	// Corporation / alliance: resolve the typed name through ESI so the
	// ID is exact. Only re-resolve when the name actually changed.
	$entity_name = pun_trim($_POST['entity_name'] ?? '');
	$entity_want = in_array($_POST['entity_type'] ?? 'auto', array('auto', 'corporation', 'alliance'), true) ? $_POST['entity_type'] : 'auto';

	if ($entity_name == '')
	{
		eveauth_save_config('o_eveauth_entity_id', '');
		eveauth_save_config('o_eveauth_entity_name', '');
		eveauth_save_config('o_eveauth_entity_type', '');
	}
	else if ($entity_name != ($pun_config['o_eveauth_entity_name'] ?? '') || $entity_want != 'auto' && $entity_want != ($pun_config['o_eveauth_entity_type'] ?? ''))
	{
		$hit = eveauth_resolve_entity($entity_name, $entity_want);
		if ($hit === false)
			$eveauth_notice = 'Could not find a '.($entity_want == 'auto' ? 'corporation or alliance' : $entity_want).' named "'.pun_htmlspecialchars($entity_name).'" - check the exact in-game spelling (or the EVE API may be unreachable).';
		else
		{
			eveauth_save_config('o_eveauth_entity_id', (string) $hit['id']);
			eveauth_save_config('o_eveauth_entity_name', $hit['name']);
			eveauth_save_config('o_eveauth_entity_type', $hit['type']);
		}
	}

	if ($eveauth_notice == '')
		redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}

// ---------------------------------------------------------------------------
// Run a membership check now
// ---------------------------------------------------------------------------
else if (isset($_POST['check_eveauth']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$moved = eveauth_recheck(true);
	$eveauth_notice = ($moved === false)
		? 'Membership check failed - the plugin is not fully configured or the EVE API could not be reached.'
		: 'Membership check complete: '.$moved.' account(s) changed membership.';
}

// ---------------------------------------------------------------------------
// Purge all plugin data
// ---------------------------------------------------------------------------
else if (isset($_POST['purge_eveauth']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DROP TABLE IF EXISTS '.$db->prefix.'eveauth_users') or error('Unable to drop eveauth_users table', __FILE__, __LINE__, $db->error());

	foreach (array('db_rev', 'client_id', 'client_secret', 'entity_id', 'entity_name', 'entity_type', 'group_member', 'group_guest', 'settitle', 'recheck_hours', 'last_check') as $key)
		$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name=\'o_eveauth_'.$key.'\'') or error('Unable to remove board config', __FILE__, __LINE__, $db->error());

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'EVE Online SSO data removed. Deactivate or delete the plugin to finish. Redirecting …');
}


// ---------------------------------------------------------------------------
// Render
// ---------------------------------------------------------------------------

$result = $db->query('SELECT g_id, g_title FROM '.$db->prefix.'groups WHERE g_id!='.PUN_GUEST.' ORDER BY g_title') or error('Unable to fetch groups', __FILE__, __LINE__, $db->error());
$eveauth_groups = array();
while ($row = $db->fetch_assoc($result))
	$eveauth_groups[$row['g_id']] = $row['g_title'];

$bound = $members = 0;
$result = $db->query('SELECT COUNT(user_id), SUM(is_member) FROM '.$db->prefix.'eveauth_users') or error('Unable to count EVE users', __FILE__, __LINE__, $db->error());
if ($row = $db->fetch_row($result))
{
	$bound = (int) $row[0];
	$members = (int) $row[1];
}

$cfg = function ($name, $fallback = '') use ($pun_config) {
	return isset($pun_config[$name]) ? $pun_config[$name] : $fallback;
};

$entity_configured = $cfg('o_eveauth_entity_id') != '';

?>
<?php if ($eveauth_notice != ''): ?>	<div class="inform">
		<div class="forminfo">
			<p><strong><?php echo $eveauth_notice ?></strong></p>
		</div>
	</div>
<?php endif; ?>	<div class="inform">
		<fieldset>
			<legend>Status</legend>
			<div class="infldset">
<?php if (eveauth_configured()): ?>				<p><strong>EVE Online SSO is active.</strong> Registration on this board runs through EVE Online. <?php echo $bound ?> account(s) are bound to EVE characters (<?php echo $members ?> member(s) of <?php echo pun_htmlspecialchars($cfg('o_eveauth_entity_name')) ?>).</p>
<?php else: ?>				<p><strong>Not configured yet</strong> - normal registration still applies. Fill in the SSO application and the corporation/alliance below.</p>
<?php endif; ?>				<p>Callback URL for your application at <a href="https://developers.eveonline.com">developers.eveonline.com</a> (no scopes needed):</p>
				<p><code><?php echo pun_htmlspecialchars(eveauth_callback_url()) ?></code></p>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>EVE SSO application</legend>
			<div class="infldset">
				<label>Client ID
					<br /><input type="text" name="client_id" size="50" maxlength="64" value="<?php echo pun_htmlspecialchars($cfg('o_eveauth_client_id')) ?>" />
				</label>
				<label>Secret key <?php if ($cfg('o_eveauth_client_secret') != '') echo '(saved - leave blank to keep)' ?>
					<br /><input type="password" name="client_secret" size="50" maxlength="64" value="" autocomplete="new-password" />
				</label>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Corporation or alliance</legend>
			<div class="infldset">
<?php if ($entity_configured): ?>				<p>
					<img src="<?php echo pun_htmlspecialchars(eveauth_logo_url($cfg('o_eveauth_entity_type'), $cfg('o_eveauth_entity_id'), 64)) ?>" width="48" height="48" alt="" style="float: left; margin: 0 12px 8px 0;" />
					Currently set to the <?php echo pun_htmlspecialchars($cfg('o_eveauth_entity_type')) ?> <strong><?php echo pun_htmlspecialchars($cfg('o_eveauth_entity_name')) ?></strong> (ID <?php echo pun_htmlspecialchars($cfg('o_eveauth_entity_id')) ?>).
				</p>
<?php endif; ?>				<p class="clearb">Exact in-game name - it is verified against the EVE API when you save, so the right entity is always matched. Clear the field to unset.</p>
				<label>Name
					<br /><input type="text" name="entity_name" size="50" maxlength="100" value="<?php echo pun_htmlspecialchars($cfg('o_eveauth_entity_name')) ?>" />
				</label>
				<label>Type
					<br /><select name="entity_type">
						<option value="auto">Detect automatically</option>
						<option value="corporation"<?php if ($cfg('o_eveauth_entity_type') == 'corporation') echo ' selected="selected"' ?>>Corporation</option>
						<option value="alliance"<?php if ($cfg('o_eveauth_entity_type') == 'alliance') echo ' selected="selected"' ?>>Alliance</option>
					</select>
				</label>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Groups</legend>
			<div class="infldset">
				<p>Members of the corporation/alliance land in the first group; everyone else (including anyone who later leaves) is moved to the second. Accounts in any other group - admins, moderators, manual assignments - are never touched.</p>
				<label>Member group
					<br /><select name="group_member">
<?php foreach ($eveauth_groups as $g_id => $g_title): ?>						<option value="<?php echo $g_id ?>"<?php if ($cfg('o_eveauth_group_member') == $g_id) echo ' selected="selected"' ?>><?php echo pun_htmlspecialchars($g_title) ?></option>
<?php endforeach; ?>					</select>
				</label>
				<label>Non-member group
					<br /><select name="group_guest">
<?php foreach ($eveauth_groups as $g_id => $g_title): ?>						<option value="<?php echo $g_id ?>"<?php if ($cfg('o_eveauth_group_guest') == $g_id) echo ' selected="selected"' ?>><?php echo pun_htmlspecialchars($g_title) ?></option>
<?php endforeach; ?>					</select>
				</label>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Options</legend>
			<div class="infldset">
				<div class="rbox">
					<label><input type="checkbox" name="settitle" value="1"<?php if ($cfg('o_eveauth_settitle', '1') == '1') echo ' checked="checked"' ?> />Show each pilot's corporation as their user title under posts<br /></label>
				</div>
				<label>Re-check memberships every
					<br /><input type="text" name="recheck_hours" size="4" maxlength="3" value="<?php echo pun_htmlspecialchars($cfg('o_eveauth_recheck_hours', '6')) ?>" /> hours (1-168; checks run quietly during normal page views)
				</label>
			</div>
		</fieldset>
	</div>
	<p class="submitend"><input type="submit" name="save_eveauth" value="Save settings" /></p>
	<div class="inform">
		<fieldset>
			<legend>Maintenance</legend>
			<div class="infldset">
				<p><input type="submit" name="check_eveauth" value="Check memberships now" /> Verify every bound account against the EVE API immediately.</p>
				<p><input type="submit" name="purge_eveauth" value="Remove all plugin data" onclick="return confirm('Remove the character registry and all EVE SSO settings? Forum accounts themselves are kept.')" /> For a clean uninstall. Forum accounts, groups and avatars are kept; only the character bindings and settings are removed.</p>
			</div>
		</fieldset>
	</div>
<?php
