# EVE Online SSO for eveBB

Registration and login through the EVE Online single sign-on. Character
name becomes the username, the in-game portrait becomes the avatar, and
corporation or alliance membership decides the member group — checked
automatically, forever.

## What it does

- **SSO-only registration.** The classic registration form is replaced
  by a *Log in with EVE Online* button. The SSO returns a verified
  character — no name spoofing, no CAPTCHA needed. The new user confirms
  an email address (for password recovery and notifications) and the
  account is created: username = character name, avatar = character
  portrait, user title = corporation name.
- **SSO login.** A *Log in with EVE Online* button on the login page.
  Bound accounts have no usable password; the classic form remains for
  accounts that predate the plugin (e.g. the admin).
- **Membership groups.** Configure one corporation or alliance (the name
  is verified against the EVE API so the match is exact, and its logo is
  pulled automatically). Characters in it join the *member* group;
  everyone else joins the *non-member* group. Both groups are created on
  activation and can be re-pointed at any existing groups.
- **Automatic re-checks.** Corporation membership is public data, so the
  plugin quietly re-verifies bound characters during normal page views
  (default: every 6 hours, batched into a single API call) and whenever
  they log in. Leave the corp in game and the forum moves you to the
  non-member group; rejoin and you're moved back. Admins, moderators and
  accounts in any other group are never touched.
- **Corp identity on posts and profiles.** The corporation name shows as
  the user title under every post (with the corp logo alongside), and
  profiles gain an EVE Online panel with portrait, corporation and
  alliance.

## Setup

1. Install the plugin zip through **Administration → Plugins → upload**
   and activate it.
2. Create an application at <https://developers.eveonline.com>
   (the EVE account must have been Omega at some point):
   - Connection type: *Authentication Only* (no scopes needed)
   - Callback URL: exactly the one shown on the plugin settings page,
     `https://your-board/plugins/eveauth/sso.php`
3. Copy the application's **Client ID** and **Secret Key** into the
   plugin settings page.
4. Enter your corporation or alliance's exact in-game name and save —
   the plugin resolves it through the EVE API and shows its logo.

That's it. Registration is now SSO-only.

## Notes

- Requires outbound HTTPS from your server to `login.eveonline.com`,
  `esi.evetech.net` and `images.evetech.net` (logos and portraits on
  pages are loaded by the visitor's browser straight from CCP's image
  server, which is designed for it).
- The email address is only used for recovery/notifications and is
  accepted without a verification round-trip — identity is already
  verified by the SSO. Board options like *allow duplicate email
  addresses* and *registrations open/closed* are respected.
- If a character's name collides with a pre-existing non-SSO account
  (character names are unique in EVE, so this is rare), registration is
  refused with a message to contact the admin.
- All EVE API calls fail open: if CCP's API is down, pages render
  normally and re-checks simply run later.
- Uninstall cleanly via *Remove all plugin data* on the settings page,
  then deactivate/delete the plugin. Accounts, groups and avatars are
  kept.
- CCP requires third-party apps to comply with the EVE Online
  Developer License Agreement.

## For test suites

`config.php` may define `EVEAUTH_SSO_BASE`, `EVEAUTH_ESI_BASE` and
`EVEAUTH_IMG_BASE` to point the plugin at mock endpoints (loopback
plain-HTTP is allowed, everything remote must be HTTPS).

License: GPL v2 or higher, same as eveBB.
