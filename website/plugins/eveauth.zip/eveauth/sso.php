<?php

/**
 * EVE Online SSO - the OAuth endpoint.
 *
 * This is the URL registered as the application callback at
 * developers.eveonline.com:  <board>/plugins/eveauth/sso.php
 *
 * Actions (?a=):
 *   go       redirect the guest to the EVE SSO authorize page
 *   (none)   SSO callback: ?code=...&state=... - verified character
 *            comes back here; existing accounts are logged in, new
 *            characters get the email confirmation form
 *   create   POST from the confirmation form: create the account
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

//
// This page lives under plugins/eveauth/, but the forum chrome links its
// stylesheets, scripts and navigation relative to the forum root.
// Absolutize every relative href/src on the way out so the page renders
// (and navigates) exactly like a root page.
//
function eveauth_absolutize($html)
{
	$base = get_base_url().'/';

	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('eveauth_absolutize');

// Only meaningful when the plugin is active and configured
$eveauth_active = in_array('eveauth', evebb_active_plugins());
if (!$eveauth_active)
	message($lang_common['Bad request'], false, '404 Not Found');

eveauth_bootstrap();

if (!eveauth_configured())
	message('EVE Online SSO is not configured yet. An administrator must finish the plugin setup first.');

// Logged-in users have nothing to do here
if (!$pun_user['is_guest'])
{
	$db->end_transaction();
	header('Location: '.get_base_url().'/index.php');
	exit;
}

$action = isset($_GET['a']) ? $_GET['a'] : null;


// ---------------------------------------------------------------------------
// go: hand the guest to the EVE SSO
// ---------------------------------------------------------------------------
if ($action == 'go')
{
	$intent = (isset($_GET['intent']) && $_GET['intent'] == 'login') ? 'login' : 'register';
	$url = eveauth_authorize_url($intent);

	$db->end_transaction();
	header('Location: '.$url);
	exit;
}


// ---------------------------------------------------------------------------
// create: POST from the email confirmation form
// ---------------------------------------------------------------------------
else if ($action == 'create')
{
	if (!isset($_POST['form_sent']))
		message($lang_common['Bad request'], false, '404 Not Found');

	check_csrf($_POST['csrf_token'] ?? null);

	$char = eveauth_unseal($_POST['eveauth_tok'] ?? '');
	if ($char === false || empty($char['character_id']) || empty($char['character_name']))
		message('Your EVE Online sign-in has expired. Please <a href="'.pun_htmlspecialchars(eveauth_callback_url()).'?a=go">start again</a>.');

	// The character may have registered in another tab meanwhile
	$existing = eveauth_user_by_character($char['character_id']);
	if ($existing !== null)
	{
		eveauth_login_user($existing);
		redirect('index.php', $lang_common['Redirecting']);
	}

	$result = eveauth_create_user($char, $_POST['req_email'] ?? '');

	if (is_int($result))
	{
		$new_user = eveauth_user_by_character($char['character_id']);
		if ($new_user !== null)
			eveauth_login_user($new_user);

		redirect('index.php', 'Welcome to '.pun_htmlspecialchars($pun_config['o_board_title']).', pilot. Registration complete.');
	}

	// Validation problem - show the form again with an error
	$eveauth_errors = array(
		'closed'		=> 'This board is not accepting new registrations at the moment.',
		'email'			=> 'The email address you entered is invalid.',
		'banned_email'	=> 'The email address you entered is not allowed on this board.',
		'dupe_email'	=> 'Someone has already registered with that email address.',
		'username'		=> 'An account named after your character already exists but is not linked to EVE Online. Please contact the board administrator.',
	);
	$eveauth_error = isset($eveauth_errors[$result]) ? $eveauth_errors[$result] : 'Registration failed. Please try again.';

	if ($result == 'closed' || $result == 'username')
		message($eveauth_error);

	// Fall through to render the confirmation form again
	$eveauth_char = $char;
	$eveauth_tok = eveauth_seal(array_diff_key($char, array('_t' => 1)));
	$eveauth_email = pun_trim($_POST['req_email'] ?? '');
}


// ---------------------------------------------------------------------------
// callback: ?code=...&state=... from the EVE SSO
// ---------------------------------------------------------------------------
else if (isset($_GET['code']))
{
	$state = eveauth_unseal($_GET['state'] ?? '', 900);
	if ($state === false || empty($state['n']) || !isset($_COOKIE['eveauth_state']) || !hash_equals($state['n'], (string) $_COOKIE['eveauth_state']))
		message('Your EVE Online sign-in could not be verified (the state check failed). Please <a href="'.pun_htmlspecialchars(eveauth_callback_url()).'?a=go">try again</a>.');

	// The nonce is spent
	forum_setcookie('eveauth_state', '', 1);

	$identity = eveauth_exchange_code($_GET['code']);
	if ($identity === false)
		message('EVE Online did not confirm your sign-in. Please try again in a moment.');

	list($character_id, $character_name) = $identity;

	// Already bound to an account? Refresh their affiliation and log in.
	$existing = eveauth_user_by_character($character_id);
	if ($existing !== null)
	{
		$char = eveauth_lookup_character($character_id);
		if ($char !== false)
		{
			eveauth_apply_affiliation($existing['id'], $char);

			// The group may have just changed - re-read before the cookie
			$existing = eveauth_user_by_character($character_id);
		}

		eveauth_login_user($existing);
		redirect('index.php', $lang_common['Redirecting']);
	}

	if ($pun_config['o_regs_allow'] == '0')
		message('This board is not accepting new registrations at the moment.');

	// New character: look up their corp/alliance, then confirm an email
	$char = eveauth_lookup_character($character_id);
	if ($char === false)
		message('Could not reach the EVE Online API to look up your corporation. Please try again in a moment.');

	$char['character_id'] = $character_id;
	$char['character_name'] = $character_name;

	$eveauth_char = $char;
	$eveauth_tok = eveauth_seal($char);
	$eveauth_email = '';
	$eveauth_error = null;
}

else
{
	$db->end_transaction();
	header('Location: '.get_base_url().'/login.php');
	exit;
}


// ---------------------------------------------------------------------------
// Render the email confirmation form (reached from callback or from a
// failed create)
// ---------------------------------------------------------------------------

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), 'EVE Online registration');
$required_fields = array('req_email' => $lang_common['Email']);
$focus_element = array('eveauth_confirm', 'req_email');

define('PUN_ACTIVE_PAGE', 'register');
require PUN_ROOT.'header.php';

$eveauth_member_note = $eveauth_char['is_member']
	? 'Your character is a member of <strong>'.pun_htmlspecialchars($pun_config['o_eveauth_entity_name']).'</strong> - you will join the board as a full member.'
	: 'Your character is not currently a member of <strong>'.pun_htmlspecialchars($pun_config['o_eveauth_entity_name']).'</strong> - you will join the board as a guest until you are.';

if (!empty($eveauth_error))
{

?>
<div id="posterror" class="block">
	<h2><span>Registration errors</span></h2>
	<div class="box">
		<div class="inbox error-info">
			<ul class="error-list">
				<li><strong><?php echo $eveauth_error ?></strong></li>
			</ul>
		</div>
	</div>
</div>

<?php

}
?>
<div id="regform" class="blockform">
	<h2><span>EVE Online registration</span></h2>
	<div class="box">
		<form id="eveauth_confirm" method="post" action="<?php echo pun_htmlspecialchars(eveauth_callback_url()) ?>?a=create" onsubmit="return process_form(this)">
			<div class="inform">
				<div class="forminfo">
					<h3>Character verified</h3>
					<p>You have signed in with EVE Online as the character below. Your forum username and avatar come straight from the game.</p>
				</div>
				<fieldset>
					<legend>Your pilot</legend>
					<div class="infldset">
						<input type="hidden" name="form_sent" value="1" />
						<input type="hidden" name="eveauth_tok" value="<?php echo pun_htmlspecialchars($eveauth_tok) ?>" />
						<p id="eveauth-char">
							<img src="<?php echo pun_htmlspecialchars(eveauth_portrait_url($eveauth_char['character_id'], 128)) ?>" width="64" height="64" alt="" style="float: left; margin: 0 12px 8px 0;" />
							<strong id="eveauth-charname"><?php echo pun_htmlspecialchars($eveauth_char['character_name']) ?></strong><br />
							<?php echo pun_htmlspecialchars(eveauth_title($eveauth_char['corp_name'], $eveauth_char['corp_ticker'])) ?>
							<?php if ($eveauth_char['alliance_name'] != ''): ?><br /><?php echo pun_htmlspecialchars($eveauth_char['alliance_name']) ?><?php endif; ?>
						</p>
						<p class="clearb" id="eveauth-membernote"><?php echo $eveauth_member_note ?></p>
					</div>
				</fieldset>
			</div>
			<div class="inform">
				<fieldset>
					<legend>Enter a valid email address</legend>
					<div class="infldset">
						<p>The board uses your email only for password recovery and any notifications you opt into. It is never shown publicly.</p>
						<label class="required"><strong><?php echo $lang_common['Email'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br />
						<input type="text" name="req_email" value="<?php echo pun_htmlspecialchars($eveauth_email) ?>" size="50" maxlength="80" /><br /></label>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="register" value="Complete registration" /></p>
		</form>
	</div>
</div>
<?php

require PUN_ROOT.'footer.php';
