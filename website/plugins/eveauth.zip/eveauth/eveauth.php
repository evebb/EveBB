<?php

/**
 * EVE Online SSO - the addon.
 *
 * Hooks:
 *   header_head_end             bootstrap, periodic membership recheck,
 *                               and per-page UI injection (register and
 *                               login buttons, corp lines on posts, EVE
 *                               panel on profiles)
 *   register_before_validation  blocks normal form registration while
 *                               SSO is configured (SSO-only boards)
 *
 * The OAuth flow itself lives in sso.php (the registered callback URL).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_eveauth extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
		$manager->bind('register_before_validation', array($this, 'block_form_registration'));
	}

	//
	// While SSO is configured, the classic registration form must not
	// create accounts (fires inside register.php's POST handling,
	// before header.php - message() is safe here)
	//
	function block_form_registration()
	{
		require_once dirname(__FILE__).'/lib.php';

		if (!eveauth_configured())
			return;

		message('This board registers new accounts through <strong>EVE Online</strong>. <a href="'.pun_htmlspecialchars(eveauth_callback_url()).'?a=go">Log in with EVE Online</a> to create your account.');
	}

	//
	// Everything else hangs off header_head_end (fires on every page)
	//
	function head()
	{
		global $pun_user, $pun_config, $db, $id;

		// message() re-includes header.php - never run twice
		static $busy;
		if ($busy)
			return;
		$busy = true;

		require_once dirname(__FILE__).'/lib.php';

		eveauth_bootstrap();

		$page = basename($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '');
		$configured = eveauth_configured();

		// Opportunistic membership recheck (time-gated; fails open).
		// Skipped on the SSO endpoint itself to keep the flow snappy.
		if ($configured && $page != 'sso.php')
			eveauth_recheck();

		if ($configured && $page == 'register.php' && $pun_user['is_guest'])
			$this->inject_register_ui();
		else if ($configured && $page == 'login.php' && $pun_user['is_guest'])
			$this->inject_login_ui();
		else if ($page == 'viewtopic.php' && intval($id ?? 0) > 0)
			$this->inject_topic_corps(intval($id));
		else if ($page == 'profile.php' && intval($_GET['id'] ?? 0) > 0 && !isset($_GET['action']) && !isset($_GET['section']))
			$this->inject_profile_panel(intval($_GET['id']));

		$busy = false;
	}

	//
	// Shared: emit the SSO button panel builder (safe: all dynamic
	// strings go through json_encode, DOM built with createElement)
	//
	function sso_panel_js($heading, $blurb, $intent)
	{
		global $pun_config;

		$data = array(
			'go'		=> eveauth_callback_url().'?a=go&intent='.$intent,
			'heading'	=> $heading,
			'blurb'		=> $blurb,
			'entity'	=> $pun_config['o_eveauth_entity_name'],
			'logo'		=> eveauth_logo_url($pun_config['o_eveauth_entity_type'], $pun_config['o_eveauth_entity_id'], 64),
		);

		return 'function eveauthPanel(){var d='.json_encode($data, JSON_UNESCAPED_SLASHES).';'
			.'var p=document.createElement("div");p.className="inform";'
			.'var f=document.createElement("fieldset");var l=document.createElement("legend");l.textContent=d.heading;f.appendChild(l);'
			.'var s=document.createElement("div");s.className="infldset";'
			.'var img=document.createElement("img");img.src=d.logo;img.width=48;img.height=48;img.alt="";img.style.cssText="float:left;margin:0 12px 8px 0;";s.appendChild(img);'
			.'var t=document.createElement("p");t.textContent=d.blurb;s.appendChild(t);'
			.'var a=document.createElement("a");a.href=d.go;a.textContent="Log in with EVE Online";'
			.'a.style.cssText="display:inline-block;margin:8px 0 4px;padding:9px 18px;background:#000;color:#fff;border:1px solid #444;border-radius:3px;font-weight:bold;text-decoration:none;";'
			// NOTE: no className here. "clearb" seems natural (the img floats
			// left) but Carbon's ".pun #login p.clearb" rule crushes such
			// paragraphs into a zero-height dotted separator, which made the
			// login button invisible inside #login (v1.0.0 bug).
			.'var w=document.createElement("p");w.style.cssText="clear:both;";w.appendChild(a);s.appendChild(w);'
			.'f.appendChild(s);p.appendChild(f);return p;}';
	}

	//
	// register.php: replace the whole classic form with the SSO panel
	//
	function inject_register_ui()
	{
		global $pun_config;

		$blurb = 'New accounts are created by signing in with your EVE Online character. Your character name becomes your username, your portrait becomes your avatar, and your corporation decides your member group on this board ('.$pun_config['o_eveauth_entity_name'].' members get full membership).';

		echo '<script>'."\n"
			.'document.addEventListener("DOMContentLoaded",function(){'
			.$this->sso_panel_js('Register with EVE Online', $blurb, 'register')
			.'var rf=document.getElementById("regform");if(!rf)return;'
			.'var form=rf.querySelector("form");if(form){form.style.display="none";}'
			.'var box=rf.querySelector(".box");if(!box)return;'
			.'var nf=document.createElement("form");nf.appendChild(eveauthPanel());box.appendChild(nf);'
			.'});</script>'."\n";
	}

	//
	// login.php: add the SSO panel above the classic login form (which
	// stays as the fallback for pre-SSO accounts and admins)
	//
	function inject_login_ui()
	{
		echo '<script>'."\n"
			.'document.addEventListener("DOMContentLoaded",function(){'
			.$this->sso_panel_js('Log in with EVE Online', 'Sign in with your EVE Online character to access this board. Accounts made before EVE sign-in was enabled can still use the password form below.', 'login')
			.'var lf=document.getElementById("login");if(!lf)return;'
			.'var d=document.createElement("div");d.appendChild(eveauthPanel());lf.insertBefore(d,lf.firstChild);'
			.'});</script>'."\n";
	}

	//
	// viewtopic.php: corp identity under every bound poster.
	// The map is keyed by username (unique on the board) and matched
	// against the author name in each post block.
	//
	function inject_topic_corps($topic_id)
	{
		global $db, $pun_config;

		$result = $db->query('SELECT DISTINCT u.username, e.corp_id, e.corp_name, e.corp_ticker, e.alliance_name FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'eveauth_users AS e ON e.user_id=p.poster_id INNER JOIN '.$db->prefix.'users AS u ON u.id=p.poster_id WHERE p.topic_id='.$topic_id) or error('Unable to fetch EVE posters', __FILE__, __LINE__, $db->error());

		$map = array();
		while ($row = $db->fetch_assoc($result))
		{
			$map[$row['username']] = array(
				'logo'		=> eveauth_logo_url('corporation', $row['corp_id'], 32),
				'corp'		=> $row['corp_name'].($row['corp_ticker'] != '' ? ' ['.$row['corp_ticker'].']' : ''),
				'alliance'	=> $row['alliance_name'],
			);
		}

		if (empty($map))
			return;

		// When the plugin manages user titles the corp name is already
		// printed as the title - only add the logo. Otherwise print the
		// full corp line.
		$titles_managed = ($pun_config['o_eveauth_settitle'] == '1');

		echo '<script>'."\n"
			.'document.addEventListener("DOMContentLoaded",function(){'
			.'var map='.json_encode($map, JSON_UNESCAPED_SLASHES).';var managed='.($titles_managed ? 'true' : 'false').';'
			.'document.querySelectorAll(".blockpost .postleft dt, .blockpost .postfootleft dt").forEach(function(dt){'
			.'var name=dt.textContent.replace(/\s+/g," ").trim();'
			.'var info=map[name];if(!info)return;'
			.'var dl=dt.parentNode;if(dl.querySelector(".eveauth-corp"))return;'
			.'var dd=document.createElement("dd");dd.className="eveauth-corp";dd.style.cssText="margin-top:2px;";'
			.'var img=document.createElement("img");img.src=info.logo;img.width=16;img.height=16;img.alt="";img.style.cssText="vertical-align:text-bottom;margin-right:4px;";dd.appendChild(img);'
			.'if(!managed){var s=document.createElement("span");s.textContent=info.corp;dd.appendChild(s);}'
			.'else{img.title=info.corp;}'
			.'if(info.alliance){var al=document.createElement("span");al.textContent=(managed?"":" / ")+info.alliance;al.style.cssText="display:"+(managed?"inline":"block")+";font-size:0.9em;";if(managed){al.style.marginLeft="4px";}dd.appendChild(al);}'
			.'var title=dl.querySelector("dd.usertitle");'
			.'if(title){title.parentNode.insertBefore(dd,title.nextSibling);}else{dl.appendChild(dd);}'
			.'});});</script>'."\n";
	}

	//
	// profile.php (view mode): a small EVE Online panel for bound users
	//
	function inject_profile_panel($user_id)
	{
		global $db, $pun_config;

		$result = $db->query('SELECT character_id, character_name, corp_id, corp_name, corp_ticker, alliance_id, alliance_name, is_member FROM '.$db->prefix.'eveauth_users WHERE user_id='.$user_id) or error('Unable to fetch EVE user', __FILE__, __LINE__, $db->error());
		if (!$db->has_rows($result))
			return;

		$row = $db->fetch_assoc($result);

		$data = array(
			'portrait'	=> eveauth_portrait_url($row['character_id'], 128),
			'name'		=> $row['character_name'],
			'corplogo'	=> eveauth_logo_url('corporation', $row['corp_id'], 32),
			'corp'		=> $row['corp_name'].($row['corp_ticker'] != '' ? ' ['.$row['corp_ticker'].']' : ''),
			'alliance'	=> $row['alliance_name'],
			'allylogo'	=> ($row['alliance_id'] > 0) ? eveauth_logo_url('alliance', $row['alliance_id'], 32) : '',
			'member'	=> intval($row['is_member']) == 1,
			'entity'	=> $pun_config['o_eveauth_entity_name'],
		);

		echo '<script>'."\n"
			.'document.addEventListener("DOMContentLoaded",function(){'
			.'var d='.json_encode($data, JSON_UNESCAPED_SLASHES).';'
			.'var host=document.getElementById("viewprofile");if(!host)return;'
			.'var blk=document.createElement("div");blk.className="inform";'
			.'var f=document.createElement("fieldset");var l=document.createElement("legend");l.textContent="EVE Online";f.appendChild(l);'
			.'var s=document.createElement("div");s.className="infldset";'
			.'function line(logo,text,bold){var p=document.createElement("p");if(logo){var i=document.createElement("img");i.src=logo;i.width=16;i.height=16;i.alt="";i.style.cssText="vertical-align:text-bottom;margin-right:5px;";p.appendChild(i);}var t=document.createElement(bold?"strong":"span");t.textContent=text;p.appendChild(t);return p;}'
			.'s.appendChild(line(null,d.name,true));'
			.'s.appendChild(line(d.corplogo,d.corp,false));'
			.'if(d.alliance)s.appendChild(line(d.allylogo,d.alliance,false));'
			.'var st=document.createElement("p");st.textContent=d.member?("Member of "+d.entity):("Not a member of "+d.entity);st.style.cssText="font-size:0.9em;opacity:0.8;";s.appendChild(st);'
			.'f.appendChild(s);blk.appendChild(f);'
			.'var box=host.querySelector(".box");(box||host).appendChild(blk);'
			.'});</script>'."\n";
	}
}
