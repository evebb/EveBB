<?php

/**
 * Knowledge Base - shared library.
 *
 * Articles are stored preparsed (same as posts) and rendered through
 * the board's own parser, so every BBCode feature and every parser
 * plugin works in articles too. Tables are created on first use,
 * guarded by the o_kb_db_rev config key (polls/showcase pattern).
 *
 * This is an official eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

define('KB_DB_REV', 1);

//
// Upsert a config value + refresh the cache
//
function kb_save_config($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}

function kb_page_url()
{
	return get_base_url(true).'/plugins/kb/';
}

function kb_article_url($slug)
{
	return kb_page_url().'?a='.rawurlencode($slug);
}

//
// May the current user write/manage articles? Admins + moderators.
//
function kb_can_edit()
{
	global $pun_user;

	return $pun_user['g_id'] == PUN_ADMIN || $pun_user['g_moderator'] == '1';
}

//
// First-run bootstrap: categories, articles, votes
//
function kb_bootstrap()
{
	global $db, $pun_config;

	if (isset($pun_config['o_kb_db_rev']))
		return;

	if (!$db->table_exists('kb_categories'))
	{
		$db->create_table('kb_categories', array(
			'FIELDS' => array(
				'id'       => array('datatype' => 'SERIAL', 'allow_null' => false),
				'name'     => array('datatype' => 'VARCHAR(80)', 'allow_null' => false, 'default' => '\'\''),
				'position' => array('datatype' => 'INT(10)', 'allow_null' => false, 'default' => '0'),
			),
			'PRIMARY KEY' => array('id'),
		)) or error('Unable to create kb_categories table', __FILE__, __LINE__, $db->error());
	}

	if (!$db->table_exists('kb_articles'))
	{
		$db->create_table('kb_articles', array(
			'FIELDS' => array(
				'id'          => array('datatype' => 'SERIAL', 'allow_null' => false),
				'category_id' => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'slug'        => array('datatype' => 'VARCHAR(60)', 'allow_null' => false, 'default' => '\'\''),
				'title'       => array('datatype' => 'VARCHAR(120)', 'allow_null' => false, 'default' => '\'\''),
				'body'        => array('datatype' => 'TEXT', 'allow_null' => true),
				'published'   => array('datatype' => 'SMALLINT(6)', 'allow_null' => false, 'default' => '0'),
				'position'    => array('datatype' => 'INT(10)', 'allow_null' => false, 'default' => '0'),
				'views'       => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'helpful_yes' => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'helpful_no'  => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'created_by'  => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'created_at'  => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'updated_at'  => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
			),
			'PRIMARY KEY' => array('id'),
			'UNIQUE KEYS' => array('slug_idx' => array('slug')),
			'INDEXES'     => array('cat_idx' => array('category_id')),
		)) or error('Unable to create kb_articles table', __FILE__, __LINE__, $db->error());
	}

	if (!$db->table_exists('kb_votes'))
	{
		$db->create_table('kb_votes', array(
			'FIELDS' => array(
				'article_id' => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'voter_key'  => array('datatype' => 'VARCHAR(48)', 'allow_null' => false, 'default' => '\'\''),
				'vote'       => array('datatype' => 'SMALLINT(6)', 'allow_null' => false, 'default' => '0'),
				'created_at' => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
			),
			'PRIMARY KEY' => array('article_id', 'voter_key'),
		)) or error('Unable to create kb_votes table', __FILE__, __LINE__, $db->error());
	}

	kb_save_config('o_kb_db_rev', KB_DB_REV);
	kb_save_config('o_kb_navlink', '1');
	kb_save_config('o_kb_votes', '1');
	kb_save_config('o_kb_posttag', '1');
}

//
// A slug: lowercase letters, digits, hyphens; derived from the title
// when not supplied.
//
function kb_make_slug($slug, $title)
{
	$s = strtolower(pun_trim($slug !== '' ? $slug : $title));
	$s = preg_replace('%[^a-z0-9]+%', '-', $s);
	$s = trim(preg_replace('%-{2,}%', '-', $s), '-');
	return utf8_substr($s, 0, 60);
}

//
// Categories in display order
//
function kb_categories()
{
	global $db;

	$result = $db->query('SELECT id, name, position FROM '.$db->prefix.'kb_categories ORDER BY position, name') or error('Unable to fetch KB categories', __FILE__, __LINE__, $db->error());

	$out = array();
	while ($row = $db->fetch_assoc($result))
		$out[$row['id']] = $row;
	return $out;
}

//
// Articles grouped per category. Drafts included only for staff.
//
function kb_articles_by_category($include_drafts)
{
	global $db;

	$where = $include_drafts ? '' : ' WHERE published=1';
	$result = $db->query('SELECT id, category_id, slug, title, published, position, views, updated_at FROM '.$db->prefix.'kb_articles'.$where.' ORDER BY position, title') or error('Unable to fetch KB articles', __FILE__, __LINE__, $db->error());

	$out = array();
	while ($row = $db->fetch_assoc($result))
		$out[$row['category_id']][] = $row;
	return $out;
}

//
// One article by slug (null when absent, or a draft for non-staff)
//
function kb_article($slug, $include_drafts)
{
	global $db;

	$result = $db->query('SELECT * FROM '.$db->prefix.'kb_articles WHERE slug=\''.$db->escape($slug).'\''.($include_drafts ? '' : ' AND published=1')) or error('Unable to fetch KB article', __FILE__, __LINE__, $db->error());
	$row = $db->fetch_assoc($result);
	return $row === false ? null : $row;
}

//
// Case-insensitive substring search over title + body (published only
// for visitors; staff also see drafts). Returns at most 50 rows.
//
function kb_search($q, $include_drafts)
{
	global $db;

	$like = '\'%'.$db->escape(str_replace(array('%', '_'), array('\\%', '\\_'), strtolower($q))).'%\'';
	$pub = $include_drafts ? '' : ' AND published=1';
	$result = $db->query('SELECT id, category_id, slug, title, published, views FROM '.$db->prefix.'kb_articles WHERE (LOWER(title) LIKE '.$like.' OR LOWER(body) LIKE '.$like.')'.$pub.' ORDER BY position, title LIMIT 50') or error('Unable to search KB', __FILE__, __LINE__, $db->error());

	$out = array();
	while ($row = $db->fetch_assoc($result))
		$out[] = $row;
	return $out;
}

//
// Who is voting - a stable key per member, per IP for guests
//
function kb_voter_key()
{
	global $pun_user;

	if (!$pun_user['is_guest'])
		return 'u'.$pun_user['id'];
	return 'i'.substr(sha1(get_remote_address()), 0, 40);
}

//
// Record a helpful yes/no. One vote per voter per article; a repeat
// vote updates the choice. Counters on the article row keep display
// cheap.
//
function kb_vote($article_id, $up)
{
	global $db;

	$article_id = intval($article_id);
	$key = kb_voter_key();
	$vote = $up ? 1 : 0;

	$result = $db->query('SELECT vote FROM '.$db->prefix.'kb_votes WHERE article_id='.$article_id.' AND voter_key=\''.$db->escape($key).'\'') or error('Unable to fetch KB vote', __FILE__, __LINE__, $db->error());
	$old = $db->fetch_assoc($result);

	if ($old === false)
		$db->query('INSERT INTO '.$db->prefix.'kb_votes (article_id, voter_key, vote, created_at) VALUES('.$article_id.', \''.$db->escape($key).'\', '.$vote.', '.time().')') or error('Unable to insert KB vote', __FILE__, __LINE__, $db->error());
	else if (intval($old['vote']) !== $vote)
		$db->query('UPDATE '.$db->prefix.'kb_votes SET vote='.$vote.' WHERE article_id='.$article_id.' AND voter_key=\''.$db->escape($key).'\'') or error('Unable to update KB vote', __FILE__, __LINE__, $db->error());
	else
		return; // unchanged

	// Recount (cheap and always right - a KB stays small)
	$db->query('UPDATE '.$db->prefix.'kb_articles SET
		helpful_yes=(SELECT COUNT(*) FROM '.$db->prefix.'kb_votes WHERE article_id='.$article_id.' AND vote=1),
		helpful_no=(SELECT COUNT(*) FROM '.$db->prefix.'kb_votes WHERE article_id='.$article_id.' AND vote=0)
		WHERE id='.$article_id) or error('Unable to update KB counters', __FILE__, __LINE__, $db->error());
}

//
// Published slug => title map (for the [kb:slug] chips in posts)
//
function kb_slug_map()
{
	global $db;

	$result = $db->query('SELECT slug, title FROM '.$db->prefix.'kb_articles WHERE published=1') or error('Unable to fetch KB slugs', __FILE__, __LINE__, $db->error());

	$out = array();
	while ($row = $db->fetch_assoc($result))
		$out[$row['slug']] = $row['title'];
	return $out;
}
