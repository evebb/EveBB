<?php

/**
 * Menu Order - the addon.
 *
 * Rearranges (and optionally hides) the items in the board navigation
 * menu (#brdmenu) by their element ids. A MutationObserver re-applies
 * the arrangement whenever the menu changes, so items that other
 * plugins inject after page load (e.g. the Showcase link) obey the
 * configured order too. Without JavaScript the menu simply keeps its
 * default order.
 *
 * Hiding is cosmetic only: the pages themselves stay reachable by URL
 * and every permission check still applies.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_navorder extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	//
	// Parse a comma-separated id list from config into a clean array
	//
	function id_list($value)
	{
		$ids = array();
		foreach (explode(',', $value) as $bit)
		{
			$bit = strtolower(trim($bit));
			if ($bit !== '' && preg_match('%^[a-z0-9_-]+$%', $bit))
				$ids[] = $bit;
		}

		return array_values(array_unique($ids));
	}

	function head()
	{
		global $pun_config;

		$order = $this->id_list($pun_config['o_navorder_order'] ?? '');
		$hide = $this->id_list($pun_config['o_navorder_hide'] ?? '');

		if (empty($order) && empty($hide))
			return;

		$data = array('order' => $order, 'hide' => $hide);

		echo '<script>'."\n"
			.'document.addEventListener("DOMContentLoaded",function(){'
			.'var d='.json_encode($data, JSON_UNESCAPED_SLASHES).';'
			.'var ul=document.querySelector("#brdmenu ul");if(!ul)return;'
			.'var busy=false,obs=null;'
			.'function apply(){'
			.'if(busy)return;busy=true;'
			.'if(obs)obs.disconnect();'
			.'d.hide.forEach(function(id){var e=document.getElementById(id);'
			.'if(e&&e.parentNode===ul)e.style.display="none";});'
			.'var listed=[];'
			.'d.order.forEach(function(id){var e=document.getElementById(id);'
			.'if(e&&e.parentNode===ul)listed.push(e);});'
			.'if(listed.length){'
			.'var frag=document.createDocumentFragment();'
			.'listed.forEach(function(e){frag.appendChild(e);});'
			.'ul.insertBefore(frag,ul.firstChild);}'
			.'if(obs)obs.observe(ul,{childList:true});'
			.'busy=false;}'
			.'obs=new MutationObserver(apply);'
			.'apply();'
			.'});</script>'."\n";
	}
}
