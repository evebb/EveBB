# Menu Order for eveBB

Rearrange the board's navigation menu without touching core — and hide
the items you don't want shown.

## What it does

The core lets you *add* menu items at chosen positions (Administration →
Options → Additional menu items), but the built-in items — Index, User
list, Rules, Search, Profile and the rest — always appear in their
hardcoded order. This plugin fixes that: list the item ids in the order
you want and the menu rearranges itself. Items you don't list keep
their usual order after the ones you do; a second list hides items
entirely.

- Works with the built-ins (`navindex`, `navuserlist`, `navrules`,
  `navsearch`, `navregister`, `navlogin`, `navprofile`, `navadmin`,
  `navlogout`), with extra items (`navextra1`, `navextra2`, …), and
  with items added by other plugins (e.g. the Showcase plugin's
  `navshowcase`) — even though those join the menu after the page
  loads, the plugin keeps watching and puts them in their place.
- **Hiding is cosmetic only**: pages stay reachable by URL and every
  permission check still applies. Use group permissions to actually
  restrict access.
- Without JavaScript the menu simply keeps its default order.

## Install

Upload the zip through Administration → Plugins, activate, then set
your order and hide lists on the settings page. No database changes at
all — two config values, gone on deactivation.

License: GPL v2 or higher, same as eveBB.
