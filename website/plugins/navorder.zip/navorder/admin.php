<?php

/**
 * Menu Order - settings page (shown inside the plugin manager).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

if (!function_exists('navorder_save_config'))
{
function navorder_save_config($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}

function navorder_clean_list($value)
{
	$ids = array();
	foreach (explode(',', $value) as $bit)
	{
		$bit = strtolower(trim($bit));
		if ($bit !== '' && preg_match('%^[a-z0-9_-]+$%', $bit))
			$ids[] = $bit;
	}

	return implode(',', array_values(array_unique($ids)));
}
}

if (isset($_POST['save_navorder']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	navorder_save_config('o_navorder_order', navorder_clean_list($_POST['order'] ?? ''));
	navorder_save_config('o_navorder_hide', navorder_clean_list($_POST['hide'] ?? ''));

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}

$no_order = $pun_config['o_navorder_order'] ?? '';
$no_hide = $pun_config['o_navorder_hide'] ?? '';

?>
	<div class="inform">
		<fieldset>
			<legend>How it works</legend>
			<div class="infldset">
				<p>Every item in the board menu has an id. List the ids you care about, in the order you want them, and the menu rearranges itself — items you don't list keep their usual order after the ones you do. Hidden items disappear from the menu everywhere.</p>
				<p><strong>Hiding is cosmetic only.</strong> The pages themselves stay reachable by their addresses and every permission check still applies — use group permissions to actually restrict access.</p>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Your menu items and their ids</legend>
			<div class="infldset">
				<p>This is your board's menu right now, as this page sees it — including items added by other plugins:</p>
				<table id="navorder-ref" style="border-collapse: collapse;">
					<tr><th style="text-align: left; padding: 2px 18px 2px 0;">Menu item</th><th style="text-align: left; padding: 2px 0;">id</th></tr>
				</table>
				<p style="margin-top: 8px;">Two ids only appear for logged-out visitors and so aren't listed above: <code>navregister</code> (Register) and <code>navlogin</code> (Login). Extra items from Administration → Options are <code>navextra1</code>, <code>navextra2</code>, … in the order listed there.</p>
				<script>
				document.addEventListener("DOMContentLoaded", function () {
					var table = document.getElementById("navorder-ref");
					function fill() {
						while (table.rows.length > 1)
							table.deleteRow(1);
						document.querySelectorAll("#brdmenu ul > li").forEach(function (li) {
							if (!li.id) return;
							var row = table.insertRow(-1);
							var name = row.insertCell(0);
							name.textContent = li.textContent.trim() + (li.style.display === "none" ? " (currently hidden)" : "");
							name.style.padding = "2px 18px 2px 0";
							var id = row.insertCell(1);
							var code = document.createElement("code");
							code.textContent = li.id;
							id.appendChild(code);
						});
					}
					// Fill now, and again once other plugins have added their items
					fill();
					setTimeout(fill, 250);
				});
				</script>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Menu Order settings</legend>
			<div class="infldset">
				<label>Order (comma-separated ids; listed items come first, in this order)
					<br /><input type="text" name="order" size="70" maxlength="255" value="<?php echo pun_htmlspecialchars($no_order) ?>" />
				</label>
				<label>Hide (comma-separated ids)
					<br /><input type="text" name="hide" size="70" maxlength="255" value="<?php echo pun_htmlspecialchars($no_hide) ?>" />
				</label>
				<p>Example: order <code>navindex,navshowcase,navsearch</code> puts Showcase right after Index with Search third; hide <code>navuserlist</code> tucks the user list away. Leave both blank to restore the default menu.</p>
				<p class="topspace"><input type="submit" name="save_navorder" value="Save settings" /></p>
			</div>
		</fieldset>
	</div>
<?php
