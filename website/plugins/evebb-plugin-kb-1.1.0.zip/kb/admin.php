<?php

/**
 * Knowledge Base - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome. Content
 * management itself lives on the public side (plugins/kb/edit.php) so
 * that moderators - not just administrators - can write articles.
 *
 * This is an official eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

kb_bootstrap();

// Save settings
if (isset($_POST['save_kb']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	kb_save_config('o_kb_navlink', isset($_POST['kb_navlink']) ? '1' : '0');
	kb_save_config('o_kb_votes', isset($_POST['kb_votes']) ? '1' : '0');
	kb_save_config('o_kb_posttag', isset($_POST['kb_posttag']) ? '1' : '0');

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}

// Remove all plugin data
if (isset($_POST['nuke_kb']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		message('Tick the confirmation box to remove the knowledge base data.');

	$db->drop_table('kb_votes');
	$db->drop_table('kb_articles');
	$db->drop_table('kb_categories');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN (\'o_kb_db_rev\', \'o_kb_navlink\', \'o_kb_votes\', \'o_kb_posttag\')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());
	unset($pun_config['o_kb_db_rev'], $pun_config['o_kb_navlink'], $pun_config['o_kb_votes'], $pun_config['o_kb_posttag']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Knowledge base data removed. Redirecting …');
}

$result = $db->query('SELECT COUNT(*) FROM '.$db->prefix.'kb_articles') or error('Unable to count articles', __FILE__, __LINE__, $db->error());
$kb_count = intval($db->result($result));

?>
<div class="blockform">
	<h2><span>Knowledge Base</span></h2>
	<div class="box"><div class="inbox">
		<p>Articles are written on the board itself, by administrators and
		moderators: <a href="<?php echo pun_htmlspecialchars(kb_page_url().'edit.php') ?>">manage articles</a>
		(<?php echo $kb_count ?> so far) &middot;
		<a href="<?php echo pun_htmlspecialchars(kb_page_url()) ?>">view the knowledge base</a>.</p>
		<p>Link an article from any post by typing <code>[kb:its-slug]</code> -
		it becomes a chip carrying the article's title.</p>
	</div></div>
</div>

<div class="blockform">
	<h2><span>Settings</span></h2>
	<div class="box"><div class="inbox">
		<fieldset>
			<legend>Display</legend>
			<div class="infldset">
				<p><label><input type="checkbox" name="kb_navlink" value="1"<?php if (($pun_config['o_kb_navlink'] ?? '1') == '1') echo ' checked="checked"' ?> /> Show a "Knowledge base" link in the board navigation</label></p>
				<p><label><input type="checkbox" name="kb_votes" value="1"<?php if (($pun_config['o_kb_votes'] ?? '1') == '1') echo ' checked="checked"' ?> /> Ask readers "Was this helpful?" on every article</label></p>
				<p><label><input type="checkbox" name="kb_posttag" value="1"<?php if (($pun_config['o_kb_posttag'] ?? '1') == '1') echo ' checked="checked"' ?> /> Turn [kb:slug] in posts into article links</label></p>
			</div>
		</fieldset>
		<p class="submitend"><input type="submit" name="save_kb" value="Save settings" /></p>
	</div></div>
</div>

<div class="blockform">
	<h2><span>Remove plugin data</span></h2>
	<div class="box"><div class="inbox">
		<p>Deletes every article, category and vote, and the plugin's settings.
		The plugin files stay installed until you uninstall them from the plugin manager.</p>
		<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently deletes every article and all feedback</label></p>
		<p><input type="submit" name="nuke_kb" value="Remove all plugin data" /></p>
	</div></div>
</div>
