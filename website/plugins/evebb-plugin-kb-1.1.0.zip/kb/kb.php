<?php

/**
 * Knowledge Base - the addon.
 *
 * Adds the "Knowledge base" tab to the board navigation (JS-injected,
 * showcase pattern) and, on topic pages, turns [kb:slug] written in
 * posts into a link chip carrying the article's real title.
 *
 * This is an official eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_kb extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		global $pun_config;

		require_once dirname(__FILE__).'/lib.php';

		if (($pun_config['o_kb_navlink'] ?? '1') == '1')
			$this->nav_link();

		$page = basename($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '');
		if ($page == 'viewtopic.php' && ($pun_config['o_kb_posttag'] ?? '1') == '1')
			$this->post_chips();
	}

	function nav_link()
	{
		echo '<script>document.addEventListener("DOMContentLoaded",function(){'
			.'var m=document.querySelector("#brdmenu ul");if(!m)return;'
			.'if(document.getElementById("navkb"))return;'
			.'var li=document.createElement("li");li.id="navkb";'
			.'var a=document.createElement("a");a.href='.json_encode(kb_page_url(), JSON_UNESCAPED_SLASHES).';a.textContent="Knowledge base";'
			.'li.appendChild(a);'
			.'var ref=document.getElementById("navsearch")||document.getElementById("navuserlist");'
			.'if(ref&&ref.parentNode===m){m.insertBefore(li,ref);}else{m.appendChild(li);}'
			.'});</script>'."\n";
	}

	//
	// Replace literal [kb:slug] in rendered posts with an article link.
	// Only published slugs resolve; unknown ones are left as typed.
	//
	function post_chips()
	{
		global $pun_config;

		// A KB stays small - one query, the map rides along as JSON
		$map = kb_slug_map();
		if (empty($map))
			return;

		echo '<style>.kb-chip{display:inline-block;padding:1px 8px;border:1px solid rgba(128,128,128,.4);'
			.'border-radius:10px;font-size:.9em;text-decoration:none}.kb-chip:before{content:"\1F4D6\00a0"}</style>'."\n"
			.'<script>document.addEventListener("DOMContentLoaded",function(){'
			.'var map='.json_encode($map, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).';'
			.'var base='.json_encode(kb_page_url().'?a=', JSON_UNESCAPED_SLASHES).';'
			.'var re=/\[kb:([a-z0-9-]{1,60})\]/;'
			.'var posts=document.querySelectorAll(".postmsg");'
			.'for(var p=0;p<posts.length;p++){'
			.'var w=document.createTreeWalker(posts[p],NodeFilter.SHOW_TEXT),nodes=[];'
			.'while(w.nextNode()){if(re.test(w.currentNode.nodeValue))nodes.push(w.currentNode);}'
			.'for(var i=0;i<nodes.length;i++){var n=nodes[i];'
			.'if(n.parentNode&&(n.parentNode.closest("code, a")))continue;'
			.'var frag=document.createDocumentFragment(),rest=n.nodeValue,m;'
			.'while((m=re.exec(rest))){'
			.'frag.appendChild(document.createTextNode(rest.slice(0,m.index)));'
			.'if(map[m[1]]){var a=document.createElement("a");a.className="kb-chip";'
			.'a.href=base+encodeURIComponent(m[1]);a.textContent=map[m[1]];frag.appendChild(a);}'
			.'else{frag.appendChild(document.createTextNode(m[0]));}'
			.'rest=rest.slice(m.index+m[0].length);}'
			.'frag.appendChild(document.createTextNode(rest));'
			.'n.parentNode.replaceChild(frag,n);}}'
			.'});</script>'."\n";
	}
}
