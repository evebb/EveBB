# Knowledge Base (official eveBB plugin)

A knowledge base for your board: staff-written articles in categories,
searchable, with draft/published states and "Was this helpful?"
feedback — rendered through the board's own BBCode parser so anything
that works in a post works in an article.

## Install

Upload `evebb-plugin-kb-<version>.zip` through Administration →
Plugins. Tables are created automatically on first use.

## Use

- **Knowledge base tab** appears in the board navigation (toggle in
  the plugin settings).
- **Writing**: administrators and moderators get a "Manage articles"
  link on the knowledge base page (`plugins/kb/edit.php`). Articles
  take a title, an optional slug (made from the title if left blank),
  a category, BBCode text, a sort position and a published tick —
  unticked articles are drafts only staff can see.
- **Search** covers titles and article text.
- **Feedback**: readers answer "Was this helpful?" once per member
  (per IP for guests); staff see the counts and view totals in the
  article footer and the manage table.
- **Link from posts**: type `[kb:the-slug]` in any post and it becomes
  a chip linking the article, labelled with the article's title.
  Unknown slugs are left as typed. (Slug shown per article in the
  manage table.)
- **Suggestions API**: `plugins/kb/suggest.php?q=free+text` returns up
  to 5 relevant published articles as JSON (`slug`, `title`, `url`,
  `category` per hit). The query is split into words, each matched
  against titles and text, best match first — built for "these
  articles might help" boxes such as the eveBB Hosted portal's
  support-ticket form. Drafts are never returned.

## Settings (Administration → Plugins → Knowledge Base)

Toggle the nav link, the feedback question and the `[kb:slug]` post
chips. "Remove all plugin data" deletes articles, categories, votes
and settings (confirmation required).

## Notes

- Bodies are stored preparsed (like posts) and rendered with
  `parse_message()`, so parser plugins (code highlighting etc.) apply.
- Uses `get_base_url(true)` for every browser-facing URL.
- Portable SQL through the DB layer — MySQL/MariaDB, PostgreSQL and
  SQLite all work.

License: GPL v2 or later.

## Changelog

**1.1.0** - New JSON suggestions endpoint (`suggest.php?q=`): word-based
matching over titles and text, published articles only, at most 5 hits,
ranked title-before-body then by views. Used by the eveBB Hosted portal
to suggest articles while a customer writes a support ticket.

**1.0.1** - Public pages now reuse the board's own blocks: categories
and search results render as index tables (attached header bar, padded
rows, alternating stripes) and an article renders as a post, with
breadcrumbs on every view. Colours, borders and rounding come from the
active style, so the knowledge base matches whatever style is in use.

**1.0.0** - First release.
