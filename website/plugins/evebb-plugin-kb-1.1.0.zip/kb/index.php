<?php

/**
 * Knowledge Base - the public pages.
 *
 * ?a=slug      one article (BBCode rendered by the board's parser)
 * ?q=term      search titles + text
 * (nothing)    the front page: categories with their articles
 *
 * Rendered inside the full forum chrome, using the board's own markup:
 * categories are laid out exactly like the board index (blocktable +
 * table), an article is laid out exactly like a post (blockpost +
 * postbody), so every style themes the knowledge base for free.
 *
 * This is an official eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

//
// Absolutize relative href/src so forum chrome works from /plugins/kb/
//
function kb_absolutize($html)
{
	$base = get_base_url(true).'/';

	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('kb_absolutize');

if (!in_array('kb', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

kb_bootstrap();

$kb_staff = kb_can_edit();

// --- "Was this helpful?" vote (POST only, CSRF-checked) --------------------
if (($_SERVER['REQUEST_METHOD'] ?? '') == 'POST' && isset($_POST['kb_vote']))
{
	check_csrf($_POST['csrf_token'] ?? null);

	$slug = pun_trim($_POST['slug'] ?? '');
	$article = kb_article($slug, false);
	if ($article !== null && ($pun_config['o_kb_votes'] ?? '1') == '1')
		kb_vote($article['id'], $_POST['kb_vote'] == 'yes');

	redirect(kb_article_url($slug), 'Thanks for the feedback. Redirecting …');
}

$kb_slug = pun_trim($_GET['a'] ?? '');
$kb_q = pun_trim($_GET['q'] ?? '');
if (pun_strlen($kb_q) > 60)
	$kb_q = pun_trim(utf8_substr($kb_q, 0, 60));

$kb_article = null;
if ($kb_slug !== '')
{
	$kb_article = kb_article($kb_slug, $kb_staff);
	if ($kb_article === null)
		message($lang_common['Bad request'], false, '404 Not Found');
}

//
// One row in a knowledge base table: title (+ optional draft flag) on
// the left, then the two narrow columns the board index uses.
//
function kb_row($n, $article, $col2, $col3)
{
	$classes = ($n % 2 == 0) ? 'roweven' : 'rowodd';
	if ($article['published'] != 1)
		$classes .= ' kb-draft';

	return "\t\t\t\t".'<tr class="'.$classes.'">'."\n"
		."\t\t\t\t\t".'<td class="tcl"><div class="tclcon"><div>'
			.'<h3><a href="'.pun_htmlspecialchars(kb_article_url($article['slug'])).'">'.pun_htmlspecialchars($article['title']).'</a>'
			.($article['published'] != 1 ? ' <em class="kb-flag">draft</em>' : '')
			.'</h3>'
		.'</div></div></td>'."\n"
		."\t\t\t\t\t".'<td class="tc2">'.$col2.'</td>'."\n"
		."\t\t\t\t\t".'<td class="tcr">'.$col3.'</td>'."\n"
		."\t\t\t\t".'</tr>'."\n";
}

//
// The open/close of a board-index style block. $id is used so styles can
// target individual sections the way they do on the index.
//
function kb_block_open($id, $heading, $col2, $col3)
{
	return '<div id="'.$id.'" class="blocktable">'."\n"
		."\t".'<h2><span>'.$heading.'</span></h2>'."\n"
		."\t".'<div class="box">'."\n"
		."\t\t".'<div class="inbox">'."\n"
		."\t\t\t".'<table>'."\n"
		."\t\t\t".'<thead>'."\n"
		."\t\t\t\t".'<tr>'."\n"
		."\t\t\t\t\t".'<th class="tcl" scope="col">Article</th>'."\n"
		."\t\t\t\t\t".'<th class="tc2" scope="col">'.$col2.'</th>'."\n"
		."\t\t\t\t\t".'<th class="tcr" scope="col">'.$col3.'</th>'."\n"
		."\t\t\t\t".'</tr>'."\n"
		."\t\t\t".'</thead>'."\n"
		."\t\t\t".'<tbody>'."\n";
}

function kb_block_close()
{
	return "\t\t\t".'</tbody>'."\n\t\t\t".'</table>'."\n\t\t".'</div>'."\n\t".'</div>'."\n".'</div>'."\n\n";
}

$kb_crumbs = array(array($lang_common['Index'], 'index.php'));
$kb_crumbs[] = array('Knowledge base', 'plugins/kb/');
if ($kb_article !== null)
	$kb_crumbs[] = $kb_article['title'];
else if ($kb_q !== '')
	$kb_crumbs[] = 'Search';

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), 'Knowledge base');
if ($kb_article !== null)
	$page_title[] = pun_htmlspecialchars($kb_article['title']);
define('PUN_ACTIVE_PAGE', 'index');
require PUN_ROOT.'header.php';

?>
<style>
/* The knowledge base borrows the board's own blocks (blocktable for the
   lists, blockpost for an article) so colours, borders and rounding all
   come from the active style. These rules only add spacing and undo the
   post layout's author-column offset, which a knowledge base has no use
   for - nothing here hard-codes a colour. */
#kb .kb-tools .inbox { padding: 10px 12px; }
#kb .kb-toolbar { display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; }
#kb .kb-toolbar form { display: flex; gap: 6px; margin: 0; }
#kb .kb-toolbar input[type=text] { max-width: 100%; }
#kb .blocktable h3 { padding: 0; }
#kb .blocktable h3 a { font-weight: bold; }
#kb .kb-draft { opacity: .7; }
#kb .kb-flag { font-size: .85em; border: 1px solid; border-color: inherit; border-radius: 8px; padding: 0 6px; font-style: normal; opacity: .8; }
#kb .kb-empty { padding: 4px 0; }

/* Article: the post block without the 194px author column */
#kb .kb-article h2 { padding-left: 12px; padding-right: 12px; font-weight: bold; }
#kb .kb-body { float: none; width: auto; margin-right: 0; border-left: 0; padding: 6px 18px 14px 18px; }
#kb .kb-meta { margin-top: 14px; padding-top: 10px; border-top: 1px solid; border-color: inherit; font-size: .923em; }
#kb .kb-vote form { display: inline; margin: 0; }
#kb .kb-vote input[type=submit] { margin-right: 6px; }
#kb .kb-meta .kb-sep { padding: 0 4px; opacity: .5; }

@media (max-width: 720px) {
	#kb .kb-article h2 { height: auto; white-space: normal; }
	#kb .kb-body { padding: 6px 12px 12px 12px; }
	#kb .kb-toolbar, #kb .kb-toolbar form { width: 100%; }
	#kb .kb-toolbar input[type=text] { flex: 1 1 auto; }
}
</style>
<div id="kb">

<div class="linkst">
	<div class="inbox crumbsplus">
		<?php echo generate_crumbs($kb_crumbs) ?>
		<div class="clearer"></div>
	</div>
</div>

<?php

// --- one article -----------------------------------------------------------
if ($kb_article !== null)
{
	// Count the view (staff previews of drafts don't count)
	if ($kb_article['published'] == 1)
		$db->query('UPDATE '.$db->prefix.'kb_articles SET views=views+1 WHERE id='.intval($kb_article['id'])) or error('Unable to count view', __FILE__, __LINE__, $db->error());

	require_once PUN_ROOT.'include/parser.php';

	echo '<div class="blockpost kb-article">'."\n"
		."\t".'<h2><span>'.pun_htmlspecialchars($kb_article['title'])
		.($kb_article['published'] != 1 ? ' <em class="kb-flag">draft - staff only</em>' : '')
		.'</span></h2>'."\n"
		."\t".'<div class="box">'."\n"
		."\t\t".'<div class="postbody kb-body">'."\n"
		."\t\t\t".'<div class="postmsg">'."\n";
	echo parse_message($kb_article['body'], 0);
	echo "\t\t\t".'</div>'."\n";

	$meta = array();
	if (($pun_config['o_kb_votes'] ?? '1') == '1' && $kb_article['published'] == 1)
	{
		$vote = '<span class="kb-vote">Was this helpful? ';
		foreach (array('yes' => 'Yes', 'no' => 'No') as $v => $label)
			$vote .= '<form method="post" action="'.pun_htmlspecialchars(kb_page_url()).'">'
				.'<input type="hidden" name="csrf_token" value="'.pun_csrf_token().'" />'
				.'<input type="hidden" name="slug" value="'.pun_htmlspecialchars($kb_article['slug']).'" />'
				.'<input type="submit" name="kb_vote" value="'.$label.'" onclick="this.form.kb_vote.value=this.value" />'
				.'<input type="hidden" name="kb_vote" value="'.$v.'" /></form> ';
		$meta[] = $vote.'</span>';

		if ($kb_staff)
			$meta[] = intval($kb_article['helpful_yes']).' yes / '.intval($kb_article['helpful_no']).' no &middot; '.forum_number_format(intval($kb_article['views'])).' views';
	}
	if ($kb_staff)
		$meta[] = '<a href="'.pun_htmlspecialchars(kb_page_url().'edit.php?id='.$kb_article['id']).'">Edit this article</a>';
	$meta[] = '<a href="'.pun_htmlspecialchars(kb_page_url()).'">All articles</a>';

	echo "\t\t\t".'<div class="kb-meta">'.implode('<span class="kb-sep">&middot;</span>', $meta).'</div>'."\n";

	echo "\t\t".'</div>'."\n\t".'</div>'."\n".'</div>'."\n\n";
}

// --- search results and front page ------------------------------------------
else
{
	$cats = kb_categories();

	// Toolbar: search box (+ the staff link to article management)
	echo '<div class="blocktable kb-tools">'."\n\t".'<div class="box">'."\n\t\t".'<div class="inbox">'."\n"
		."\t\t\t".'<div class="kb-toolbar">'."\n"
		."\t\t\t\t".'<form method="get" action="'.pun_htmlspecialchars(kb_page_url()).'">'
			.'<input type="text" name="q" size="30" maxlength="60" placeholder="Search the knowledge base" value="'.pun_htmlspecialchars($kb_q).'" />'
			.'<input type="submit" value="Search" /></form>'."\n"
		."\t\t\t\t".'<span>'
			.($kb_q !== '' ? '<a href="'.pun_htmlspecialchars(kb_page_url()).'">All articles</a>' : '')
			.($kb_q !== '' && $kb_staff ? '<span class="kb-sep">&middot;</span>' : '')
			.($kb_staff ? '<a href="'.pun_htmlspecialchars(kb_page_url().'edit.php').'">Manage articles</a>' : '')
			.'</span>'."\n"
		."\t\t\t".'</div>'."\n"
		."\t\t".'</div>'."\n\t".'</div>'."\n".'</div>'."\n\n";

	// --- search results ----------------------------------------------------
	if ($kb_q !== '')
	{
		$hits = kb_search($kb_q, $kb_staff);

		echo kb_block_open('kbsearch', 'Search results', 'Views', 'Category');
		if (empty($hits))
			echo "\t\t\t\t".'<tr class="rowodd">'."\n"
				."\t\t\t\t\t".'<td class="tcl"><div class="tclcon"><div><p class="kb-empty">Nothing found for &#8220;'.pun_htmlspecialchars($kb_q).'&#8221;. Try a shorter or different term.</p></div></div></td>'."\n"
				."\t\t\t\t\t".'<td class="tc2">0</td>'."\n"
				."\t\t\t\t\t".'<td class="tcr">- - -</td>'."\n"
				."\t\t\t\t".'</tr>'."\n";
		else
		{
			$n = 0;
			foreach ($hits as $hit)
			{
				$cat = isset($cats[$hit['category_id']]) ? pun_htmlspecialchars($cats[$hit['category_id']]['name']) : '- - -';
				echo kb_row(++$n, $hit, forum_number_format(intval($hit['views'])), $cat);
			}
		}
		echo kb_block_close();
	}

	// --- front page --------------------------------------------------------
	else
	{
		$arts = kb_articles_by_category($kb_staff);

		$shown = 0;
		foreach ($cats as $cat_id => $cat)
		{
			if (empty($arts[$cat_id]))
				continue;
			++$shown;

			echo kb_block_open('kbcat'.$shown, pun_htmlspecialchars($cat['name']), 'Views', 'Updated');
			$n = 0;
			foreach ($arts[$cat_id] as $a)
				echo kb_row(++$n, $a,
					forum_number_format(intval($a['views'])),
					intval($a['updated_at']) > 0 ? format_time(intval($a['updated_at']), true) : '- - -');
			echo kb_block_close();
		}

		// Uncategorised articles (category deleted or never set)
		if (!empty($arts[0]))
		{
			++$shown;
			echo kb_block_open('kbcat'.$shown, 'Other articles', 'Views', 'Updated');
			$n = 0;
			foreach ($arts[0] as $a)
				echo kb_row(++$n, $a,
					forum_number_format(intval($a['views'])),
					intval($a['updated_at']) > 0 ? format_time(intval($a['updated_at']), true) : '- - -');
			echo kb_block_close();
		}

		if ($shown === 0)
			echo kb_block_open('kbcat1', 'Knowledge base', 'Views', 'Updated')
				."\t\t\t\t".'<tr class="rowodd">'."\n"
				."\t\t\t\t\t".'<td class="tcl"><div class="tclcon"><div><p class="kb-empty">'
					.($kb_staff ? 'No articles yet - <a href="'.pun_htmlspecialchars(kb_page_url().'edit.php').'">write the first one</a>.' : 'No articles yet. Check back soon.')
					.'</p></div></div></td>'."\n"
				."\t\t\t\t\t".'<td class="tc2">0</td>'."\n"
				."\t\t\t\t\t".'<td class="tcr">- - -</td>'."\n"
				."\t\t\t\t".'</tr>'."\n"
				.kb_block_close();
	}
}

?>
</div>
<?php

require PUN_ROOT.'footer.php';
