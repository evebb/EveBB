<?php

/**
 * Knowledge Base - article & category management.
 *
 * For administrators and moderators (kb_can_edit). Create, edit,
 * publish/unpublish and delete articles; add, rename, reorder and
 * delete categories. Bodies are preparsed exactly like posts, so the
 * whole BBCode toolbox works in articles.
 *
 * This is an official eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

function kb_edit_absolutize($html)
{
	$base = get_base_url(true).'/';

	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('kb_edit_absolutize');

if (!in_array('kb', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

kb_bootstrap();

if (!kb_can_edit())
	message($lang_common['No permission'], false, '403 Forbidden');

$kb_errors = array();

// --- actions ---------------------------------------------------------------
if (($_SERVER['REQUEST_METHOD'] ?? '') == 'POST')
{
	check_csrf($_POST['csrf_token'] ?? null);

	// Category add / rename / delete / reorder
	if (isset($_POST['add_category']))
	{
		$name = pun_trim($_POST['cat_name'] ?? '');
		if ($name === '' || pun_strlen($name) > 80)
			$kb_errors[] = 'Category names must be 1-80 characters.';
		else
		{
			$db->query('INSERT INTO '.$db->prefix.'kb_categories (name, position) VALUES(\''.$db->escape($name).'\', '.intval($_POST['cat_position'] ?? 0).')') or error('Unable to add category', __FILE__, __LINE__, $db->error());
			redirect(kb_page_url().'edit.php', 'Category added. Redirecting …');
		}
	}
	else if (isset($_POST['save_categories']))
	{
		foreach ((array) ($_POST['cat'] ?? array()) as $id => $row)
		{
			$id = intval($id);
			$name = pun_trim($row['name'] ?? '');
			if ($id < 1 || $name === '' || pun_strlen($name) > 80)
				continue;
			$db->query('UPDATE '.$db->prefix.'kb_categories SET name=\''.$db->escape($name).'\', position='.intval($row['position'] ?? 0).' WHERE id='.$id) or error('Unable to update category', __FILE__, __LINE__, $db->error());
		}
		redirect(kb_page_url().'edit.php', 'Categories saved. Redirecting …');
	}
	else if (isset($_POST['delete_category']))
	{
		$id = intval($_POST['delete_category']);
		// Articles survive - they fall back to "Other articles"
		$db->query('UPDATE '.$db->prefix.'kb_articles SET category_id=0 WHERE category_id='.$id) or error('Unable to detach articles', __FILE__, __LINE__, $db->error());
		$db->query('DELETE FROM '.$db->prefix.'kb_categories WHERE id='.$id) or error('Unable to delete category', __FILE__, __LINE__, $db->error());
		redirect(kb_page_url().'edit.php', 'Category removed (its articles are kept). Redirecting …');
	}

	// Article save (create or update)
	else if (isset($_POST['save_article']))
	{
		$id = intval($_POST['id'] ?? 0);
		$title = pun_trim($_POST['title'] ?? '');
		$slug = kb_make_slug(pun_trim($_POST['slug'] ?? ''), $title);
		$category_id = intval($_POST['category_id'] ?? 0);
		$published = isset($_POST['published']) ? 1 : 0;
		$position = intval($_POST['position'] ?? 0);
		$body = pun_linebreaks(pun_trim($_POST['req_message'] ?? ''));

		if ($title === '' || pun_strlen($title) > 120)
			$kb_errors[] = 'Articles need a title of 1-120 characters.';
		if ($slug === '')
			$kb_errors[] = 'The slug came out empty - give the article a title with letters or digits in it.';
		if ($body === '')
			$kb_errors[] = 'The article text is empty.';
		if (pun_strlen($body) > 65000)
			$kb_errors[] = 'The article is too long - split it into two.';

		// Slug must be unique (excluding this article)
		if (empty($kb_errors))
		{
			$result = $db->query('SELECT id FROM '.$db->prefix.'kb_articles WHERE slug=\''.$db->escape($slug).'\''.($id > 0 ? ' AND id<>'.$id : '')) or error('Unable to check slug', __FILE__, __LINE__, $db->error());
			if ($db->has_rows($result))
				$kb_errors[] = 'The slug "'.pun_htmlspecialchars($slug).'" is already used by another article.';
		}

		if (empty($kb_errors))
		{
			// Preparse exactly like a post, so rendering matches posts
			require_once PUN_ROOT.'include/parser.php';
			$body = preparse_bbcode($body, $kb_errors);
		}

		if (empty($kb_errors))
		{
			if ($id > 0)
				$db->query('UPDATE '.$db->prefix.'kb_articles SET category_id='.$category_id.', slug=\''.$db->escape($slug).'\', title=\''.$db->escape($title).'\', body=\''.$db->escape($body).'\', published='.$published.', position='.$position.', updated_at='.time().' WHERE id='.$id) or error('Unable to update article', __FILE__, __LINE__, $db->error());
			else
				$db->query('INSERT INTO '.$db->prefix.'kb_articles (category_id, slug, title, body, published, position, created_by, created_at, updated_at) VALUES('.$category_id.', \''.$db->escape($slug).'\', \''.$db->escape($title).'\', \''.$db->escape($body).'\', '.$published.', '.$position.', '.intval($pun_user['id']).', '.time().', '.time().')') or error('Unable to insert article', __FILE__, __LINE__, $db->error());

			redirect(kb_article_url($slug), 'Article saved. Redirecting …');
		}
	}

	// Article delete (with its votes)
	else if (isset($_POST['delete_article']))
	{
		$id = intval($_POST['delete_article']);
		$db->query('DELETE FROM '.$db->prefix.'kb_votes WHERE article_id='.$id) or error('Unable to delete votes', __FILE__, __LINE__, $db->error());
		$db->query('DELETE FROM '.$db->prefix.'kb_articles WHERE id='.$id) or error('Unable to delete article', __FILE__, __LINE__, $db->error());
		redirect(kb_page_url().'edit.php', 'Article deleted. Redirecting …');
	}
}

// --- data for the page -----------------------------------------------------
$cats = kb_categories();

$editing = null;
if (isset($_GET['id']))
{
	$result = $db->query('SELECT * FROM '.$db->prefix.'kb_articles WHERE id='.intval($_GET['id'])) or error('Unable to fetch article', __FILE__, __LINE__, $db->error());
	$editing = $db->fetch_assoc($result);
	if ($editing === false)
		message($lang_common['Bad request'], false, '404 Not Found');
}
$want_new = isset($_GET['new']) || $editing !== null;

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), 'Knowledge base', 'Manage');
define('PUN_ACTIVE_PAGE', 'index');
require PUN_ROOT.'header.php';

$result = $db->query('SELECT id, category_id, slug, title, published, position, views, helpful_yes, helpful_no FROM '.$db->prefix.'kb_articles ORDER BY category_id, position, title') or error('Unable to fetch articles', __FILE__, __LINE__, $db->error());
$all = array();
while ($row = $db->fetch_assoc($result))
	$all[] = $row;

?>
<div class="linkst"><div class="inbox"><ul class="crumbs">
	<li><a href="<?php echo pun_htmlspecialchars(kb_page_url()) ?>">Knowledge base</a></li>
	<li><span>&raquo;&#160;</span><strong>Manage</strong></li>
</ul></div></div>

<?php if (!empty($kb_errors)): ?>
<div class="block"><h2><span>Article not saved</span></h2><div class="box"><div class="inbox error-info"><ul class="error-list">
<?php foreach ($kb_errors as $e) echo "\t".'<li><strong>'.$e.'</strong></li>'."\n"; ?>
</ul></div></div></div>
<?php endif; ?>

<div class="blockform">
	<h2><span><?php echo $editing !== null ? 'Edit article' : 'New article' ?></span></h2>
	<div class="box"><div class="inbox">
	<form method="post" action="<?php echo pun_htmlspecialchars(kb_page_url().'edit.php') ?>">
		<input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token() ?>" />
		<input type="hidden" name="id" value="<?php echo $editing !== null ? intval($editing['id']) : 0 ?>" />
		<fieldset>
			<legend>The article</legend>
			<div class="infldset">
				<label>Title<br /><input type="text" name="title" size="60" maxlength="120" value="<?php echo pun_htmlspecialchars($editing['title'] ?? ($_POST['title'] ?? '')) ?>" /></label>
				<label>Slug <small>(the address - leave blank to make one from the title)</small><br /><input type="text" name="slug" size="40" maxlength="60" value="<?php echo pun_htmlspecialchars($editing['slug'] ?? ($_POST['slug'] ?? '')) ?>" /></label>
				<label>Category<br /><select name="category_id">
					<option value="0">- none -</option>
<?php foreach ($cats as $cid => $cat): $sel = intval($editing['category_id'] ?? ($_POST['category_id'] ?? 0)) === intval($cid); ?>
					<option value="<?php echo intval($cid) ?>"<?php if ($sel) echo ' selected="selected"' ?>><?php echo pun_htmlspecialchars($cat['name']) ?></option>
<?php endforeach; ?>
				</select></label>
				<label>Text <small>(BBCode, exactly as in posts)</small><br />
				<textarea name="req_message" rows="18" cols="95"><?php echo pun_htmlspecialchars($editing['body'] ?? ($_POST['req_message'] ?? '')) ?></textarea></label>
				<label>Position <small>(sort order inside its category, low first)</small><br /><input type="text" name="position" size="4" value="<?php echo intval($editing['position'] ?? ($_POST['position'] ?? 0)) ?>" /></label>
				<label><input type="checkbox" name="published" value="1"<?php if (intval($editing['published'] ?? 0) === 1 || isset($_POST['published'])) echo ' checked="checked"' ?> /> Published <small>(unticked = draft, visible to staff only)</small></label>
			</div>
		</fieldset>
		<p class="buttons"><input type="submit" name="save_article" value="Save article" /></p>
	</form>
<?php if ($editing !== null): ?>
	<form method="post" action="<?php echo pun_htmlspecialchars(kb_page_url().'edit.php') ?>" onsubmit="return confirm('Delete this article and its feedback? This cannot be undone.');">
		<input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token() ?>" />
		<p class="buttons"><button type="submit" name="delete_article" value="<?php echo intval($editing['id']) ?>">Delete this article</button></p>
	</form>
<?php endif; ?>
	</div></div>
</div>

<div class="blockform">
	<h2><span>All articles</span></h2>
	<div class="box"><div class="inbox">
<?php if (empty($all)): ?>
	<p>No articles yet.</p>
<?php else: ?>
	<table>
	<thead><tr><th class="tcl">Article</th><th class="tc2">Category</th><th class="tc2">State</th><th class="tc2">Views</th><th class="tc2">Helpful</th><th class="tcr">&#160;</th></tr></thead>
	<tbody>
<?php foreach ($all as $a): ?>
	<tr>
		<td class="tcl"><a href="<?php echo pun_htmlspecialchars(kb_article_url($a['slug'])) ?>"><?php echo pun_htmlspecialchars($a['title']) ?></a> <small>[kb:<?php echo pun_htmlspecialchars($a['slug']) ?>]</small></td>
		<td class="tc2"><?php echo isset($cats[$a['category_id']]) ? pun_htmlspecialchars($cats[$a['category_id']]['name']) : '-' ?></td>
		<td class="tc2"><?php echo $a['published'] == 1 ? 'Published' : '<em>Draft</em>' ?></td>
		<td class="tc2"><?php echo intval($a['views']) ?></td>
		<td class="tc2"><?php echo intval($a['helpful_yes']) ?> / <?php echo intval($a['helpful_no']) ?></td>
		<td class="tcr"><a href="<?php echo pun_htmlspecialchars(kb_page_url().'edit.php?id='.$a['id']) ?>">Edit</a></td>
	</tr>
<?php endforeach; ?>
	</tbody>
	</table>
<?php endif; ?>
	</div></div>
</div>

<div class="blockform">
	<h2><span>Categories</span></h2>
	<div class="box"><div class="inbox">
	<form method="post" action="<?php echo pun_htmlspecialchars(kb_page_url().'edit.php') ?>">
		<input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token() ?>" />
<?php if (!empty($cats)): ?>
		<table>
		<thead><tr><th class="tcl">Name</th><th class="tc2">Position</th><th class="tcr">&#160;</th></tr></thead>
		<tbody>
<?php foreach ($cats as $cid => $cat): ?>
		<tr>
			<td class="tcl"><input type="text" name="cat[<?php echo intval($cid) ?>][name]" size="40" maxlength="80" value="<?php echo pun_htmlspecialchars($cat['name']) ?>" /></td>
			<td class="tc2"><input type="text" name="cat[<?php echo intval($cid) ?>][position]" size="4" value="<?php echo intval($cat['position']) ?>" /></td>
			<td class="tcr"><button type="submit" name="delete_category" value="<?php echo intval($cid) ?>" onclick="return confirm('Remove this category? Its articles are kept and move to Other articles.');">Remove</button></td>
		</tr>
<?php endforeach; ?>
		</tbody>
		</table>
		<p class="buttons"><input type="submit" name="save_categories" value="Save categories" /></p>
<?php endif; ?>
		<p>Add a category: <input type="text" name="cat_name" size="30" maxlength="80" />
		position <input type="text" name="cat_position" size="4" value="0" />
		<input type="submit" name="add_category" value="Add" /></p>
	</form>
	</div></div>
</div>
<?php

require PUN_ROOT.'footer.php';
