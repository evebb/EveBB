<?php

/**
 * Knowledge Base - article suggestions as JSON.
 *
 * ?q=free text (a support-ticket subject, a search phrase) returns up
 * to 5 published articles that look relevant:
 *
 *   {"q":"...","hits":[{"slug":"...","title":"...","url":"...","category":"..."}]}
 *
 * The query is split into words and each word is matched against title
 * and body (case-insensitive), so a whole sentence like "my board is
 * suspended" still finds the article whose title shares only a word
 * with it. Title hits weigh more than body hits; ties break on views.
 *
 * Used by the eveBB Hosted portal to suggest articles while a customer
 * writes a support ticket, and usable by anything else on the same
 * origin. Published articles only - never drafts, whoever asks.
 *
 * This is an official eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
define('PUN_QUIET_VISIT', 1);
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

if (!in_array('kb', evebb_active_plugins()))
{
	$db->end_transaction();
	header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found');
	exit('{"error":"not found"}');
}

kb_bootstrap();

$q = pun_trim($_GET['q'] ?? '');
if (pun_strlen($q) > 120)
	$q = pun_trim(utf8_substr($q, 0, 120));

$out = array();
foreach (kb_suggest($q) as $hit)
	$out[] = array(
		'slug'     => $hit['slug'],
		'title'    => $hit['title'],
		'url'      => kb_article_url($hit['slug']),
		'category' => $hit['category'],
	);

$db->end_transaction();
echo json_encode(array('q' => $q, 'hits' => $out));
