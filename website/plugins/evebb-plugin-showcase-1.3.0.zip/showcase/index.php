<?php

/**
 * Showcase Directory - the gallery page.
 *
 * Standalone page rendered inside the full forum chrome (same pattern
 * as eveauth's sso.php: relative asset/nav URLs are absolutized on the
 * way out because this file lives under plugins/).
 *
 * Two views:
 *   (default)   curated front page - featured row + newest per section
 *   ?view=all   the full catalogue for one section, paged
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

//
// Absolutize relative href/src so forum chrome works from /plugins/showcase/
//
function showcase_absolutize($html)
{
	$base = get_base_url(true).'/';

	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('showcase_absolutize');

if (!in_array('showcase', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

showcase_bootstrap();

$sc_is_admin = ($pun_user['g_id'] == PUN_ADMIN);

// Read the view first: admin actions return the visitor to where they were
$sc_view_all = (($_GET['view'] ?? '') == 'all');
$sc_q = pun_trim($_GET['q'] ?? '');
if (pun_strlen($sc_q) > 60)
	$sc_q = pun_trim(utf8_substr($sc_q, 0, 60));
$sc_f = intval($_GET['f'] ?? 0);
$sc_page = max(1, intval($_GET['p'] ?? 1));

$sc_forums = showcase_readable_forums();
if ($sc_f > 0 && !isset($sc_forums[$sc_f]))
	$sc_f = 0;   // unknown/unreadable section falls back to all

// "View all" is always scoped to one section; fall back to the first
if ($sc_view_all && $sc_f == 0)
{
	$sc_first = array_keys($sc_forums);
	$sc_f = empty($sc_first) ? 0 : $sc_first[0];
	if ($sc_f == 0)
		$sc_view_all = false;
}

//
// The URL of the view currently being looked at (admin actions come back here)
//
function showcase_current_url()
{
	global $sc_view_all, $sc_f, $sc_q, $sc_page;

	$args = array();
	if ($sc_view_all)
		$args['view'] = 'all';
	if ($sc_f > 0)
		$args['f'] = $sc_f;
	if ($sc_q !== '')
		$args['q'] = $sc_q;
	if ($sc_page > 1)
		$args['p'] = $sc_page;

	return showcase_page_url().(empty($args) ? '' : '?'.http_build_query($args));
}

// Administrators only: toggle the Approved / Featured marks
if ($sc_is_admin && (isset($_GET['sc_approve']) || isset($_GET['sc_feature'])))
{
	check_csrf($_GET['csrf_token'] ?? null);

	$sc_featuring = isset($_GET['sc_feature']);
	$topic_id = intval($sc_featuring ? $_GET['sc_feature'] : $_GET['sc_approve']);
	$state = (($_GET['state'] ?? '') == '1');

	// Re-validate server-side: the topic must live in a mapped forum
	$mapped = showcase_forum_ids();
	if ($topic_id > 0 && !empty($mapped))
	{
		$result = $db->query('SELECT 1 FROM '.$db->prefix.'topics WHERE id='.$topic_id.' AND moved_to IS NULL AND forum_id IN('.implode(',', $mapped).')') or error('Unable to fetch topic', __FILE__, __LINE__, $db->error());
		if ($db->has_rows($result))
		{
			if ($sc_featuring)
				showcase_set_featured($topic_id, $state);
			else
				showcase_set_approved($topic_id, $state, $pun_user['id']);
		}
	}

	redirect(showcase_current_url(), 'Saved. Redirecting …');
}

$sc_searching = ($sc_q !== '' || ($sc_f > 0 && !$sc_view_all));
$sc_featured = array();
$sc_more_pages = false;

if ($sc_view_all)
{
	// One section, the full catalogue, paged
	$sc_per_page = max(1, min(200, intval($pun_config['o_showcase_max'] ?? 50)));
	$sc_scan = showcase_scan($sc_f, $sc_q, $sc_per_page, ($sc_page - 1) * $sc_per_page);
	$sc_more_pages = $sc_scan['more'];

	$sections = empty($sc_scan['entries']) ? array() : array(array(
		'forum_id'	=> $sc_f,
		'forum_name'	=> $sc_forums[$sc_f],
		'entries'	=> $sc_scan['entries'],
		'more'		=> false,
	));
}
else if ($sc_searching)
	$sections = showcase_sections($sc_q, $sc_f);   // search shows everything it finds
else
{
	$sc_featured = showcase_featured_entries();

	// A featured card must not appear a second time further down
	$sc_feat_ids = array();
	foreach ($sc_featured as $entry)
		$sc_feat_ids[] = $entry['topic_id'];

	$sections = showcase_front_sections($sc_feat_ids);
}

// Approval + featured badges (one query each across every listed topic)
$sc_all_ids = array();
foreach ($sc_featured as $entry)
	$sc_all_ids[] = $entry['topic_id'];
foreach ($sections as $section)
	foreach ($section['entries'] as $entry)
		$sc_all_ids[] = $entry['topic_id'];
$sc_all_ids = array_unique($sc_all_ids);
$sc_approved = showcase_approved_set($sc_all_ids);
$sc_featured_set = $sc_is_admin ? showcase_featured_set($sc_all_ids) : array();

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), 'Showcase');
define('PUN_ACTIVE_PAGE', 'index');
define('PUN_ALLOW_INDEX', 1);
require PUN_ROOT.'header.php';

//
// One grid of cards
//
function showcase_render_grid($entries)
{
	global $sc_is_admin, $sc_approved, $sc_featured_set;

	echo "\t\t\t".'<div class="showcase-grid">'."\n";

	foreach ($entries as $entry)
	{
		$topic_url = get_base_url(true).'/viewtopic.php?id='.$entry['topic_id'];
		$is_approved = isset($sc_approved[$entry['topic_id']]);
		$is_featured = isset($sc_featured_set[$entry['topic_id']]);

		echo "\t\t\t\t".'<div class="showcase-card">'."\n";
		if ($entry['thumb'] !== null)
			echo "\t\t\t\t\t".'<a href="'.pun_htmlspecialchars($topic_url).'"><div class="showcase-thumb" style="background-image: url('.pun_htmlspecialchars($entry['thumb']).')"></div></a>'."\n";
		else
			echo "\t\t\t\t\t".'<a href="'.pun_htmlspecialchars($topic_url).'" style="text-decoration: none;"><div class="showcase-thumb">'.pun_htmlspecialchars(utf8_substr(pun_trim($entry['subject']), 0, 1)).'</div></a>'."\n";

		echo "\t\t\t\t\t".'<div class="showcase-body">'."\n";
		echo "\t\t\t\t\t\t".'<h4><a href="'.pun_htmlspecialchars($topic_url).'">'.pun_htmlspecialchars($entry['subject']).'</a>'.($is_approved ? '<span class="sc-approved" title="Checked and approved by the board staff">&#10003; Approved</span>' : '').'</h4>'."\n";
		if ($entry['excerpt'] != '')
			echo "\t\t\t\t\t\t".'<p class="sc-excerpt">'.pun_htmlspecialchars($entry['excerpt']).'</p>'."\n";
		echo "\t\t\t\t\t\t".'<p class="sc-meta">'.pun_htmlspecialchars($entry['poster']).' &middot; '.format_time($entry['posted'], true).' &middot; '.forum_number_format($entry['replies']).' '.($entry['replies'] == 1 ? 'reply' : 'replies').'</p>'."\n";
		echo "\t\t\t\t\t\t".'<p class="showcase-actions"><a class="sc-dl" href="'.pun_htmlspecialchars($entry['download']).'">Download</a><a class="sc-topic" href="'.pun_htmlspecialchars($topic_url).'">Discussion &raquo;</a></p>'."\n";
		if ($sc_is_admin)
		{
			$base = showcase_current_url();
			$join = (strpos($base, '?') === false) ? '?' : '&amp;';
			echo "\t\t\t\t\t\t".'<p class="sc-adminact">'
				.'<a href="'.pun_htmlspecialchars($base).$join.'sc_approve='.$entry['topic_id'].'&amp;state='.($is_approved ? '0' : '1').'&amp;csrf_token='.pun_csrf_token().'">'.($is_approved ? 'Remove approval' : 'Approve').'</a>'
				.' &middot; '
				.'<a href="'.pun_htmlspecialchars($base).$join.'sc_feature='.$entry['topic_id'].'&amp;state='.($is_featured ? '0' : '1').'&amp;csrf_token='.pun_csrf_token().'">'.($is_featured ? 'Unfeature' : 'Feature').'</a>'
				.'</p>'."\n";
		}
		echo "\t\t\t\t\t".'</div>'."\n";
		echo "\t\t\t\t".'</div>'."\n";
	}

	echo "\t\t\t".'</div>'."\n";
}

?>
<style>
.showcase-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 14px; padding: 6px 0; }
.showcase-card { border: 1px solid rgba(128,128,128,.35); border-radius: 5px; overflow: hidden; display: flex; flex-direction: column; background: rgba(128,128,128,.06); }
.showcase-thumb { aspect-ratio: 16/9; background: linear-gradient(135deg, rgba(230,115,0,.25), rgba(51,55,59,.4)) center/cover no-repeat; display: flex; align-items: center; justify-content: center; font-size: 34px; font-weight: bold; opacity: .95; }
.showcase-body { padding: 10px 12px 12px; display: flex; flex-direction: column; flex: 1; }
.showcase-body h4 { margin: 0 0 6px; font-size: 14px; }
.showcase-body p.sc-excerpt { font-size: 12px; margin: 0 0 8px; flex: 1; }
.showcase-body p.sc-meta { font-size: 11px; opacity: .75; margin: 0 0 10px; }
.showcase-actions a.sc-dl { display: inline-block; padding: 5px 12px; background: #e67300; color: #fff; border-radius: 3px; font-weight: bold; font-size: 12px; text-decoration: none; }
.showcase-actions a.sc-topic { font-size: 12px; margin-left: 10px; }
.sc-approved { display: inline-block; padding: 1px 8px; background: #2e7d32; color: #fff; border-radius: 10px; font-size: 11px; font-weight: bold; margin-left: 6px; vertical-align: 2px; white-space: nowrap; }
.sc-adminact { font-size: 11px; margin: 6px 0 0; opacity: .85; }
.sc-search { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin: 2px 0 10px; }
.sc-search input[type=text] { flex: 1 1 220px; max-width: 340px; padding: 6px 9px; }
.sc-search select { padding: 5px 6px; }
.sc-search input[type=submit] { padding: 6px 14px; }
.sc-results { font-size: 12px; opacity: .85; margin: 0 0 10px; }
.sc-sechead { display: flex; flex-wrap: wrap; gap: 10px; align-items: baseline; justify-content: space-between; margin: 12px 0 2px; }
.sc-sechead h3 { margin: 0; }
.sc-sechead .sc-forumlink { font-weight: normal; font-size: 12px; opacity: .7; }
.sc-viewall { font-size: 12px; font-weight: bold; white-space: nowrap; }
.sc-pager { display: flex; gap: 14px; align-items: center; margin: 12px 0 2px; font-size: 12px; }
.sc-pager .sc-pagenum { opacity: .75; }
</style>
<div class="block">
	<h2><span>Showcase</span></h2>
	<div class="box">
		<div class="inbox">
<?php

// The search bar (only useful once forums are mapped)
if (!empty($sc_forums))
{
	echo "\t\t\t".'<form class="sc-search" method="get" action="'.pun_htmlspecialchars(showcase_page_url()).'">'."\n";
	if ($sc_view_all)
		echo "\t\t\t\t".'<input type="hidden" name="view" value="all" />'."\n";
	echo "\t\t\t\t".'<input type="text" name="q" value="'.pun_htmlspecialchars($sc_q).'" maxlength="60" placeholder="Search the showcase &hellip;" />'."\n";
	echo "\t\t\t\t".'<select name="f">'."\n";
	if (!$sc_view_all)
		echo "\t\t\t\t\t".'<option value="0">All sections</option>'."\n";
	foreach ($sc_forums as $sc_fid => $sc_fname)
		echo "\t\t\t\t\t".'<option value="'.$sc_fid.'"'.($sc_f == $sc_fid ? ' selected="selected"' : '').'>'.pun_htmlspecialchars($sc_fname).'</option>'."\n";
	echo "\t\t\t\t".'</select>'."\n";
	echo "\t\t\t\t".'<input type="submit" value="Search" />'."\n";
	echo "\t\t\t".'</form>'."\n";
}

if ($sc_view_all)
{
	$sc_what = ($sc_q !== '') ? ' matching &ldquo;'.pun_htmlspecialchars($sc_q).'&rdquo;' : '';
	echo "\t\t\t".'<p class="sc-results">Everything in '.pun_htmlspecialchars($sc_forums[$sc_f]).$sc_what.' &middot; <a href="'.pun_htmlspecialchars(showcase_page_url()).'">Back to the showcase</a></p>'."\n";
}
else if ($sc_searching)
{
	$sc_hits = 0;
	foreach ($sections as $section)
		$sc_hits += count($section['entries']);

	$sc_scope = ($sc_f > 0) ? 'in '.pun_htmlspecialchars($sc_forums[$sc_f]) : 'across all sections';
	$sc_what = ($sc_q !== '') ? ' for &ldquo;'.pun_htmlspecialchars($sc_q).'&rdquo;' : '';
	echo "\t\t\t".'<p class="sc-results">'.$sc_hits.' '.($sc_hits == 1 ? 'result' : 'results').$sc_what.' '.$sc_scope.' &middot; <a href="'.pun_htmlspecialchars(showcase_page_url()).'">Show everything</a></p>'."\n";
}

if (empty($sections) && empty($sc_featured))
{
	if (empty(showcase_forum_ids()))
		echo "\t\t\t".'<p>The showcase has not been configured yet — an administrator needs to map one or more forums on the plugin settings page.</p>'."\n";
	else if ($sc_view_all && $sc_page > 1)
		echo "\t\t\t".'<p>Nothing on this page. <a href="'.pun_htmlspecialchars(showcase_page_url().'?view=all&f='.$sc_f).'">Back to the first page</a>.</p>'."\n";
	else if ($sc_searching || $sc_q !== '')
		echo "\t\t\t".'<p>No matching entries. Try a shorter search, or a different section.</p>'."\n";
	else
		echo "\t\t\t".'<p>Nothing to show yet — releases appear here automatically once topics with download links are posted.</p>'."\n";
}

// The featured row (front page only, and only once an admin has chosen some)
if (!empty($sc_featured))
{
	echo "\t\t\t".'<div class="sc-sechead"><h3>Featured</h3></div>'."\n";
	showcase_render_grid($sc_featured);
}

foreach ($sections as $section)
{
	$forum_link = '<span class="sc-forumlink">(<a href="'.get_base_url(true).'/viewforum.php?id='.$section['forum_id'].'">forum</a>)</span>';

	echo "\t\t\t".'<div class="sc-sechead"><h3>'.pun_htmlspecialchars($section['forum_name']).' '.$forum_link.'</h3>';
	if ($section['more'])
		echo '<span class="sc-viewall"><a href="'.pun_htmlspecialchars(showcase_page_url().'?view=all&f='.$section['forum_id']).'">View all in '.pun_htmlspecialchars($section['forum_name']).' &raquo;</a></span>';
	echo '</div>'."\n";

	showcase_render_grid($section['entries']);
}

// Pager (View all only)
if ($sc_view_all && ($sc_page > 1 || $sc_more_pages))
{
	$sc_pager_base = showcase_page_url().'?view=all&f='.$sc_f.($sc_q !== '' ? '&q='.urlencode($sc_q) : '');

	echo "\t\t\t".'<p class="sc-pager">';
	if ($sc_page > 1)
		echo '<a href="'.pun_htmlspecialchars($sc_pager_base.'&p='.($sc_page - 1)).'">&laquo; Newer</a>';
	echo '<span class="sc-pagenum">Page '.$sc_page.'</span>';
	if ($sc_more_pages)
		echo '<a href="'.pun_htmlspecialchars($sc_pager_base.'&p='.($sc_page + 1)).'">Older &raquo;</a>';
	echo '</p>'."\n";
}

?>
		</div>
	</div>
</div>
<?php

require PUN_ROOT.'footer.php';
