<?php

/**
 * Showcase Directory - shared library.
 *
 * Entries are derived live from topics in the mapped forums: a topic
 * whose FIRST post contains a download link (a .zip, or anything under
 * a /downloads/ path) is a release and becomes a card. The first
 * [img] in that post becomes the thumbnail; the BBCode-stripped opening
 * text becomes the excerpt. Nothing is stored - the forum stays the
 * single source of truth.
 *
 * Since 1.3.0 the gallery is curated: the front page shows the newest
 * few entries per section plus an admin-chosen Featured row, and the
 * full catalogue lives behind a paged "View all" page. Approval and
 * featuring both live in the showcase_approved table.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

define('SHOWCASE_DB_REV', 2);

// A section shorter than (latest + this) is shown whole rather than
// truncated - hiding one or two entries behind a link helps nobody.
define('SHOWCASE_SHORT_SECTION_SLACK', 2);

// Topics read per database round trip while looking for release posts,
// and the ceiling on how many round trips one page will make. Release
// detection needs the post body, so it cannot be done in SQL.
define('SHOWCASE_SCAN_CHUNK', 60);
define('SHOWCASE_SCAN_MAX_CHUNKS', 20);

//
// Upsert a config value + refresh the cache
//
function showcase_save_config($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}

function showcase_page_url()
{
	return get_base_url(true).'/plugins/showcase/';
}

//
// How many entries each section shows on the front page (0 = no
// curation: the whole catalogue is listed, as it was before 1.3.0)
//
function showcase_latest_count()
{
	global $pun_config;

	return max(0, min(50, intval($pun_config['o_showcase_latest'] ?? 4)));
}

//
// How many featured entries the featured row shows
//
function showcase_featured_count()
{
	global $pun_config;

	return max(0, min(50, intval($pun_config['o_showcase_featured_max'] ?? 4)));
}

//
// First-run bootstrap: the approvals table (guarded by config key, same
// pattern as the solved plugin). Rev 2 adds the featured column, which
// doubles as the featured ordering (0 = not featured).
//
function showcase_bootstrap()
{
	global $db, $pun_config;

	if (isset($pun_config['o_showcase_db_rev']) && intval($pun_config['o_showcase_db_rev']) >= SHOWCASE_DB_REV)
		return;

	$db->query('CREATE TABLE IF NOT EXISTS '.$db->prefix.'showcase_approved (
		topic_id INT NOT NULL,
		approved_by INT NOT NULL DEFAULT 0,
		approved_at INT NOT NULL DEFAULT 0,
		featured INT NOT NULL DEFAULT 0,
		PRIMARY KEY (topic_id)
	)') or error('Unable to create showcase_approved table', __FILE__, __LINE__, $db->error());

	// Boards upgrading from rev 1 already have the table without the
	// column. add_field() is a no-op when the field is already there.
	$db->add_field('showcase_approved', 'featured', 'INT(10)', false, 0) or error('Unable to add featured field', __FILE__, __LINE__, $db->error());

	showcase_save_config('o_showcase_db_rev', (string) SHOWCASE_DB_REV);
}

//
// Which of these topic IDs carry the staff Approved mark?
// Returns topic_id => true. A row may exist purely because the topic is
// featured, so approval is approved_at > 0, not row existence.
//
function showcase_approved_set($topic_ids)
{
	global $db;

	$topic_ids = array_values(array_map('intval', $topic_ids));
	if (empty($topic_ids))
		return array();

	$result = $db->query('SELECT topic_id FROM '.$db->prefix.'showcase_approved WHERE approved_at>0 AND topic_id IN('.implode(',', $topic_ids).')') or error('Unable to fetch approvals', __FILE__, __LINE__, $db->error());

	$set = array();
	while ($row = $db->fetch_assoc($result))
		$set[(int) $row['topic_id']] = true;

	return $set;
}

//
// Which of these topic IDs are featured? Returns topic_id => position.
//
function showcase_featured_set($topic_ids)
{
	global $db;

	$topic_ids = array_values(array_map('intval', $topic_ids));
	if (empty($topic_ids))
		return array();

	$result = $db->query('SELECT topic_id, featured FROM '.$db->prefix.'showcase_approved WHERE featured>0 AND topic_id IN('.implode(',', $topic_ids).')') or error('Unable to fetch featured entries', __FILE__, __LINE__, $db->error());

	$set = array();
	while ($row = $db->fetch_assoc($result))
		$set[(int) $row['topic_id']] = (int) $row['featured'];

	return $set;
}

//
// Make sure a row exists for this topic, then run an UPDATE against it
//
function showcase_touch_row($topic_id)
{
	global $db;

	$result = $db->query('SELECT 1 FROM '.$db->prefix.'showcase_approved WHERE topic_id='.intval($topic_id)) or error('Unable to fetch approval row', __FILE__, __LINE__, $db->error());
	if (!$db->has_rows($result))
		$db->query('INSERT INTO '.$db->prefix.'showcase_approved (topic_id, approved_by, approved_at, featured) VALUES('.intval($topic_id).', 0, 0, 0)') or error('Unable to create approval row', __FILE__, __LINE__, $db->error());
}

//
// Drop the row if it now carries neither an approval nor a feature mark
//
function showcase_prune_row($topic_id)
{
	global $db;

	$db->query('DELETE FROM '.$db->prefix.'showcase_approved WHERE topic_id='.intval($topic_id).' AND approved_at=0 AND featured=0') or error('Unable to prune approval row', __FILE__, __LINE__, $db->error());
}

//
// Set/clear the Approved mark on a topic (caller has already verified
// the actor is an administrator and the topic is showcased)
//
function showcase_set_approved($topic_id, $approve, $user_id)
{
	global $db;

	$topic_id = intval($topic_id);

	if ($approve)
	{
		showcase_touch_row($topic_id);
		$db->query('UPDATE '.$db->prefix.'showcase_approved SET approved_by='.intval($user_id).', approved_at='.time().' WHERE topic_id='.$topic_id) or error('Unable to save approval', __FILE__, __LINE__, $db->error());
	}
	else
	{
		$db->query('UPDATE '.$db->prefix.'showcase_approved SET approved_by=0, approved_at=0 WHERE topic_id='.$topic_id) or error('Unable to clear approval', __FILE__, __LINE__, $db->error());
		showcase_prune_row($topic_id);
	}
}

//
// Set/clear the Featured mark. Featured entries appear in the order they
// were flagged: a new one takes the next position, so the row stays
// stable when the admin adds another. Re-flagging moves an entry to the
// end, which is how it gets reordered.
//
function showcase_set_featured($topic_id, $feature)
{
	global $db;

	$topic_id = intval($topic_id);

	if ($feature)
	{
		$result = $db->query('SELECT MAX(featured) AS top FROM '.$db->prefix.'showcase_approved') or error('Unable to read featured order', __FILE__, __LINE__, $db->error());
		$row = $db->fetch_assoc($result);
		$next = intval($row['top'] ?? 0) + 1;

		showcase_touch_row($topic_id);
		$db->query('UPDATE '.$db->prefix.'showcase_approved SET featured='.$next.' WHERE topic_id='.$topic_id) or error('Unable to save featured entry', __FILE__, __LINE__, $db->error());
	}
	else
	{
		$db->query('UPDATE '.$db->prefix.'showcase_approved SET featured=0 WHERE topic_id='.$topic_id) or error('Unable to clear featured entry', __FILE__, __LINE__, $db->error());
		showcase_prune_row($topic_id);
	}
}

//
// The mapped forum IDs (setting), in the order the admin listed them
//
function showcase_forum_ids()
{
	global $pun_config;

	$ids = array();
	foreach (explode(',', $pun_config['o_showcase_forums'] ?? '') as $bit)
	{
		if (intval(trim($bit)) > 0)
			$ids[] = intval(trim($bit));
	}

	return array_unique($ids);
}

//
// Find the download link in a first post's BBCode source.
// Returns the URL or null. A download link is a .zip, or any URL with
// /downloads/ in its path.
//
function showcase_download_link($message)
{
	$urls = array();

	// [url=X]... and [url]X[/url]
	if (preg_match_all('%\[url=([^\]\s]+)\]%i', $message, $m))
		$urls = array_merge($urls, $m[1]);
	if (preg_match_all('%\[url\]([^\[\s]+)\[/url\]%i', $message, $m))
		$urls = array_merge($urls, $m[1]);
	// bare URLs
	if (preg_match_all('%https?://[^\s\[\]<>"\']+%i', $message, $m))
		$urls = array_merge($urls, $m[0]);

	foreach ($urls as $url)
	{
		$path = parse_url($url, PHP_URL_PATH);
		if ($path === null || $path === false)
			continue;
		if (preg_match('%\.zip$%i', $path) || stripos($path, '/downloads/') !== false)
			return $url;
	}

	return null;
}

//
// First [img] URL in a first post's BBCode source, or null
//
function showcase_thumbnail($message)
{
	if (preg_match('%\[img(?:=[^\]]*)?\]\s*(https?://[^\[\s]+)\s*\[/img\]%i', $message, $m))
		return $m[1];

	return null;
}

//
// Plain-text excerpt of a BBCode message
//
function showcase_excerpt($message, $length = 190)
{
	// Drop quote/code blocks entirely - they're rarely descriptive
	$text = preg_replace('%\[(quote|code)(?:=[^\]]*)?\].*?\[/\1\]%is', ' ', $message);
	// Drop img tags with their contents
	$text = preg_replace('%\[img(?:=[^\]]*)?\][^\[]*\[/img\]%i', ' ', $text);
	// Strip remaining BBCode tags, keep their inner text
	$text = preg_replace('%\[/?[a-z*]+(?:=[^\]]*)?\]%i', '', $text);
	// Bare URLs read badly in an excerpt - the card has its own buttons
	$text = preg_replace('%https?://[^\s]+%i', '', $text);
	// Collapse whitespace and orphaned punctuation left by removals
	$text = pun_trim(preg_replace('%\s+%', ' ', $text));
	$text = pun_trim(preg_replace('%\s+([.,;:!?])%', '$1', $text));

	if (pun_strlen($text) > $length)
		$text = pun_trim(utf8_substr($text, 0, $length)).' …';

	return $text;
}

//
// The mapped forums the current user may read, as forum_id => forum_name,
// in the admin's listed order (used by the sections builder and by the
// search form's section dropdown).
//
function showcase_readable_forums()
{
	global $db, $pun_user;

	$forum_ids = showcase_forum_ids();
	if (empty($forum_ids))
		return array();

	$result = $db->query('SELECT f.id, f.forum_name FROM '.$db->prefix.'forums AS f LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.$pun_user['g_id'].') WHERE f.id IN('.implode(',', $forum_ids).') AND (fp.read_forum IS NULL OR fp.read_forum=1)') or error('Unable to fetch forums', __FILE__, __LINE__, $db->error());

	$names = array();
	while ($row = $db->fetch_assoc($result))
		$names[(int) $row['id']] = $row['forum_name'];

	$ordered = array();
	foreach ($forum_ids as $forum_id)
		if (isset($names[$forum_id]))
			$ordered[$forum_id] = $names[$forum_id];

	return $ordered;
}

//
// Escape a user search term for use inside a LIKE pattern. '!' is the
// escape character (declared with ESCAPE '!') because it is quoting-safe
// across MySQL, SQLite and PostgreSQL, unlike backslash.
//
function showcase_like_escape($term)
{
	return str_replace(array('!', '%', '_'), array('!!', '!%', '!_'), $term);
}

//
// Build a card from a topics+posts row
//
function showcase_entry($row, $download)
{
	return array(
		'topic_id'	=> (int) $row['id'],
		'subject'	=> $row['subject'],
		'poster'	=> $row['poster'],
		'posted'	=> (int) $row['posted'],
		'replies'	=> (int) $row['num_replies'],
		'download'	=> $download,
		'thumb'		=> showcase_thumbnail($row['message']),
		'excerpt'	=> showcase_excerpt($row['message']),
	);
}

//
// Scan one forum newest-first for release topics.
//
// $need   how many entries to return
// $skip   how many matching entries to step over first (paging)
//
// Whether a topic is a release depends on its post body, so it cannot be
// filtered in SQL; rows are read in chunks until enough entries are
// found or the forum runs out. Returns array('entries', 'more'), where
// 'more' means at least one further entry exists past this page.
//
function showcase_scan($forum_id, $search, $need, $skip = 0)
{
	global $db;

	$forum_id = intval($forum_id);
	$need = max(0, intval($need));
	$skip = max(0, intval($skip));

	$search_sql = '';
	if ($search !== '')
	{
		$pattern = '%'.showcase_like_escape(utf8_strtolower($search)).'%';
		$search_sql = ' AND LOWER(t.subject) LIKE \''.$db->escape($pattern).'\' ESCAPE \'!\'';
	}

	$entries = array();
	$matched = 0;
	$more = false;
	$offset = 0;

	for ($chunk = 0; $chunk < SHOWCASE_SCAN_MAX_CHUNKS; $chunk++)
	{
		$result = $db->query('SELECT t.id, t.subject, t.poster, t.posted, t.num_replies, p.message FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'posts AS p ON p.id=t.first_post_id WHERE t.forum_id='.$forum_id.' AND t.moved_to IS NULL'.$search_sql.' ORDER BY t.posted DESC LIMIT '.SHOWCASE_SCAN_CHUNK.' OFFSET '.$offset) or error('Unable to fetch topics', __FILE__, __LINE__, $db->error());

		$rows_seen = 0;
		while ($row = $db->fetch_assoc($result))
		{
			$rows_seen++;

			$download = showcase_download_link($row['message']);
			if ($download === null)
				continue;   // not a release topic

			$matched++;
			if ($matched <= $skip)
				continue;

			if (count($entries) >= $need)
			{
				$more = true;
				break;
			}

			$entries[] = showcase_entry($row, $download);
		}

		if ($more || $rows_seen < SHOWCASE_SCAN_CHUNK)
			break;

		$offset += SHOWCASE_SCAN_CHUNK;
	}

	return array('entries' => $entries, 'more' => $more);
}

//
// The showcase content for the current user: array of sections, each
// array('forum_id', 'forum_name', 'entries', 'more'). Forums the viewing
// user cannot read are silently absent (same forum_perms pattern as
// search.php).
//
// $search      filters by topic subject (case-insensitive substring;
//              applied in SQL so it reaches entries older than the
//              front page's scan window)
// $only_forum  restricts to one mapped section (0 = all)
// $per_section how many entries per section (0 = the o_showcase_max
//              ceiling, i.e. the whole catalogue)
// $skip        entries to step over in each section (paging)
//
function showcase_sections($search = '', $only_forum = 0, $per_section = 0, $skip = 0)
{
	global $pun_config;

	$names = showcase_readable_forums();
	if (empty($names))
		return array();

	$max = max(1, min(200, intval($pun_config['o_showcase_max'] ?? 50)));
	$need = ($per_section > 0) ? intval($per_section) : $max;

	$sections = array();
	foreach ($names as $forum_id => $forum_name)
	{
		if ($only_forum > 0 && $forum_id != $only_forum)
			continue;

		$scan = showcase_scan($forum_id, $search, $need, $skip);

		if (!empty($scan['entries']))
			$sections[] = array(
				'forum_id'	=> $forum_id,
				'forum_name'	=> $forum_name,
				'entries'	=> $scan['entries'],
				'more'		=> $scan['more'],
			);
	}

	return $sections;
}

//
// The front page's curated sections. Each section asks for a little more
// than it will show: a section only gets truncated when truncating
// actually hides something worth a click, so a small board still sees
// its whole catalogue on one page with no configuration.
//
function showcase_front_sections($exclude = array())
{
	$latest = showcase_latest_count();
	$exclude = array_flip(array_map('intval', $exclude));

	// Curation off: the whole catalogue, minus anything already in the
	// featured row (a card should never appear twice on one page).
	if ($latest < 1)
		return showcase_drop_entries(showcase_sections(), $exclude);

	// Ask for enough that the excluded entries can be topped up
	$sections = showcase_sections('', 0, $latest + SHOWCASE_SHORT_SECTION_SLACK + count($exclude));
	$sections = showcase_drop_entries($sections, $exclude);

	foreach ($sections as &$section)
	{
		$total = count($section['entries']);
		$truncate = ($section['more'] || $total > $latest + SHOWCASE_SHORT_SECTION_SLACK);

		if ($truncate)
		{
			$section['entries'] = array_slice($section['entries'], 0, $latest);
			$section['more'] = true;
		}
		else
			$section['more'] = false;
	}
	unset($section);

	return $sections;
}

//
// Remove entries whose topic id is a key of $drop, dropping any section
// left empty
//
function showcase_drop_entries($sections, $drop)
{
	if (empty($drop))
		return $sections;

	$out = array();
	foreach ($sections as $section)
	{
		$kept = array();
		foreach ($section['entries'] as $entry)
			if (!isset($drop[$entry['topic_id']]))
				$kept[] = $entry;

		if (!empty($kept))
		{
			$section['entries'] = $kept;
			$out[] = $section;
		}
	}

	return $out;
}

//
// The featured row: entries the admin has flagged, in flag order,
// restricted to topics the viewer can read that are still releases.
//
function showcase_featured_entries()
{
	global $db;

	$count = showcase_featured_count();
	if ($count < 1)
		return array();

	$names = showcase_readable_forums();
	if (empty($names))
		return array();

	$result = $db->query('SELECT t.id, t.subject, t.poster, t.posted, t.num_replies, p.message, s.featured FROM '.$db->prefix.'showcase_approved AS s INNER JOIN '.$db->prefix.'topics AS t ON t.id=s.topic_id INNER JOIN '.$db->prefix.'posts AS p ON p.id=t.first_post_id WHERE s.featured>0 AND t.moved_to IS NULL AND t.forum_id IN('.implode(',', array_keys($names)).') ORDER BY s.featured ASC') or error('Unable to fetch featured entries', __FILE__, __LINE__, $db->error());

	$entries = array();
	while (count($entries) < $count && ($row = $db->fetch_assoc($result)))
	{
		$download = showcase_download_link($row['message']);
		if ($download === null)
			continue;   // no longer a release topic

		$entries[] = showcase_entry($row, $download);
	}

	return $entries;
}
