# Showcase Directory for eveBB

A browsable gallery built from your release topics — an extensions
directory that maintains itself.

## Finding things

The front page is curated rather than exhaustive: a **Featured** row you
choose, then the newest few entries in each section, each with a **View
all** link to that section's full catalogue, paged. A section holding
only a couple more entries than it would show is listed in full instead,
so a small board looks exactly as it always did with no configuration.

A search bar sits at the top: type a name and optionally pick a section
(each mapped forum — e.g. Plugins or Styles — is a section), and only
matching entries are shown. The search looks at entry names, is
case-insensitive, and reaches the full catalogue — including releases
older than the front page's newest-first window.

## What it does

Map one or more forums (say, Styles & Themes and Plugins &
Modifications) and the plugin renders a gallery page at
`<board>/plugins/showcase/`, one card per release:

- **A topic becomes a card when its first post contains a download
  link** — a `.zip`, or any link with `/downloads/` in its path.
  Question and discussion topics never appear. Nothing is entered
  twice: post an announcement like you already do and the catalogue
  updates itself.
- The card takes its **name from the topic subject**, its
  **description from the opening text** (BBCode stripped), and its
  **thumbnail from the first image in the post** (cards without an
  image get a clean monogram tile). Each card has a Download button and
  a Discussion link into the topic.
- **Permission-aware**: visitors only see sections for forums their
  group can read — same rules as the rest of the board.
- **Approved badges**: administrators get an *Approve* link on every
  card; approved entries carry a green **✓ Approved** badge so visitors
  can tell at a glance which releases the board staff have checked.
  Everything stays listed either way — the badge is a trust signal, not
  a gate.
- **Featured row**: administrators get a *Feature* link on every card.
  Featured entries lead the front page in the order they were flagged —
  to move one to the end, unfeature it and feature it again. Featuring
  is independent of approval: an entry can be either, both or neither.
- A **Showcase link** is added to the board navigation (or untick that
  and add the URL via Administration → Options → Additional menu items
  for a no-JavaScript nav).

## Install

Upload the zip through Administration → Plugins, activate, then enter
the forum IDs to showcase on the settings page. One small table stores
the approval and featured marks (created automatically, and extended in
place when upgrading from 1.2.x — existing approvals are kept); the
settings page has a one-click data removal for clean uninstalls.

The settings page also sets how many entries each section shows on the
front page (default 4, `0` restores the pre-1.3 behaviour of listing
everything), how many the Featured row shows (default 4, `0` hides it),
and how many appear per View all page.

Tip: give each release topic a screenshot in its first post and the
gallery turns properly visual, especially for styles.

License: GPL v2 or higher, same as eveBB.
