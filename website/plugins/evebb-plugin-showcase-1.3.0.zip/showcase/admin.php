<?php

/**
 * Showcase Directory - settings page (shown inside the plugin manager).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

showcase_bootstrap();

if (isset($_POST['purge_showcase']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DROP TABLE IF EXISTS '.$db->prefix.'showcase_approved') or error('Unable to drop showcase_approved table', __FILE__, __LINE__, $db->error());
	foreach (array('db_rev', 'forums', 'navlink', 'max', 'latest', 'featured_max') as $key)
		$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name=\'o_showcase_'.$key.'\'') or error('Unable to remove board config', __FILE__, __LINE__, $db->error());

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'Showcase data removed. Deactivate or delete the plugin to finish. Redirecting …');
}

if (isset($_POST['save_showcase']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$forums = array();
	foreach (explode(',', $_POST['forums'] ?? '') as $bit)
	{
		if (intval(trim($bit)) > 0)
			$forums[] = intval(trim($bit));
	}
	showcase_save_config('o_showcase_forums', implode(',', array_unique($forums)));
	showcase_save_config('o_showcase_navlink', isset($_POST['navlink']) ? '1' : '0');
	showcase_save_config('o_showcase_max', (string) max(1, min(200, intval($_POST['max_entries'] ?? 50))));
	showcase_save_config('o_showcase_latest', (string) max(0, min(50, intval($_POST['latest'] ?? 4))));
	showcase_save_config('o_showcase_featured_max', (string) max(0, min(50, intval($_POST['featured_max'] ?? 4))));

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}

$sc_forums = $pun_config['o_showcase_forums'] ?? '';
$sc_navlink = ($pun_config['o_showcase_navlink'] ?? '1') == '1';
$sc_max = intval($pun_config['o_showcase_max'] ?? 50);
$sc_latest = showcase_latest_count();
$sc_featured_max = showcase_featured_count();

$result = $db->query('SELECT id, forum_name FROM '.$db->prefix.'forums ORDER BY id') or error('Unable to fetch forums', __FILE__, __LINE__, $db->error());
$forum_legend = array();
while ($row = $db->fetch_assoc($result))
	$forum_legend[] = $row['id'].' = '.pun_htmlspecialchars($row['forum_name']);

?>
	<div class="inform">
		<fieldset>
			<legend>How it works</legend>
			<div class="infldset">
				<p>The showcase is a gallery built from your release topics. Any topic in the mapped forums whose <strong>first post contains a download link</strong> (a .zip, or a link with /downloads/ in its path) becomes a card automatically — name from the subject, description from the opening text, thumbnail from the first image in the post, plus Download and Discussion buttons. Question topics without a download link never appear. Visitors only ever see forums their group can read.</p>
				<p>The front page stays short: a <strong>Featured</strong> row you choose, then the newest few entries in each section, each with a <strong>View all</strong> link to the full paged catalogue. Visitors can also search the whole catalogue at any time. A section with only a couple more entries than it would show is listed in full instead - nothing is hidden behind a link for the sake of it, so a small board needs no configuration here.</p>
				<p>Your showcase lives at: <code><?php echo pun_htmlspecialchars(showcase_page_url()) ?></code></p>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Showcase Directory settings</legend>
			<div class="infldset">
				<label>Forums to showcase (comma-separated forum IDs, in the order the sections should appear)
					<br /><input type="text" name="forums" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($sc_forums) ?>" />
				</label>
<?php if (!empty($forum_legend)): ?>				<p><?php echo implode('; &#160; ', $forum_legend) ?></p>
<?php endif; ?>				<label>Entries shown per section on the front page (0 = show the whole catalogue, no View all links)
					<br /><input type="text" name="latest" size="4" maxlength="2" value="<?php echo $sc_latest ?>" />
				</label>
				<label>Entries shown in the Featured row (0 = never show it)
					<br /><input type="text" name="featured_max" size="4" maxlength="2" value="<?php echo $sc_featured_max ?>" />
				</label>
				<label>Entries per page on View all, and per section when searching (1–200)
					<br /><input type="text" name="max_entries" size="4" maxlength="3" value="<?php echo $sc_max ?>" />
				</label>
				<div class="rbox">
					<label><input type="checkbox" name="navlink" value="1"<?php if ($sc_navlink) echo ' checked="checked"' ?> />Add a "Showcase" link to the board navigation (JavaScript). Alternatively, untick this and add the URL above through Administration → Options → Additional menu items.<br /></label>
				</div>
				<p class="topspace"><input type="submit" name="save_showcase" value="Save settings" /></p>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Approved badges and the Featured row</legend>
			<div class="infldset">
				<p>Administrators see an <em>Approve</em> link on every showcase card; approved entries carry a green <strong>&#10003; Approved</strong> badge so visitors can tell at a glance which releases the board staff have checked. All entries stay listed either way — the badge is a trust signal, not a gate.</p>
				<p>Every card also carries a <em>Feature</em> link. Featured entries appear in the Featured row at the top of the front page, in the order you flagged them — to move one to the end, unfeature it and feature it again. Featuring is independent of approval: an entry can be either, both or neither.</p>
				<p><input type="submit" name="purge_showcase" value="Remove all showcase data" onclick="return confirm('Remove all approval marks and showcase settings? Topics and posts are not touched.')" /> For a clean uninstall — approval marks and settings only; the forum content is never touched.</p>
			</div>
		</fieldset>
	</div>
<?php
