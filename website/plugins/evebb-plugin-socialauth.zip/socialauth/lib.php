<?php

/**
 * Social Sign-in - shared library.
 *
 * A provider registry (Google, Discord, Microsoft, GitHub) over one shared
 * OAuth2/OIDC flow: authorize -> code -> token -> identity, normalised into
 * a single shape. Account matching/creation, sealed HMAC state tokens and
 * small helpers used by the addon (socialauth.php), the endpoint (auth.php)
 * and the settings page (admin.php).
 *
 * For tests, defining SOCIALAUTH_MOCK_BASE in config.php points EVERY
 * provider's endpoints at <mock>/<provider>/{authorize,token,userinfo}
 * (+ /github/user, /github/user/emails).
 *
 * This is an official eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

if (!defined('SOCIALAUTH_DB_REV'))
	define('SOCIALAUTH_DB_REV', 1);


//
// The provider registry. Endpoints are real-world defaults, replaced
// wholesale by SOCIALAUTH_MOCK_BASE when defined (test suites).
//
function evebb_socialauth_providers()
{
	static $providers = null;
	if ($providers !== null)
		return $providers;

	$mock = defined('SOCIALAUTH_MOCK_BASE') ? rtrim(SOCIALAUTH_MOCK_BASE, '/') : null;

	$providers = array(
		'google' => array(
			'label'     => 'Google',
			'color'     => '#4285f4',
			'authorize' => $mock ? $mock.'/google/authorize' : 'https://accounts.google.com/o/oauth2/v2/auth',
			'token'     => $mock ? $mock.'/google/token' : 'https://oauth2.googleapis.com/token',
			'userinfo'  => $mock ? $mock.'/google/userinfo' : 'https://openidconnect.googleapis.com/v1/userinfo',
			'scope'     => 'openid email profile',
			'setup'     => 'Google Cloud Console → APIs &amp; Services → Credentials → Create OAuth client ID (Web application)'
		),
		'discord' => array(
			'label'     => 'Discord',
			'color'     => '#5865f2',
			'authorize' => $mock ? $mock.'/discord/authorize' : 'https://discord.com/oauth2/authorize',
			'token'     => $mock ? $mock.'/discord/token' : 'https://discord.com/api/oauth2/token',
			'userinfo'  => $mock ? $mock.'/discord/userinfo' : 'https://discord.com/api/users/@me',
			'scope'     => 'identify email',
			'setup'     => 'Discord Developer Portal → New Application → OAuth2'
		),
		'microsoft' => array(
			'label'     => 'Microsoft',
			'color'     => '#2f2f2f',
			'authorize' => $mock ? $mock.'/microsoft/authorize' : 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
			'token'     => $mock ? $mock.'/microsoft/token' : 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
			'userinfo'  => $mock ? $mock.'/microsoft/userinfo' : 'https://graph.microsoft.com/oidc/userinfo',
			'scope'     => 'openid email profile',
			'setup'     => 'Microsoft Entra admin center → App registrations → New registration (any-org + personal accounts)'
		),
		'github' => array(
			'label'     => 'GitHub',
			'color'     => '#24292f',
			'authorize' => $mock ? $mock.'/github/authorize' : 'https://github.com/login/oauth/authorize',
			'token'     => $mock ? $mock.'/github/token' : 'https://github.com/login/oauth/access_token',
			'userinfo'  => $mock ? $mock.'/github/user' : 'https://api.github.com/user',
			'emails'    => $mock ? $mock.'/github/user/emails' : 'https://api.github.com/user/emails',
			'scope'     => 'read:user user:email',
			'setup'     => 'GitHub → Settings → Developer settings → OAuth Apps → New OAuth App'
		)
	);

	return $providers;
}

//
// A valid, existing provider key or null.
//
function evebb_socialauth_provider($key)
{
	$all = evebb_socialauth_providers();
	return (is_string($key) && isset($all[$key])) ? $key : null;
}

//
// Is a specific provider configured (client id + secret set)?
//
function evebb_socialauth_configured($provider)
{
	global $pun_config;

	return !empty($pun_config['o_socialauth_'.$provider.'_id'])
		&& !empty($pun_config['o_socialauth_'.$provider.'_secret']);
}

//
// Every configured provider key, in registry order.
//
function evebb_socialauth_active_providers()
{
	$out = array();
	foreach (evebb_socialauth_providers() as $key => $p)
		if (evebb_socialauth_configured($key))
			$out[] = $key;
	return $out;
}

//
// The single callback URL to register with EVERY provider.
//
function evebb_socialauth_callback_url()
{
	return get_base_url().'/plugins/socialauth/auth.php';
}

function evebb_socialauth_conf($name, $default)
{
	global $pun_config;
	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Fetch a URL. HTTPS-only for remote hosts (loopback plain-HTTP allowed for
// the test mock). Returns body or false.
//
function evebb_socialauth_http($url, $post = null, $headers = array(), $timeout = 15)
{
	$host = parse_url($url, PHP_URL_HOST);
	$is_loopback = in_array($host, array('127.0.0.1', '::1', 'localhost'), true);
	if (!$is_loopback && stripos($url, 'https://') !== 0)
		return false;

	$headers[] = 'User-Agent: eveBB-socialauth/1.0 (+'.get_base_url().')';

	if (function_exists('curl_init'))
	{
		$ch = curl_init($url);
		curl_setopt_array($ch, array(
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_MAXREDIRS      => 3,
			CURLOPT_TIMEOUT        => $timeout,
			CURLOPT_CONNECTTIMEOUT => 10,
			CURLOPT_HTTPHEADER     => $headers,
			CURLOPT_SSL_VERIFYPEER => true,
			CURLOPT_SSL_VERIFYHOST => 2,
			CURLOPT_PROTOCOLS      => CURLPROTO_HTTPS | CURLPROTO_HTTP,
			CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS
		));
		if ($post !== null)
		{
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		$body = curl_exec($ch);
		$status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
		curl_close($ch);

		return ($body !== false && $status >= 200 && $status < 300) ? $body : false;
	}

	if (ini_get('allow_url_fopen'))
	{
		$http = array(
			'timeout'          => $timeout,
			'follow_location'  => 1,
			'max_redirects'    => 3,
			'protocol_version' => 1.1,
			'ignore_errors'    => false,
			'header'           => implode("\r\n", $headers)."\r\n"
		);
		if ($post !== null)
		{
			$http['method'] = 'POST';
			$http['content'] = $post;
		}
		$context = stream_context_create(array('http' => $http, 'ssl' => array('verify_peer' => true, 'verify_peer_name' => true)));
		$body = @file_get_contents($url, false, $context);

		return ($body !== false) ? $body : false;
	}

	return false;
}

function evebb_socialauth_http_json($url, $post = null, $headers = array(), $timeout = 15)
{
	$body = evebb_socialauth_http($url, $post, $headers, $timeout);
	if ($body === false)
		return false;
	$data = json_decode($body, true);
	return is_array($data) ? $data : false;
}


// ---------------------------------------------------------------------------
// Sealed tokens (stateless, HMAC-signed with the board's cookie seed)
// ---------------------------------------------------------------------------

function evebb_socialauth_b64url_encode($data)
{
	return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function evebb_socialauth_b64url_decode($data)
{
	return base64_decode(strtr($data, '-_', '+/'));
}

function evebb_socialauth_seal($data)
{
	global $cookie_seed;

	$data['_t'] = time();
	$payload = evebb_socialauth_b64url_encode(json_encode($data));

	return $payload.'.'.forum_hmac($payload, $cookie_seed.'_socialauth');
}

function evebb_socialauth_unseal($token, $max_age = 1800)
{
	global $cookie_seed;

	if (!is_string($token) || substr_count($token, '.') != 1)
		return false;

	list($payload, $mac) = explode('.', $token);
	if (!hash_equals(forum_hmac($payload, $cookie_seed.'_socialauth'), $mac))
		return false;

	$data = json_decode(evebb_socialauth_b64url_decode($payload), true);
	if (!is_array($data) || !isset($data['_t']))
		return false;

	$age = time() - (int) $data['_t'];
	if ($age < 0 || $age > $max_age)
		return false;

	return $data;
}


// ---------------------------------------------------------------------------
// OAuth flow
// ---------------------------------------------------------------------------

//
// The authorize URL for a provider. One callback URL serves every provider;
// the provider key rides inside the sealed state (plus a nonce cookie for
// login-CSRF protection).
//
function evebb_socialauth_authorize_url($provider, $intent)
{
	global $pun_config;

	$p = evebb_socialauth_providers()[$provider];

	$nonce = random_key(12, true);
	forum_setcookie('socialauth_state', $nonce, time() + 900);

	$state = evebb_socialauth_seal(array('n' => $nonce, 'p' => $provider, 'i' => $intent));

	$params = array(
		'client_id'     => $pun_config['o_socialauth_'.$provider.'_id'],
		'redirect_uri'  => evebb_socialauth_callback_url(),
		'response_type' => 'code',
		'scope'         => $p['scope'],
		'state'         => $state
	);

	// Provider quirks
	if ($provider == 'google')
		$params['access_type'] = 'online';
	if ($provider == 'discord')
		$params['prompt'] = 'consent';
	if ($provider == 'github')
	{
		unset($params['response_type']); // implied
		$params['allow_signup'] = 'false';
	}

	return $p['authorize'].'?'.http_build_query($params);
}

//
// Exchange an authorization code for an access token. Returns token or false.
//
function evebb_socialauth_exchange_code($provider, $code)
{
	global $pun_config;

	$p = evebb_socialauth_providers()[$provider];

	$data = evebb_socialauth_http_json($p['token'],
		http_build_query(array(
			'client_id'     => $pun_config['o_socialauth_'.$provider.'_id'],
			'client_secret' => $pun_config['o_socialauth_'.$provider.'_secret'],
			'code'          => $code,
			'grant_type'    => 'authorization_code',
			'redirect_uri'  => evebb_socialauth_callback_url()
		)),
		array('Accept: application/json', 'Content-Type: application/x-www-form-urlencoded'));

	if ($data === false || empty($data['access_token']))
		return false;

	return (string) $data['access_token'];
}

//
// The verified identity behind an access token, normalised to:
//   array('provider' =>, 'id' => string, 'login' =>, 'name' =>,
//         'avatar_url' =>, 'email' => verified-primary-or-'',
//         'verified_emails' => array)
// or false. Only VERIFIED emails ever appear.
//
function evebb_socialauth_identity($provider, $token)
{
	$p = evebb_socialauth_providers()[$provider];
	$auth = array('Authorization: Bearer '.$token, 'Accept: application/json');

	$u = evebb_socialauth_http_json($p['userinfo'], null, $auth);
	if ($u === false)
		return false;

	$id = ''; $login = ''; $name = ''; $avatar = ''; $email = ''; $verified = array();

	if ($provider == 'google')
	{
		// OIDC userinfo: sub, name, email, email_verified, picture
		if (empty($u['sub']))
			return false;
		$id = (string) $u['sub'];
		$name = isset($u['name']) ? (string) $u['name'] : '';
		$avatar = isset($u['picture']) ? (string) $u['picture'] : '';
		if (!empty($u['email']) && !empty($u['email_verified']))
		{
			$email = strtolower(trim($u['email']));
			$verified[] = $email;
		}
		$login = $name !== '' ? $name : ($email !== '' ? strstr($email, '@', true) : '');
	}
	else if ($provider == 'discord')
	{
		// /users/@me: id, username, global_name, email, verified, avatar
		if (empty($u['id']) || empty($u['username']))
			return false;
		$id = (string) $u['id'];
		$login = (string) $u['username'];
		$name = !empty($u['global_name']) ? (string) $u['global_name'] : '';
		if (!empty($u['avatar']))
			$avatar = 'https://cdn.discordapp.com/avatars/'.$id.'/'.$u['avatar'].'.png';
		if (!empty($u['email']) && !empty($u['verified']))
		{
			$email = strtolower(trim($u['email']));
			$verified[] = $email;
		}
	}
	else if ($provider == 'microsoft')
	{
		// Graph OIDC userinfo: sub, name, email, picture. A Microsoft
		// account's email IS the account credential, so it is verified.
		if (empty($u['sub']))
			return false;
		$id = (string) $u['sub'];
		$name = isset($u['name']) ? (string) $u['name'] : '';
		if (!empty($u['email']))
		{
			$email = strtolower(trim($u['email']));
			$verified[] = $email;
		}
		$login = $name !== '' ? $name : ($email !== '' ? strstr($email, '@', true) : '');
	}
	else if ($provider == 'github')
	{
		if (empty($u['id']) || empty($u['login']))
			return false;
		$id = (string) $u['id'];
		$login = (string) $u['login'];
		$name = isset($u['name']) ? (string) $u['name'] : '';
		$avatar = isset($u['avatar_url']) ? (string) $u['avatar_url'] : '';

		$emails = evebb_socialauth_http_json($p['emails'], null, $auth);
		if (is_array($emails))
		{
			$primary = '';
			foreach ($emails as $e)
			{
				if (empty($e['email']) || empty($e['verified']))
					continue;
				$addr = strtolower(trim($e['email']));
				$verified[] = $addr;
				if (!empty($e['primary']))
					$primary = $addr;
			}
			$email = ($primary !== '') ? $primary : (isset($verified[0]) ? $verified[0] : '');
		}
	}

	if ($id === '' || ($login === '' && $name === ''))
		return false;

	// Avatar URLs must be https to be usable in pages
	if ($avatar !== '' && !preg_match('%^https://%i', $avatar))
		$avatar = '';

	return array(
		'provider'        => $provider,
		'id'              => $id,
		'login'           => $login,
		'name'            => $name,
		'avatar_url'      => $avatar,
		'email'           => $email,
		'verified_emails' => array_values(array_unique($verified))
	);
}


// ---------------------------------------------------------------------------
// Schema + config
// ---------------------------------------------------------------------------

function evebb_socialauth_save_config($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}

//
// First-run bootstrap: the link table + defaults. Guarded by
// o_socialauth_db_rev.
//
function evebb_socialauth_bootstrap()
{
	global $db, $pun_config;

	if (isset($pun_config['o_socialauth_db_rev']) && (int) $pun_config['o_socialauth_db_rev'] >= SOCIALAUTH_DB_REV)
		return;

	if (!$db->table_exists('socialauth_users'))
	{
		$schema = array(
			'FIELDS' => array(
				'user_id' => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'provider' => array('datatype' => 'VARCHAR(16)', 'allow_null' => false, 'default' => '\'\''),
				'ext_id' => array('datatype' => 'VARCHAR(64)', 'allow_null' => false, 'default' => '\'\''),
				'ext_login' => array('datatype' => 'VARCHAR(80)', 'allow_null' => false, 'default' => '\'\''),
				'avatar_url' => array('datatype' => 'VARCHAR(255)', 'allow_null' => false, 'default' => '\'\''),
				'linked_at' => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0')
			),
			'PRIMARY KEY' => array('user_id', 'provider'),
			'UNIQUE KEYS' => array('provider_ext_idx' => array('provider', 'ext_id'))
		);

		$db->create_table('socialauth_users', $schema) or error('Unable to create socialauth_users table', __FILE__, __LINE__, $db->error());
	}

	if (!isset($pun_config['o_socialauth_link_by_email']))
		evebb_socialauth_save_config('o_socialauth_link_by_email', '1');

	evebb_socialauth_save_config('o_socialauth_db_rev', (string) SOCIALAUTH_DB_REV);
}


// ---------------------------------------------------------------------------
// Account matching / creation / login
// ---------------------------------------------------------------------------

//
// The forum user row bound to (provider, ext_id), or null.
//
function evebb_socialauth_user_by_ext($provider, $ext_id)
{
	global $db;

	$result = $db->query('SELECT u.* FROM '.$db->prefix.'socialauth_users AS s INNER JOIN '.$db->prefix.'users AS u ON u.id=s.user_id WHERE s.provider=\''.$db->escape($provider).'\' AND s.ext_id=\''.$db->escape($ext_id).'\'') or error('Unable to fetch linked user', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? $db->fetch_assoc($result) : null;
}

//
// A real (non-guest) user whose email matches and who has NO link for this
// provider yet. Null if none.
//
function evebb_socialauth_user_by_email($provider, $email)
{
	global $db;

	$email = strtolower(trim($email));
	if ($email === '')
		return null;

	$result = $db->query('SELECT u.* FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'socialauth_users AS s ON (s.user_id=u.id AND s.provider=\''.$db->escape($provider).'\') WHERE u.id>1 AND s.user_id IS NULL AND LOWER(u.email)=\''.$db->escape($email).'\' ORDER BY u.id LIMIT 1') or error('Unable to fetch user by email', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? $db->fetch_assoc($result) : null;
}

//
// Bind an identity to a forum user.
//
function evebb_socialauth_link($user_id, $ident)
{
	global $db;

	$db->query('INSERT INTO '.$db->prefix.'socialauth_users (user_id, provider, ext_id, ext_login, avatar_url, linked_at) VALUES('.(int) $user_id.', \''.$db->escape($ident['provider']).'\', \''.$db->escape($ident['id']).'\', \''.$db->escape(pun_trim($ident['login']) !== '' ? $ident['login'] : $ident['name']).'\', \''.$db->escape($ident['avatar_url']).'\', '.time().')') or error('Unable to link account', __FILE__, __LINE__, $db->error());
}

//
// Turn identity names into a valid, unique forum username via core
// check_username() rules, numeric suffix on collision. '' if impossible.
//
function evebb_socialauth_pick_username($ident)
{
	global $errors;

	$candidates = array();
	foreach (array($ident['login'], $ident['name'], ($ident['email'] !== '' ? strstr($ident['email'], '@', true) : '')) as $raw)
	{
		$cand = pun_trim(preg_replace('%\s+%', ' ', (string) $raw));
		if ($cand !== '' && !in_array($cand, $candidates, true))
			$candidates[] = $cand;
	}

	foreach ($candidates as $cand)
	{
		if (pun_strlen($cand) > 25)
			$cand = pun_trim(utf8_substr($cand, 0, 25));

		for ($i = 0; $i <= 99; $i++)
		{
			$try = ($i === 0) ? $cand : (pun_trim(utf8_substr($cand, 0, 22)).$i);

			$saved = $errors;
			$errors = array();
			check_username($try);
			$ok = empty($errors);
			$errors = $saved;

			if ($ok)
				return $try;
		}
	}

	return '';
}

//
// Create a forum account for a verified identity, linked to it. Returns the
// new user id (int) or a string error key:
//   'closed', 'email', 'banned_email', 'dupe_email', 'username'
//
function evebb_socialauth_create_user($ident, $email)
{
	global $db, $pun_config;

	if ($pun_config['o_regs_allow'] == '0')
		return 'closed';

	require_once PUN_ROOT.'include/email.php';

	$email = strtolower(pun_trim($email));
	if (!is_valid_email($email))
		return 'email';

	if (is_banned_email($email) && $pun_config['p_allow_banned_email'] == '0')
		return 'banned_email';

	if ($pun_config['p_allow_dupe_email'] == '0')
	{
		$result = $db->query('SELECT 1 FROM '.$db->prefix.'users WHERE email=\''.$db->escape($email).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
		if ($db->has_rows($result))
			return 'dupe_email';
	}

	$username = evebb_socialauth_pick_username($ident);
	if ($username === '')
		return 'username';

	$now = time();
	$group_id = intval($pun_config['o_default_user_group']);
	$password_hash = flux_password_hash(random_pass(24));

	$db->query('INSERT INTO '.$db->prefix.'users (username, group_id, password, email, email_setting, timezone, dst, language, style, registered, registration_ip, last_visit) VALUES(\''.$db->escape($username).'\', '.$group_id.', \''.$db->escape($password_hash).'\', \''.$db->escape($email).'\', '.intval($pun_config['o_default_email_setting']).', '.floatval($pun_config['o_default_timezone']).', '.intval($pun_config['o_default_dst']).', \''.$db->escape($pun_config['o_default_lang']).'\', \''.$db->escape($pun_config['o_default_style']).'\', '.$now.', \''.$db->escape(get_remote_address()).'\', '.$now.')') or error('Unable to create user', __FILE__, __LINE__, $db->error());
	$new_uid = (int) $db->insert_id();

	evebb_socialauth_link($new_uid, $ident);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_users_info_cache();

	return $new_uid;
}

//
// Log a user row in (mirrors login.php's success path).
//
function evebb_socialauth_login_user($cur_user)
{
	global $db, $pun_config;

	$db->query('DELETE FROM '.$db->prefix.'online WHERE ident=\''.$db->escape(get_remote_address()).'\'') or error('Unable to delete from online list', __FILE__, __LINE__, $db->error());

	pun_setcookie($cur_user['id'], $cur_user['password'], time() + $pun_config['o_timeout_visit']);
	set_tracked_topics(null);
}
