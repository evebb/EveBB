# Moderator Notes & Warnings

An unofficial [eveBB](https://evebb.net) plugin giving the board staff a
private notes log and a formal warnings system for members.

## Features

- **Notes** — private, timestamped staff observations on any member
  ("spoken to about tone", "verified plugin author"). Visible only to
  administrators and global moderators; the member never sees them.
- **Warnings** — formal and member-visible, each carrying points
  (0–100) and an optional expiry in days. Expired warnings stay on
  record but stop counting.
- The member sees their own warnings on their profile and a banner
  while any warning is active (setting to turn the banner off).
- Staff see the full history in a panel on the member's profile, an
  active-points ⚠ marker next to poster names on topic pages (setting),
  and an **over the limit** flag when the configurable points threshold
  is reached. Nothing is automatic — banning stays a human decision via
  the core Bans page.
- Administrators can delete any entry; a moderator can delete their
  own. The settings page lists members with active points, highest
  first.

## Installation

Upload `modnotes.zip` through **Administration → Plugins → Upload
plugin**, then activate it. The plugin creates its database table
(`mod_notes`) automatically on first use. Staff then work directly from
member profiles.

## Notes

- "Staff" means administrators plus members of groups with global
  moderator powers.
- Warning points and thresholds are advisory tooling for humans; the
  plugin never bans or restricts anyone by itself.
- Without JavaScript nothing breaks — the panels are page decoration,
  and all actions are re-validated server-side either way.

## License

GPL version 2 or higher, like eveBB itself.
