<?php

/**
 * Moderator Notes & Warnings - the addon.
 *
 * Staff (administrators + global moderators) keep a private, timestamped
 * notes log on any member, and issue formal warnings carrying points and
 * an optional expiry. Members see their own WARNINGS (never the notes) on
 * their profile, plus a banner while any warning is active. Staff see the
 * full history in a panel on the member's profile, an active-points ⚠
 * marker next to poster names on topic pages, and an over-threshold flag
 * when the configured points limit is reached (action stays a human
 * decision - nothing automatic).
 *
 * Wiring is the series' standard kit: everything hangs off
 * header_head_end; profile actions are a POST (add - global CSRF gate
 * covers it) and a GET + csrf_token (delete, solved-plugin pattern), both
 * re-validated server-side; page decoration is DOM-built JS driven by a
 * per-viewer config blob that only ever contains what THAT viewer may
 * see (notes never enter a non-staff page).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_modnotes extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		// The hook can fire twice in one request when core re-includes
		// header.php (e.g. message() rendering an error page). Act once.
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		evebb_modnotes_ensure_schema();

		$page = isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : '';

		if ($page == 'profile.php')
			$this->head_profile();
		else if ($page == 'viewtopic.php')
			$this->head_viewtopic();

		if (!defined('PUN_ADMIN_CONSOLE'))
			$this->head_banner();
	}


	//
	// profile.php: handle staff actions, then emit the staff panel (for
	// staff viewers) and/or the member's own warnings panel
	//
	function head_profile()
	{
		global $db, $id, $pun_user;

		if (!isset($id) || (int) $id < 2)
			return;

		// The target must be a real registered member
		$result = $db->query('SELECT username FROM '.$db->prefix.'users WHERE id='.(int) $id.' AND id>1') or error('Unable to fetch member', __FILE__, __LINE__, $db->error());
		if (!$db->has_rows($result))
			return;
		$target_name = $db->result($result);

		$is_staff = evebb_modnotes_is_staff();
		$section = isset($_GET['section']) ? (string) $_GET['section'] : 'essentials';

		if ($is_staff && isset($_POST['modnotes_action']) && $_POST['modnotes_action'] === 'add')
			$this->handle_add((int) $id);

		if ($is_staff && isset($_GET['modnotes_action']) && $_GET['modnotes_action'] === 'del')
			$this->handle_delete((int) $id);

		$threshold = (int) evebb_modnotes_conf('o_modnotes_threshold', '3');

		// Staff panel lives on the member's Administration section, as its
		// own form section above the Delete/ban block
		if ($is_staff && $section === 'admin')
		{
			$active = evebb_modnotes_active_points($id);
			$now = time();
			$entries = array();

			foreach (evebb_modnotes_entries($id) as $row)
			{
				$expired = ($row['kind'] == 'warning' && (int) $row['expires_at'] > 0 && (int) $row['expires_at'] <= $now);
				$entries[] = array(
					'id'      => (int) $row['id'],
					'kind'    => $row['kind'],
					'body'    => $row['body'],
					'author'  => ($row['author'] !== null) ? $row['author'] : 'deleted user',
					'at'      => format_time($row['created_at']),
					'points'  => (int) $row['points'],
					'expires' => ((int) $row['expires_at'] > 0) ? format_time($row['expires_at']) : null,
					'expired' => $expired,
					'canDel'  => ((int) $pun_user['g_id'] == PUN_ADMIN || (int) $row['author_id'] == (int) $pun_user['id'])
				);
			}

			$this->emit(array(
				'page'      => 'staff',
				'user'      => (int) $id,
				'name'      => $target_name,
				'entries'   => $entries,
				'active'    => $active,
				'threshold' => $threshold,
				'flagged'   => ($threshold > 0 && $active >= $threshold),
				'token'     => pun_csrf_token(),
				'text'      => array(
					'title'    => 'Moderator notes & warnings',
					'staffTag' => 'staff only',
					'status'   => 'Active warning points:',
					'flag'     => 'OVER THE LIMIT — consider action (Bans live under Administration).',
					'note'     => 'NOTE',
					'warning'  => 'WARNING',
					'pts'      => 'pts',
					'by'       => 'by',
					'expires'  => 'expires',
					'expired'  => 'expired',
					'del'      => 'delete',
					'confirm'  => 'Delete this entry? This cannot be undone.',
					'addNote'  => 'Add a private note',
					'addWarn'  => 'Issue a warning (the member will see it)',
					'points'   => 'Points',
					'days'     => 'Expires after days (0 = never)',
					'pointsNote' => '(points/expiry apply to warnings only)',
					'saveNote' => 'Add private note',
					'saveWarn' => 'Issue warning',
					'none'     => 'No notes or warnings for this member.'
				)
			));
		}

		// The member's own warnings (notes are never included) - on their
		// own Essentials section, as a native section
		if (!$pun_user['is_guest'] && (int) $pun_user['id'] == (int) $id
			&& ($section === 'essentials' || $section === ''))
		{
			$warnings = array();
			$now = time();

			foreach (evebb_modnotes_entries($id, true) as $row)
				$warnings[] = array(
					'body'    => $row['body'],
					'author'  => ($row['author'] !== null) ? $row['author'] : 'staff',
					'at'      => format_time($row['created_at']),
					'points'  => (int) $row['points'],
					'expires' => ((int) $row['expires_at'] > 0) ? format_time($row['expires_at']) : null,
					'expired' => ((int) $row['expires_at'] > 0 && (int) $row['expires_at'] <= $now)
				);

			if (!empty($warnings))
				$this->emit(array(
					'page'     => 'own',
					'warnings' => $warnings,
					'active'   => evebb_modnotes_active_points($id),
					'text'     => array(
						'title'   => 'Your warnings',
						'blurb'   => 'Warnings are issued by the board staff. Expired warnings no longer count against you.',
						'pts'     => 'pts',
						'by'      => 'by',
						'expires' => 'expires',
						'expired' => 'expired',
						'active'  => 'Active warning points:'
					)
				));
		}
	}


	//
	// Add a note or warning (staff, POST - the global CSRF gate has
	// validated the token). Every well-formed path exits via redirect.
	//
	function handle_add($target_id)
	{
		global $pun_user;

		while (ob_get_level() > 0)
			ob_end_clean();

		$ok = evebb_modnotes_add(
			$target_id,
			$pun_user['id'],
			isset($_POST['modnotes_kind']) ? (string) $_POST['modnotes_kind'] : 'note',
			isset($_POST['modnotes_body']) ? (string) $_POST['modnotes_body'] : '',
			isset($_POST['modnotes_points']) ? (int) $_POST['modnotes_points'] : 0,
			isset($_POST['modnotes_days']) ? (int) $_POST['modnotes_days'] : 0
		);

		redirect('profile.php?id='.$target_id, $ok ? 'Saved. Redirecting …' : 'The entry needs some text. Redirecting …');
	}


	//
	// Delete an entry (staff; administrators may delete anything, a
	// moderator only their own entries). GET + csrf_token.
	//
	function handle_delete($target_id)
	{
		global $db, $pun_user;

		while (ob_get_level() > 0)
			ob_end_clean();

		$token = isset($_GET['csrf_token']) ? $_GET['csrf_token'] : null;
		if (!is_string($token) || !hash_equals(pun_csrf_token(), $token))
			redirect('profile.php?id='.$target_id, 'Bad request. Redirecting …');

		$nid = isset($_GET['nid']) ? (int) $_GET['nid'] : 0;

		$result = $db->query('SELECT author_id FROM '.$db->prefix.'mod_notes WHERE id='.$nid.' AND user_id='.$target_id) or error('Unable to fetch entry', __FILE__, __LINE__, $db->error());
		if (!$db->has_rows($result))
			redirect('profile.php?id='.$target_id, 'Bad request. Redirecting …');

		$author_id = (int) $db->result($result);
		if ((int) $pun_user['g_id'] != PUN_ADMIN && $author_id != (int) $pun_user['id'])
			redirect('profile.php?id='.$target_id, 'Only administrators can delete another moderator\'s entries. Redirecting …');

		$db->query('DELETE FROM '.$db->prefix.'mod_notes WHERE id='.$nid) or error('Unable to delete entry', __FILE__, __LINE__, $db->error());

		redirect('profile.php?id='.$target_id, 'Entry deleted. Redirecting …');
	}


	//
	// viewtopic.php: give staff viewers an active-points map for this
	// topic's posters
	//
	function head_viewtopic()
	{
		global $db, $cur_topic, $id;

		if (!isset($cur_topic) || !isset($id))
			return;

		if (!evebb_modnotes_is_staff())
			return;

		if (evebb_modnotes_conf('o_modnotes_marker', '1') != '1')
			return;

		$result = $db->query('SELECT u.username, SUM(n.points) AS pts FROM '.$db->prefix.'mod_notes AS n INNER JOIN '.$db->prefix.'users AS u ON u.id=n.user_id WHERE n.kind=\'warning\' AND (n.expires_at=0 OR n.expires_at>'.time().') AND n.user_id IN (SELECT poster_id FROM '.$db->prefix.'posts WHERE topic_id='.(int) $id.' AND poster_id>1) GROUP BY u.id, u.username') or error('Unable to fetch warning points', __FILE__, __LINE__, $db->error());

		$map = array();
		while ($row = $db->fetch_assoc($result))
		{
			if ((int) $row['pts'] > 0)
				$map[$row['username']] = (int) $row['pts'];
		}

		if (empty($map))
			return;

		$this->emit(array(
			'page'      => 'topic',
			'map'       => $map,
			'threshold' => (int) evebb_modnotes_conf('o_modnotes_threshold', '3'),
			'text'      => array('marker' => 'Active warning points (visible to staff only)')
		));
	}


	//
	// Every page: a banner for the member themselves while a warning is
	// active
	//
	function head_banner()
	{
		global $pun_user;

		if ($pun_user['is_guest'])
			return;

		if (evebb_modnotes_conf('o_modnotes_banner', '1') != '1')
			return;

		$active = evebb_modnotes_active_points($pun_user['id']);
		if ($active < 1)
			return;

		$this->emit(array(
			'page'   => 'banner',
			'active' => $active,
			'url'    => 'profile.php?id='.(int) $pun_user['id'],
			'text'   => array(
				'msg'  => 'You have an active warning from the board staff',
				'pts'  => 'point(s)',
				'link' => 'See your warnings'
			)
		));
	}


	//
	// Emit the shared CSS plus the page JS with its config blob into <head>
	//
	function emit($cfg)
	{
		static $css_done = false;

		if (!$css_done)
		{
			$css_done = true;
			echo '<style>'
				.'.mnkind{display:inline-block;padding:0 .5em;border-radius:3px;color:#fff;font-size:.8em;font-weight:bold;margin-right:.5em;vertical-align:baseline}'
				.'.mnkind-note{background:#4a6d8c}'
				.'.mnkind-warning{background:#b5443c}'
				.'.mnentry{border-bottom:1px solid rgba(128,128,128,.25);padding:.5em 0}'
				.'.mnentry:last-child{border-bottom:0}'
				.'.mnbody{white-space:pre-wrap;margin:.25em 0}'
				.'.mnmeta{font-size:.85em;opacity:.8}'
				.'.mnmeta a{margin-left:.6em}'
				.'.mnexpired{opacity:.55}'
				.'.mnflag{color:#b5443c;font-weight:bold}'
				.'.mnstatus{margin:.2em 0 .6em}'
				.'#mnpanel form{margin:.6em 0}'
				.'#mnpanel textarea{width:95%;max-width:40em}'
				.'#mnpanel input[type=text]{width:4.5em}'
				.'.mnmark{display:inline-block;padding:0 .45em;border-radius:3px;background:#b5443c;color:#fff;font-size:.8em;font-weight:bold;cursor:default}'
				.'dd.mnmarkrow{margin-top:.35em}'
				.'#mnbanner{border:1px solid rgba(181,68,60,.7);background:rgba(181,68,60,.12);border-radius:4px;padding:.55em .9em;margin:.6em 0;font-size:.95em}'
				.'#mnbanner a{margin-left:.8em}'
				.'</style>'."\n";
		}

		$json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES);

		echo '<script>/* Moderator Notes & Warnings plugin */'."\n".'(function(){'."\n"
			.'var cfg = '.$json.';'."\n"
			.<<<'EOJS'
function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

function el(tag, cls, text) {
	var e = document.createElement(tag);
	if (cls) e.className = cls;
	if (text) e.textContent = text;
	return e;
}

// Build a native profile section: div.inform > fieldset > legend +
// div.infldset. Optionally wrap the whole thing in a form (staff panel).
// Returns the infldset to fill, or null.
function makeSection(id, legendText, asForm) {
	var inform = el('div', 'inform');
	inform.id = id;
	var container = inform;
	if (asForm) {
		var form = document.createElement('form');
		form.method = 'post';
		form.appendChild(inform);
		container = form;
	}
	var fs = document.createElement('fieldset');
	var lg = document.createElement('legend');
	lg.textContent = legendText;
	fs.appendChild(lg);
	var fld = el('div', 'infldset');
	fs.appendChild(fld);
	inform.appendChild(fs);
	inform._container = container;
	inform._fld = fld;
	return inform;
}

// The .box of the current profile section (where the core forms live)
function sectionBox() {
	var bf = document.querySelector('div.blockform');
	return bf ? bf.querySelector('.box') : null;
}

function entryRow(e, delUrl) {
	var row = el('div', 'mnentry' + (e.expired ? ' mnexpired' : ''));
	var head = el('div');
	head.appendChild(el('span', 'mnkind mnkind-' + e.kind, e.kind === 'warning' ? cfg.text.warning : cfg.text.note));
	if (e.kind === 'warning') {
		var meta = cfg.text.pts + ' ' + e.points;
		if (e.expires) meta += ' · ' + (e.expired ? cfg.text.expired : cfg.text.expires + ' ' + e.expires);
		head.appendChild(el('strong', null, meta));
	}
	row.appendChild(head);
	row.appendChild(el('div', 'mnbody', e.body));
	var m = el('div', 'mnmeta', cfg.text.by + ' ' + e.author + ' — ' + e.at);
	if (delUrl) {
		var a = document.createElement('a');
		a.href = delUrl;
		a.textContent = cfg.text.del;
		a.addEventListener('click', function (ev) { if (!window.confirm(cfg.text.confirm)) ev.preventDefault(); });
		m.appendChild(a);
	}
	row.appendChild(m);
	return row;
}

// ---- staff panel: one native section at the top of the Admin box -----------
function staffPanel() {
	var box = sectionBox();
	if (!box) return;

	var section = makeSection('mnpanel', cfg.text.title + ': ' + cfg.name + ' — ' + cfg.text.staffTag, true);
	var form = section._container;
	var fld = section._fld;
	form.action = 'profile.php?section=admin&id=' + cfg.user;

	var h1 = document.createElement('input');
	h1.type = 'hidden'; h1.name = 'modnotes_action'; h1.value = 'add';
	form.appendChild(h1);
	var h2 = document.createElement('input');
	h2.type = 'hidden'; h2.name = 'csrf_token'; h2.value = cfg.token;
	form.appendChild(h2);

	var status = el('p', 'mnstatus');
	status.appendChild(document.createTextNode(cfg.text.status + ' '));
	status.appendChild(el('strong', null, String(cfg.active) + ' / ' + cfg.threshold));
	if (cfg.flagged) {
		status.appendChild(document.createTextNode(' — '));
		status.appendChild(el('span', 'mnflag', cfg.text.flag));
	}
	fld.appendChild(status);

	if (cfg.entries.length === 0)
		fld.appendChild(el('p', null, cfg.text.none));
	for (var i = 0; i < cfg.entries.length; i++) {
		var e = cfg.entries[i];
		var delUrl = e.canDel
			? 'profile.php?section=admin&id=' + cfg.user + '&modnotes_action=del&nid=' + e.id + '&csrf_token=' + encodeURIComponent(cfg.token)
			: null;
		fld.appendChild(entryRow(e, delUrl));
	}

	// One add form; a private note or a member-visible warning, chosen by
	// which submit button is pressed (name=modnotes_kind carries the kind)
	fld.appendChild(el('p', null, cfg.text.addNote + ' / ' + cfg.text.addWarn + ':'));
	var ta = document.createElement('textarea');
	ta.name = 'modnotes_body';
	ta.rows = 3;
	fld.appendChild(ta);

	var prow = el('p');
	prow.appendChild(document.createTextNode(cfg.text.points + ' '));
	var pts = document.createElement('input');
	pts.type = 'text'; pts.name = 'modnotes_points'; pts.value = '1'; pts.maxLength = 3;
	prow.appendChild(pts);
	prow.appendChild(document.createTextNode(' ' + cfg.text.days + ' '));
	var days = document.createElement('input');
	days.type = 'text'; days.name = 'modnotes_days'; days.value = '30'; days.maxLength = 4;
	prow.appendChild(days);
	prow.appendChild(el('span', 'mnmeta', ' ' + cfg.text.pointsNote));
	fld.appendChild(prow);

	var brow = el('p');
	var bNote = document.createElement('button');
	bNote.type = 'submit'; bNote.name = 'modnotes_kind'; bNote.value = 'note';
	bNote.textContent = cfg.text.saveNote;
	brow.appendChild(bNote);
	brow.appendChild(document.createTextNode(' '));
	var bWarn = document.createElement('button');
	bWarn.type = 'submit'; bWarn.name = 'modnotes_kind'; bWarn.value = 'warning';
	bWarn.textContent = cfg.text.saveWarn;
	brow.appendChild(bWarn);
	fld.appendChild(brow);

	box.insertBefore(form, box.firstChild);
}

// ---- the member's own warnings: a native section on their Essentials -------
function ownPanel() {
	var box = sectionBox();
	if (!box) return;

	var section = makeSection('mnown', cfg.text.title, false);
	var fld = section._fld;

	var status = el('p', 'mnstatus');
	status.appendChild(document.createTextNode(cfg.text.active + ' '));
	status.appendChild(el('strong', null, String(cfg.active)));
	fld.appendChild(status);
	fld.appendChild(el('p', 'mnmeta', cfg.text.blurb));

	for (var i = 0; i < cfg.warnings.length; i++) {
		var w = cfg.warnings[i];
		var row = el('div', 'mnentry' + (w.expired ? ' mnexpired' : ''));
		var head = el('div');
		head.appendChild(el('span', 'mnkind mnkind-warning', cfg.text.pts + ' ' + w.points));
		if (w.expires) head.appendChild(el('strong', null, w.expired ? cfg.text.expired : cfg.text.expires + ' ' + w.expires));
		row.appendChild(head);
		row.appendChild(el('div', 'mnbody', w.body));
		row.appendChild(el('div', 'mnmeta', cfg.text.by + ' ' + w.author + ' — ' + w.at));
		fld.appendChild(row);
	}

	box.appendChild(section);
}

// ---- staff marker on topic pages --------------------------------------------
function topicPage() {
	var lists = document.querySelectorAll('div.blockpost .postleft dl');
	for (var i = 0; i < lists.length; i++) {
		var dt = lists[i].querySelector('dt');
		if (!dt) continue;
		var name = dt.textContent.replace(/^\s+|\s+$/g, '');
		if (!(name in cfg.map)) continue;
		var dd = el('dd', 'mnmarkrow');
		var mark = el('span', 'mnmark', '⚠ ' + cfg.map[name]);
		mark.title = cfg.text.marker;
		dd.appendChild(mark);
		lists[i].appendChild(dd);
	}
}

// ---- the member's active-warning banner -------------------------------------
function banner() {
	var main = document.getElementById('brdmain') || document.body;
	var bar = el('div');
	bar.id = 'mnbanner';
	bar.appendChild(document.createTextNode(cfg.text.msg + ' (' + cfg.active + ' ' + cfg.text.pts + ').'));
	var a = document.createElement('a');
	a.href = cfg.url;
	a.textContent = cfg.text.link;
	bar.appendChild(a);
	main.insertBefore(bar, main.firstChild);
}

ready(function () {
	if (cfg.page === 'staff') staffPanel();
	else if (cfg.page === 'own') ownPanel();
	else if (cfg.page === 'topic') topicPage();
	else banner();
});
EOJS
			."\n".'})();</script>'."\n";
	}
}
