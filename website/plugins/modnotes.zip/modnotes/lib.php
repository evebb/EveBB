<?php

/**
 * Moderator Notes & Warnings - shared library.
 *
 * Schema management and helpers used by the addon (modnotes.php) and the
 * settings page (admin.php). One table holds both kinds of entry: private
 * staff notes (kind 'note') and formal warnings (kind 'warning', carrying
 * points and an optional expiry).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


//
// Create the mod_notes table on first use. Guarded by the
// o_modnotes_db_rev config key so the check is free on every later request.
//
function evebb_modnotes_ensure_schema()
{
	global $db, $pun_config;

	if (isset($pun_config['o_modnotes_db_rev']))
		return;

	if (!$db->table_exists('mod_notes'))
	{
		$schema = array(
			'FIELDS' => array(
				'id' => array(
					'datatype'   => 'SERIAL',
					'allow_null' => false
				),
				'user_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'author_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'kind' => array(
					'datatype'   => 'VARCHAR(10)',
					'allow_null' => false,
					'default'    => '\'note\''
				),
				'body' => array(
					'datatype'   => 'TEXT',
					'allow_null' => false
				),
				'points' => array(
					'datatype'   => 'INT(10)',
					'allow_null' => false,
					'default'    => '0'
				),
				'expires_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'created_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('id'),
			'INDEXES' => array(
				'user_id_idx' => array('user_id')
			)
		);

		$db->create_table('mod_notes', $schema) or error('Unable to create the mod_notes table', __FILE__, __LINE__, $db->error());
	}

	// Record the schema revision. No or-error here: if two requests race,
	// the loser's duplicate insert may fail and that is fine.
	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_modnotes_db_rev\', \'1\')');
	$pun_config['o_modnotes_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Read a plugin config value with a default
//
function evebb_modnotes_conf($name, $default)
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Insert or update a config value and refresh the config cache
//
function evebb_modnotes_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


//
// Is the current user staff (administrator or a global moderator)?
//
function evebb_modnotes_is_staff()
{
	global $pun_user;

	return !$pun_user['is_guest']
		&& ((int) $pun_user['g_id'] == PUN_ADMIN || $pun_user['g_moderator'] == '1');
}


//
// A member's entries, newest first (staff view: everything; own view:
// warnings only - notes are private to staff)
//
function evebb_modnotes_entries($user_id, $warnings_only = false)
{
	global $db;

	$result = $db->query('SELECT n.id, n.author_id, n.kind, n.body, n.points, n.expires_at, n.created_at, a.username AS author FROM '.$db->prefix.'mod_notes AS n LEFT JOIN '.$db->prefix.'users AS a ON a.id=n.author_id WHERE n.user_id='.(int) $user_id.($warnings_only ? ' AND n.kind=\'warning\'' : '').' ORDER BY n.created_at DESC, n.id DESC') or error('Unable to fetch moderation entries', __FILE__, __LINE__, $db->error());

	$entries = array();
	while ($row = $db->fetch_assoc($result))
		$entries[] = $row;

	return $entries;
}


//
// A member's ACTIVE warning points (unexpired warnings only)
//
function evebb_modnotes_active_points($user_id)
{
	global $db;

	$result = $db->query('SELECT COALESCE(SUM(points), 0) FROM '.$db->prefix.'mod_notes WHERE user_id='.(int) $user_id.' AND kind=\'warning\' AND (expires_at=0 OR expires_at>'.time().')') or error('Unable to sum warning points', __FILE__, __LINE__, $db->error());

	return (int) $db->result($result);
}


//
// Add an entry. $kind 'note' (points/expiry forced to 0) or 'warning'.
//
function evebb_modnotes_add($user_id, $author_id, $kind, $body, $points, $expire_days)
{
	global $db;

	$kind = ($kind === 'warning') ? 'warning' : 'note';
	$body = pun_trim($body);

	if ($body === '' || strlen($body) > 65000)
		return false;

	if ($kind === 'note')
	{
		$points = 0;
		$expires_at = 0;
	}
	else
	{
		$points = max(0, min(100, (int) $points));
		$expire_days = max(0, min(3650, (int) $expire_days));
		$expires_at = $expire_days > 0 ? time() + $expire_days * 86400 : 0;
	}

	$db->query('INSERT INTO '.$db->prefix.'mod_notes (user_id, author_id, kind, body, points, expires_at, created_at) VALUES('.(int) $user_id.', '.(int) $author_id.', \''.$kind.'\', \''.$db->escape($body).'\', '.$points.', '.$expires_at.', '.time().')') or error('Unable to add moderation entry', __FILE__, __LINE__, $db->error());

	return true;
}
