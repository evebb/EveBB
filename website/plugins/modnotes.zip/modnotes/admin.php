<?php

/**
 * Moderator Notes & Warnings - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome (and inside a POST
 * form that footer.php injects the CSRF token into). $db, $pun_config and
 * $plugin_slug are available here.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

// The addon normally creates the table on first page view, but make sure
// it exists even if the settings page is visited before that
evebb_modnotes_ensure_schema();

$mn_back = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

// Settings
if (isset($_POST['save_modnotes']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$threshold = isset($_POST['mn_threshold']) ? (int) $_POST['mn_threshold'] : 3;
	if ($threshold < 0)
		$threshold = 0;
	else if ($threshold > 1000)
		$threshold = 1000;
	evebb_modnotes_save_conf('o_modnotes_threshold', (string) $threshold);

	evebb_modnotes_save_conf('o_modnotes_marker', isset($_POST['mn_marker']) ? '1' : '0');
	evebb_modnotes_save_conf('o_modnotes_banner', isset($_POST['mn_banner']) ? '1' : '0');

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect($mn_back, 'Settings saved. Redirecting …');
}

// Remove entries whose members no longer exist
if (isset($_POST['purge_modnotes']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DELETE FROM '.$db->prefix.'mod_notes WHERE user_id NOT IN (SELECT id FROM '.$db->prefix.'users)') or error('Unable to purge entries', __FILE__, __LINE__, $db->error());

	redirect($mn_back, 'Orphaned entries purged. Redirecting …');
}

// Remove ALL plugin data (before uninstalling)
if (isset($_POST['nuke_modnotes']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect($mn_back, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('mod_notes');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN (\'o_modnotes_db_rev\', \'o_modnotes_threshold\', \'o_modnotes_marker\', \'o_modnotes_banner\')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());

	unset($pun_config['o_modnotes_db_rev'], $pun_config['o_modnotes_threshold'], $pun_config['o_modnotes_marker'], $pun_config['o_modnotes_banner']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Moderator Notes & Warnings data removed. You can now deactivate and delete the plugin. Redirecting …');
}

$mn_threshold = (int) evebb_modnotes_conf('o_modnotes_threshold', '3');
$mn_marker    = evebb_modnotes_conf('o_modnotes_marker', '1') == '1';
$mn_banner    = evebb_modnotes_conf('o_modnotes_banner', '1') == '1';

// Totals + the members with active points, highest first
$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'mod_notes') or error('Unable to count entries', __FILE__, __LINE__, $db->error());
$mn_total = (int) $db->result($result);

$result = $db->query('SELECT u.id, u.username, SUM(n.points) AS pts FROM '.$db->prefix.'mod_notes AS n INNER JOIN '.$db->prefix.'users AS u ON u.id=n.user_id WHERE n.kind=\'warning\' AND (n.expires_at=0 OR n.expires_at>'.time().') GROUP BY u.id, u.username ORDER BY pts DESC, u.username LIMIT 15') or error('Unable to fetch active points', __FILE__, __LINE__, $db->error());
$mn_actives = array();
while ($row = $db->fetch_assoc($result))
{
	if ((int) $row['pts'] > 0)
		$mn_actives[] = $row;
}

?>
		<div class="inform">
			<fieldset>
				<legend>Moderator Notes &amp; Warnings settings</legend>
				<div class="infldset">
					<p>Entries on record: <strong><?php echo $mn_total ?></strong>. Staff (administrators and global moderators) add notes and warnings from a member's profile page. Notes are private to staff; warnings are visible to the member they concern.</p>
					<label>Warning-points threshold — members at or over it are flagged to staff (0 disables the flag)
						<br /><input type="text" name="mn_threshold" size="5" maxlength="4" value="<?php echo $mn_threshold ?>" />
					</label>
					<label><input type="checkbox" name="mn_marker" value="1"<?php if ($mn_marker) echo ' checked="checked"' ?> /> Show staff a ⚠ active-points marker next to poster names on topic pages</label>
					<label><input type="checkbox" name="mn_banner" value="1"<?php if ($mn_banner) echo ' checked="checked"' ?> /> Show members a banner while they have an active warning</label>
					<p class="topspace"><input type="submit" name="save_modnotes" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>
<?php if (!empty($mn_actives)): ?>
		<div class="inform">
			<fieldset>
				<legend>Members with active warning points</legend>
				<div class="infldset">
					<ul>
<?php foreach ($mn_actives as $cur): ?>
						<li><span><strong><?php echo (int) $cur['pts'] ?></strong> — <a href="<?php echo get_base_url(true) ?>/profile.php?id=<?php echo (int) $cur['id'] ?>"><?php echo pun_htmlspecialchars($cur['username']) ?></a><?php if ($mn_threshold > 0 && (int) $cur['pts'] >= $mn_threshold) echo ' <strong style="color:#b5443c;">— over the limit</strong>' ?></span></li>
<?php endforeach; ?>
					</ul>
				</div>
			</fieldset>
		</div>
<?php endif; ?>
		<div class="inform">
			<fieldset>
				<legend>Maintenance</legend>
				<div class="infldset">
					<p>Deleting a member does not remove their entries. Purging clears entries for deleted members.</p>
					<p><input type="submit" name="purge_modnotes" value="Purge orphaned entries" /></p>
					<p class="topspace">To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the mod_notes table and all of this plugin's settings.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently deletes every note and warning</label></p>
					<p><input type="submit" name="nuke_modnotes" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
