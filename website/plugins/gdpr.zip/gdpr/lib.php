<?php

/**
 * Data Export & Anonymise - shared library.
 *
 * Schema (an audit log), the export gatherer (returns a structured array
 * of everything the board holds on a member), and the anonymiser (scrubs
 * the account in place while keeping their posts). Kept free of page
 * concerns so both the standalone export endpoint and the admin page use
 * the same code.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


//
// Create the gdpr_log audit table on first use. Guarded by the
// o_gdpr_db_rev config key so the check is free on every later request.
//
function evebb_gdpr_ensure_schema()
{
	global $db, $pun_config;

	if (isset($pun_config['o_gdpr_db_rev']))
		return;

	if (!$db->table_exists('gdpr_log'))
	{
		$schema = array(
			'FIELDS' => array(
				'id' => array(
					'datatype'   => 'SERIAL',
					'allow_null' => false
				),
				'action' => array(
					'datatype'   => 'VARCHAR(20)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'subject_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'subject_name' => array(
					'datatype'   => 'VARCHAR(200)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'admin_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'admin_name' => array(
					'datatype'   => 'VARCHAR(200)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'created_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('id')
		);

		$db->create_table('gdpr_log', $schema) or error('Unable to create the gdpr_log table', __FILE__, __LINE__, $db->error());
	}

	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_gdpr_db_rev\', \'1\')');
	$pun_config['o_gdpr_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Read/write plugin config
//
function evebb_gdpr_conf($name, $default)
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}

function evebb_gdpr_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


//
// Is the current user staff (administrator or a global moderator)?
//
function evebb_gdpr_is_staff()
{
	global $pun_user;

	return !$pun_user['is_guest']
		&& ((int) $pun_user['g_id'] == PUN_ADMIN || $pun_user['g_moderator'] == '1');
}


//
// Fetch a member row (or null). Used by both endpoint and admin page.
//
function evebb_gdpr_user($user_id)
{
	global $db;

	$result = $db->query('SELECT u.*, g.g_title, g.g_id, g.g_moderator FROM '.$db->prefix.'users AS u INNER JOIN '.$db->prefix.'groups AS g ON g.g_id=u.group_id WHERE u.id='.(int) $user_id.' AND u.id>1') or error('Unable to fetch member', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? $db->fetch_assoc($result) : null;
}

function evebb_gdpr_user_by_name($username)
{
	global $db;

	$username = pun_trim((string) $username);
	if ($username === '')
		return null;

	$result = $db->query('SELECT id FROM '.$db->prefix.'users WHERE id>1 AND username=\''.$db->escape($username).'\'') or error('Unable to fetch member', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? evebb_gdpr_user((int) $db->result($result)) : null;
}


//
// Gather everything the board holds on a member, as a structured array.
// Secrets (password, activation keys) are never included.
//
function evebb_gdpr_gather($user_id)
{
	global $db, $pun_config;

	$user = evebb_gdpr_user($user_id);
	if ($user === null)
		return null;

	// Account: every users column that is personal data, human-labelled.
	// Excludes password / activate_string / activate_key (secrets).
	$account = array();
	$fields = array(
		'id' => 'User ID', 'username' => 'Username', 'email' => 'Email',
		'title' => 'Custom title', 'realname' => 'Real name', 'url' => 'Website',
		'discord' => 'Discord', 'telegram' => 'Telegram', 'signal_id' => 'Signal',
		'twitter' => 'Twitter', 'mastodon' => 'Mastodon', 'bluesky' => 'Bluesky',
		'location' => 'Location', 'country' => 'Country', 'birthday' => 'Birthday',
		'signature' => 'Signature', 'g_title' => 'Group', 'num_posts' => 'Post count',
		'registration_ip' => 'Registration IP', 'language' => 'Language',
		'style' => 'Style', 'timezone' => 'Timezone'
	);
	foreach ($fields as $key => $label)
		$account[$label] = isset($user[$key]) ? (string) $user[$key] : '';

	$account['Registered'] = ((int) $user['registered'] > 0) ? gmdate('Y-m-d H:i:s', $user['registered']).' UTC' : '';
	$account['Last visit'] = ((int) $user['last_visit'] > 0) ? gmdate('Y-m-d H:i:s', $user['last_visit']).' UTC' : '';

	// Posts (their content - portability)
	$posts = array();
	$result = $db->query('SELECT p.id, p.message, p.posted, p.edited, p.poster_ip, t.id AS topic_id, t.subject, f.forum_name FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id WHERE p.poster_id='.(int) $user_id.' ORDER BY p.posted') or error('Unable to fetch posts', __FILE__, __LINE__, $db->error());
	while ($row = $db->fetch_assoc($result))
		$posts[] = array(
			'id'      => (int) $row['id'],
			'forum'   => $row['forum_name'],
			'topic'   => $row['subject'],
			'topic_id' => (int) $row['topic_id'],
			'posted'  => gmdate('Y-m-d H:i:s', $row['posted']).' UTC',
			'edited'  => ((int) $row['edited'] > 0) ? gmdate('Y-m-d H:i:s', $row['edited']).' UTC' : '',
			'ip'      => (string) $row['poster_ip'],
			'message' => $row['message']
		);

	// Topics they started (by their username string)
	$topics = array();
	$result = $db->query('SELECT t.id, t.subject, t.posted, t.num_replies, f.forum_name FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id WHERE t.poster=\''.$db->escape($user['username']).'\' ORDER BY t.posted') or error('Unable to fetch topics', __FILE__, __LINE__, $db->error());
	while ($row = $db->fetch_assoc($result))
		$topics[] = array(
			'id'      => (int) $row['id'],
			'subject' => $row['subject'],
			'forum'   => $row['forum_name'],
			'posted'  => gmdate('Y-m-d H:i:s', $row['posted']).' UTC',
			'replies' => (int) $row['num_replies']
		);

	// Subscriptions
	$sub_topics = array();
	$result = $db->query('SELECT t.id, t.subject FROM '.$db->prefix.'topic_subscriptions AS s INNER JOIN '.$db->prefix.'topics AS t ON t.id=s.topic_id WHERE s.user_id='.(int) $user_id) or error('Unable to fetch topic subscriptions', __FILE__, __LINE__, $db->error());
	while ($row = $db->fetch_assoc($result))
		$sub_topics[] = array('id' => (int) $row['id'], 'subject' => $row['subject']);

	$sub_forums = array();
	if ($db->table_exists('forum_subscriptions'))
	{
		$result = $db->query('SELECT f.id, f.forum_name FROM '.$db->prefix.'forum_subscriptions AS s INNER JOIN '.$db->prefix.'forums AS f ON f.id=s.forum_id WHERE s.user_id='.(int) $user_id) or error('Unable to fetch forum subscriptions', __FILE__, __LINE__, $db->error());
		while ($row = $db->fetch_assoc($result))
			$sub_forums[] = array('id' => (int) $row['id'], 'name' => $row['forum_name']);
	}

	// Warnings the member has received (from the modnotes plugin, if
	// present). Private staff NOTES are never included.
	$warnings = array();
	if ($db->table_exists('mod_notes'))
	{
		$result = $db->query('SELECT body, points, expires_at, created_at FROM '.$db->prefix.'mod_notes WHERE user_id='.(int) $user_id.' AND kind=\'warning\' ORDER BY created_at') or error('Unable to fetch warnings', __FILE__, __LINE__, $db->error());
		while ($row = $db->fetch_assoc($result))
			$warnings[] = array(
				'body'    => $row['body'],
				'points'  => (int) $row['points'],
				'issued'  => gmdate('Y-m-d H:i:s', $row['created_at']).' UTC',
				'expires' => ((int) $row['expires_at'] > 0) ? gmdate('Y-m-d H:i:s', $row['expires_at']).' UTC' : 'never'
			);
	}

	// Bans on record for this username
	$bans = array();
	$result = $db->query('SELECT message, expire FROM '.$db->prefix.'bans WHERE username=\''.$db->escape($user['username']).'\'') or error('Unable to fetch bans', __FILE__, __LINE__, $db->error());
	while ($row = $db->fetch_assoc($result))
		$bans[] = array(
			'reason'  => (string) $row['message'],
			'expires' => ((int) $row['expire'] > 0) ? gmdate('Y-m-d H:i:s', $row['expire']).' UTC' : 'never'
		);

	return array(
		'meta' => array(
			'board'       => $pun_config['o_board_title'],
			'exported_at' => gmdate('Y-m-d H:i:s').' UTC',
			'subject'     => $user['username'],
			'subject_id'  => (int) $user_id,
			'note'        => 'This file contains the personal data '.$pun_config['o_board_title'].' holds about this account. Passwords and security secrets are never included.'
		),
		'account'       => $account,
		'posts'         => $posts,
		'topics_started' => $topics,
		'subscriptions' => array('topics' => $sub_topics, 'forums' => $sub_forums),
		'warnings'      => $warnings,
		'bans'          => $bans
	);
}


//
// Render a gathered-data array as a readable HTML document
//
function evebb_gdpr_html($data)
{
	$h = function ($s) { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); };

	$out = '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8" />'
		.'<meta name="viewport" content="width=device-width, initial-scale=1" />'
		.'<title>'.$h('Your data — '.$data['meta']['board']).'</title>'
		.'<style>body{font:15px/1.5 system-ui,Segoe UI,Arial,sans-serif;max-width:52em;margin:2em auto;padding:0 1em;color:#222}'
		.'h1{font-size:1.5em}h2{font-size:1.2em;margin-top:1.6em;border-bottom:1px solid #ddd;padding-bottom:.2em}'
		.'table{border-collapse:collapse;width:100%}th,td{text-align:left;vertical-align:top;padding:.35em .6em;border-bottom:1px solid #eee}'
		.'th{width:12em;color:#555;font-weight:600}.post{border:1px solid #e5e5e5;border-radius:5px;padding:.6em .8em;margin:.6em 0}'
		.'.post .meta{color:#666;font-size:.9em;margin-bottom:.3em}.post .body{white-space:pre-wrap}'
		.'.muted{color:#777}</style></head><body>';

	$out .= '<h1>'.$h('Your data on '.$data['meta']['board']).'</h1>';
	$out .= '<p class="muted">'.$h($data['meta']['note']).'<br>Exported '.$h($data['meta']['exported_at']).'.</p>';

	$out .= '<h2>Account</h2><table>';
	foreach ($data['account'] as $label => $value)
		$out .= '<tr><th>'.$h($label).'</th><td>'.($value === '' ? '<span class="muted">—</span>' : $h($value)).'</td></tr>';
	$out .= '</table>';

	$out .= '<h2>Posts ('.count($data['posts']).')</h2>';
	if (empty($data['posts']))
		$out .= '<p class="muted">None.</p>';
	foreach ($data['posts'] as $p)
		$out .= '<div class="post"><div class="meta">'.$h($p['forum'].' › '.$p['topic'].' — '.$p['posted'].($p['edited'] ? ' (edited '.$p['edited'].')' : '').($p['ip'] ? ' — IP '.$p['ip'] : '')).'</div><div class="body">'.$h($p['message']).'</div></div>';

	$out .= '<h2>Topics started ('.count($data['topics_started']).')</h2>';
	if (empty($data['topics_started']))
		$out .= '<p class="muted">None.</p>';
	else
	{
		$out .= '<ul>';
		foreach ($data['topics_started'] as $t)
			$out .= '<li>'.$h($t['subject']).' <span class="muted">('.$h($t['forum'].', '.$t['posted'].', '.$t['replies'].' replies').')</span></li>';
		$out .= '</ul>';
	}

	$out .= '<h2>Subscriptions</h2><p><strong>Topics:</strong> ';
	$out .= empty($data['subscriptions']['topics']) ? '<span class="muted">none</span>' : $h(implode('; ', array_map(function ($t) { return $t['subject']; }, $data['subscriptions']['topics'])));
	$out .= '</p><p><strong>Forums:</strong> ';
	$out .= empty($data['subscriptions']['forums']) ? '<span class="muted">none</span>' : $h(implode('; ', array_map(function ($f) { return $f['name']; }, $data['subscriptions']['forums'])));
	$out .= '</p>';

	if (!empty($data['warnings']))
	{
		$out .= '<h2>Warnings ('.count($data['warnings']).')</h2><ul>';
		foreach ($data['warnings'] as $w)
			$out .= '<li>'.$h($w['body']).' <span class="muted">('.$h($w['points'].' pts, issued '.$w['issued'].', expires '.$w['expires']).')</span></li>';
		$out .= '</ul>';
	}

	if (!empty($data['bans']))
	{
		$out .= '<h2>Bans ('.count($data['bans']).')</h2><ul>';
		foreach ($data['bans'] as $b)
			$out .= '<li>'.$h(($b['reason'] !== '' ? $b['reason'] : 'no reason recorded').' (expires '.$b['expires'].')').'</li>';
		$out .= '</ul>';
	}

	return $out.'</body></html>';
}


//
// Record an action in the audit log
//
function evebb_gdpr_log($action, $subject_id, $subject_name, $admin_id, $admin_name)
{
	global $db;

	$db->query('INSERT INTO '.$db->prefix.'gdpr_log (action, subject_id, subject_name, admin_id, admin_name, created_at) VALUES(\''.$db->escape($action).'\', '.(int) $subject_id.', \''.$db->escape($subject_name).'\', '.(int) $admin_id.', \''.$db->escape($admin_name).'\', '.time().')') or error('Unable to write the GDPR log', __FILE__, __LINE__, $db->error());
}


//
// Anonymise a member: keep their posts (reattributed to a neutral name)
// but scrub every personal field from the account. Returns the new
// neutral name, or false if the target is not a valid member.
//
function evebb_gdpr_anonymise($user_id)
{
	global $db, $pun_config;

	$user = evebb_gdpr_user($user_id);
	if ($user === null)
		return false;

	$uid = (int) $user_id;
	$old = $user['username'];
	$new = 'former member #'.$uid;

	// A random, unrecoverable password locks the account for good
	if (function_exists('flux_password_hash'))
		$locked = flux_password_hash(bin2hex(random_bytes(20)));
	else
		$locked = sha1(bin2hex(random_bytes(20)));

	// Scrub the account row (all personal fields; secrets blanked)
	$db->query('UPDATE '.$db->prefix.'users SET '
		.'username=\''.$db->escape($new).'\', '
		.'password=\''.$db->escape($locked).'\', '
		.'email=\'\', title=\'\', realname=\'\', url=\'\', '
		.'discord=\'\', telegram=\'\', signal_id=\'\', twitter=\'\', mastodon=\'\', bluesky=\'\', '
		.'location=\'\', country=\'\', birthday=NULL, signature=\'\', '
		.'registration_ip=\'0.0.0.0\', admin_note=\'\', activate_string=\'\', activate_key=\'\' '
		.'WHERE id='.$uid) or error('Unable to scrub the account', __FILE__, __LINE__, $db->error());

	// Reattribute their content (denormalised username strings + IPs)
	$db->query('UPDATE '.$db->prefix.'posts SET poster=\''.$db->escape($new).'\', poster_ip=\'\', poster_email=NULL WHERE poster_id='.$uid) or error('Unable to reattribute posts', __FILE__, __LINE__, $db->error());
	$db->query('UPDATE '.$db->prefix.'posts SET edited_by=\''.$db->escape($new).'\' WHERE edited_by=\''.$db->escape($old).'\'') or error('Unable to reattribute edits', __FILE__, __LINE__, $db->error());
	$db->query('UPDATE '.$db->prefix.'topics SET poster=\''.$db->escape($new).'\' WHERE poster=\''.$db->escape($old).'\'') or error('Unable to reattribute topics', __FILE__, __LINE__, $db->error());
	$db->query('UPDATE '.$db->prefix.'topics SET last_poster=\''.$db->escape($new).'\' WHERE last_poster=\''.$db->escape($old).'\'') or error('Unable to reattribute topic last-posters', __FILE__, __LINE__, $db->error());
	$db->query('UPDATE '.$db->prefix.'forums SET last_poster=\''.$db->escape($new).'\' WHERE last_poster=\''.$db->escape($old).'\'') or error('Unable to reattribute forum last-posters', __FILE__, __LINE__, $db->error());

	// Bans keyed on the username stay effective but lose their PII
	$db->query('UPDATE '.$db->prefix.'bans SET username=\''.$db->escape($new).'\', email=\'\', ip=\'\' WHERE username=\''.$db->escape($old).'\'') or error('Unable to scrub bans', __FILE__, __LINE__, $db->error());

	// Session + interest links (personal, not content)
	$db->query('DELETE FROM '.$db->prefix.'online WHERE user_id='.$uid) or error('Unable to clear online row', __FILE__, __LINE__, $db->error());
	$db->query('DELETE FROM '.$db->prefix.'topic_subscriptions WHERE user_id='.$uid) or error('Unable to clear topic subscriptions', __FILE__, __LINE__, $db->error());
	if ($db->table_exists('forum_subscriptions'))
		$db->query('DELETE FROM '.$db->prefix.'forum_subscriptions WHERE user_id='.$uid) or error('Unable to clear forum subscriptions', __FILE__, __LINE__, $db->error());

	// Two-factor secrets are the person's - remove them if that plugin is
	// installed
	if ($db->table_exists('tfa_users'))
		$db->query('DELETE FROM '.$db->prefix.'tfa_users WHERE user_id='.$uid);
	if ($db->table_exists('tfa_backup'))
		$db->query('DELETE FROM '.$db->prefix.'tfa_backup WHERE user_id='.$uid);

	// Per-forum moderator assignments store usernames in a serialized map
	$result = $db->query('SELECT id, moderators FROM '.$db->prefix.'forums WHERE moderators IS NOT NULL AND moderators<>\'\'') or error('Unable to fetch forum moderators', __FILE__, __LINE__, $db->error());
	while ($row = $db->fetch_assoc($result))
	{
		$mods = @unserialize($row['moderators'], array('allowed_classes' => false));
		if (!is_array($mods) || !array_key_exists($old, $mods))
			continue;
		$mods[$new] = $mods[$old];
		unset($mods[$old]);
		$db->query('UPDATE '.$db->prefix.'forums SET moderators=\''.$db->escape(serialize($mods)).'\' WHERE id='.(int) $row['id']) or error('Unable to update forum moderators', __FILE__, __LINE__, $db->error());
	}

	// Delete their avatar file
	if (function_exists('delete_avatar'))
		delete_avatar($uid);

	// The username strings are cached in various places
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	if (function_exists('generate_users_info_cache'))
		generate_users_info_cache();

	return $new;
}
