# Data Export & Anonymise

An unofficial [eveBB](https://evebb.net) plugin providing the GDPR
essentials: data portability (Article 15/20) and the right to erasure
(Article 17).

## Features

- **Members export their own data** — a "Your data" section on their
  profile downloads a ZIP containing a machine-readable `data.json`
  (portable) and a readable `data.html` copy. It covers the profile,
  every post and topic, subscriptions, warnings and bans. Passwords and
  security secrets are never included.
- **Staff export anyone** — administrators and global moderators can
  export any member's data from the plugin's settings page.
- **Anonymise (right to erasure)** — administrators can scrub an
  account while keeping its posts, so threads stay readable. The person
  is reattributed to a neutral name ("former member #ID") and every
  personal field — email, real name, contact handles (Discord,
  Telegram, Signal, Twitter, Mastodon, Bluesky), location, signature,
  IP addresses, avatar and any two-factor secrets — is permanently
  removed. The account can no longer be logged into.

## Safeguards on anonymise

- Administrators only (not moderators).
- Type the username again to confirm — no accidental erasures.
- Staff accounts (administrators/moderators) are protected by default;
  a deliberate override tick is required to anonymise one.
- Every anonymisation is written to an audit log (who, whom, when).

## Installation

Upload `gdpr.zip` through **Administration → Plugins → Upload plugin**,
then activate it. The plugin creates its audit-log table (`gdpr_log`)
automatically on first use.

## Notes

- Anonymisation is irreversible by design. If the member also wants a
  copy of their data, export it first.
- Posts are kept and reattributed, matching how most forums balance the
  right to erasure against the integrity of public discussions. If you
  need posts deleted too, the core Delete-user tool remains available.
- The plugin is self-contained: removing its data drops only the audit
  log; anonymisations already performed are permanent.

## License

GPL version 2 or higher, like eveBB itself.
