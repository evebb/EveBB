<?php

/**
 * Data Export & Anonymise - the export endpoint.
 *
 *   <board>/plugins/gdpr/export.php?uid=N&csrf_token=...
 *
 * Streams a ZIP containing data.json (machine-readable, for portability)
 * and data.html (a readable copy). A member may export their own account;
 * staff (administrators and global moderators) may export anyone. Guests
 * are refused. A CSRF token is required so the download can't be forced
 * cross-site.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

if (!in_array('gdpr', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

if ($pun_user['is_guest'])
	message($lang_common['No permission'], false, '403 Forbidden');

evebb_gdpr_ensure_schema();

// CSRF: the export links carry the token
$token = isset($_GET['csrf_token']) ? $_GET['csrf_token'] : null;
if (!is_string($token) || !hash_equals(pun_csrf_token(), $token))
	message($lang_common['Bad request'], false, '404 Not Found');

$uid = isset($_GET['uid']) ? (int) $_GET['uid'] : (int) $pun_user['id'];

// Self, or staff exporting anyone
if ($uid !== (int) $pun_user['id'] && !evebb_gdpr_is_staff())
	message($lang_common['No permission'], false, '403 Forbidden');

$data = evebb_gdpr_gather($uid);
if ($data === null)
	message($lang_common['Bad request'], false, '404 Not Found');

$json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
$html = evebb_gdpr_html($data);

// A sanitised filename stem
$stem = 'evebb-data-'.preg_replace('%[^A-Za-z0-9_-]%', '_', $data['meta']['subject']).'-'.gmdate('Ymd');

// The DB work is done; release it before streaming a binary body
$db->end_transaction();
$db->close();

while (ob_get_level() > 0)
	ob_end_clean();

$made = false;
if (class_exists('ZipArchive'))
{
	$tmp = tempnam(sys_get_temp_dir(), 'evebbgdpr');
	$zip = new ZipArchive();
	if ($tmp !== false && $zip->open($tmp, ZipArchive::OVERWRITE) === true)
	{
		$zip->addFromString('data.json', $json);
		$zip->addFromString('data.html', $html);
		$zip->close();

		header('Content-Type: application/zip');
		header('Content-Disposition: attachment; filename="'.$stem.'.zip"');
		header('Content-Length: '.filesize($tmp));
		header('X-Content-Type-Options: nosniff');
		readfile($tmp);
		@unlink($tmp);
		$made = true;
	}
}

// Fallback (no zip extension): a single self-contained HTML file with the
// JSON embedded for machine reading
if (!$made)
{
	$embed = $html.'<script type="application/json" id="evebb-data">'.str_replace('</', '<\/', $json).'</script>';
	header('Content-Type: text/html; charset=utf-8');
	header('Content-Disposition: attachment; filename="'.$stem.'.html"');
	header('X-Content-Type-Options: nosniff');
	echo $embed;
}

exit;
