<?php

/**
 * Data Export & Anonymise - settings / operations page.
 *
 * Admin-only (the plugin manager is administrator-only). Staff export any
 * member's data, and administrators anonymise an account with a
 * type-to-confirm safeguard, staff-account protection and an audit log.
 *
 * $db, $pun_config, $pun_user and $plugin_slug are available here.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

evebb_gdpr_ensure_schema();

$gdpr_back = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

// Export a member's data (redirect to the streaming endpoint)
if (isset($_POST['gdpr_export']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$user = evebb_gdpr_user_by_name($_POST['gdpr_export_user'] ?? '');
	if ($user === null)
		redirect($gdpr_back, 'No member with that exact username. Redirecting …');

	redirect(get_base_url(true).'/plugins/gdpr/export.php?uid='.(int) $user['id'].'&csrf_token='.urlencode(pun_csrf_token()), 'Preparing the export. Redirecting …');
}

// Anonymise a member
if (isset($_POST['gdpr_anonymise']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	// Administrators only (heavier than a warning)
	if ((int) $pun_user['g_id'] != PUN_ADMIN)
		redirect($gdpr_back, 'Only administrators can anonymise an account. Redirecting …');

	$name = pun_trim($_POST['gdpr_anon_user'] ?? '');
	$confirm = pun_trim($_POST['gdpr_anon_confirm'] ?? '');
	$user = evebb_gdpr_user_by_name($name);

	if ($user === null)
		redirect($gdpr_back, 'No member with that exact username. Redirecting …');

	if ($confirm !== $name)
		redirect($gdpr_back, 'The confirmation did not match the username exactly — nothing was changed. Redirecting …');

	if ((int) $user['id'] == (int) $pun_user['id'])
		redirect($gdpr_back, 'You cannot anonymise your own account from here. Redirecting …');

	// Staff-account protection: refuse admins/global mods unless overridden
	$is_staff_target = ((int) $user['g_id'] == PUN_ADMIN || $user['g_moderator'] == '1');
	if ($is_staff_target && !isset($_POST['gdpr_anon_staff']))
		redirect($gdpr_back, 'That account is an administrator or moderator. Tick the staff-override box if you really mean to anonymise it. Redirecting …');

	$subject_name = $user['username'];
	$subject_id = (int) $user['id'];

	$new = evebb_gdpr_anonymise($subject_id);
	if ($new === false)
		redirect($gdpr_back, 'Could not anonymise that account. Redirecting …');

	evebb_gdpr_log('anonymise', $subject_id, $subject_name, (int) $pun_user['id'], $pun_user['username']);

	redirect($gdpr_back, 'Account anonymised: "'.pun_htmlspecialchars($subject_name).'" is now "'.pun_htmlspecialchars($new).'". Their posts remain; all personal data has been scrubbed. Redirecting …');
}

// Clear the audit log
if (isset($_POST['gdpr_clearlog']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DELETE FROM '.$db->prefix.'gdpr_log') or error('Unable to clear the log', __FILE__, __LINE__, $db->error());

	redirect($gdpr_back, 'Audit log cleared. Redirecting …');
}

// Remove ALL plugin data (before uninstalling)
if (isset($_POST['nuke_gdpr']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect($gdpr_back, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('gdpr_log');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name=\'o_gdpr_db_rev\'') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());

	unset($pun_config['o_gdpr_db_rev']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Data Export & Anonymise data removed (anonymisations already performed are permanent). You can now deactivate and delete the plugin. Redirecting …');
}

$is_admin = ((int) $pun_user['g_id'] == PUN_ADMIN);

// Recent log entries
$log = array();
$result = $db->query('SELECT action, subject_name, admin_name, created_at FROM '.$db->prefix.'gdpr_log ORDER BY created_at DESC, id DESC LIMIT 30') or error('Unable to fetch the log', __FILE__, __LINE__, $db->error());
while ($row = $db->fetch_assoc($result))
	$log[] = $row;

?>
		<div class="inform">
			<fieldset>
				<legend>Export a member's data</legend>
				<div class="infldset">
					<p>Download everything the board holds on a member (their profile, posts, topics, subscriptions, warnings and bans) as a ZIP containing a machine-readable JSON file and a readable HTML copy. Members can also export their own data from their profile.</p>
					<p>Member <input type="text" name="gdpr_export_user" size="20" maxlength="25" /> <input type="submit" name="gdpr_export" value="Export data" /> <em>(exact username)</em></p>
				</div>
			</fieldset>
		</div>
<?php if ($is_admin): ?>
		<div class="inform">
			<fieldset>
				<legend>Anonymise a member (right to erasure)</legend>
				<div class="infldset">
					<p><strong>This cannot be undone.</strong> The member's posts stay so threads remain readable, but they are reattributed to a neutral name (&quot;former member #ID&quot;) and every personal field on the account — email, real name, contact handles, location, signature, IP addresses, avatar and any two-factor secrets — is permanently scrubbed. The account can no longer be logged into.</p>
					<p>Consider exporting the member's data first (above) if they have also asked for a copy.</p>
					<p>Member to anonymise <input type="text" name="gdpr_anon_user" size="20" maxlength="25" /></p>
					<p>Type the username again to confirm <input type="text" name="gdpr_anon_confirm" size="20" maxlength="25" /></p>
					<p><label><input type="checkbox" name="gdpr_anon_staff" value="1" /> Yes, even if this is a staff account (administrators/moderators are protected by default)</label></p>
					<p><input type="submit" name="gdpr_anonymise" value="Anonymise this account" /></p>
				</div>
			</fieldset>
		</div>
<?php else: ?>
		<div class="inform">
			<fieldset>
				<legend>Anonymise a member (right to erasure)</legend>
				<div class="infldset">
					<p>Only administrators can anonymise an account.</p>
				</div>
			</fieldset>
		</div>
<?php endif; ?>
		<div class="inform">
			<fieldset>
				<legend>Audit log</legend>
				<div class="infldset">
<?php if (empty($log)): ?>
					<p>No erasures recorded yet.</p>
<?php else: ?>
					<table>
						<tr><th scope="col">When</th><th scope="col">Action</th><th scope="col">Member</th><th scope="col">By</th></tr>
<?php foreach ($log as $row): ?>
						<tr><td><?php echo format_time($row['created_at']) ?></td><td><?php echo pun_htmlspecialchars($row['action']) ?></td><td><?php echo pun_htmlspecialchars($row['subject_name']) ?></td><td><?php echo pun_htmlspecialchars($row['admin_name']) ?></td></tr>
<?php endforeach; ?>
					</table>
					<p class="topspace"><input type="submit" name="gdpr_clearlog" value="Clear the audit log" /></p>
<?php endif; ?>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Maintenance</legend>
				<div class="infldset">
					<p>To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the audit-log table. Anonymisations already performed are permanent and are not affected.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this removes the audit log</label></p>
					<p><input type="submit" name="nuke_gdpr" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
