<?php

/**
 * Data Export & Anonymise - the addon.
 *
 * Adds a "Your data" section to the member's own Essentials profile page
 * with a one-click download of everything the board holds on them. Staff
 * export and account anonymisation live on the plugin's admin settings
 * page (admins only, deliberate). Built as a native profile section (the
 * inform>fieldset>legend pattern), inserted by JS driven by a per-viewer
 * config blob.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_gdpr extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		evebb_gdpr_ensure_schema();

		$page = isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : '';
		if ($page != 'profile.php')
			return;

		global $id, $pun_user;

		if ($pun_user['is_guest'] || !isset($id) || (int) $id != (int) $pun_user['id'])
			return;

		$section = isset($_GET['section']) ? (string) $_GET['section'] : 'essentials';
		if ($section !== 'essentials' && $section !== '')
			return;

		$this->emit(array(
			'url'  => 'plugins/gdpr/export.php?uid='.(int) $pun_user['id'].'&csrf_token='.urlencode(pun_csrf_token()),
			'text' => array(
				'title' => 'Your data',
				'blurb' => 'Download a copy of everything this board holds about your account, as a machine-readable JSON file plus a readable HTML copy (in a ZIP). This covers your profile, posts, topics, subscriptions and any warnings.',
				'button' => 'Download my data'
			)
		));
	}

	function emit($cfg)
	{
		$json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES);

		echo '<style>#gdprbox .infldset p{margin:.5em 0}</style>'."\n";

		echo '<script>/* Data Export & Anonymise plugin */'."\n".'(function(){'."\n"
			.'var cfg = '.$json.';'."\n"
			.<<<'EOJS'
function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

ready(function () {
	var bf = document.querySelector('div.blockform');
	var box = bf ? bf.querySelector('.box') : null;
	if (!box) return;

	var inform = document.createElement('div');
	inform.className = 'inform';
	inform.id = 'gdprbox';
	var fs = document.createElement('fieldset');
	var lg = document.createElement('legend');
	lg.textContent = cfg.text.title;
	fs.appendChild(lg);
	var fld = document.createElement('div');
	fld.className = 'infldset';

	var p = document.createElement('p');
	p.textContent = cfg.text.blurb;
	fld.appendChild(p);

	var pp = document.createElement('p');
	var a = document.createElement('a');
	a.href = cfg.url;
	a.textContent = cfg.text.button;
	// Render as a button-ish link
	a.style.display = 'inline-block';
	a.style.padding = '.4em 1em';
	a.style.border = '1px solid #888';
	a.style.borderRadius = '4px';
	a.style.textDecoration = 'none';
	pp.appendChild(a);
	fld.appendChild(pp);

	fs.appendChild(fld);
	inform.appendChild(fs);
	box.appendChild(inform);
});
EOJS
			."\n".'})();</script>'."\n";
	}
}
