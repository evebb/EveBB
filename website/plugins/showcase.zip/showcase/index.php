<?php

/**
 * Showcase Directory - the gallery page.
 *
 * Standalone page rendered inside the full forum chrome (same pattern
 * as eveauth's sso.php: relative asset/nav URLs are absolutized on the
 * way out because this file lives under plugins/).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

//
// Absolutize relative href/src so forum chrome works from /plugins/showcase/
//
function showcase_absolutize($html)
{
	$base = get_base_url().'/';

	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('showcase_absolutize');

if (!in_array('showcase', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

$sections = showcase_sections();

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), 'Showcase');
define('PUN_ACTIVE_PAGE', 'index');
define('PUN_ALLOW_INDEX', 1);
require PUN_ROOT.'header.php';

?>
<style>
.showcase-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 14px; padding: 6px 0; }
.showcase-card { border: 1px solid rgba(128,128,128,.35); border-radius: 5px; overflow: hidden; display: flex; flex-direction: column; background: rgba(128,128,128,.06); }
.showcase-thumb { aspect-ratio: 16/9; background: linear-gradient(135deg, rgba(230,115,0,.25), rgba(51,55,59,.4)) center/cover no-repeat; display: flex; align-items: center; justify-content: center; font-size: 34px; font-weight: bold; opacity: .95; }
.showcase-body { padding: 10px 12px 12px; display: flex; flex-direction: column; flex: 1; }
.showcase-body h4 { margin: 0 0 6px; font-size: 14px; }
.showcase-body p.sc-excerpt { font-size: 12px; margin: 0 0 8px; flex: 1; }
.showcase-body p.sc-meta { font-size: 11px; opacity: .75; margin: 0 0 10px; }
.showcase-actions a.sc-dl { display: inline-block; padding: 5px 12px; background: #e67300; color: #fff; border-radius: 3px; font-weight: bold; font-size: 12px; text-decoration: none; }
.showcase-actions a.sc-topic { font-size: 12px; margin-left: 10px; }
</style>
<div class="block">
	<h2><span>Showcase</span></h2>
	<div class="box">
		<div class="inbox">
<?php

if (empty($sections))
{
	if (empty(showcase_forum_ids()))
		echo "\t\t\t".'<p>The showcase has not been configured yet — an administrator needs to map one or more forums on the plugin settings page.</p>'."\n";
	else
		echo "\t\t\t".'<p>Nothing to show yet — releases appear here automatically once topics with download links are posted.</p>'."\n";
}

foreach ($sections as $section)
{
	echo "\t\t\t".'<h3 style="margin: 12px 0 2px;">'.pun_htmlspecialchars($section['forum_name']).' <span style="font-weight: normal; font-size: 12px; opacity: .7;">(<a href="'.get_base_url().'/viewforum.php?id='.$section['forum_id'].'">forum</a>)</span></h3>'."\n";
	echo "\t\t\t".'<div class="showcase-grid">'."\n";

	foreach ($section['entries'] as $entry)
	{
		$topic_url = get_base_url().'/viewtopic.php?id='.$entry['topic_id'];

		echo "\t\t\t\t".'<div class="showcase-card">'."\n";
		if ($entry['thumb'] !== null)
			echo "\t\t\t\t\t".'<a href="'.pun_htmlspecialchars($topic_url).'"><div class="showcase-thumb" style="background-image: url('.pun_htmlspecialchars($entry['thumb']).')"></div></a>'."\n";
		else
			echo "\t\t\t\t\t".'<a href="'.pun_htmlspecialchars($topic_url).'" style="text-decoration: none;"><div class="showcase-thumb">'.pun_htmlspecialchars(utf8_substr(pun_trim($entry['subject']), 0, 1)).'</div></a>'."\n";
		echo "\t\t\t\t\t".'<div class="showcase-body">'."\n";
		echo "\t\t\t\t\t\t".'<h4><a href="'.pun_htmlspecialchars($topic_url).'">'.pun_htmlspecialchars($entry['subject']).'</a></h4>'."\n";
		if ($entry['excerpt'] != '')
			echo "\t\t\t\t\t\t".'<p class="sc-excerpt">'.pun_htmlspecialchars($entry['excerpt']).'</p>'."\n";
		echo "\t\t\t\t\t\t".'<p class="sc-meta">'.pun_htmlspecialchars($entry['poster']).' &middot; '.format_time($entry['posted'], true).' &middot; '.forum_number_format($entry['replies']).' '.($entry['replies'] == 1 ? 'reply' : 'replies').'</p>'."\n";
		echo "\t\t\t\t\t\t".'<p class="showcase-actions"><a class="sc-dl" href="'.pun_htmlspecialchars($entry['download']).'">Download</a><a class="sc-topic" href="'.pun_htmlspecialchars($topic_url).'">Discussion &raquo;</a></p>'."\n";
		echo "\t\t\t\t\t".'</div>'."\n";
		echo "\t\t\t\t".'</div>'."\n";
	}

	echo "\t\t\t".'</div>'."\n";
}

?>
		</div>
	</div>
</div>
<?php

require PUN_ROOT.'footer.php';
