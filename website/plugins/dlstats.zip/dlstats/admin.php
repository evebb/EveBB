<?php

/**
 * Download Statistics - settings + full breakdown.
 *
 * Included by admin_plugins.php inside the admin chrome and inside a
 * single POST form (footer.php injects the CSRF token). $db, $pun_config
 * and $plugin_slug are available.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

evebb_dlstats_bootstrap();

$redir = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

if (isset($_POST['save_dlstats']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$repo = pun_trim($_POST['ds_repo'] ?? '');
	if ($repo === '' || preg_match('%^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$%', $repo))
		evebb_dlstats_save_conf('o_dlstats_repo', $repo);

	$ttl = isset($_POST['ds_ttl']) ? (int) $_POST['ds_ttl'] : 3600;
	if ($ttl < 300) $ttl = 300;
	if ($ttl > 86400) $ttl = 86400;
	evebb_dlstats_save_conf('o_dlstats_ttl', (string) $ttl);

	$dir = pun_trim($_POST['ds_dir'] ?? 'downloads');
	evebb_dlstats_save_conf('o_dlstats_dir', $dir);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect($redir, 'Settings saved. Redirecting ...');
}

if (isset($_POST['refresh_dlstats']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	evebb_dlstats_github_summary(true);
	redirect($redir, 'Release counts refreshed. Redirecting ...');
}

if (isset($_POST['nuke_dlstats']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	evebb_dlstats_nuke();
	redirect('admin_plugins.php', 'Download Statistics removed. Redirecting ...');
}

$gh = evebb_dlstats_github_summary();
$local = evebb_dlstats_local_top(100);
list($local_files, $local_hits) = evebb_dlstats_local_total();

$base_url = function_exists('get_base_url') ? get_base_url(true) : '';

?>
<div class="blockform">
	<h2><span>Download Statistics</span></h2>

	<div class="box">
		<div class="inform">
			<fieldset>
				<legend>Release packages (GitHub)</legend>
				<div class="infldset">
<?php if (pun_trim($pun_config['o_dlstats_repo'] ?? '') === ''): ?>
					<p>No repository configured. Enter your project's <code>owner/name</code> in the settings below to count its release downloads here.</p>
<?php else: ?>
					<p><strong><?php echo number_format($gh['total']) ?></strong> total zip downloads across all releases<?php if ($gh['error']): ?> <em>(the releases feed could not be refreshed; showing the last good numbers)</em><?php endif; ?>. Counts include boards updating themselves and one-click/cloud installs, since both pull the same release assets. Last refreshed: <?php echo format_time($gh['fetched']) ?>.</p>
<?php if (!empty($gh['releases'])): ?>
					<table>
						<thead><tr><th class="tcl" scope="col">Release</th><th class="tc2" scope="col">Type</th><th class="tcr" scope="col">Zip downloads</th></tr></thead>
						<tbody>
<?php foreach ($gh['releases'] as $r): ?>
							<tr><td class="tcl"><?php echo pun_htmlspecialchars($r['tag']) ?></td><td class="tc2"><?php echo $r['prerelease'] ? 'pre-release' : 'stable' ?></td><td class="tcr"><?php echo number_format($r['count']) ?></td></tr>
<?php endforeach; ?>
						</tbody>
					</table>
<?php endif; ?>
					<input type="submit" name="refresh_dlstats" value="Refresh now" />
<?php endif; ?>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Files on this site</legend>
				<div class="infldset">
					<p><strong><?php echo number_format($local_hits) ?></strong> downloads across <strong><?php echo number_format($local_files) ?></strong> files, counted by the bundled endpoint.</p>
<?php if (!empty($local)): ?>
					<table>
						<thead><tr><th class="tcl" scope="col">File</th><th class="tc2" scope="col">Downloads</th><th class="tcr" scope="col">Last download</th></tr></thead>
						<tbody>
<?php foreach ($local as $row): ?>
							<tr><td class="tcl"><?php echo pun_htmlspecialchars($row['file']) ?></td><td class="tc2"><?php echo number_format($row['hits']) ?></td><td class="tcr"><?php echo format_time($row['last_hit']) ?></td></tr>
<?php endforeach; ?>
						</tbody>
					</table>
<?php else: ?>
					<p>No hits recorded yet. Route your downloads directory through the counter to start counting - existing links keep working:</p>
<?php endif; ?>
					<p>Put this in an <code>.htaccess</code> file inside your downloads directory (Apache):</p>
					<p><code>RewriteEngine On<br />RewriteCond %{REQUEST_FILENAME} -f<br />RewriteRule ^(.+\.zip)$ <?php echo pun_htmlspecialchars($base_url) ?>/plugins/dlstats/count.php?f=$1 [L]</code></p>
					<p>Or link directly to <code><?php echo pun_htmlspecialchars($base_url) ?>/plugins/dlstats/count.php?f=plugins/example.zip</code> (paths are relative to the configured directory below).</p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Settings</legend>
				<div class="infldset">
					<table class="aligntop">
						<tr>
							<th scope="row">GitHub repository</th>
							<td>
								<input type="text" name="ds_repo" size="35" maxlength="100" value="<?php echo pun_htmlspecialchars($pun_config['o_dlstats_repo'] ?? '') ?>" />
								<span>owner/name, e.g. evebb/EveBB. Blank disables the release counts.</span>
							</td>
						</tr>
						<tr>
							<th scope="row">Refresh interval</th>
							<td>
								<input type="text" name="ds_ttl" size="8" maxlength="6" value="<?php echo pun_htmlspecialchars($pun_config['o_dlstats_ttl'] ?? '3600') ?>" />
								<span>Seconds between releases-feed refreshes (300-86400). Keeps well inside GitHub's rate limits.</span>
							</td>
						</tr>
						<tr>
							<th scope="row">Downloads directory</th>
							<td>
								<input type="text" name="ds_dir" size="35" maxlength="200" value="<?php echo pun_htmlspecialchars($pun_config['o_dlstats_dir'] ?? 'downloads') ?>" />
								<span>Where the counter finds your zips. Relative paths are from the forum root (e.g. <code>downloads</code>); absolute paths work too.</span>
							</td>
						</tr>
					</table>
					<input type="submit" name="save_dlstats" value="Save settings" />
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Remove</legend>
				<div class="infldset">
					<p>Removes the tables, counters and settings. Counted totals are lost.</p>
					<input type="submit" name="nuke_dlstats" value="Remove all Download Statistics data" onclick="return confirm('Delete all download statistics? The counts cannot be recovered.')" />
				</div>
			</fieldset>
		</div>
	</div>
</div>
