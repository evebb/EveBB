# Download Statistics for eveBB

See how often your software is downloaded, at a glance, on the admin
index page - and in full on the plugin's settings page.

Two sources, combined:

- **Release packages (GitHub)**: zip download counts for every release of
  a configurable repository (default: eveBB's own), fetched from the
  GitHub releases API and cached. These counts include boards updating
  themselves through the in-app updater and one-click/cloud-init installs,
  because they download the same assets - so the trend doubles as a rough
  census of active boards.
- **Files on this site**: exact hit counts for zips you host yourself
  (e.g. `/downloads/plugins/*.zip`), recorded by the bundled
  `count.php` endpoint.

## Install

Upload the zip in Administration -> Plugins, activate. Administrators
see two new "Downloads" rows in the stats box on the admin index page.

## Counting your own hosted files

Published links don't have to change. Put this `.htaccess` in your
downloads directory (Apache):

    RewriteEngine On
    RewriteCond %{REQUEST_FILENAME} -f
    RewriteRule ^(.+\.zip)$ /plugins/dlstats/count.php?f=$1 [L]

Every existing link to a `.zip` in that directory now routes through the
counter, which records the hit and streams the file. Alternatively, link
new downloads directly to `count.php?f=<relative path>`.

The endpoint validates paths strictly (zips only, no traversal, resolved
inside the configured directory) and is safe to expose publicly.

## Settings

- **GitHub repository** - `owner/name` whose releases to count. Any
  project that publishes releases on GitHub works; blank disables it.
- **Refresh interval** - how often the releases feed is re-fetched
  (default hourly; cached in between, well inside API rate limits).
- **Downloads directory** - where `count.php` finds your files, relative
  to the forum root or absolute.

## Notes

- Marketplace platforms that deploy from a baked image (for example a
  DigitalOcean 1-Click droplet) don't download anything at deploy time,
  so those numbers live in the platform's own vendor dashboard - but the
  *image build* and every subsequent board update do show up in the
  GitHub counts.
- Nothing personal is recorded: no IPs, no user agents - a filename, a
  counter and a timestamp.

License: GPL v2 or later.
