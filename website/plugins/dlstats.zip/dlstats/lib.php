<?php

/**
 * Download Statistics - shared library.
 *
 * Two data sources:
 *  - GitHub release assets: fetched from the releases API (same transport
 *    the core updater uses), cached in a small table so the API is hit at
 *    most once per TTL. Includes downloads made by the in-app updater and
 *    by one-click/cloud-init installs, since those pull the same assets.
 *  - Local files: exact hit counts recorded by count.php for zips served
 *    from this site (e.g. /downloads/plugins/*.zip routed through it).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

define('EVEBB_DLSTATS_DB_REV', 1);

//
// Bootstrap: config keys + tables, guarded by a db_rev config row
//
function evebb_dlstats_bootstrap()
{
	global $db, $pun_config;

	if (isset($pun_config['o_dlstats_db_rev']) && (int) $pun_config['o_dlstats_db_rev'] >= EVEBB_DLSTATS_DB_REV)
		return;

	// Local hit counters
	if (!$db->table_exists('dlstats_hits'))
	{
		$schema = array(
			'FIELDS' => array(
				'file'     => array('datatype' => 'VARCHAR(255)', 'allow_null' => false, 'default' => '\'\''),
				'hits'     => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'last_hit' => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
			),
			'PRIMARY KEY' => array('file'),
		);
		$db->create_table('dlstats_hits', $schema);
	}

	// Tiny cache store (GitHub summary JSON)
	if (!$db->table_exists('dlstats_cache'))
	{
		$schema = array(
			'FIELDS' => array(
				'k'  => array('datatype' => 'VARCHAR(50)', 'allow_null' => false, 'default' => '\'\''),
				'v'  => array('datatype' => 'TEXT', 'allow_null' => true),
				'ts' => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
			),
			'PRIMARY KEY' => array('k'),
		);
		$db->create_table('dlstats_cache', $schema);
	}

	$defaults = array(
		'o_dlstats_repo' => 'evebb/EveBB',
		'o_dlstats_ttl'  => '3600',
		'o_dlstats_dir'  => 'downloads',
		'o_dlstats_db_rev' => (string) EVEBB_DLSTATS_DB_REV,
	);
	foreach ($defaults as $k => $v)
	{
		if (!isset($pun_config[$k]))
		{
			$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($k).'\', \''.$db->escape($v).'\')')
				or error('Unable to insert config', __FILE__, __LINE__, $db->error());
			$pun_config[$k] = $v;
		}
	}

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}

function evebb_dlstats_save_conf($name, $value)
{
	global $db;
	$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'')
		or error('Unable to update config', __FILE__, __LINE__, $db->error());
}

//
// Cache-table get/set
//
function evebb_dlstats_cache_get($key)
{
	global $db;
	$result = $db->query('SELECT v, ts FROM '.$db->prefix.'dlstats_cache WHERE k=\''.$db->escape($key).'\'')
		or error('Unable to read cache', __FILE__, __LINE__, $db->error());
	if (!$db->has_rows($result))
		return array(null, 0);
	$row = $db->fetch_assoc($result);
	return array($row['v'], (int) $row['ts']);
}

function evebb_dlstats_cache_set($key, $value)
{
	global $db;
	$db->query('UPDATE '.$db->prefix.'dlstats_cache SET v=\''.$db->escape($value).'\', ts='.time().' WHERE k=\''.$db->escape($key).'\'')
		or error('Unable to write cache', __FILE__, __LINE__, $db->error());
	if ($db->affected_rows() < 1)
		$db->query('INSERT INTO '.$db->prefix.'dlstats_cache (k, v, ts) VALUES(\''.$db->escape($key).'\', \''.$db->escape($value).'\', '.time().')')
			or error('Unable to write cache', __FILE__, __LINE__, $db->error());
}

//
// GitHub releases summary: array(
//   'total' => int, 'fetched' => ts, 'error' => bool,
//   'releases' => array(array('tag','prerelease','count'), ...)
// )
// Cached for o_dlstats_ttl seconds; $force refetches now.
//
function evebb_dlstats_github_summary($force = false)
{
	global $pun_config;

	$ttl = max(60, (int) ($pun_config['o_dlstats_ttl'] ?? 3600));
	list($cached, $ts) = evebb_dlstats_cache_get('github');
	if (!$force && $cached !== null && (time() - $ts) < $ttl)
	{
		$data = json_decode($cached, true);
		if (is_array($data))
			return $data;
	}

	$repo = pun_trim($pun_config['o_dlstats_repo'] ?? '');
	$summary = array('total' => 0, 'fetched' => time(), 'error' => false, 'releases' => array());

	if ($repo === '' || !preg_match('%^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$%', $repo))
	{
		$summary['error'] = true;
		return $summary;
	}

	if (!function_exists('evebb_http_get'))
		require PUN_ROOT.'include/update.php';

	$base = defined('DLSTATS_API_BASE') ? DLSTATS_API_BASE : 'https://api.github.com';
	$body = evebb_http_get($base.'/repos/'.$repo.'/releases?per_page=100', 10);
	$releases = ($body !== false) ? json_decode($body, true) : false;

	if (!is_array($releases))
	{
		// Keep the stale cache if we have one - stale data beats no data
		if ($cached !== null)
		{
			$data = json_decode($cached, true);
			if (is_array($data))
			{
				$data['error'] = true;
				return $data;
			}
		}
		$summary['error'] = true;
		return $summary;
	}

	foreach ($releases as $release)
	{
		if (!is_array($release) || !isset($release['tag_name']) || !empty($release['draft']))
			continue;

		$count = 0;
		if (isset($release['assets']) && is_array($release['assets']))
			foreach ($release['assets'] as $asset)
				if (isset($asset['name'], $asset['download_count']) && preg_match('%\.zip$%i', $asset['name']))
					$count += (int) $asset['download_count'];

		$summary['releases'][] = array(
			'tag'        => (string) $release['tag_name'],
			'prerelease' => !empty($release['prerelease']),
			'count'      => $count,
		);
		$summary['total'] += $count;
	}

	evebb_dlstats_cache_set('github', json_encode($summary));
	return $summary;
}

//
// Local counters
//
function evebb_dlstats_local_total()
{
	global $db;
	$result = $db->query('SELECT COUNT(*), COALESCE(SUM(hits),0) FROM '.$db->prefix.'dlstats_hits')
		or error('Unable to read hits', __FILE__, __LINE__, $db->error());
	$row = $db->fetch_row($result);
	return array((int) $row[0], (int) $row[1]);
}

function evebb_dlstats_local_top($limit = 50)
{
	global $db;
	$result = $db->query('SELECT file, hits, last_hit FROM '.$db->prefix.'dlstats_hits ORDER BY hits DESC, file ASC LIMIT '.(int) $limit)
		or error('Unable to read hits', __FILE__, __LINE__, $db->error());
	$rows = array();
	while ($row = $db->fetch_assoc($result))
		$rows[] = $row;
	return $rows;
}

//
// Validate a requested file path (relative, .zip, no tricks) and resolve
// it inside the configured downloads dir. Returns absolute path or false.
//
function evebb_dlstats_resolve($rel)
{
	global $pun_config;

	$rel = str_replace('\\', '/', (string) $rel);
	if ($rel === '' || strlen($rel) > 200 || strpos($rel, "\0") !== false)
		return false;
	// D: $ anchors at the absolute end (no trailing-newline latitude)
	if (!preg_match('%^[A-Za-z0-9][A-Za-z0-9._/-]*\.zip$%D', $rel))
		return false;
	if (strpos($rel, '..') !== false || strpos($rel, '//') !== false)
		return false;

	$dir = pun_trim($pun_config['o_dlstats_dir'] ?? 'downloads');
	if ($dir === '')
		return false;
	// Relative dirs are taken from the forum root's parent-independent root
	if ($dir[0] !== '/' && !preg_match('%^[A-Za-z]:%', $dir))
		$dir = PUN_ROOT.$dir;
	$dir = rtrim($dir, '/');

	$abs = realpath($dir.'/'.$rel);
	$root = realpath($dir);
	if ($abs === false || $root === false)
		return false;
	if (strpos($abs, $root.'/') !== 0 && $abs !== $root)
		return false;
	if (!is_file($abs))
		return false;

	return $abs;
}

//
// Record one hit for a validated relative path
//
function evebb_dlstats_hit($rel)
{
	global $db;
	$db->query('UPDATE '.$db->prefix.'dlstats_hits SET hits=hits+1, last_hit='.time().' WHERE file=\''.$db->escape($rel).'\'')
		or error('Unable to count hit', __FILE__, __LINE__, $db->error());
	if ($db->affected_rows() < 1)
		$db->query('INSERT INTO '.$db->prefix.'dlstats_hits (file, hits, last_hit) VALUES(\''.$db->escape($rel).'\', 1, '.time().')')
			or error('Unable to count hit', __FILE__, __LINE__, $db->error());
}

//
// Uninstall: drop tables + config (counts are lost - deliberate)
//
function evebb_dlstats_nuke()
{
	global $db;
	if ($db->table_exists('dlstats_hits'))
		$db->drop_table('dlstats_hits');
	if ($db->table_exists('dlstats_cache'))
		$db->drop_table('dlstats_cache');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name LIKE \'o!_dlstats!_%\' ESCAPE \'!\'')
		or error('Unable to clear config', __FILE__, __LINE__, $db->error());
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}
