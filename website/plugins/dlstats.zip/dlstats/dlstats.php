<?php

/**
 * Download Statistics - the addon.
 *
 * One hook: header_head_end. On the ADMIN INDEX page only (and only for
 * administrators) it appends a "Downloads" entry to the existing #adstats
 * box: total release-package downloads from GitHub (cached), plus the
 * exact local zip hit count from the bundled counter. Everything else -
 * breakdowns, settings, the counting endpoint - lives in admin.php and
 * count.php.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

class plugin_dlstats extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		global $pun_user;

		static $busy;
		if ($busy)
			return;
		$busy = true;

		$page = basename($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '');
		if ($page == 'admin_index.php' && !$pun_user['is_guest'] && $pun_user['g_id'] == PUN_ADMIN)
		{
			evebb_dlstats_bootstrap();

			$gh = evebb_dlstats_github_summary();
			list($files, $hits) = evebb_dlstats_local_total();

			$latest = null;
			foreach ($gh['releases'] as $r)
			{
				if (!$r['prerelease']) { $latest = $r; break; }
			}

			$core_line = $gh['error'] && $gh['total'] == 0
				? 'unavailable right now'
				: number_format($gh['total']).' package downloads'
					.($latest !== null ? ' ('.number_format($latest['count']).' for '.$latest['tag'].')' : '');

			$local_line = $hits > 0
				? number_format($hits).' downloads across '.number_format($files).' files'
				: 'no hits recorded yet';

			$payload = array(
				'core'  => $core_line,
				'local' => $local_line,
				'more'  => 'admin_plugins.php?action=settings&plugin=dlstats',
			);

?>
<script type="text/javascript">
// dlstats: append download counters to the admin-index stats box
(function () {
	var D = <?php echo json_encode($payload) ?>;
	function ready(fn) {
		if (document.readyState != 'loading') fn();
		else document.addEventListener('DOMContentLoaded', fn);
	}
	ready(function () {
		var dl = document.querySelector('#adstats dl');
		if (!dl) return;
		function row(label, text, link) {
			var dt = document.createElement('dt');
			dt.appendChild(document.createTextNode(label));
			var dd = document.createElement('dd');
			dd.appendChild(document.createTextNode(text + ' '));
			if (link) {
				var a = document.createElement('a');
				a.href = link.href;
				a.appendChild(document.createTextNode(link.text));
				dd.appendChild(a);
			}
			dl.appendChild(dt);
			dl.appendChild(dd);
		}
		row('Downloads (releases)', D.core, {href: D.more, text: 'Details'});
		row('Downloads (this site)', D.local, null);
	});
})();
</script>
<?php
		}

		$busy = false;
	}
}
