<?php

/**
 * Download Statistics - counting endpoint.
 *
 * Serves a zip from the configured downloads directory and records the
 * hit. Existing direct links keep working when the downloads directory
 * routes through this script with a rewrite (see the settings page for
 * the .htaccess snippet), so published URLs never have to change.
 *
 * Public by design (guests download files); the only side effect is a
 * counter. The requested path is strictly validated and resolved inside
 * the configured directory - no traversal, no non-zip files.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
define('PUN_TURN_OFF_MAINT', 1);
define('PUN_QUIET_VISIT', 1);

require PUN_ROOT.'include/common.php';
require_once dirname(__FILE__).'/lib.php';

evebb_dlstats_bootstrap();

$rel = isset($_GET['f']) ? (string) $_GET['f'] : '';
$abs = evebb_dlstats_resolve($rel);

if ($abs === false)
{
	header('HTTP/1.1 404 Not Found');
	header('Content-Type: text/plain; charset=utf-8');
	$db->end_transaction();
	$db->close();
	exit('File not found.');
}

evebb_dlstats_hit($rel);

// Commit the count and release the connection before streaming
$db->end_transaction();
$db->close();

// Discard any buffered output so the zip bytes go out clean
while (ob_get_level())
	ob_end_clean();

header('Content-Type: application/zip');
header('Content-Length: '.filesize($abs));
header('Content-Disposition: attachment; filename="'.basename($abs).'"');
header('X-Content-Type-Options: nosniff');
readfile($abs);
exit;
