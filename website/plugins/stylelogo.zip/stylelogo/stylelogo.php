<?php

/**
 * Style-matched Logo - an eveBB plugin.
 *
 * The board logo is a single board-wide setting, but styles are chosen
 * per member - so a blue Ocean board and a dark Midnight board can be on
 * screen for two members at the same moment, both wearing one logo. This
 * plugin fixes the mismatch at render time: just before the header is
 * assembled it swaps the logo URL (in memory only, for this request)
 * for a style-matched file when one exists.
 *
 * CONVENTION: upload logo files named  img/logo-<style>.png  (the style
 * name lower-cased, e.g. logo-midnight.png for "Midnight"). A member
 * whose active style has a matching file sees that logo; anyone else -
 * including guests - sees the board's normal logo. Files should share
 * the board logo's dimensions so the configured size/alignment applies.
 *
 * Nothing is written to the database and the board's configured logo is
 * never modified; deactivate the plugin and the board is exactly as it
 * was.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_stylelogo extends flux_addon
{
	function register($manager)
	{
		// header_head_end fires before header.php reads o_logo_url,
		// so a swap here lands in the rendered page
		$manager->bind('header_head_end', array($this, 'swap_logo'));
	}

	function swap_logo()
	{
		global $pun_config, $pun_user;

		// Only swap where the board actually shows a logo - if the admin
		// prefers the text title, respect that everywhere
		if (empty($pun_config['o_logo_url']))
			return;

		if (!isset($pun_user['style']) || $pun_user['style'] == '')
			return;

		// Style names are validated on save, but stay defensive: the
		// value becomes part of a filesystem path
		$style = strtolower(preg_replace('/[^A-Za-z0-9_\-]/', '', $pun_user['style']));
		if ($style == '')
			return;

		$rel = 'img/logo-'.$style.'.png';
		$file = PUN_ROOT.$rel;

		if (is_file($file))
			$pun_config['o_logo_url'] = $pun_config['o_base_url'].'/'.$rel.'?v='.filemtime($file);
	}
}
