Style-matched Logo - an eveBB plugin
====================================

Shows each member the board logo recoloured to match their chosen style.

INSTALL
  1. Administration -> Plugins -> upload this zip, then Activate.
  2. Upload logo files into your forum's img/ directory, named
     logo-<style>.png with the style name in lower case:
        img/logo-midnight.png   (for the Midnight style)
        img/logo-ocean.png      (for Ocean)
        ...and so on.
  3. Done. A member whose chosen style has a matching file sees that
     logo; everyone else (including guests) sees the normal board logo.

The plugin never touches the database or the configured board logo -
deactivate it and everything is exactly as before. Logo files should
share the board logo's dimensions so the configured size and alignment
still apply. The style packs on the eveBB community board each include
a matching logo you can rename to this convention.

License: GPL v2 or later, same as eveBB.
