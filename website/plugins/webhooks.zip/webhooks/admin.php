<?php

/**
 * Outbound Webhooks - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome and inside a single
 * POST form (footer.php injects the CSRF token). $db, $pun_config and
 * $plugin_slug are available.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

evebb_webhooks_ensure_schema();

$all_events = evebb_webhooks_events();
$event_total = count($all_events);

// Normalise a set of posted event keys into a stored value: '' means all.
function evebb_webhooks_norm_events($posted, $all_events, $event_total)
{
	$chosen = array();
	if (is_array($posted))
	{
		foreach ($posted as $k)
		{
			if (isset($all_events[$k]))
				$chosen[$k] = true;
		}
	}
	$n = count($chosen);
	if ($n === 0 || $n === $event_total)
		return '';
	return implode(',', array_keys($chosen));
}

$redir = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

// ---- Add an endpoint -------------------------------------------------------
if (isset($_POST['add_endpoint']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$url = pun_trim($_POST['new_url'] ?? '');
	if ($url === '' || !preg_match('%^https?://%i', $url) || pun_strlen($url) > 255)
		redirect($redir, 'Enter a valid http(s) URL for the endpoint. Redirecting …');

	$events = evebb_webhooks_norm_events($_POST['new_events'] ?? array(), $all_events, $event_total);
	$secret = evebb_webhooks_new_secret();

	$db->query('INSERT INTO '.$db->prefix.'webhook_endpoints (url, secret, events, active, created_at) VALUES(\''.$db->escape($url).'\', \''.$db->escape($secret).'\', \''.$db->escape($events).'\', 1, '.time().')') or error('Unable to add endpoint', __FILE__, __LINE__, $db->error());

	redirect($redir, 'Endpoint added. Redirecting …');
}

// ---- Save existing endpoints ----------------------------------------------
if (isset($_POST['save_endpoints']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$urls    = isset($_POST['url']) && is_array($_POST['url']) ? $_POST['url'] : array();
	$evsets  = isset($_POST['events']) && is_array($_POST['events']) ? $_POST['events'] : array();
	$actives = isset($_POST['active']) && is_array($_POST['active']) ? $_POST['active'] : array();

	foreach ($urls as $id => $url)
	{
		$id = (int) $id;
		if ($id < 1)
			continue;

		$url = pun_trim($url);
		if ($url === '' || !preg_match('%^https?://%i', $url) || pun_strlen($url) > 255)
			continue; // leave a bad edit untouched

		$events = evebb_webhooks_norm_events(isset($evsets[$id]) ? $evsets[$id] : array(), $all_events, $event_total);
		$active = isset($actives[$id]) ? 1 : 0;

		$db->query('UPDATE '.$db->prefix.'webhook_endpoints SET url=\''.$db->escape($url).'\', events=\''.$db->escape($events).'\', active='.$active.' WHERE id='.$id) or error('Unable to save endpoint', __FILE__, __LINE__, $db->error());
	}

	redirect($redir, 'Endpoints saved. Redirecting …');
}

// ---- Delete / rotate / test one endpoint ----------------------------------
if (isset($_POST['webhook_delete']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$id = (int) $_POST['webhook_delete'];
	$db->query('DELETE FROM '.$db->prefix.'webhook_endpoints WHERE id='.$id) or error('Unable to delete endpoint', __FILE__, __LINE__, $db->error());

	redirect($redir, 'Endpoint deleted. Redirecting …');
}

if (isset($_POST['webhook_rotate']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$id = (int) $_POST['webhook_rotate'];
	$db->query('UPDATE '.$db->prefix.'webhook_endpoints SET secret=\''.$db->escape(evebb_webhooks_new_secret()).'\' WHERE id='.$id) or error('Unable to rotate secret', __FILE__, __LINE__, $db->error());

	redirect($redir, 'Signing secret rotated. Redirecting …');
}

if (isset($_POST['webhook_test']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$id = (int) $_POST['webhook_test'];
	$result = $db->query('SELECT id, url, secret FROM '.$db->prefix.'webhook_endpoints WHERE id='.$id) or error('Unable to fetch endpoint', __FILE__, __LINE__, $db->error());
	if ($db->has_rows($result))
	{
		$e = $db->fetch_assoc($result);
		$payload = array(
			'event'     => 'ping',
			'board'     => array('title' => $pun_config['o_board_title'], 'url' => get_base_url()),
			'message'   => 'This is a test delivery from your eveBB board.',
			'timestamp' => time()
		);
		$body = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
		$timeout = max(1, min(30, (int) evebb_webhooks_conf('o_webhooks_timeout', '5')));
		list($code, $status) = evebb_webhooks_send($e['url'], 'ping', uniqid('', true), $e['secret'], $body, $timeout);
		evebb_webhooks_record($db, $id, $code, $status);

		redirect($redir, 'Test delivery sent: '.$status.'. Redirecting …');
	}

	redirect($redir, 'Endpoint not found. Redirecting …');
}

// ---- Global settings -------------------------------------------------------
if (isset($_POST['save_webhook_settings']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	evebb_webhooks_save_conf('o_webhooks_guestonly', isset($_POST['webhooks_guestonly']) ? '1' : '0');

	$timeout = isset($_POST['webhooks_timeout']) ? (int) $_POST['webhooks_timeout'] : 5;
	if ($timeout < 1)
		$timeout = 1;
	else if ($timeout > 30)
		$timeout = 30;
	evebb_webhooks_save_conf('o_webhooks_timeout', (string) $timeout);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect($redir, 'Settings saved. Redirecting …');
}

// ---- Remove all plugin data ------------------------------------------------
if (isset($_POST['nuke_webhooks']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect($redir, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('webhook_endpoints');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN (\'o_webhooks_db_rev\', \'o_webhooks_guestonly\', \'o_webhooks_timeout\')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());
	unset($pun_config['o_webhooks_db_rev'], $pun_config['o_webhooks_guestonly'], $pun_config['o_webhooks_timeout']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Outbound Webhooks data removed. You can now deactivate and delete the plugin. Redirecting …');
}

// ---- Read current state ----------------------------------------------------
$guestonly = evebb_webhooks_conf('o_webhooks_guestonly', '1') == '1';
$timeout   = (int) evebb_webhooks_conf('o_webhooks_timeout', '5');

$endpoints = array();
$result = $db->query('SELECT id, url, secret, events, active, last_at, last_code, last_status FROM '.$db->prefix.'webhook_endpoints ORDER BY id') or error('Unable to fetch endpoints', __FILE__, __LINE__, $db->error());
while ($row = $db->fetch_assoc($result))
	$endpoints[] = $row;

?>
		<div class="inform">
			<fieldset>
				<legend>Outbound Webhooks</legend>
				<div class="infldset">
					<p>Each endpoint below receives a JSON <strong>HTTP POST</strong> when a subscribed event happens. Every request carries an <code>X-EveBB-Signature</code> header &mdash; <code>sha256=</code> followed by the HMAC-SHA256 of the exact request body, keyed with that endpoint's secret &mdash; so your receiver can verify the call really came from this board. Delivery is best-effort with a <?php echo $timeout ?>-second timeout; the visitor is never held up waiting for your endpoint.</p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Endpoints</legend>
				<div class="infldset">
<?php if (empty($endpoints)): ?>
					<p>No endpoints yet. Add one below.</p>
<?php else: ?>
					<p>Untick every event box (or tick them all) to receive <em>all</em> events, including any added in future versions.</p>
					<table>
						<thead>
							<tr><th>#</th><th>URL &amp; events</th><th>Active</th><th>Secret</th><th>Last delivery</th><th>Actions</th></tr>
						</thead>
						<tbody>
<?php foreach ($endpoints as $e): $eid = (int) $e['id'];
	$subscribed = trim($e['events']) === '' ? array_keys($all_events) : array_map('trim', explode(',', $e['events'])); ?>
							<tr>
								<td><?php echo $eid ?></td>
								<td>
									<input type="text" name="url[<?php echo $eid ?>]" value="<?php echo pun_htmlspecialchars($e['url']) ?>" size="40" maxlength="255" /><br />
<?php foreach ($all_events as $key => $label): ?>
									<label style="display:inline-block;margin-right:1em"><input type="checkbox" name="events[<?php echo $eid ?>][]" value="<?php echo $key ?>"<?php if (in_array($key, $subscribed, true)) echo ' checked="checked"' ?> /> <?php echo pun_htmlspecialchars($label) ?></label>
<?php endforeach; ?>
								</td>
								<td><input type="checkbox" name="active[<?php echo $eid ?>]" value="1"<?php if ((int) $e['active'] === 1) echo ' checked="checked"' ?> /></td>
								<td><code style="font-size:.85em"><?php echo pun_htmlspecialchars($e['secret']) ?></code></td>
								<td><?php
	if ((int) $e['last_at'] === 0)
		echo '<span style="opacity:.7">never</span>';
	else
		echo pun_htmlspecialchars($e['last_status']).'<br /><span style="opacity:.7;font-size:.85em">'.format_time($e['last_at']).'</span>';
?></td>
								<td>
									<button type="submit" name="webhook_test" value="<?php echo $eid ?>">test</button>
									<button type="submit" name="webhook_rotate" value="<?php echo $eid ?>">rotate secret</button>
									<button type="submit" name="webhook_delete" value="<?php echo $eid ?>" onclick="return confirm('Delete this endpoint?')">delete</button>
								</td>
							</tr>
<?php endforeach; ?>
						</tbody>
					</table>
					<p class="topspace"><input type="submit" name="save_endpoints" value="Save endpoint changes" /></p>
<?php endif; ?>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Add an endpoint</legend>
				<div class="infldset">
					<label>Endpoint URL (https recommended)<br /><input type="text" name="new_url" size="50" maxlength="255" value="" placeholder="https://example.com/hooks/evebb" /></label>
					<p>Send these events (leave all ticked for everything):</p>
<?php foreach ($all_events as $key => $label): ?>
					<label style="display:inline-block;margin-right:1em"><input type="checkbox" name="new_events[]" value="<?php echo $key ?>" checked="checked" /> <?php echo pun_htmlspecialchars($label) ?></label>
<?php endforeach; ?>
					<p class="topspace"><input type="submit" name="add_endpoint" value="Add endpoint" /></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Delivery settings</legend>
				<div class="infldset">
					<label><input type="checkbox" name="webhooks_guestonly" value="1"<?php if ($guestonly) echo ' checked="checked"' ?> /> Only send events for content a guest could read (keeps private-forum topics, replies and reports off the wire)</label>
					<label>Request timeout in seconds (1&ndash;30)<br /><input type="text" name="webhooks_timeout" size="4" maxlength="2" value="<?php echo $timeout ?>" /></label>
					<p class="topspace"><input type="submit" name="save_webhook_settings" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Payload &amp; verification</legend>
				<div class="infldset">
					<p>Bodies are JSON. Every payload has an <code>event</code> string, a <code>board</code> object and a <code>timestamp</code> (Unix seconds). Verify a request in your receiver like this (PHP):</p>
					<pre style="white-space:pre-wrap">$body = file_get_contents('php://input');
$sig  = 'sha256='.hash_hmac('sha256', $body, $YOUR_SECRET);
if (hash_equals($sig, $_SERVER['HTTP_X_EVEBB_SIGNATURE'])) { /* trusted */ }</pre>
					<p>Registration events deliberately carry <strong>no email address or IP</strong>. Report and post/topic events include the forum id and name so you can route them (for example, staff-only forums to a moderators' channel).</p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Uninstall</legend>
				<div class="infldset">
					<p>To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the webhook_endpoints table and all of this plugin's settings.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently deletes every configured endpoint</label></p>
					<p><input type="submit" name="nuke_webhooks" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
