<?php

/**
 * Outbound Webhooks - the addon.
 *
 * Delivers a signed JSON POST to configured endpoints when a topic is
 * started, a reply is posted, a member registers, or a post is reported.
 *
 * How it works: eveBB's post.php and register.php create the row and then
 * redirect() (closing the request DB handle) before any page is rendered,
 * so there is no post-insert hook to read the new id from. The plugin arms
 * a shutdown callback from the *_after_validation hooks; by the time it runs
 * the new ids live in global scope ($new_tid / $new_pid / $new_uid). The
 * callback opens a fresh DB connection (the request's is gone), builds the
 * payloads, and posts them to every subscribed endpoint. Report events are
 * built inline from the report_after_insert core hook (the DB is still open
 * there) and delivered by the same shutdown callback.
 *
 * Delivery is best-effort with a short timeout: the visitor has already been
 * redirected, so a slow or dead endpoint never delays them, and the outcome
 * of the last attempt is stored per endpoint for the admin page to show.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_webhooks extends flux_addon
{
	function register($manager)
	{
		$manager->bind('post_after_validation', array($this, 'on_post'));
		$manager->bind('register_after_validation', array($this, 'on_register'));
		$manager->bind('report_after_insert', array($this, 'on_report'));
	}


	//
	// Capture the config we need at request time (get_base_url, config cache
	// and helpers are all available now, but not inside the shutdown handler)
	// and register the shutdown dispatcher exactly once.
	//
	function arm()
	{
		global $pun_config;

		// Never configured -> nothing can be subscribed, do no work
		if (!isset($pun_config['o_webhooks_db_rev']))
			return false;

		if (!isset($GLOBALS['evebb_webhooks_cfg']))
		{
			$GLOBALS['evebb_webhooks_cfg'] = array(
				'guestonly'   => evebb_webhooks_conf('o_webhooks_guestonly', '1') == '1',
				'timeout'     => max(1, min(30, (int) evebb_webhooks_conf('o_webhooks_timeout', '5'))),
				'base_url'    => get_base_url(),
				'board_title' => isset($pun_config['o_board_title']) ? $pun_config['o_board_title'] : ''
			);
			register_shutdown_function(array('plugin_webhooks', 'dispatch'));
		}

		return true;
	}


	//
	// post.php: a topic or reply passed validation. Arm the dispatcher; the
	// shutdown handler decides topic vs reply from the new ids.
	//
	function on_post()
	{
		global $errors;

		if (!empty($errors) || isset($_POST['preview']))
			return;

		$this->arm();
	}


	//
	// register.php: a registration passed validation.
	//
	function on_register()
	{
		global $errors;

		if (!empty($errors))
			return;

		$this->arm();
	}


	//
	// misc.php: a post was just reported. The DB is open here and the report
	// variables are in scope, so build the payload now and stash it for the
	// shutdown dispatcher.
	//
	function on_report()
	{
		global $db, $pun_user, $post_id, $topic_id, $forum_id;

		if (!$this->arm())
			return;

		$cfg = $GLOBALS['evebb_webhooks_cfg'];

		$subject = '';
		$forum_name = '';
		$result = $db->query('SELECT t.subject, f.forum_name FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id WHERE t.id='.(int) $topic_id);
		if ($result && $db->has_rows($result))
		{
			$row = $db->fetch_assoc($result);
			$subject = $row['subject'];
			$forum_name = $row['forum_name'];
		}

		$reason = isset($_POST['req_reason']) ? pun_trim($_POST['req_reason']) : '';

		$payload = array(
			'event'     => 'post.reported',
			'board'     => array('title' => $cfg['board_title'], 'url' => $cfg['base_url']),
			'report'    => array(
				'reason'      => $reason,
				'reporter'    => $pun_user['username'],
				'reporter_id' => (int) $pun_user['id']
			),
			'post'      => array(
				'id'  => (int) $post_id,
				'url' => $cfg['base_url'].'/viewtopic.php?pid='.(int) $post_id.'#p'.(int) $post_id
			),
			'topic'     => array(
				'id'         => (int) $topic_id,
				'subject'    => $subject,
				'forum_id'   => (int) $forum_id,
				'forum_name' => $forum_name,
				'url'        => $cfg['base_url'].'/viewtopic.php?id='.(int) $topic_id
			),
			'timestamp' => time()
		);

		$GLOBALS['evebb_webhooks_report'] = array('post.reported', $payload, (int) $forum_id);
	}


	//
	// Shutdown: reconnect, work out which events fired, deliver them.
	//
	static function dispatch()
	{
		if (empty($GLOBALS['evebb_webhooks_cfg']))
			return;

		$cfg = $GLOBALS['evebb_webhooks_cfg'];

		global $db_type, $db_host, $db_username, $db_password, $db_name, $db_prefix, $p_connect;
		$db = null;
		require PUN_ROOT.'include/dblayer/common_db.php';

		if (!is_object($db) || !$db->table_exists('webhook_endpoints'))
			return;

		$events = array();

		if (!empty($GLOBALS['evebb_webhooks_report']))
			$events[] = $GLOBALS['evebb_webhooks_report'];

		// A new post exists. post.php sets $new_tid for BOTH a new topic
		// (fresh topic id) and a reply (the existing topic id), so we cannot
		// tell them apart from that alone: a reply is a new post whose id is
		// NOT the topic's first post. Compare against first_post_id.
		if (!empty($GLOBALS['new_pid']))
		{
			$pid = (int) $GLOBALS['new_pid'];
			$tid = !empty($GLOBALS['new_tid']) ? (int) $GLOBALS['new_tid'] : 0;

			$is_new_topic = false;
			if ($tid > 0)
			{
				$res = $db->query('SELECT first_post_id FROM '.$db->prefix.'topics WHERE id='.$tid);
				if ($res && $db->has_rows($res))
					$is_new_topic = ((int) $db->result($res) === $pid);
			}

			$p = $is_new_topic ? self::build_topic($db, $tid, $cfg) : self::build_post($db, $pid, $cfg);
			if ($p)
				$events[] = $p;
		}

		if (!empty($GLOBALS['new_uid']))
		{
			$p = self::build_user($db, (int) $GLOBALS['new_uid'], $cfg);
			if ($p)
				$events[] = $p;
		}

		foreach ($events as $ev)
		{
			list($event, $payload, $forum_id) = $ev;

			// Guest-readable gate: skip forum-scoped events whose forum a
			// guest could not read (keeps private content off the wire).
			if ($cfg['guestonly'] && $forum_id !== null && !evebb_webhooks_guest_can_read($db, $forum_id))
				continue;

			$endpoints = evebb_webhooks_endpoints($db, $event);
			if (empty($endpoints))
				continue;

			$body = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

			foreach ($endpoints as $e)
			{
				$delivery = uniqid('', true);
				list($code, $status) = evebb_webhooks_send($e['url'], $event, $delivery, $e['secret'], $body, $cfg['timeout']);
				evebb_webhooks_record($db, $e['id'], $code, $status);
			}
		}

		$db->close();
	}


	//
	// Payload builders. Each returns array(event, payload, forum_id) or null.
	//
	static function build_topic($db, $tid, $cfg)
	{
		$result = $db->query('SELECT t.id, t.subject, t.forum_id, t.first_post_id, f.forum_name FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id WHERE t.id='.$tid);
		if (!$result || !$db->has_rows($result))
			return null;
		$t = $db->fetch_assoc($result);

		$post = self::fetch_post($db, (int) $t['first_post_id'], $cfg);

		$payload = array(
			'event'     => 'topic.created',
			'board'     => array('title' => $cfg['board_title'], 'url' => $cfg['base_url']),
			'topic'     => array(
				'id'         => (int) $t['id'],
				'subject'    => $t['subject'],
				'forum_id'   => (int) $t['forum_id'],
				'forum_name' => $t['forum_name'],
				'url'        => $cfg['base_url'].'/viewtopic.php?id='.(int) $t['id']
			),
			'post'      => $post,
			'timestamp' => time()
		);

		return array('topic.created', $payload, (int) $t['forum_id']);
	}

	static function build_post($db, $pid, $cfg)
	{
		$result = $db->query('SELECT p.id, p.topic_id, t.subject, t.forum_id, f.forum_name FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id WHERE p.id='.$pid);
		if (!$result || !$db->has_rows($result))
			return null;
		$r = $db->fetch_assoc($result);

		$post = self::fetch_post($db, $pid, $cfg);

		$payload = array(
			'event'     => 'post.created',
			'board'     => array('title' => $cfg['board_title'], 'url' => $cfg['base_url']),
			'topic'     => array(
				'id'         => (int) $r['topic_id'],
				'subject'    => $r['subject'],
				'forum_id'   => (int) $r['forum_id'],
				'forum_name' => $r['forum_name'],
				'url'        => $cfg['base_url'].'/viewtopic.php?id='.(int) $r['topic_id']
			),
			'post'      => $post,
			'timestamp' => time()
		);

		return array('post.created', $payload, (int) $r['forum_id']);
	}

	static function fetch_post($db, $pid, $cfg)
	{
		$result = $db->query('SELECT id, poster, poster_id, message, posted FROM '.$db->prefix.'posts WHERE id='.(int) $pid);
		if (!$result || !$db->has_rows($result))
			return array('id' => (int) $pid);
		$p = $db->fetch_assoc($result);

		return array(
			'id'        => (int) $p['id'],
			'author'    => $p['poster'],
			'author_id' => (int) $p['poster_id'],
			'message'   => $p['message'],
			'posted'    => (int) $p['posted'],
			'url'       => $cfg['base_url'].'/viewtopic.php?pid='.(int) $p['id'].'#p'.(int) $p['id']
		);
	}

	static function build_user($db, $uid, $cfg)
	{
		$result = $db->query('SELECT id, username, registered FROM '.$db->prefix.'users WHERE id='.$uid);
		if (!$result || !$db->has_rows($result))
			return null;
		$u = $db->fetch_assoc($result);

		// Deliberately no email or IP: registration webhooks carry no PII.
		$payload = array(
			'event'     => 'user.registered',
			'board'     => array('title' => $cfg['board_title'], 'url' => $cfg['base_url']),
			'user'      => array(
				'id'         => (int) $u['id'],
				'username'   => $u['username'],
				'registered' => (int) $u['registered'],
				'url'        => $cfg['base_url'].'/profile.php?id='.(int) $u['id']
			),
			'timestamp' => time()
		);

		return array('user.registered', $payload, null);
	}
}
