<?php

/**
 * Outbound Webhooks - shared library.
 *
 * Schema management, config helpers, endpoint lookup, payload signing and
 * the actual HTTP delivery. Used by the addon (webhooks.php) and the
 * settings page (admin.php).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


// The events this plugin can deliver, in display order. Keys are the wire
// names sent in the payload and the X-EveBB-Event header.
function evebb_webhooks_events()
{
	return array(
		'topic.created'  => 'New topic started',
		'post.created'   => 'New reply posted',
		'user.registered'=> 'New member registered',
		'post.reported'  => 'A post was reported'
	);
}


//
// Create the endpoints table on first use. Guarded by o_webhooks_db_rev so
// the check is free on every later request.
//
function evebb_webhooks_ensure_schema()
{
	global $db, $pun_config;

	if (isset($pun_config['o_webhooks_db_rev']))
		return;

	if (!$db->table_exists('webhook_endpoints'))
	{
		$schema = array(
			'FIELDS' => array(
				'id' => array(
					'datatype'   => 'SERIAL',
					'allow_null' => false
				),
				'url' => array(
					'datatype'   => 'VARCHAR(255)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'secret' => array(
					'datatype'   => 'VARCHAR(64)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'events' => array(
					'datatype'   => 'VARCHAR(255)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'active' => array(
					'datatype'   => 'SMALLINT(6)',
					'allow_null' => false,
					'default'    => '1'
				),
				'created_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'last_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'last_code' => array(
					'datatype'   => 'INT(10)',
					'allow_null' => false,
					'default'    => '0'
				),
				'last_status' => array(
					'datatype'   => 'VARCHAR(64)',
					'allow_null' => false,
					'default'    => '\'\''
				)
			),
			'PRIMARY KEY' => array('id')
		);

		$db->create_table('webhook_endpoints', $schema) or error('Unable to create the webhook_endpoints table', __FILE__, __LINE__, $db->error());
	}

	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_webhooks_db_rev\', \'1\')');
	$pun_config['o_webhooks_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Read a plugin config value with a default
//
function evebb_webhooks_conf($name, $default)
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Insert or update a config value (caller refreshes the cache)
//
function evebb_webhooks_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


//
// A random 40-char hex signing secret for a new endpoint
//
function evebb_webhooks_new_secret()
{
	if (function_exists('random_bytes'))
		return bin2hex(random_bytes(20));

	// Fallback for very old PHP
	$s = '';
	for ($i = 0; $i < 40; $i++)
		$s .= dechex(mt_rand(0, 15));
	return $s;
}


//
// Fetch active endpoints subscribed to $event. An endpoint with an empty
// events list is subscribed to everything. $db is passed explicitly so the
// shutdown dispatcher can use its own reconnected handle.
//
function evebb_webhooks_endpoints($db, $event)
{
	if (!$db->table_exists('webhook_endpoints'))
		return array();

	$result = $db->query('SELECT id, url, secret, events FROM '.$db->prefix.'webhook_endpoints WHERE active=1') or error('Unable to fetch webhook endpoints', __FILE__, __LINE__, $db->error());

	$out = array();
	while ($row = $db->fetch_assoc($result))
	{
		$list = trim($row['events']);
		if ($list !== '')
		{
			$wanted = array_map('trim', explode(',', $list));
			if (!in_array($event, $wanted, true))
				continue;
		}
		$out[] = $row;
	}

	return $out;
}


//
// Can a guest read this forum? Used to gate content when the board is set to
// only emit guest-readable events. Mirrors core's forum_perms check for the
// guest group: a missing row means the default (readable).
//
function evebb_webhooks_guest_can_read($db, $forum_id)
{
	$forum_id = (int) $forum_id;
	if ($forum_id < 1)
		return false;

	$result = $db->query('SELECT read_forum FROM '.$db->prefix.'forum_perms WHERE forum_id='.$forum_id.' AND group_id='.PUN_GUEST) or error('Unable to check forum permissions', __FILE__, __LINE__, $db->error());

	if (!$db->has_rows($result))
		return true; // no explicit deny

	return (int) $db->result($result) == 1;
}


//
// HMAC-SHA256 signature of a raw body, hex, prefixed "sha256=" (the same
// shape GitHub and Stripe use, so existing verifier snippets work).
//
function evebb_webhooks_sign($secret, $body)
{
	return 'sha256='.hash_hmac('sha256', $body, $secret);
}


//
// Deliver one payload to one URL. Returns array(http_code, status_label).
// Best-effort: never throws, short timeout, follows no redirects.
//
function evebb_webhooks_send($url, $event, $delivery_id, $secret, $body, $timeout)
{
	$headers = array(
		'Content-Type: application/json',
		'User-Agent: eveBB-Webhooks/1.0',
		'X-EveBB-Event: '.$event,
		'X-EveBB-Delivery: '.$delivery_id,
		'X-EveBB-Signature: '.evebb_webhooks_sign($secret, $body)
	);

	if (function_exists('curl_init'))
	{
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, (int) $timeout);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, (int) $timeout);
		curl_setopt($ch, CURLOPT_NOSIGNAL, true);
		curl_exec($ch);
		$code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$err  = curl_error($ch);
		curl_close($ch);

		if ($code >= 200 && $code < 300)
			return array($code, 'delivered');
		if ($code > 0)
			return array($code, 'http '.$code);
		return array(0, $err !== '' ? substr($err, 0, 60) : 'no response');
	}

	// Stream fallback
	$ctx = stream_context_create(array('http' => array(
		'method'        => 'POST',
		'header'        => implode("\r\n", $headers),
		'content'       => $body,
		'timeout'       => (int) $timeout,
		'ignore_errors' => true
	)));

	$resp = @file_get_contents($url, false, $ctx);
	$code = 0;
	if (isset($http_response_header) && isset($http_response_header[0]) &&
		preg_match('%\s(\d{3})\s%', $http_response_header[0], $m))
		$code = (int) $m[1];

	if ($code >= 200 && $code < 300)
		return array($code, 'delivered');
	if ($code > 0)
		return array($code, 'http '.$code);
	return array(0, $resp === false ? 'no response' : 'unknown');
}


//
// Record the outcome of the most recent delivery attempt on an endpoint.
//
function evebb_webhooks_record($db, $endpoint_id, $code, $status)
{
	$db->query('UPDATE '.$db->prefix.'webhook_endpoints SET last_at='.time().', last_code='.(int) $code.', last_status=\''.$db->escape(substr($status, 0, 64)).'\' WHERE id='.(int) $endpoint_id) or error('Unable to record webhook delivery', __FILE__, __LINE__, $db->error());
}
