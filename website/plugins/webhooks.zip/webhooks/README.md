# Outbound Webhooks

An unofficial eveBB plugin that delivers a signed JSON **HTTP POST** to your
own endpoints when things happen on the board. Point it at a Discord or Slack
relay, a moderation alert bot, an analytics pipeline, or any custom
integration you like.

## Events

| Event             | Fires when                          |
|-------------------|-------------------------------------|
| `topic.created`   | a member starts a new topic         |
| `post.created`    | a member posts a reply              |
| `user.registered` | a new member completes registration |
| `post.reported`   | a member reports a post             |

Each endpoint can subscribe to all events or just the ones it cares about.

## Security

Every request carries these headers:

- `X-EveBB-Event` — the event name (e.g. `topic.created`)
- `X-EveBB-Delivery` — a unique id for this delivery attempt
- `X-EveBB-Signature` — `sha256=` followed by the HMAC-SHA256 of the **exact
  request body**, keyed with that endpoint's secret

Verify it in your receiver (PHP shown; the scheme is the same one GitHub and
Stripe use, so most existing verifier snippets work):

```php
$body = file_get_contents('php://input');
$expected = 'sha256=' . hash_hmac('sha256', $body, $YOUR_ENDPOINT_SECRET);
if (hash_equals($expected, $_SERVER['HTTP_X_EVEBB_SIGNATURE'])) {
    // trusted — process $body
}
```

Each endpoint has its own secret. Rotate it any time from the settings page.

## Privacy

- **Guest-readable gate** (on by default): topic, reply and report events are
  only sent for content a guest could read. Private-forum activity stays off
  the wire unless you turn the gate off.
- **Registration events carry no PII** — username, id, registration time and
  profile URL only. No email address, no IP.

## Delivery

Delivery is best-effort and happens *after* the visitor has been redirected,
so a slow or dead endpoint never delays anyone. Requests use a configurable
timeout (default 5s, 1–30). The outcome of the most recent attempt is shown
per endpoint on the settings page, and a **test** button sends a `ping`
payload on demand.

There is no automatic retry in this version: a failed delivery is recorded
but not re-queued. Reliable retries are a natural fit for the core task
scheduler planned for eveBB 2.1.

## Requirements

`post.reported` needs the `report_after_insert` hook added to `misc.php` in
eveBB (shipped alongside this plugin). On an older core without that hook the
other three events still work; report events simply never fire.

## Payload shape

```json
{
  "event": "topic.created",
  "board": { "title": "My Board", "url": "https://example.com/forum" },
  "topic": { "id": 42, "subject": "Hello", "forum_id": 2,
             "forum_name": "General", "url": "https://.../viewtopic.php?id=42" },
  "post":  { "id": 99, "author": "alice", "author_id": 7,
             "message": "…", "posted": 1737400000,
             "url": "https://.../viewtopic.php?pid=99#p99" },
  "timestamp": 1737400000
}
```

## Install

Upload the zip on **Admin → Plugins**, activate, then open the plugin's
settings to add an endpoint. Tables are created automatically.

## Uninstall

Use **Remove all plugin data** on the settings page (drops the
`webhook_endpoints` table and this plugin's settings), then deactivate and
delete the plugin.

## License

GPL version 2 or higher — http://www.gnu.org/licenses/gpl.html
