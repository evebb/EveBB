<?php

/**
 * Board Statistics - the dashboard (shown inside the plugin manager;
 * admin console is already admin-only).
 *
 * Everything is computed live with a handful of aggregate queries and
 * rendered as HTML/CSS - no JS libraries, no cron, no stored data.
 * Time bucketing uses pure integer arithmetic on the stored epoch
 * timestamps (portable across MySQL/PostgreSQL/SQLite; all buckets are
 * UTC-based).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

$bs_start = microtime(true);
$now = time();
$day = 86400;
$cut30 = $now - 30 * $day;
$cut90 = $now - 90 * $day;
$cut365 = $now - 365 * $day;

// ---------------------------------------------------------------------------
// Gather
// ---------------------------------------------------------------------------

// Totals
$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'users WHERE id>1') or error('Unable to count users', __FILE__, __LINE__, $db->error());
$bs_users = (int) $db->result($result);
$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'topics WHERE moved_to IS NULL') or error('Unable to count topics', __FILE__, __LINE__, $db->error());
$bs_topics = (int) $db->result($result);
$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'posts') or error('Unable to count posts', __FILE__, __LINE__, $db->error());
$bs_posts = (int) $db->result($result);
$result = $db->query('SELECT username, registered FROM '.$db->prefix.'users WHERE id>1 ORDER BY registered DESC LIMIT 1') or error('Unable to fetch newest user', __FILE__, __LINE__, $db->error());
$bs_newest = $db->fetch_assoc($result);

// 30-day and 90-day post counts (headline deltas)
$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'posts WHERE posted>'.$cut30) or error('Unable to count recent posts', __FILE__, __LINE__, $db->error());
$bs_posts30 = (int) $db->result($result);
$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'users WHERE id>1 AND registered>'.$cut30) or error('Unable to count recent regs', __FILE__, __LINE__, $db->error());
$bs_regs30 = (int) $db->result($result);

// Daily buckets, last 30 days: posts and new topics
function bs_daily_counts($table, $column, $cutoff)
{
	global $db;

	$expr = '('.$column.'-('.$column.'%86400))';
	$extra = ($table == 'topics') ? ' AND moved_to IS NULL' : (($table == 'users') ? ' AND id>1' : '');
	$result = $db->query('SELECT '.$expr.' AS bucket, COUNT(*) AS n FROM '.$db->prefix.$table.' WHERE '.$column.'>'.$cutoff.$extra.' GROUP BY '.$expr) or error('Unable to fetch daily counts', __FILE__, __LINE__, $db->error());

	$out = array();
	while ($row = $db->fetch_assoc($result))
		$out[(int) $row['bucket']] = (int) $row['n'];

	return $out;
}

$bs_daily_posts = bs_daily_counts('posts', 'posted', $cut30);
$bs_daily_topics = bs_daily_counts('topics', 'posted', $cut30);

// Monthly buckets, last 12 calendar months: posts and registrations
// (aggregated in PHP from daily buckets - calendar months don't fit
// fixed-width arithmetic)
function bs_monthly($daily)
{
	$out = array();
	foreach ($daily as $bucket => $n)
	{
		$key = gmdate('Y-m', $bucket);
		$out[$key] = ($out[$key] ?? 0) + $n;
	}

	return $out;
}

$bs_monthly_posts = bs_monthly(bs_daily_counts('posts', 'posted', $cut365));
$bs_monthly_regs = bs_monthly(bs_daily_counts('users', 'registered', $cut365));

// Top posters: all time (users.num_posts) and last 30 days (live count)
$result = $db->query('SELECT username, id, num_posts FROM '.$db->prefix.'users WHERE id>1 AND num_posts>0 ORDER BY num_posts DESC LIMIT 10') or error('Unable to fetch top posters', __FILE__, __LINE__, $db->error());
$bs_top_all = array();
while ($row = $db->fetch_assoc($result))
	$bs_top_all[] = $row;

$result = $db->query('SELECT p.poster_id AS id, p.poster AS username, COUNT(*) AS num_posts FROM '.$db->prefix.'posts AS p WHERE p.posted>'.$cut30.' AND p.poster_id>1 GROUP BY p.poster_id, p.poster ORDER BY num_posts DESC, p.poster ASC LIMIT 10') or error('Unable to fetch recent posters', __FILE__, __LINE__, $db->error());
$bs_top_30 = array();
while ($row = $db->fetch_assoc($result))
	$bs_top_30[] = $row;

// Dormant members (no visit for 90 days) and group breakdown
$result = $db->query('SELECT COUNT(id) FROM '.$db->prefix.'users WHERE id>1 AND last_visit<'.$cut90) or error('Unable to count dormant users', __FILE__, __LINE__, $db->error());
$bs_dormant = (int) $db->result($result);

$result = $db->query('SELECT g.g_title, COUNT(u.id) AS n FROM '.$db->prefix.'groups AS g LEFT JOIN '.$db->prefix.'users AS u ON u.group_id=g.g_id AND u.id>1 WHERE g.g_id!='.PUN_GUEST.' GROUP BY g.g_id, g.g_title ORDER BY n DESC, g.g_title ASC') or error('Unable to fetch group breakdown', __FILE__, __LINE__, $db->error());
$bs_groups = array();
while ($row = $db->fetch_assoc($result))
	$bs_groups[] = $row;

// Busiest forums and topics, last 30 days
$result = $db->query('SELECT f.forum_name, COUNT(*) AS n FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id WHERE p.posted>'.$cut30.' GROUP BY f.id, f.forum_name ORDER BY n DESC LIMIT 8') or error('Unable to fetch busiest forums', __FILE__, __LINE__, $db->error());
$bs_busy_forums = array();
while ($row = $db->fetch_assoc($result))
	$bs_busy_forums[] = $row;

$result = $db->query('SELECT t.id, t.subject, COUNT(*) AS n FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id WHERE p.posted>'.$cut30.' GROUP BY t.id, t.subject ORDER BY n DESC LIMIT 8') or error('Unable to fetch busiest topics', __FILE__, __LINE__, $db->error());
$bs_busy_topics = array();
while ($row = $db->fetch_assoc($result))
	$bs_busy_topics[] = $row;

// Posting heatmap, last 90 days: hour-of-week buckets via pure %-arithmetic.
// Epoch second 0 was a Thursday; +259200s (3 days) makes bucket 0 = Monday 00:00 UTC.
$how = '(('.('p.posted+259200').')%604800)';
$expr = $how.'-('.$how.'%3600)';
$result = $db->query('SELECT '.$expr.' AS bucket, COUNT(*) AS n FROM '.$db->prefix.'posts AS p WHERE p.posted>'.$cut90.' GROUP BY '.$expr) or error('Unable to fetch heatmap', __FILE__, __LINE__, $db->error());
$bs_heat = array_fill(0, 7, array_fill(0, 24, 0));
$bs_heat_max = 0;
while ($row = $db->fetch_assoc($result))
{
	$dow = intval($row['bucket'] / 86400);
	$hour = intval(($row['bucket'] % 86400) / 3600);
	$bs_heat[$dow][$hour] = (int) $row['n'];
	if ($bs_heat[$dow][$hour] > $bs_heat_max)
		$bs_heat_max = $bs_heat[$dow][$hour];
}

$bs_ms = (int) round((microtime(true) - $bs_start) * 1000);

// ---------------------------------------------------------------------------
// Render helpers
// ---------------------------------------------------------------------------

//
// Horizontal bar list (label, count, scaled bar)
//
function bs_bars($rows, $label_key, $count_key)
{
	$max = 0;
	foreach ($rows as $row)
		$max = max($max, (int) $row[$count_key]);

	if ($max == 0)
	{
		echo "\t\t\t\t".'<p>No activity in this period yet.</p>'."\n";
		return;
	}

	echo "\t\t\t\t".'<table style="width: 100%; border-collapse: collapse;">'."\n";
	foreach ($rows as $row)
	{
		$pct = max(1, (int) round((int) $row[$count_key] / $max * 100));
		echo "\t\t\t\t".'<tr>'
			.'<td style="width: 34%; padding: 2px 8px 2px 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 0;">'.pun_htmlspecialchars($row[$label_key]).'</td>'
			.'<td style="width: 8%; padding: 2px 8px 2px 0; text-align: right;">'.forum_number_format($row[$count_key]).'</td>'
			.'<td><div style="height: 11px; width: '.$pct.'%; background: #5a7fa6; border-radius: 2px;"></div></td>'
			.'</tr>'."\n";
	}
	echo "\t\t\t\t".'</table>'."\n";
}

//
// Vertical column strip for time series (assoc bucket => count, gaps filled)
//
function bs_columns($series, $title)
{
	$max = max(1, empty($series) ? 0 : max($series));

	echo "\t\t\t\t".'<p style="margin: 8px 0 2px;"><strong>'.pun_htmlspecialchars($title).'</strong></p>'."\n";
	echo "\t\t\t\t".'<div style="display: flex; align-items: flex-end; gap: 2px; height: 64px;">'."\n";
	foreach ($series as $label => $n)
	{
		$h = ($n == 0) ? 1 : max(2, (int) round($n / $max * 64));
		echo "\t\t\t\t\t".'<div title="'.pun_htmlspecialchars($label.': '.$n).'" style="flex: 1; height: '.$h.'px; background: '.($n == 0 ? 'rgba(128,128,128,.25)' : '#5a7fa6').'; border-radius: 1px 1px 0 0;"></div>'."\n";
	}
	echo "\t\t\t\t".'</div>'."\n";
}

// Fill day gaps for the 30-day strips (oldest → newest)
function bs_fill_days($daily, $days, $now)
{
	$out = array();
	$today = $now - ($now % 86400);
	for ($i = $days - 1; $i >= 0; $i--)
	{
		$bucket = $today - $i * 86400;
		$out[gmdate('j M', $bucket)] = $daily[$bucket] ?? 0;
	}

	return $out;
}

// Fill month gaps for the 12-month strips (oldest → newest)
function bs_fill_months($monthly, $months, $now)
{
	$out = array();
	for ($i = $months - 1; $i >= 0; $i--)
	{
		$key = gmdate('Y-m', gmmktime(12, 0, 0, (int) gmdate('n', $now) - $i, 15, (int) gmdate('Y', $now)));
		$out[gmdate('M y', gmmktime(12, 0, 0, (int) gmdate('n', $now) - $i, 15, (int) gmdate('Y', $now)))] = $monthly[$key] ?? 0;
	}

	return $out;
}

// ---------------------------------------------------------------------------
// Render
// ---------------------------------------------------------------------------

?>
	<div class="inform">
		<fieldset>
			<legend>Board at a glance</legend>
			<div class="infldset">
				<p>
					<strong><?php echo forum_number_format($bs_users) ?></strong> members
					(<?php echo forum_number_format($bs_regs30) ?> joined in the last 30 days,
					<?php echo forum_number_format($bs_dormant) ?> dormant &gt;90 days) &#160;•&#160;
					<strong><?php echo forum_number_format($bs_topics) ?></strong> topics &#160;•&#160;
					<strong><?php echo forum_number_format($bs_posts) ?></strong> posts
					(<?php echo forum_number_format($bs_posts30) ?> in the last 30 days)
<?php if ($bs_newest): ?>					&#160;•&#160; newest member: <strong><?php echo pun_htmlspecialchars($bs_newest['username']) ?></strong> (<?php echo format_time($bs_newest['registered'], true) ?>)
<?php endif; ?>				</p>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Activity over time</legend>
			<div class="infldset">
<?php
bs_columns(bs_fill_days($bs_daily_posts, 30, $now), 'Posts per day - last 30 days');
bs_columns(bs_fill_days($bs_daily_topics, 30, $now), 'New topics per day - last 30 days');
bs_columns(bs_fill_months($bs_monthly_posts, 12, $now), 'Posts per month - last 12 months');
bs_columns(bs_fill_months($bs_monthly_regs, 12, $now), 'Registrations per month - last 12 months');
?>
				<p style="opacity: .7;">Hover any bar for the exact figure. Buckets are UTC.</p>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Members</legend>
			<div class="infldset">
				<p style="margin: 0 0 2px;"><strong>Most posts, last 30 days</strong></p>
<?php bs_bars($bs_top_30, 'username', 'num_posts'); ?>
				<p style="margin: 12px 0 2px;"><strong>Most posts, all time</strong></p>
<?php bs_bars($bs_top_all, 'username', 'num_posts'); ?>
				<p style="margin: 12px 0 2px;"><strong>Members by group</strong></p>
<?php bs_bars($bs_groups, 'g_title', 'n'); ?>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Content</legend>
			<div class="infldset">
				<p style="margin: 0 0 2px;"><strong>Busiest forums, last 30 days</strong></p>
<?php bs_bars($bs_busy_forums, 'forum_name', 'n'); ?>
				<p style="margin: 12px 0 2px;"><strong>Busiest topics, last 30 days</strong></p>
<?php bs_bars($bs_busy_topics, 'subject', 'n'); ?>
				<p style="margin: 12px 0 2px;"><strong>When the board is busy</strong> (posts by hour and weekday, last 90 days, UTC)</p>
				<table style="border-collapse: collapse;">
<?php
$bs_days = array('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun');
echo "\t\t\t\t".'<tr><td></td>';
for ($h = 0; $h < 24; $h++)
	echo '<td style="font-size: .75em; opacity: .7; padding: 0 1px; text-align: center;">'.(($h % 3 == 0) ? sprintf('%02d', $h) : '').'</td>';
echo '</tr>'."\n";
for ($d = 0; $d < 7; $d++)
{
	echo "\t\t\t\t".'<tr><td style="font-size: .8em; opacity: .8; padding-right: 6px;">'.$bs_days[$d].'</td>';
	for ($h = 0; $h < 24; $h++)
	{
		$n = $bs_heat[$d][$h];
		$alpha = ($bs_heat_max > 0) ? round($n / $bs_heat_max, 2) : 0;
		echo '<td title="'.$bs_days[$d].' '.sprintf('%02d', $h).':00 - '.$n.' post'.($n == 1 ? '' : 's').'" style="width: 16px; height: 14px; background: rgba(90,127,166,'.max($alpha, ($n > 0 ? 0.12 : 0.03)).'); border: 1px solid rgba(128,128,128,.15);"></td>';
	}
	echo '</tr>'."\n";
}
?>
				</table>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<div class="forminfo">
			<p>Computed live in <?php echo $bs_ms ?> ms — nothing is stored, no background jobs run. Reload the page to refresh.</p>
		</div>
	</div>
<?php
