# Board Statistics for eveBB

One clean dashboard for administrators: how active the board is, who's
posting, and where — computed live from the board's own tables.

## What it shows

**Board at a glance** — members (with 30-day joins and >90-day dormant
count), topics, posts, newest member.

**Activity over time** — posts per day and new topics per day for the
last 30 days, posts per month and registrations per month for the last
12 months. Hover any bar for the exact figure.

**Members** — most posts in the last 30 days, most posts all time,
members by group.

**Content** — busiest forums and topics of the last 30 days, plus a
posting heatmap by hour and weekday (last 90 days) that shows when your
board is actually alive.

## Design principles

- **Nothing is stored, nothing runs in the background.** Every view is
  a handful of aggregate queries computed on demand (the page footer
  shows how long they took — typically a few milliseconds).
- **No external libraries.** Charts and the heatmap are plain HTML/CSS,
  so the page works on any host, offline, forever.
- **Portable.** Time bucketing is pure integer arithmetic on the stored
  timestamps and works identically on MySQL, PostgreSQL and SQLite.
  All buckets are UTC.

## Install

Upload the zip through Administration → Plugins, activate, and open the
plugin's settings entry — that *is* the dashboard. Admin-only (the admin
console already is). No database changes at all; deactivate to remove.

License: GPL v2 or higher, same as eveBB.
