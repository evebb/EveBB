<?php

/**
 * Post to Social - the manual share page.
 *
 *   <board>/plugins/socialpost/share.php?tid=<topic id>
 *
 * Admins and moderators land here from the "Share to social" link on a
 * topic page. The page shows the post text built from the template, lets
 * the sharer edit it and tick the networks to publish to, then posts and
 * reports per-network results. Every attempt is written to the share log,
 * and networks the topic already went to are marked (re-sharing is allowed
 * but has to be ticked deliberately).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

if (!in_array('socialpost', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

// Staff only: admins and members of moderator groups
if ($pun_user['is_guest'] || ($pun_user['g_id'] != PUN_ADMIN && $pun_user['g_moderator'] != '1'))
	message($lang_common['No permission'], false, '403 Forbidden');

evebb_socialpost_ensure_schema();

$tid = isset($_REQUEST['tid']) ? (int) $_REQUEST['tid'] : 0;
if ($tid < 1)
	message($lang_common['Bad request'], false, '404 Not Found');

$cfg = evebb_socialpost_capture_cfg();
$topic = evebb_socialpost_topic($db, $tid, $cfg['base_url']);
if ($topic === null)
	message($lang_common['Bad request'], false, '404 Not Found');

$networks = evebb_socialpost_configured_networks();
if (empty($networks))
	message('No social network is configured yet. Add credentials on the plugin settings page first.');

$guest_ok = evebb_socialpost_guest_can_read($db, $topic['forum_id']);

$results = null;
$text = evebb_socialpost_text($topic, $cfg);

// ---- Publish --------------------------------------------------------------
if (isset($_POST['do_share']))
{
	check_csrf($_POST['csrf_token'] ?? null);

	$text = pun_trim((string) ($_POST['share_text'] ?? ''));
	$chosen = isset($_POST['networks']) && is_array($_POST['networks']) ? $_POST['networks'] : array();

	if ($text === '')
		message('The post text cannot be empty.');

	$results = array();
	foreach ($chosen as $network)
	{
		if (!isset($networks[$network]))
			continue;

		$r = evebb_socialpost_publish($network, $text, $topic['url'], $cfg);
		evebb_socialpost_record($db, $tid, $network, 'manual', $pun_user['id'], $r['ok'], $r['remote_id'], $r['detail']);
		$results[$network] = $r;
	}

	if (empty($results))
		$results = false; // nothing ticked
}

// ---- Share history for this topic -----------------------------------------
$history = array();
$result = $db->query('SELECT network, mode, posted_at, status, detail FROM '.$db->prefix.'socialpost_log WHERE topic_id='.$tid.' ORDER BY id DESC') or error('Unable to fetch share log', __FILE__, __LINE__, $db->error());
while ($row = $db->fetch_assoc($result))
	$history[] = $row;

$posted_to = array();
foreach ($history as $h)
{
	if ($h['status'] == 'ok')
		$posted_to[$h['network']] = true;
}

// The per-request transaction common.php opened must be closed by
// standalone pages before output.
$db->end_transaction();

$board_title = pun_htmlspecialchars($pun_config['o_board_title']);

header('Content-Type: text/html; charset=utf-8');

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="robots" content="noindex" />
<title>Share to social - <?php echo $board_title ?></title>
<style>
body { font: 14px/1.5 Verdana, Arial, Helvetica, sans-serif; color: #333; background: #f4f4f4; margin: 0; padding: 1.5em; }
.wrap { max-width: 46em; margin: 0 auto; background: #fff; border: 1px solid #ddd; border-radius: 4px; padding: 1.5em 2em; }
h1 { font-size: 1.3em; margin-top: 0; }
h2 { font-size: 1.05em; border-bottom: 1px solid #eee; padding-bottom: .3em; }
textarea { width: 100%; box-sizing: border-box; font: inherit; padding: .5em; border: 1px solid #ccc; border-radius: 3px; }
label.net { display: block; margin: .3em 0; }
.btn { background: #2e6da4; color: #fff; border: 0; border-radius: 3px; padding: .5em 1.2em; font: inherit; cursor: pointer; }
.ok { color: #2d7a2d; } .fail { color: #b33; }
.warn { background: #fff6e0; border: 1px solid #e6ce8c; border-radius: 3px; padding: .6em .8em; }
.meta { color: #777; font-size: .92em; }
table { border-collapse: collapse; width: 100%; font-size: .92em; }
th, td { text-align: left; padding: .3em .5em; border-bottom: 1px solid #eee; }
a { color: #2e6da4; }
</style>
</head>
<body>
<div class="wrap">
	<h1>Share to social</h1>
	<p class="meta"><strong><?php echo pun_htmlspecialchars($topic['subject']) ?></strong> in <?php echo pun_htmlspecialchars($topic['forum_name']) ?> &mdash; <a href="<?php echo pun_htmlspecialchars($topic['url']) ?>">back to the topic</a></p>

<?php if (!$guest_ok): ?>
	<p class="warn"><strong>Heads up:</strong> guests cannot read this forum. Sharing will publish the subject and excerpt to public social media anyway &mdash; make sure that is what you want.</p>
<?php endif; ?>

<?php if (is_array($results)): ?>
	<h2>Results</h2>
	<table>
		<tbody>
<?php foreach ($results as $network => $r): ?>
			<tr>
				<td><?php echo pun_htmlspecialchars($networks[$network]) ?></td>
				<td class="<?php echo $r['ok'] ? 'ok' : 'fail' ?>"><?php echo $r['ok'] ? 'Posted' : 'Failed: '.pun_htmlspecialchars($r['detail']) ?></td>
			</tr>
<?php endforeach; ?>
		</tbody>
	</table>
	<p><a href="<?php echo pun_htmlspecialchars($topic['url']) ?>">Back to the topic</a></p>
<?php elseif ($results === false): ?>
	<p class="warn">Nothing was posted &mdash; no network was ticked.</p>
<?php endif; ?>

	<form method="post" action="share.php?tid=<?php echo $tid ?>">
		<input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token() ?>" />
		<h2>Post text</h2>
		<textarea name="share_text" rows="8"><?php echo pun_htmlspecialchars($text) ?></textarea>
		<p class="meta">Instagram publishes this as the caption on the configured card image. Links are not clickable in Instagram captions.</p>

		<h2>Post to</h2>
<?php foreach ($networks as $key => $label): ?>
		<label class="net"><input type="checkbox" name="networks[]" value="<?php echo $key ?>"<?php if (!isset($posted_to[$key])) echo ' checked="checked"' ?> /> <?php echo pun_htmlspecialchars($label) ?><?php if (isset($posted_to[$key])) echo ' <span class="meta">(already shared &mdash; tick again to re-share)</span>' ?></label>
<?php endforeach; ?>

		<p><button type="submit" name="do_share" value="1" class="btn">Share now</button></p>
	</form>

<?php if (!empty($history)): ?>
	<h2>Share history for this topic</h2>
	<table>
		<thead><tr><th>Network</th><th>How</th><th>When</th><th>Result</th></tr></thead>
		<tbody>
<?php foreach ($history as $h): ?>
			<tr>
				<td><?php echo pun_htmlspecialchars($h['network']) ?></td>
				<td><?php echo pun_htmlspecialchars($h['mode']) ?></td>
				<td><?php echo format_time($h['posted_at']) ?></td>
				<td class="<?php echo $h['status'] == 'ok' ? 'ok' : 'fail' ?>"><?php echo $h['status'] == 'ok' ? 'ok' : pun_htmlspecialchars($h['detail']) ?></td>
			</tr>
<?php endforeach; ?>
		</tbody>
	</table>
<?php endif; ?>
</div>
</body>
</html>
