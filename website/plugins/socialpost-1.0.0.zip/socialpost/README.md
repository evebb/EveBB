# Post to Social for eveBB

Shares board topics to the board's social media accounts — a **Facebook
Page**, an **Instagram** professional account and **LinkedIn**.

Two ways to share:

* **Automatic** — every new topic started in forums you tick (announcement
  and release forums are the natural picks) is posted to the networks you
  enable, right after the topic is created. Auto-posting only ever shares
  topics a guest could read, and never posts the same topic to the same
  network twice.
* **Manual** — admins and moderators get a *Share to social* link at the
  bottom of every topic page. It opens a preview where the text can be
  edited and networks ticked per share. Re-sharing is possible but has to
  be ticked deliberately.

The post text is built from a template with `{subject}`, `{excerpt}`,
`{url}`, `{forum}` and `{board}` placeholders. Every attempt (success or
failure, with the API's error message) is kept in a share log shown on the
settings page and on each topic's share screen.

## Installation

1. Upload the `socialpost` folder to your board's `plugins/` directory.
2. Activate it in Administration → Plugins.
3. Open its settings page and add credentials for the networks you use
   (see below), tick the forums and networks for auto-posting, and use the
   per-network **Test connection** buttons to confirm everything works.

Requires eveBB 2.0+ (or FluxBB 1.5 with the eveBB plugin manager). Uses
cURL when available, with a PHP streams fallback.

## Credentials — where each one comes from

The plugin deliberately performs **no OAuth flow**: you paste tokens
obtained from each platform's own developer tooling. Saved tokens are
write-only — the settings page never displays them again, only a stub.

### Facebook Page

You need a Facebook Page you admin and a (free) Meta developer app. The
app can stay in Development mode — posting to your **own** Page needs no
App Review.

1. developers.facebook.com → create an app (Business type).
2. Graph API Explorer: select your app, add the `pages_manage_posts` and
   `pages_show_list` permissions, generate a User token, then use
   the Explorer's `/me/accounts` call — the response contains each Page's
   `id` and a Page `access_token`.
3. Exchange the user token for a long-lived one (Token Debugger → Extend),
   then re-fetch `/me/accounts`: Page tokens obtained this way **do not
   expire**.
4. Paste the Page ID and Page token into the settings page.

### Instagram

The account must be a **professional** (Business or Creator) account.
Instagram cannot publish text-only posts, so every share is the post text
as a caption on a **card image** — a public https URL you configure once
(your board's social card is ideal). Two API routes work; pick whichever
you set up:

* **Instagram login** (default, no Facebook Page needed): create an
  Instagram app at developers.facebook.com, add your account as an app
  tester, and generate a long-lived access token (~60 days; the settings
  page reminds you when it is getting old). API host stays
  `graph.instagram.com`.
* **Facebook login**: if your Instagram is linked to your Facebook Page,
  you can use the same Meta app as above with the
  `instagram_basic` + `instagram_content_publish` permissions and the
  `graph.facebook.com` host.

The Instagram user ID is returned by `/me?fields=user_id,username`
(Instagram login) or `/{page-id}?fields=instagram_business_account`
(Facebook login).

### LinkedIn

Posting to a **member profile** is self-serve; posting as an
**organization page** requires LinkedIn's partner-programme approval —
if you have it, the same settings work with an organization URN and token.

1. linkedin.com/developers → create an app, add the **Share on LinkedIn**
   and **Sign In with LinkedIn using OpenID Connect** products.
2. Use the developer portal's **token generator** tool to create an access
   token with the `w_member_social`, `openid` and `profile` scopes.
3. Your author URN is `urn:li:person:<id>` — the `sub` field returned by
   `https://api.linkedin.com/v2/userinfo` with that token.
4. Paste the token and URN into the settings page. Tokens last ~60 days;
   the settings page reminds you when a replacement is due.

## Notes

* Auto-posting is best-effort with a short timeout and runs after the
  poster has already been redirected — a slow or dead API never delays
  anyone. Failures are recorded in the share log; use *Share to social*
  on the topic to retry.
* The `o_socialpost_api_base` config value (no UI) reroutes all API calls
  to one base URL. It exists for the test suite; never set it on a live
  board.
* Uninstall cleanly from the settings page (removes the log table and all
  settings **including saved tokens**), then deactivate and delete the
  plugin.

## License

GPL version 2 or higher, like eveBB itself.
