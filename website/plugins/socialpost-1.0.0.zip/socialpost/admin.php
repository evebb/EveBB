<?php

/**
 * Post to Social - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome and inside a single
 * POST form (footer.php injects the CSRF token). $db, $pun_config and
 * $plugin_slug are available.
 *
 * Access tokens are WRITE-ONLY: once saved, the form shows only a stub
 * ("set, ends ...abcd"). Leave a token field blank to keep the saved value;
 * paste a new value to replace it; tick the clear box to remove it.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

evebb_socialpost_ensure_schema();

$all_networks = evebb_socialpost_networks();
$redir = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

//
// Save a pasted secret honouring write-only semantics: blank keeps, new
// value replaces, the clear tick removes. Returns true when it changed.
//
function evebb_socialpost_save_secret($conf_name, $field, $clear_field)
{
	$new = isset($_POST[$field]) ? pun_trim($_POST[$field]) : '';

	if (isset($_POST[$clear_field]))
	{
		evebb_socialpost_save_conf($conf_name, '');
		return true;
	}
	if ($new !== '')
	{
		evebb_socialpost_save_conf($conf_name, $new);
		return true;
	}
	return false;
}

// ---- Save settings ---------------------------------------------------------
if (isset($_POST['save_socialpost']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	// Auto-post forums + networks
	$forums = array();
	if (isset($_POST['auto_forums']) && is_array($_POST['auto_forums']))
	{
		foreach ($_POST['auto_forums'] as $fid)
		{
			$fid = (int) $fid;
			if ($fid > 0)
				$forums[] = $fid;
		}
	}
	evebb_socialpost_save_conf('o_socialpost_forums', implode(',', $forums));

	$auto = array();
	if (isset($_POST['auto_networks']) && is_array($_POST['auto_networks']))
	{
		foreach ($_POST['auto_networks'] as $key)
		{
			if (isset($all_networks[$key]))
				$auto[] = $key;
		}
	}
	evebb_socialpost_save_conf('o_socialpost_auto_networks', implode(',', $auto));

	// Text building
	$template = pun_trim($_POST['template'] ?? '');
	evebb_socialpost_save_conf('o_socialpost_template', pun_strlen($template) > 1000 ? '' : $template);

	$elen = (int) ($_POST['excerpt_len'] ?? 200);
	evebb_socialpost_save_conf('o_socialpost_excerpt_len', (string) max(20, min(1500, $elen)));

	$timeout = (int) ($_POST['timeout'] ?? 10);
	evebb_socialpost_save_conf('o_socialpost_timeout', (string) max(1, min(30, $timeout)));

	// Facebook
	evebb_socialpost_save_conf('o_socialpost_fb_page_id', pun_trim($_POST['fb_page_id'] ?? ''));
	evebb_socialpost_save_conf('o_socialpost_fb_ver', pun_trim($_POST['fb_ver'] ?? ''));
	evebb_socialpost_save_secret('o_socialpost_fb_token', 'fb_token', 'fb_token_clear');

	// Instagram
	evebb_socialpost_save_conf('o_socialpost_ig_user_id', pun_trim($_POST['ig_user_id'] ?? ''));
	evebb_socialpost_save_conf('o_socialpost_ig_host', ($_POST['ig_host'] ?? '') === 'graph.facebook.com' ? 'graph.facebook.com' : 'graph.instagram.com');
	$ig_image = pun_trim($_POST['ig_image'] ?? '');
	evebb_socialpost_save_conf('o_socialpost_ig_image', preg_match('%^https://%i', $ig_image) ? $ig_image : '');
	if (evebb_socialpost_save_secret('o_socialpost_ig_token', 'ig_token', 'ig_token_clear'))
		evebb_socialpost_save_conf('o_socialpost_ig_saved_at', (string) time());

	// LinkedIn
	evebb_socialpost_save_conf('o_socialpost_li_urn', pun_trim($_POST['li_urn'] ?? ''));
	evebb_socialpost_save_conf('o_socialpost_li_ver', pun_trim($_POST['li_ver'] ?? ''));
	if (evebb_socialpost_save_secret('o_socialpost_li_token', 'li_token', 'li_token_clear'))
		evebb_socialpost_save_conf('o_socialpost_li_saved_at', (string) time());

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect($redir, 'Settings saved. Redirecting …');
}

// ---- Connection tests ------------------------------------------------------
$test_result = null;
if (isset($_POST['test_network']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$net = $_POST['test_network'];
	if (isset($all_networks[$net]) && evebb_socialpost_configured($net))
	{
		list($ok, $label) = evebb_socialpost_test($net, evebb_socialpost_capture_cfg());
		$test_result = array($net, $ok, $label);
	}
	else
		$test_result = array($net, false, 'not fully configured yet');
}

// ---- Remove all plugin data ------------------------------------------------
if (isset($_POST['nuke_socialpost']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect($redir, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('socialpost_log');
	$names = array();
	foreach (evebb_socialpost_conf_names() as $n)
	{
		$names[] = '\''.$db->escape($n).'\'';
		unset($pun_config[$n]);
	}
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN ('.implode(', ', $names).')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Post to Social data removed. You can now deactivate and delete the plugin. Redirecting …');
}

// ---- Read current state ----------------------------------------------------
$auto_forums = evebb_socialpost_auto_forums();
$auto_nets   = array_map('trim', explode(',', evebb_socialpost_conf('o_socialpost_auto_networks')));
$template    = evebb_socialpost_conf('o_socialpost_template');
if (trim($template) === '')
	$template = "{subject}\n\n{excerpt}\n\n{url}";
$excerpt_len = (int) evebb_socialpost_conf('o_socialpost_excerpt_len', '200');
$timeout     = (int) evebb_socialpost_conf('o_socialpost_timeout', '10');

// Forum tree for the auto-post picker
$forum_tree = array();
$result = $db->query('SELECT c.cat_name, f.id, f.forum_name FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON f.cat_id=c.id ORDER BY c.disp_position, c.id, f.disp_position') or error('Unable to fetch forum list', __FILE__, __LINE__, $db->error());
while ($row = $db->fetch_assoc($result))
	$forum_tree[$row['cat_name']][] = $row;

// Recent share log
$log = array();
$result = $db->query('SELECT l.topic_id, l.network, l.mode, l.posted_at, l.status, l.detail, t.subject FROM '.$db->prefix.'socialpost_log AS l LEFT JOIN '.$db->prefix.'topics AS t ON t.id=l.topic_id ORDER BY l.id DESC LIMIT 20') or error('Unable to fetch share log', __FILE__, __LINE__, $db->error());
while ($row = $db->fetch_assoc($result))
	$log[] = $row;

// Token freshness notes (IG and LinkedIn tokens last ~60 days)
function evebb_socialpost_age_note($saved_at_conf)
{
	$t = (int) evebb_socialpost_conf($saved_at_conf, '0');
	if ($t === 0)
		return '';

	$days = (int) floor((time() - $t) / 86400);
	$left = 60 - $days;
	if ($left <= 7)
		return ' <strong style="color:#b33">Saved '.$days.' days ago &mdash; these tokens last about 60 days, replace it soon.</strong>';
	return ' <span style="opacity:.7">Saved '.$days.' days ago (tokens last about 60 days).</span>';
}

?>
		<div class="inform">
			<fieldset>
				<legend>Post to Social</legend>
				<div class="infldset">
					<p>Shares topics from this board to its social media accounts. New topics in the forums ticked below are posted <strong>automatically</strong> to the networks enabled for auto-posting; admins and moderators also get a <strong>Share to social</strong> link on every topic page for one-off shares with a preview. Auto-posting only ever shares topics a guest could read. Where each credential comes from is explained step by step in the plugin's README.</p>
<?php if ($test_result !== null): list($tn, $tok, $tlabel) = $test_result; ?>
					<p><strong><?php echo isset($all_networks[$tn]) ? pun_htmlspecialchars($all_networks[$tn]) : 'Test' ?>:</strong> <span style="color:<?php echo $tok ? '#2d7a2d' : '#b33' ?>"><?php echo pun_htmlspecialchars($tlabel) ?></span></p>
<?php endif; ?>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Automatic posting</legend>
				<div class="infldset">
					<p>Post new topics from these forums (announcements and release forums are the natural picks &mdash; every new topic here goes out, so keep it to forums where only staff start topics):</p>
<?php foreach ($forum_tree as $cat => $forums): ?>
					<p style="margin-bottom:.2em"><strong><?php echo pun_htmlspecialchars($cat) ?></strong></p>
<?php foreach ($forums as $f): ?>
					<label style="display:inline-block;margin:0 1em .2em 1em"><input type="checkbox" name="auto_forums[]" value="<?php echo (int) $f['id'] ?>"<?php if (in_array((int) $f['id'], $auto_forums, true)) echo ' checked="checked"' ?> /> <?php echo pun_htmlspecialchars($f['forum_name']) ?></label>
<?php endforeach; ?>
					<br />
<?php endforeach; ?>
					<p class="topspace">To these networks (only fully-configured networks actually post):</p>
<?php foreach ($all_networks as $key => $label): ?>
					<label style="display:inline-block;margin-right:1em"><input type="checkbox" name="auto_networks[]" value="<?php echo $key ?>"<?php if (in_array($key, $auto_nets, true)) echo ' checked="checked"' ?> /> <?php echo pun_htmlspecialchars($label) ?><?php if (!evebb_socialpost_configured($key)) echo ' <span style="opacity:.6">(not configured)</span>' ?></label>
<?php endforeach; ?>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Post text</legend>
				<div class="infldset">
					<p>Template &mdash; placeholders: <code>{subject}</code>, <code>{excerpt}</code>, <code>{url}</code>, <code>{forum}</code>, <code>{board}</code>:</p>
					<textarea name="template" rows="4" cols="60"><?php echo pun_htmlspecialchars($template) ?></textarea>
					<label>Excerpt length in characters (20&ndash;1500)<br /><input type="text" name="excerpt_len" size="5" maxlength="4" value="<?php echo $excerpt_len ?>" /></label>
					<label>API request timeout in seconds (1&ndash;30)<br /><input type="text" name="timeout" size="4" maxlength="2" value="<?php echo $timeout ?>" /></label>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Facebook Page</legend>
				<div class="infldset">
					<label>Page ID<br /><input type="text" name="fb_page_id" size="30" maxlength="64" value="<?php echo pun_htmlspecialchars(evebb_socialpost_conf('o_socialpost_fb_page_id')) ?>" /></label>
					<label>Page access token (long-lived Page tokens do not expire) <?php echo evebb_socialpost_token_stub('o_socialpost_fb_token') ?><br /><input type="password" name="fb_token" size="50" autocomplete="new-password" value="" placeholder="paste to set or replace" /></label>
					<label><input type="checkbox" name="fb_token_clear" value="1" /> Clear the saved token</label>
					<label>Graph API version<br /><input type="text" name="fb_ver" size="8" maxlength="8" value="<?php echo pun_htmlspecialchars(evebb_socialpost_conf('o_socialpost_fb_ver', 'v23.0')) ?>" /></label>
					<p><button type="submit" name="test_network" value="facebook">Test Facebook connection</button></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Instagram</legend>
				<div class="infldset">
					<p>Instagram cannot publish text-only posts: every share is the text as a <strong>caption on the card image below</strong>. The account must be a professional (Business or Creator) account.</p>
					<label>Instagram user ID<br /><input type="text" name="ig_user_id" size="30" maxlength="64" value="<?php echo pun_htmlspecialchars(evebb_socialpost_conf('o_socialpost_ig_user_id')) ?>" /></label>
					<label>Access token <?php echo evebb_socialpost_token_stub('o_socialpost_ig_token') ?><?php echo evebb_socialpost_age_note('o_socialpost_ig_saved_at') ?><br /><input type="password" name="ig_token" size="50" autocomplete="new-password" value="" placeholder="paste to set or replace" /></label>
					<label><input type="checkbox" name="ig_token_clear" value="1" /> Clear the saved token</label>
					<p>API host:</p>
					<label style="display:inline-block;margin-right:1em"><input type="radio" name="ig_host" value="graph.instagram.com"<?php if (evebb_socialpost_conf('o_socialpost_ig_host', 'graph.instagram.com') != 'graph.facebook.com') echo ' checked="checked"' ?> /> graph.instagram.com (Instagram login)</label>
					<label style="display:inline-block"><input type="radio" name="ig_host" value="graph.facebook.com"<?php if (evebb_socialpost_conf('o_socialpost_ig_host') == 'graph.facebook.com') echo ' checked="checked"' ?> /> graph.facebook.com (Facebook login)</label>
					<label>Card image URL (public https, JPEG recommended, square or 4:5)<br /><input type="text" name="ig_image" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars(evebb_socialpost_conf('o_socialpost_ig_image')) ?>" placeholder="https://example.com/img/social-card.jpg" /></label>
					<p><button type="submit" name="test_network" value="instagram">Test Instagram connection</button></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>LinkedIn</legend>
				<div class="infldset">
					<p>Posts to the member profile (or organization, if your token carries that scope) named by the author URN.</p>
					<label>Author URN (e.g. <code>urn:li:person:AbC123</code> or <code>urn:li:organization:12345</code>)<br /><input type="text" name="li_urn" size="40" maxlength="128" value="<?php echo pun_htmlspecialchars(evebb_socialpost_conf('o_socialpost_li_urn')) ?>" /></label>
					<label>Access token <?php echo evebb_socialpost_token_stub('o_socialpost_li_token') ?><?php echo evebb_socialpost_age_note('o_socialpost_li_saved_at') ?><br /><input type="password" name="li_token" size="50" autocomplete="new-password" value="" placeholder="paste to set or replace" /></label>
					<label><input type="checkbox" name="li_token_clear" value="1" /> Clear the saved token</label>
					<label>API version (YYYYMM)<br /><input type="text" name="li_ver" size="8" maxlength="6" value="<?php echo pun_htmlspecialchars(evebb_socialpost_conf('o_socialpost_li_ver', '202506')) ?>" /></label>
					<p><button type="submit" name="test_network" value="linkedin">Test LinkedIn connection</button></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Save</legend>
				<div class="infldset">
					<p><input type="submit" name="save_socialpost" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>

<?php if (!empty($log)): ?>
		<div class="inform">
			<fieldset>
				<legend>Recent shares</legend>
				<div class="infldset">
					<table>
						<thead>
							<tr><th>Topic</th><th>Network</th><th>How</th><th>When</th><th>Result</th></tr>
						</thead>
						<tbody>
<?php foreach ($log as $l): ?>
							<tr>
								<td><a href="viewtopic.php?id=<?php echo (int) $l['topic_id'] ?>"><?php echo pun_htmlspecialchars($l['subject'] !== null ? $l['subject'] : 'topic #'.$l['topic_id']) ?></a></td>
								<td><?php echo pun_htmlspecialchars($l['network']) ?></td>
								<td><?php echo pun_htmlspecialchars($l['mode']) ?></td>
								<td><?php echo format_time($l['posted_at']) ?></td>
								<td style="color:<?php echo $l['status'] == 'ok' ? '#2d7a2d' : '#b33' ?>"><?php echo $l['status'] == 'ok' ? 'ok' : pun_htmlspecialchars($l['detail']) ?></td>
							</tr>
<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</fieldset>
		</div>
<?php endif; ?>

		<div class="inform">
			<fieldset>
				<legend>Uninstall</legend>
				<div class="infldset">
					<p>To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the socialpost_log table and all of this plugin's settings <strong>including the saved access tokens</strong>.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently deletes the share log and every saved credential</label></p>
					<p><input type="submit" name="nuke_socialpost" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
