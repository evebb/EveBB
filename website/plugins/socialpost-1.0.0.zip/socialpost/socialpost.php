<?php

/**
 * Post to Social - the addon.
 *
 * Automatically shares new topics from admin-chosen forums to the configured
 * social networks, and gives admins/moderators a "Share to social" link on
 * every topic page (which leads to the manual share/preview page).
 *
 * How auto-posting works (same shape as the webhooks plugin): post.php
 * creates the row and then redirect()s before any hook can read the new id,
 * so the post_after_validation hook arms a shutdown callback. By the time it
 * runs the new ids live in global scope ($new_tid / $new_pid). The callback
 * opens a fresh DB connection, checks this really is a NEW TOPIC (a reply is
 * a new post whose id is not the topic's first post), checks the forum is
 * one of the selected ones AND guest-readable (social is public), dedupes
 * against the share log, builds the text and publishes. Best-effort with a
 * short timeout - the visitor has already been redirected and is never held
 * up by a slow API.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_socialpost extends flux_addon
{
	function register($manager)
	{
		$manager->bind('post_after_validation', array($this, 'on_post'));
		$manager->bind('header_head_end', array($this, 'head'));
	}


	//
	// post.php: a topic or reply passed validation. Capture config and arm
	// the shutdown dispatcher; it decides topic vs reply from the new ids.
	//
	function on_post()
	{
		global $pun_config, $errors;

		if (!empty($errors) || isset($_POST['preview']))
			return;

		// Never configured, or nothing enabled for auto-posting -> no work
		if (!isset($pun_config['o_socialpost_db_rev']))
			return;

		if (isset($GLOBALS['evebb_socialpost_cfg']))
			return;

		$cfg = evebb_socialpost_capture_cfg();
		if (empty($cfg['auto_networks']) || empty($cfg['auto_forums']))
			return;

		$GLOBALS['evebb_socialpost_cfg'] = $cfg;
		register_shutdown_function(array('plugin_socialpost', 'dispatch'));
	}


	//
	// viewtopic.php: offer staff the manual share link. Injected with a dab
	// of JS (the page has no hook near its action links); the link points at
	// plugins/socialpost/share.php which does its own permission checks.
	//
	function head()
	{
		global $pun_config, $pun_user, $id, $is_admmod;

		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		$page = isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : '';
		if ($page != 'viewtopic.php' || empty($is_admmod) || !isset($id))
			return;

		evebb_socialpost_ensure_schema();

		if (count(evebb_socialpost_configured_networks()) == 0)
			return;

		$share_url = get_base_url().'/plugins/socialpost/share.php?tid='.(int) $id;

?>
<script type="text/javascript">
(function () {
	function add() {
		var box = document.querySelector('.postlinksb .inbox');
		if (!box) return;
		var p = document.createElement('p');
		p.className = 'subscribelink clearb';
		var a = document.createElement('a');
		a.href = <?php echo json_encode($share_url, JSON_UNESCAPED_SLASHES) ?>;
		a.appendChild(document.createTextNode('Share to social'));
		p.appendChild(a);
		box.appendChild(p);
	}
	if (document.readyState === 'loading')
		document.addEventListener('DOMContentLoaded', add);
	else
		add();
})();
</script>
<?php
	}


	//
	// Shutdown: reconnect, confirm a new topic in a selected forum, publish.
	//
	static function dispatch()
	{
		if (empty($GLOBALS['evebb_socialpost_cfg']) || empty($GLOBALS['new_pid']))
			return;

		$cfg = $GLOBALS['evebb_socialpost_cfg'];

		global $db_type, $db_host, $db_username, $db_password, $db_name, $db_prefix, $p_connect;
		$db = null;
		require PUN_ROOT.'include/dblayer/common_db.php';

		if (!is_object($db) || !$db->table_exists('socialpost_log'))
			return;

		$pid = (int) $GLOBALS['new_pid'];
		$tid = !empty($GLOBALS['new_tid']) ? (int) $GLOBALS['new_tid'] : 0;
		if ($tid < 1)
		{
			$db->close();
			return;
		}

		// A reply is a new post whose id is NOT the topic's first post
		$is_new_topic = false;
		$res = $db->query('SELECT first_post_id FROM '.$db->prefix.'topics WHERE id='.$tid);
		if ($res && $db->has_rows($res))
			$is_new_topic = ((int) $db->result($res) === $pid);

		if (!$is_new_topic)
		{
			$db->close();
			return;
		}

		$topic = evebb_socialpost_topic($db, $tid, $cfg['base_url']);

		if ($topic === null
			|| !in_array($topic['forum_id'], $cfg['auto_forums'], true)
			|| !evebb_socialpost_guest_can_read($db, $topic['forum_id']))
		{
			$db->close();
			return;
		}

		$text = evebb_socialpost_text($topic, $cfg);

		foreach ($cfg['auto_networks'] as $network)
		{
			if (evebb_socialpost_already_posted($db, $tid, $network))
				continue;

			$r = evebb_socialpost_publish($network, $text, $topic['url'], $cfg);
			evebb_socialpost_record($db, $tid, $network, 'auto', 0, $r['ok'], $r['remote_id'], $r['detail']);
		}

		$db->close();
	}
}
