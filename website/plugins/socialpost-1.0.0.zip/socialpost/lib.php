<?php

/**
 * Post to Social - shared library.
 *
 * Network registry, schema management, config helpers, post-text building,
 * the HTTP client and one publish function per network. Used by the addon
 * (socialpost.php), the manual share page (share.php) and the settings page
 * (admin.php).
 *
 * Networks and what each one needs (all credentials are pasted tokens -
 * the plugin performs no OAuth flow itself; see README.md for where each
 * token comes from):
 *   facebook  - Page ID + a long-lived Page access token (does not expire).
 *   instagram - IG user ID + access token (~60 days, refreshable) + a public
 *               image URL (Instagram cannot publish text-only posts).
 *   linkedin  - member access token (~60 days) + author URN.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


// The networks this plugin can publish to, in display order.
function evebb_socialpost_networks()
{
	return array(
		'facebook'  => 'Facebook Page',
		'instagram' => 'Instagram',
		'linkedin'  => 'LinkedIn'
	);
}


//
// Create the share log table on first use. Guarded by o_socialpost_db_rev so
// the check is free on every later request.
//
function evebb_socialpost_ensure_schema()
{
	global $db, $pun_config;

	if (isset($pun_config['o_socialpost_db_rev']))
		return;

	if (!$db->table_exists('socialpost_log'))
	{
		$schema = array(
			'FIELDS' => array(
				'id' => array(
					'datatype'   => 'SERIAL',
					'allow_null' => false
				),
				'topic_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'network' => array(
					'datatype'   => 'VARCHAR(16)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'mode' => array(
					'datatype'   => 'VARCHAR(8)',
					'allow_null' => false,
					'default'    => '\'auto\''
				),
				'posted_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'posted_by' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'status' => array(
					'datatype'   => 'VARCHAR(8)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'remote_id' => array(
					'datatype'   => 'VARCHAR(128)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'detail' => array(
					'datatype'   => 'VARCHAR(255)',
					'allow_null' => false,
					'default'    => '\'\''
				)
			),
			'PRIMARY KEY' => array('id'),
			'INDEXES' => array(
				'topic_idx' => array('topic_id')
			)
		);

		$db->create_table('socialpost_log', $schema) or error('Unable to create the socialpost_log table', __FILE__, __LINE__, $db->error());
	}

	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_socialpost_db_rev\', \'1\')');
	$pun_config['o_socialpost_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Read a plugin config value with a default
//
function evebb_socialpost_conf($name, $default = '')
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Insert or update a config value (caller refreshes the cache)
//
function evebb_socialpost_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


// Every config key this plugin owns (used by uninstall)
function evebb_socialpost_conf_names()
{
	return array(
		'o_socialpost_db_rev', 'o_socialpost_forums', 'o_socialpost_auto_networks',
		'o_socialpost_template', 'o_socialpost_excerpt_len', 'o_socialpost_timeout',
		'o_socialpost_fb_page_id', 'o_socialpost_fb_token', 'o_socialpost_fb_ver',
		'o_socialpost_ig_user_id', 'o_socialpost_ig_token', 'o_socialpost_ig_host',
		'o_socialpost_ig_image', 'o_socialpost_ig_saved_at',
		'o_socialpost_li_token', 'o_socialpost_li_urn', 'o_socialpost_li_ver',
		'o_socialpost_li_saved_at', 'o_socialpost_api_base'
	);
}


//
// Is a network fully configured (credentials complete)?
//
function evebb_socialpost_configured($network)
{
	switch ($network)
	{
		case 'facebook':
			return evebb_socialpost_conf('o_socialpost_fb_page_id') !== '' && evebb_socialpost_conf('o_socialpost_fb_token') !== '';

		case 'instagram':
			return evebb_socialpost_conf('o_socialpost_ig_user_id') !== '' && evebb_socialpost_conf('o_socialpost_ig_token') !== '' && evebb_socialpost_conf('o_socialpost_ig_image') !== '';

		case 'linkedin':
			return evebb_socialpost_conf('o_socialpost_li_token') !== '' && evebb_socialpost_conf('o_socialpost_li_urn') !== '';
	}

	return false;
}


// All configured networks, in registry order
function evebb_socialpost_configured_networks()
{
	$out = array();
	foreach (evebb_socialpost_networks() as $key => $label)
	{
		if (evebb_socialpost_configured($key))
			$out[$key] = $label;
	}
	return $out;
}


// Networks enabled for automatic posting (configured AND ticked in settings)
function evebb_socialpost_auto_networks()
{
	$list = trim(evebb_socialpost_conf('o_socialpost_auto_networks'));
	if ($list === '')
		return array();

	$wanted = array_map('trim', explode(',', $list));
	$out = array();
	foreach (evebb_socialpost_configured_networks() as $key => $label)
	{
		if (in_array($key, $wanted, true))
			$out[$key] = $label;
	}
	return $out;
}


// Forum ids selected for automatic posting
function evebb_socialpost_auto_forums()
{
	$list = trim(evebb_socialpost_conf('o_socialpost_forums'));
	if ($list === '')
		return array();

	return array_map('intval', explode(',', $list));
}


//
// Show a saved token as a write-only stub ("set, ends ...abcd") - the full
// value is never echoed back into the admin form.
//
function evebb_socialpost_token_stub($conf_name)
{
	$v = evebb_socialpost_conf($conf_name);
	if ($v === '')
		return '';

	return 'set, ends &hellip;'.pun_htmlspecialchars(substr($v, -4));
}


//
// Can a guest read this forum? Auto-posts are public by definition, so the
// dispatcher refuses to share topics a guest could not see. Mirrors core's
// forum_perms check for the guest group: a missing row means readable.
//
function evebb_socialpost_guest_can_read($db, $forum_id)
{
	$forum_id = (int) $forum_id;
	if ($forum_id < 1)
		return false;

	$result = $db->query('SELECT read_forum FROM '.$db->prefix.'forum_perms WHERE forum_id='.$forum_id.' AND group_id='.PUN_GUEST) or error('Unable to check forum permissions', __FILE__, __LINE__, $db->error());

	if (!$db->has_rows($result))
		return true; // no explicit deny

	return (int) $db->result($result) == 1;
}


//
// Strip BBCode down to plain text for excerpts: quotes/code blocks removed
// whole (quoting someone else's words on social is misleading), remaining
// tags unwrapped, whitespace collapsed.
//
function evebb_socialpost_plain($message)
{
	$text = (string) $message;

	// Remove quote and code blocks entirely (non-greedy, tolerate nesting once)
	for ($i = 0; $i < 2; $i++)
		$text = preg_replace('%\[(quote|code)(?:=[^\]]*)?\].*?\[/\1\]%is', ' ', $text);

	// [img=...]...[/img] and [img]...[/img] add nothing as text
	$text = preg_replace('%\[img(?:=[^\]]*)?\].*?\[/img\]%is', ' ', $text);

	// [url=X]label[/url] -> label; [url]X[/url] -> X; unwrap everything else
	$text = preg_replace('%\[url=[^\]]*\](.*?)\[/url\]%is', '$1', $text);
	$text = preg_replace('%\[/?[a-z\*]+(?:=[^\]]*)?\]%i', '', $text);

	return pun_trim(preg_replace('%\s+%u', ' ', $text));
}


// Trim plain text to $len characters on a word boundary, adding an ellipsis
function evebb_socialpost_excerpt($text, $len)
{
	$len = max(20, (int) $len);
	if (pun_strlen($text) <= $len)
		return $text;

	$cut = function_exists('utf8_substr') ? utf8_substr($text, 0, $len) : substr($text, 0, $len);
	$sp = strrpos($cut, ' ');
	if ($sp !== false && $sp > $len / 2)
		$cut = substr($cut, 0, $sp);

	return rtrim($cut, " \t.,;:").'…';
}


//
// Build the post text from the template. Placeholders: {subject}, {url},
// {forum}, {board}, {excerpt}.
//
function evebb_socialpost_text($topic, $cfg)
{
	$template = isset($cfg['template']) && trim($cfg['template']) !== '' ? $cfg['template'] : "{subject}\n\n{excerpt}\n\n{url}";

	$excerpt = evebb_socialpost_excerpt(evebb_socialpost_plain($topic['message']), $cfg['excerpt_len']);

	$text = str_replace(
		array('{subject}', '{url}', '{forum}', '{board}', '{excerpt}'),
		array($topic['subject'], $topic['url'], $topic['forum_name'], $cfg['board_title'], $excerpt),
		$template
	);

	// Collapse the blank lines an empty excerpt leaves behind
	return pun_trim(preg_replace("%\n{3,}%", "\n\n", $text));
}


//
// HTTP client. Returns array(http_code, body, headers_string). Best-effort:
// never throws, short timeout, no redirects followed.
//
function evebb_socialpost_http($method, $url, $headers, $body, $timeout)
{
	$timeout = max(1, min(30, (int) $timeout));

	if (function_exists('curl_init'))
	{
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
		if ($body !== null)
			curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_NOSIGNAL, true);
		$resp = curl_exec($ch);
		$code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$hsize = (int) curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$err  = curl_error($ch);
		curl_close($ch);

		if ($resp === false)
			return array(0, $err !== '' ? $err : 'no response', '');

		return array($code, substr($resp, $hsize), substr($resp, 0, $hsize));
	}

	// Stream fallback
	$ctx = stream_context_create(array('http' => array(
		'method'        => $method,
		'header'        => implode("\r\n", $headers),
		'content'       => $body === null ? '' : $body,
		'timeout'       => $timeout,
		'ignore_errors' => true
	)));

	$resp = @file_get_contents($url, false, $ctx);
	$code = 0;
	$hdrs = '';
	if (isset($http_response_header) && is_array($http_response_header))
	{
		$hdrs = implode("\r\n", $http_response_header);
		if (preg_match('%\s(\d{3})\s%', $http_response_header[0], $m))
			$code = (int) $m[1];
	}

	return array($code, $resp === false ? 'no response' : $resp, $hdrs);
}


// A short human label from an API error body (JSON "message"/"error" fields
// when present), capped for the log column.
function evebb_socialpost_err_label($code, $body)
{
	$label = 'http '.$code;
	$j = json_decode($body, true);
	if (is_array($j))
	{
		if (isset($j['error']['message']))
			$label .= ': '.$j['error']['message'];
		else if (isset($j['message']))
			$label .= ': '.$j['message'];
		else if (isset($j['error_message']))
			$label .= ': '.$j['error_message'];
	}
	else if ($code === 0 && $body !== '')
		$label = $body;

	return substr($label, 0, 255);
}


// ---------------------------------------------------------------------------
// Publishers. Each takes the built text plus a cfg array (captured at request
// time so the shutdown dispatcher never touches $pun_config) and returns
// array('ok' => bool, 'remote_id' => string, 'detail' => string).
// ---------------------------------------------------------------------------

//
// API root for a network host. Normally https://<host>; the hidden config
// value o_socialpost_api_base (set directly in the DB - no UI) overrides it,
// which is how the test suite points the publishers at a mock server. Never
// set it on a live board.
//
function evebb_socialpost_api_root($cfg, $host)
{
	if (!empty($cfg['api_base']))
		return rtrim($cfg['api_base'], '/');

	return 'https://'.$host;
}

//
// Facebook Page: one call, message + link. Long-lived Page tokens don't
// expire, so this is the low-maintenance network.
//
function evebb_socialpost_publish_facebook($text, $link, $cfg)
{
	$ver = $cfg['fb_ver'] !== '' ? $cfg['fb_ver'] : 'v23.0';
	$url = evebb_socialpost_api_root($cfg, 'graph.facebook.com').'/'.rawurlencode($ver).'/'.rawurlencode($cfg['fb_page_id']).'/feed';

	$body = http_build_query(array(
		'message'      => $text,
		'link'         => $link,
		'access_token' => $cfg['fb_token']
	));

	list($code, $resp) = evebb_socialpost_http('POST', $url, array('Content-Type: application/x-www-form-urlencoded', 'User-Agent: eveBB-SocialPost/1.0'), $body, $cfg['timeout']);

	$j = json_decode($resp, true);
	if ($code >= 200 && $code < 300 && isset($j['id']))
		return array('ok' => true, 'remote_id' => (string) $j['id'], 'detail' => 'posted');

	return array('ok' => false, 'remote_id' => '', 'detail' => evebb_socialpost_err_label($code, $resp));
}


//
// Instagram: two calls - create a media container (image_url + caption),
// then publish it. Instagram cannot post text-only, so the caption rides on
// the configured card image. Works against either API host: graph.instagram.com
// (Instagram login) or graph.facebook.com (Facebook login), same shapes.
//
function evebb_socialpost_publish_instagram($caption, $cfg)
{
	$host = $cfg['ig_host'] === 'graph.facebook.com' ? 'graph.facebook.com' : 'graph.instagram.com';
	$base = evebb_socialpost_api_root($cfg, $host).'/'.rawurlencode($cfg['fb_ver'] !== '' ? $cfg['fb_ver'] : 'v23.0').'/'.rawurlencode($cfg['ig_user_id']);
	$hdrs = array('Content-Type: application/x-www-form-urlencoded', 'User-Agent: eveBB-SocialPost/1.0');

	// 1: container
	$body = http_build_query(array(
		'image_url'    => $cfg['ig_image'],
		'caption'      => $caption,
		'access_token' => $cfg['ig_token']
	));
	list($code, $resp) = evebb_socialpost_http('POST', $base.'/media', $hdrs, $body, $cfg['timeout']);
	$j = json_decode($resp, true);
	if ($code < 200 || $code >= 300 || !isset($j['id']))
		return array('ok' => false, 'remote_id' => '', 'detail' => 'container: '.evebb_socialpost_err_label($code, $resp));

	// 2: publish
	$body = http_build_query(array(
		'creation_id'  => $j['id'],
		'access_token' => $cfg['ig_token']
	));
	list($code, $resp) = evebb_socialpost_http('POST', $base.'/media_publish', $hdrs, $body, $cfg['timeout']);
	$j = json_decode($resp, true);
	if ($code >= 200 && $code < 300 && isset($j['id']))
		return array('ok' => true, 'remote_id' => (string) $j['id'], 'detail' => 'posted');

	return array('ok' => false, 'remote_id' => '', 'detail' => 'publish: '.evebb_socialpost_err_label($code, $resp));
}


//
// LinkedIn commentary uses "little text format": these characters are markup
// unless backslash-escaped. Escape them so subjects with parentheses or
// asterisks post literally.
//
function evebb_socialpost_li_escape($text)
{
	return preg_replace('%([\\\\|{}@\[\]()<>#*_~])%', '\\\\$1', $text);
}


//
// LinkedIn: Posts API (versioned). Author is the URN saved in settings; the
// new post's id comes back in the x-restli-id response header.
//
function evebb_socialpost_publish_linkedin($text, $cfg)
{
	$ver = $cfg['li_ver'] !== '' ? $cfg['li_ver'] : '202506';

	$payload = array(
		'author'         => $cfg['li_urn'],
		'commentary'     => evebb_socialpost_li_escape($text),
		'visibility'     => 'PUBLIC',
		'distribution'   => array(
			'feedDistribution'               => 'MAIN_FEED',
			'targetEntities'                 => array(),
			'thirdPartyDistributionChannels' => array()
		),
		'lifecycleState' => 'PUBLISHED',
		'isReshareDisabledByAuthor' => false
	);

	$hdrs = array(
		'Content-Type: application/json',
		'Authorization: Bearer '.$cfg['li_token'],
		'LinkedIn-Version: '.$ver,
		'X-Restli-Protocol-Version: 2.0.0',
		'User-Agent: eveBB-SocialPost/1.0'
	);

	list($code, $resp, $rhdrs) = evebb_socialpost_http('POST', evebb_socialpost_api_root($cfg, 'api.linkedin.com').'/rest/posts', $hdrs, json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $cfg['timeout']);

	if ($code >= 200 && $code < 300)
	{
		$rid = '';
		if (preg_match('%^x-restli-id:\s*(\S+)%mi', $rhdrs, $m))
			$rid = $m[1];
		return array('ok' => true, 'remote_id' => $rid, 'detail' => 'posted');
	}

	return array('ok' => false, 'remote_id' => '', 'detail' => evebb_socialpost_err_label($code, $resp));
}


// Publish $text/$link to one network. $cfg is the captured config array.
function evebb_socialpost_publish($network, $text, $link, $cfg)
{
	switch ($network)
	{
		case 'facebook':
			return evebb_socialpost_publish_facebook($text, $link, $cfg);

		case 'instagram':
			return evebb_socialpost_publish_instagram($text, $cfg);

		case 'linkedin':
			return evebb_socialpost_publish_linkedin($text, $cfg);
	}

	return array('ok' => false, 'remote_id' => '', 'detail' => 'unknown network');
}


//
// Cheap read-only connection test per network. Returns array(ok, label).
//
function evebb_socialpost_test($network, $cfg)
{
	$ua = array('User-Agent: eveBB-SocialPost/1.0');

	switch ($network)
	{
		case 'facebook':
			$ver = $cfg['fb_ver'] !== '' ? $cfg['fb_ver'] : 'v23.0';
			list($code, $resp) = evebb_socialpost_http('GET', evebb_socialpost_api_root($cfg, 'graph.facebook.com').'/'.rawurlencode($ver).'/'.rawurlencode($cfg['fb_page_id']).'?fields=name&access_token='.rawurlencode($cfg['fb_token']), $ua, null, $cfg['timeout']);
			$j = json_decode($resp, true);
			if ($code >= 200 && $code < 300 && isset($j['name']))
				return array(true, 'OK - Page "'.$j['name'].'"');
			return array(false, evebb_socialpost_err_label($code, $resp));

		case 'instagram':
			$host = $cfg['ig_host'] === 'graph.facebook.com' ? 'graph.facebook.com' : 'graph.instagram.com';
			$ver = $cfg['fb_ver'] !== '' ? $cfg['fb_ver'] : 'v23.0';
			list($code, $resp) = evebb_socialpost_http('GET', evebb_socialpost_api_root($cfg, $host).'/'.rawurlencode($ver).'/'.rawurlencode($cfg['ig_user_id']).'?fields=username&access_token='.rawurlencode($cfg['ig_token']), $ua, null, $cfg['timeout']);
			$j = json_decode($resp, true);
			if ($code >= 200 && $code < 300 && isset($j['username']))
				return array(true, 'OK - @'.$j['username']);
			return array(false, evebb_socialpost_err_label($code, $resp));

		case 'linkedin':
			list($code, $resp) = evebb_socialpost_http('GET', evebb_socialpost_api_root($cfg, 'api.linkedin.com').'/v2/userinfo', array_merge($ua, array('Authorization: Bearer '.$cfg['li_token'])), null, $cfg['timeout']);
			$j = json_decode($resp, true);
			if ($code >= 200 && $code < 300 && is_array($j))
				return array(true, 'OK - '.(isset($j['name']) ? $j['name'] : 'token valid'));
			return array(false, evebb_socialpost_err_label($code, $resp));
	}

	return array(false, 'unknown network');
}


//
// Capture everything the publishers need into one plain array. Done at
// request time (or on the admin/share pages); the shutdown dispatcher gets
// this array and never needs $pun_config.
//
function evebb_socialpost_capture_cfg()
{
	global $pun_config;

	return array(
		'board_title' => isset($pun_config['o_board_title']) ? $pun_config['o_board_title'] : '',
		'base_url'    => get_base_url(),
		'template'    => evebb_socialpost_conf('o_socialpost_template'),
		'excerpt_len' => (int) evebb_socialpost_conf('o_socialpost_excerpt_len', '200'),
		'timeout'     => max(1, min(30, (int) evebb_socialpost_conf('o_socialpost_timeout', '10'))),
		'fb_page_id'  => evebb_socialpost_conf('o_socialpost_fb_page_id'),
		'fb_token'    => evebb_socialpost_conf('o_socialpost_fb_token'),
		'fb_ver'      => evebb_socialpost_conf('o_socialpost_fb_ver'),
		'ig_user_id'  => evebb_socialpost_conf('o_socialpost_ig_user_id'),
		'ig_token'    => evebb_socialpost_conf('o_socialpost_ig_token'),
		'ig_host'     => evebb_socialpost_conf('o_socialpost_ig_host', 'graph.instagram.com'),
		'ig_image'    => evebb_socialpost_conf('o_socialpost_ig_image'),
		'li_token'    => evebb_socialpost_conf('o_socialpost_li_token'),
		'li_urn'      => evebb_socialpost_conf('o_socialpost_li_urn'),
		'li_ver'      => evebb_socialpost_conf('o_socialpost_li_ver'),
		'api_base'    => evebb_socialpost_conf('o_socialpost_api_base'),
		'auto_networks' => array_keys(evebb_socialpost_auto_networks()),
		'auto_forums'   => evebb_socialpost_auto_forums()
	);
}


//
// Fetch the pieces of a topic the text builder needs. $db passed explicitly
// so the shutdown dispatcher can use its reconnected handle.
//
function evebb_socialpost_topic($db, $tid, $base_url)
{
	$result = $db->query('SELECT t.id, t.subject, t.forum_id, t.first_post_id, f.forum_name FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id WHERE t.id='.(int) $tid);
	if (!$result || !$db->has_rows($result))
		return null;
	$t = $db->fetch_assoc($result);

	$message = '';
	$result = $db->query('SELECT message FROM '.$db->prefix.'posts WHERE id='.(int) $t['first_post_id']);
	if ($result && $db->has_rows($result))
		$message = $db->result($result);

	return array(
		'id'         => (int) $t['id'],
		'subject'    => $t['subject'],
		'forum_id'   => (int) $t['forum_id'],
		'forum_name' => $t['forum_name'],
		'message'    => $message,
		'url'        => $base_url.'/viewtopic.php?id='.(int) $t['id']
	);
}


// Has this topic already been posted successfully to this network?
function evebb_socialpost_already_posted($db, $tid, $network)
{
	if (!$db->table_exists('socialpost_log'))
		return false;

	$result = $db->query('SELECT 1 FROM '.$db->prefix.'socialpost_log WHERE topic_id='.(int) $tid.' AND network=\''.$db->escape($network).'\' AND status=\'ok\'') or error('Unable to check share log', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result);
}


// Record one publish attempt
function evebb_socialpost_record($db, $tid, $network, $mode, $uid, $ok, $remote_id, $detail)
{
	$db->query('INSERT INTO '.$db->prefix.'socialpost_log (topic_id, network, mode, posted_at, posted_by, status, remote_id, detail) VALUES('.(int) $tid.', \''.$db->escape($network).'\', \''.$db->escape($mode).'\', '.time().', '.(int) $uid.', \''.($ok ? 'ok' : 'fail').'\', \''.$db->escape(substr($remote_id, 0, 128)).'\', \''.$db->escape(substr($detail, 0, 255)).'\')') or error('Unable to record share', __FILE__, __LINE__, $db->error());
}
