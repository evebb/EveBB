<?php

/**
 * Two-Factor Authentication - the addon.
 *
 * Optional TOTP 2FA per member. Three jobs:
 *
 *  1. Login enforcement: login_before_submit renders an optional
 *     "one-time code" field inside the login form; login_after_validation
 *     (which fires with $authorized, $cur_user and $errors in scope)
 *     refuses a password-valid login for a 2FA-enabled account unless a
 *     fresh TOTP code (never-replayable: slots are consumed) or a
 *     single-use backup code accompanies it. Bad codes join the normal
 *     login error list AND feed the core per-IP login throttle, so codes
 *     cannot be brute-forced faster than passwords.
 *
 *  2. Profile section: on a member's own profile, JS injects a
 *     "Two-factor authentication" block (status + manage link to
 *     plugins/tfa/, where setup/QR/backup codes live).
 *
 *  3. New-member prompt: members registered within the last day who
 *     haven't enabled 2FA see a slim dismissible banner suggesting it
 *     (setting to turn off; dismiss = cookie, 7 days).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_tfa extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
		$manager->bind('login_before_submit', array($this, 'login_field'));
		$manager->bind('login_after_validation', array($this, 'login_check'));
	}


	//
	// The optional code field inside the login form
	//
	function login_field()
	{
?>
						<div class="rbox clearb">
							<label><strong>One-time code</strong><br /><input type="text" name="tfa_code" size="12" maxlength="12" autocomplete="one-time-code" inputmode="numeric" /><br /><small>Only needed if your account uses two-factor authentication (a 6-digit app code or a backup code).</small><br /></label>
						</div>
<?php
	}


	//
	// Enforce 2FA once the password has been accepted. Appending to
	// $errors makes login.php re-render its form with the message - the
	// same path as a wrong password.
	//
	function login_check()
	{
		global $db, $errors, $authorized, $cur_user;

		if (empty($authorized) || !empty($errors) || empty($cur_user['id']) || (int) $cur_user['id'] < 2)
			return;

		evebb_tfa_ensure_schema();

		$row = evebb_tfa_row($cur_user['id']);
		if ($row === null)
			return;

		$code = isset($_POST['tfa_code']) ? pun_trim($_POST['tfa_code']) : '';

		if ($code === '')
		{
			$errors[] = 'This account is protected by two-factor authentication. Enter the 6-digit code from your authenticator app (or one of your backup codes) in the one-time code field.';
			return;
		}

		if (evebb_tfa_check_code($row, $code))
			return;

		$errors[] = 'The one-time code was not valid. Codes expire after 30 seconds and can only be used once - try the next code from your app, or a backup code.';

		// A wrong code counts against the same per-IP throttle as a wrong
		// password, so codes can't be brute-forced within the window
		if (function_exists('login_throttle_record'))
			login_throttle_record(get_remote_address());
	}


	function head()
	{
		// The hook can fire twice in one request when core re-includes
		// header.php (e.g. message() rendering an error page). Act once.
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		evebb_tfa_ensure_schema();

		global $pun_user;

		if ($pun_user['is_guest'])
			return;

		$script = isset($_SERVER['SCRIPT_NAME']) ? (string) $_SERVER['SCRIPT_NAME'] : '';
		$page = basename($script);

		if ($page == 'profile.php')
			$this->head_profile();

		// New-member prompt (not on the setup page itself, and not in the
		// admin console)
		if (strpos($script, '/plugins/tfa/') === false && !defined('PUN_ADMIN_CONSOLE'))
			$this->head_hint();
	}


	//
	// A member's own profile gets the 2FA status/manage section
	//
	function head_profile()
	{
		global $id, $pun_user;

		if (!isset($id) || (int) $id != (int) $pun_user['id'])
			return;

		$row = evebb_tfa_row($pun_user['id']);

		$this->emit(array(
			'page'    => 'profile',
			'enabled' => ($row !== null),
			'since'   => ($row !== null) ? format_time($row['enabled_at']) : null,
			'url'     => 'plugins/tfa/',
			'text'    => array(
				'title'    => 'Two-factor authentication',
				'on'       => 'Enabled',
				'off'      => 'Not enabled',
				'since'    => 'since',
				'manage'   => 'Manage two-factor authentication',
				'enable'   => 'Set up two-factor authentication',
				'blurb'    => 'Protect your account with 6-digit codes from an authenticator app in addition to your password.'
			)
		));
	}


	//
	// The dismissible set-up-2FA prompt for brand-new members
	//
	function head_hint()
	{
		global $pun_user;

		if (evebb_tfa_conf('o_tfa_hint', '1') != '1')
			return;

		if (isset($_COOKIE['evebb_tfa_hint']))
			return;

		if (time() - (int) $pun_user['registered'] > 86400)
			return;

		if (evebb_tfa_row($pun_user['id']) !== null)
			return;

		$this->emit(array(
			'page' => 'hint',
			'url'  => 'plugins/tfa/',
			'text' => array(
				'msg'     => 'Welcome! You can protect your new account with two-factor authentication.',
				'go'      => 'Set it up',
				'dismiss' => 'No thanks'
			)
		));
	}


	//
	// Emit the shared CSS plus the page JS with its config blob into <head>
	//
	function emit($cfg)
	{
		static $css_done = false;

		if (!$css_done)
		{
			$css_done = true;
			echo '<style>'
				.'#tfahint{border:1px solid rgba(82,126,180,.6);background:rgba(82,126,180,.12);border-radius:4px;padding:.55em .9em;margin:.6em 0;font-size:.95em}'
				.'#tfahint a{margin-left:.8em}'
				.'#tfaprofile .tfastatus-on{color:#2f9e5f;font-weight:bold}'
				.'#tfaprofile .tfastatus-off{opacity:.85}'
				.'</style>'."\n";
		}

		$json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

		echo '<script>/* Two-Factor Authentication plugin */'."\n".'(function(){'."\n"
			.'var cfg = '.$json.';'."\n"
			.<<<'EOJS'
function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

function el(tag, cls, text) {
	var e = document.createElement(tag);
	if (cls) e.className = cls;
	if (text) e.textContent = text;
	return e;
}

// ---- own profile: status block with a manage link ---------------------------
function profilePage() {
	var anchor = document.querySelector('div.blockform') || document.getElementById('viewprofile');
	if (!anchor) return;

	var block = el('div', 'block');
	block.id = 'tfaprofile';
	var h2 = el('h2');
	h2.appendChild(el('span', null, cfg.text.title));
	block.appendChild(h2);
	var box = el('div', 'box');
	var inbox = el('div', 'inbox');

	var p = el('p');
	if (cfg.enabled) {
		p.appendChild(el('span', 'tfastatus-on', '✓ ' + cfg.text.on));
		p.appendChild(document.createTextNode(' ' + cfg.text.since + ' ' + cfg.since + ' — '));
		var a = document.createElement('a');
		a.href = cfg.url;
		a.textContent = cfg.text.manage;
		p.appendChild(a);
	} else {
		p.appendChild(el('span', 'tfastatus-off', cfg.text.off));
		p.appendChild(document.createTextNode(' — ' + cfg.text.blurb + ' '));
		var a2 = document.createElement('a');
		a2.href = cfg.url;
		a2.textContent = cfg.text.enable;
		p.appendChild(a2);
	}
	inbox.appendChild(p);
	box.appendChild(inbox);
	block.appendChild(box);
	anchor.parentNode.insertBefore(block, anchor.nextSibling);
}

// ---- new-member prompt ------------------------------------------------------
function hintBanner() {
	var main = document.getElementById('brdmain') || document.querySelector('#punwrap') || document.body;
	if (!main) return;

	var bar = el('div');
	bar.id = 'tfahint';
	bar.appendChild(document.createTextNode(cfg.text.msg));
	var go = document.createElement('a');
	go.href = cfg.url;
	go.textContent = cfg.text.go;
	bar.appendChild(go);
	var no = document.createElement('a');
	no.href = '#';
	no.textContent = cfg.text.dismiss;
	no.addEventListener('click', function (e) {
		e.preventDefault();
		document.cookie = 'evebb_tfa_hint=1; max-age=' + (86400 * 7) + '; path=/; SameSite=Lax';
		if (bar.parentNode) bar.parentNode.removeChild(bar);
	});
	bar.appendChild(no);
	main.insertBefore(bar, main.firstChild);
}

ready(function () { if (cfg.page === 'profile') profilePage(); else hintBanner(); });
EOJS
			."\n".'})();</script>'."\n";
	}
}
