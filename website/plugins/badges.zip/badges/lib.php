<?php

/**
 * Badges & Milestones - shared library.
 *
 * Schema management, the milestone sweep and helpers used by the addon
 * (badges.php) and the settings page (admin.php).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


//
// Create the badge tables on first use. Guarded by the o_badges_db_rev
// config key so the check is free on every later request.
//
function evebb_badges_ensure_schema()
{
	global $db, $pun_config;

	if (isset($pun_config['o_badges_db_rev']))
		return;

	if (!$db->table_exists('badges'))
	{
		$schema = array(
			'FIELDS' => array(
				'id' => array(
					'datatype'   => 'SERIAL',
					'allow_null' => false
				),
				'name' => array(
					'datatype'   => 'VARCHAR(40)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'descr' => array(
					'datatype'   => 'VARCHAR(255)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'glyph' => array(
					'datatype'   => 'VARCHAR(8)',
					'allow_null' => false,
					'default'    => '\'★\''
				),
				'color' => array(
					'datatype'   => 'VARCHAR(7)',
					'allow_null' => false,
					'default'    => '\'#4a6d8c\''
				),
				'rule_type' => array(
					'datatype'   => 'VARCHAR(10)',
					'allow_null' => false,
					'default'    => '\'manual\''
				),
				'rule_value' => array(
					'datatype'   => 'INT(10)',
					'allow_null' => false,
					'default'    => '0'
				),
				'disp_position' => array(
					'datatype'   => 'INT(10)',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('id')
		);

		$db->create_table('badges', $schema) or error('Unable to create the badges table', __FILE__, __LINE__, $db->error());
	}

	if (!$db->table_exists('user_badges'))
	{
		$schema = array(
			'FIELDS' => array(
				'user_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'badge_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'awarded_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'awarded_by' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('user_id', 'badge_id'),
			'INDEXES' => array(
				'badge_id_idx' => array('badge_id')
			)
		);

		$db->create_table('user_badges', $schema) or error('Unable to create the user_badges table', __FILE__, __LINE__, $db->error());
	}

	// Record the schema revision AND bootstrap the sweep timestamp here,
	// inside the one cache regeneration - the sweep itself must only ever
	// UPDATE the row (an INSERT there would race itself on every request
	// whose config cache predates the row). No or-error: if two requests
	// race, the loser's duplicate insert may fail and that is fine.
	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_badges_db_rev\', \'1\')');
	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_badges_last_check\', \'0\')');
	$pun_config['o_badges_db_rev'] = '1';
	$pun_config['o_badges_last_check'] = '0';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Read a plugin config value with a default
//
function evebb_badges_conf($name, $default)
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Insert or update a config value and refresh the config cache
//
function evebb_badges_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


//
// Normalise a colour value to #rrggbb, or fall back to the default
//
function evebb_badges_color($raw)
{
	$raw = pun_trim((string) $raw);

	return preg_match('%^#[0-9a-fA-F]{6}$%', $raw) ? strtolower($raw) : '#4a6d8c';
}


//
// The milestone sweep: award every rule-based badge to every member who
// qualifies. Set-based (one INSERT ... SELECT per rule badge), so it is
// cheap even on large boards. Time-gated to once an hour on ordinary
// page views; the gate is claimed with a compare-and-set on the
// o_badges_last_check config row so concurrent requests never run the
// inserts twice ($force, from the admin button, skips the gate).
//
function evebb_badges_sweep($force = false)
{
	global $db, $pun_config;

	$now = time();
	$last = (int) evebb_badges_conf('o_badges_last_check', '0');

	if (!$force && $now - $last < 3600)
		return;

	// The row is guaranteed to exist (bootstrapped by ensure_schema), so
	// this is always an UPDATE. Ordinary page views claim the sweep with a
	// compare-and-set - the loser of a race simply skips; the admin's
	// run-now button ($force) updates unconditionally.
	if ($force)
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$now.'\' WHERE conf_name=\'o_badges_last_check\'') or error('Unable to stamp badge sweep', __FILE__, __LINE__, $db->error());
	else
	{
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$now.'\' WHERE conf_name=\'o_badges_last_check\' AND conf_value=\''.$db->escape((string) $last).'\'') or error('Unable to claim badge sweep', __FILE__, __LINE__, $db->error());
		if ($db->affected_rows() != 1)
			return;
	}

	$pun_config['o_badges_last_check'] = (string) $now;
	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	$result = $db->query('SELECT id, rule_type, rule_value FROM '.$db->prefix.'badges WHERE rule_type<>\'manual\'') or error('Unable to fetch badge rules', __FILE__, __LINE__, $db->error());

	while ($cur_badge = $db->fetch_assoc($result))
	{
		$badge_id = (int) $cur_badge['id'];
		$value = (int) $cur_badge['rule_value'];

		if ($cur_badge['rule_type'] == 'posts')
			$where = 'u.num_posts>='.$value;
		else if ($cur_badge['rule_type'] == 'years')
			$where = 'u.registered>0 AND u.registered<='.($now - $value * 31536000);
		else
			continue;

		$db->query('INSERT INTO '.$db->prefix.'user_badges (user_id, badge_id, awarded_at, awarded_by) SELECT u.id, '.$badge_id.', '.$now.', 0 FROM '.$db->prefix.'users AS u WHERE u.id>1 AND '.$where.' AND NOT EXISTS (SELECT 1 FROM '.$db->prefix.'user_badges AS ub WHERE ub.user_id=u.id AND ub.badge_id='.$badge_id.')') or error('Unable to award milestone badges', __FILE__, __LINE__, $db->error());
	}
}


//
// Every badge, in display order
//
function evebb_badges_all()
{
	global $db;

	$result = $db->query('SELECT id, name, descr, glyph, color, rule_type, rule_value, disp_position FROM '.$db->prefix.'badges ORDER BY disp_position, name') or error('Unable to fetch badges', __FILE__, __LINE__, $db->error());

	$badges = array();
	while ($row = $db->fetch_assoc($result))
		$badges[] = $row;

	return $badges;
}


//
// The default starter set (name, descr, glyph, color, rule_type,
// rule_value, position). Seeding only adds names that don't exist yet.
//
function evebb_badges_defaults()
{
	return array(
		array('First Post', 'Made their first post', '✎', '#6a8caf', 'posts', 1, 1),
		array('Ten Posts', 'Reached 10 posts', '✦', '#3b6ea5', 'posts', 10, 2),
		array('Century', 'Reached 100 posts', '✪', '#c9971c', 'posts', 100, 3),
		array('Prolific', 'Reached 500 posts', '★', '#b5443c', 'posts', 500, 4),
		array('One Year', 'A member for one year', '⚑', '#2f9e5f', 'years', 1, 5),
		array('Veteran', 'A member for two years', '❖', '#527e46', 'years', 2, 6),
		array('Contributor', 'Recognised by the staff for contributions to the community', '♦', '#6a4d8c', 'manual', 0, 7)
	);
}

function evebb_badges_seed()
{
	global $db;

	$added = 0;
	foreach (evebb_badges_defaults() as $def)
	{
		$result = $db->query('SELECT 1 FROM '.$db->prefix.'badges WHERE name=\''.$db->escape($def[0]).'\'') or error('Unable to check badge', __FILE__, __LINE__, $db->error());
		if ($db->has_rows($result))
			continue;

		$db->query('INSERT INTO '.$db->prefix.'badges (name, descr, glyph, color, rule_type, rule_value, disp_position) VALUES(\''.$db->escape($def[0]).'\', \''.$db->escape($def[1]).'\', \''.$db->escape($def[2]).'\', \''.$def[3].'\', \''.$def[4].'\', '.(int) $def[5].', '.(int) $def[6].')') or error('Unable to seed badge', __FILE__, __LINE__, $db->error());
		$added++;
	}

	return $added;
}
