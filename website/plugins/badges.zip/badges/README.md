# Badges & Milestones

An unofficial [eveBB](https://evebb.net) plugin that awards badges to
members — automatically for milestones, and by hand from the staff.

## Features

- Milestone badges awarded automatically: post-count thresholds
  (e.g. 10 / 100 / 500 posts) and years-of-membership anniversaries.
  Checks run hourly on ordinary page views, set-based, so they cost one
  query per rule no matter how many members you have.
- Staff-awarded badges (like **Contributor**) handed out — and revoked —
  by exact username from the settings page.
- Badges render as small coloured glyph pills under the poster's name on
  topic pages (capped, full name and description in the tooltip) and as
  a Badges panel with award dates on member profiles.
- Every badge is admin-defined: name, description, glyph (any short
  character/emoji), colour, rule and display position.
- A one-click starter set: First Post, Ten Posts, Century, Prolific,
  One Year, Veteran and a staff-awarded Contributor.

## Installation

Upload `badges.zip` through **Administration → Plugins → Upload
plugin**, then activate it. The plugin creates its two database tables
(`badges`, `user_badges`) automatically on first use. Then add the
starter set (or your own badges) on the settings page.

## Settings

**Administration → Plugins → Badges & Milestones → Settings**

- Add, edit and delete badges, with live holder counts
- Award / revoke badges by username
- Run the milestone check on demand
- Display: pills under posts on/off, pill cap (1–10)
- Maintenance: purge orphaned award rows; full data removal for a clean
  uninstall

## Notes

- Revoking a milestone badge is temporary if the member still qualifies —
  it returns on the next hourly check. Delete or edit the badge instead
  if you want it gone for good.
- Editing a rule's threshold never takes badges away from existing
  holders; it only affects future awards.
- Guests never hold badges. Without JavaScript nothing breaks — pages
  simply render without the pills.

## License

GPL version 2 or higher, like eveBB itself.
