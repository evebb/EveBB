<?php

/**
 * Badges & Milestones - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome (and inside a POST
 * form that footer.php injects the CSRF token into). $db, $pun_config and
 * $plugin_slug are available here.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

// The addon normally creates the tables on first page view, but make sure
// they exist even if the settings page is visited before that
evebb_badges_ensure_schema();

$badges_back = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

//
// Normalise a posted rule (type + value)
//
function evebb_badges_rule($type, $value)
{
	$type = in_array($type, array('manual', 'posts', 'years'), true) ? $type : 'manual';
	$value = (int) $value;

	if ($type == 'manual')
		$value = 0;
	else if ($value < 1)
		$value = 1;

	return array($type, $value);
}

//
// Look up a registered member by exact username
//
function evebb_badges_find_user($username)
{
	global $db;

	$username = pun_trim((string) $username);
	if ($username === '')
		return 0;

	$result = $db->query('SELECT id FROM '.$db->prefix.'users WHERE id>1 AND username=\''.$db->escape($username).'\'') or error('Unable to fetch user', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? (int) $db->result($result) : 0;
}

// Seed the starter set
if (isset($_POST['seed_badges']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$added = evebb_badges_seed();
	evebb_badges_sweep(true);

	redirect($badges_back, $added.' starter badge(s) added and milestones checked. Redirecting …');
}

// Add a badge
if (isset($_POST['add_badge']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$name = pun_trim($_POST['b_new_name'] ?? '');
	if ($name === '' || pun_strlen($name) > 40)
		redirect($badges_back, 'Give the new badge a name of 1-40 characters. Redirecting …');

	$descr = pun_trim($_POST['b_new_descr'] ?? '');
	if (pun_strlen($descr) > 255)
		$descr = '';

	$glyph = pun_trim($_POST['b_new_glyph'] ?? '');
	if ($glyph === '' || utf8_strlen($glyph) > 4)
		$glyph = '★';

	$color = evebb_badges_color($_POST['b_new_color'] ?? '');
	list($rule_type, $rule_value) = evebb_badges_rule($_POST['b_new_rule'] ?? 'manual', $_POST['b_new_value'] ?? 0);
	$pos = (int) ($_POST['b_new_pos'] ?? 0);

	$db->query('INSERT INTO '.$db->prefix.'badges (name, descr, glyph, color, rule_type, rule_value, disp_position) VALUES(\''.$db->escape($name).'\', \''.$db->escape($descr).'\', \''.$db->escape($glyph).'\', \''.$db->escape($color).'\', \''.$rule_type.'\', '.$rule_value.', '.$pos.')') or error('Unable to add badge', __FILE__, __LINE__, $db->error());

	if ($rule_type != 'manual')
		evebb_badges_sweep(true);

	redirect($badges_back, 'Badge added. Redirecting …');
}

// Save changes to the existing badges
if (isset($_POST['save_badges']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	foreach (evebb_badges_all() as $cur_badge)
	{
		$bid = (int) $cur_badge['id'];
		if (!isset($_POST['b_name_'.$bid]))
			continue;

		$name = pun_trim($_POST['b_name_'.$bid]);
		if ($name === '' || pun_strlen($name) > 40)
			$name = $cur_badge['name'];

		$descr = pun_trim($_POST['b_descr_'.$bid] ?? $cur_badge['descr']);
		if (pun_strlen($descr) > 255)
			$descr = $cur_badge['descr'];

		$glyph = pun_trim($_POST['b_glyph_'.$bid] ?? $cur_badge['glyph']);
		if ($glyph === '' || utf8_strlen($glyph) > 4)
			$glyph = $cur_badge['glyph'];

		$color = evebb_badges_color($_POST['b_color_'.$bid] ?? $cur_badge['color']);
		list($rule_type, $rule_value) = evebb_badges_rule($_POST['b_rule_'.$bid] ?? $cur_badge['rule_type'], $_POST['b_value_'.$bid] ?? $cur_badge['rule_value']);
		$pos = (int) ($_POST['b_pos_'.$bid] ?? $cur_badge['disp_position']);

		$db->query('UPDATE '.$db->prefix.'badges SET name=\''.$db->escape($name).'\', descr=\''.$db->escape($descr).'\', glyph=\''.$db->escape($glyph).'\', color=\''.$db->escape($color).'\', rule_type=\''.$rule_type.'\', rule_value='.$rule_value.', disp_position='.$pos.' WHERE id='.$bid) or error('Unable to update badge', __FILE__, __LINE__, $db->error());
	}

	evebb_badges_sweep(true);

	redirect($badges_back, 'Badges saved and milestones checked. Redirecting …');
}

// Delete one badge (buttons named bdel_<id>)
foreach ($_POST as $badges_key => $badges_unused)
{
	if (strpos($badges_key, 'bdel_') === 0)
	{
		confirm_referrer('admin_plugins.php');
		check_csrf($_POST['csrf_token'] ?? null);

		$bid = (int) substr($badges_key, 5);
		if ($bid > 0)
		{
			$db->query('DELETE FROM '.$db->prefix.'user_badges WHERE badge_id='.$bid) or error('Unable to delete badge', __FILE__, __LINE__, $db->error());
			$db->query('DELETE FROM '.$db->prefix.'badges WHERE id='.$bid) or error('Unable to delete badge', __FILE__, __LINE__, $db->error());
		}

		redirect($badges_back, 'Badge deleted. Redirecting …');
	}
}

// Award a manual badge
if (isset($_POST['award_badge']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$user_id = evebb_badges_find_user($_POST['award_user'] ?? '');
	$badge_id = (int) ($_POST['award_which'] ?? 0);

	if ($user_id < 2)
		redirect($badges_back, 'No member with that exact username. Redirecting …');

	$result = $db->query('SELECT rule_type FROM '.$db->prefix.'badges WHERE id='.$badge_id) or error('Unable to fetch badge', __FILE__, __LINE__, $db->error());
	if (!$db->has_rows($result))
		redirect($badges_back, 'Pick a badge to award. Redirecting …');

	$result = $db->query('SELECT 1 FROM '.$db->prefix.'user_badges WHERE user_id='.$user_id.' AND badge_id='.$badge_id) or error('Unable to check award', __FILE__, __LINE__, $db->error());
	if ($db->has_rows($result))
		redirect($badges_back, 'That member already has that badge. Redirecting …');

	$db->query('INSERT INTO '.$db->prefix.'user_badges (user_id, badge_id, awarded_at, awarded_by) VALUES('.$user_id.', '.$badge_id.', '.time().', '.(int) $pun_user['id'].')') or error('Unable to award badge', __FILE__, __LINE__, $db->error());

	redirect($badges_back, 'Badge awarded. Redirecting …');
}

// Revoke a badge
if (isset($_POST['revoke_badge']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$user_id = evebb_badges_find_user($_POST['revoke_user'] ?? '');
	$badge_id = (int) ($_POST['revoke_which'] ?? 0);

	if ($user_id < 2)
		redirect($badges_back, 'No member with that exact username. Redirecting …');

	$db->query('DELETE FROM '.$db->prefix.'user_badges WHERE user_id='.$user_id.' AND badge_id='.$badge_id) or error('Unable to revoke badge', __FILE__, __LINE__, $db->error());

	redirect($badges_back, 'Badge revoked (a milestone badge returns on the next check if the member still qualifies). Redirecting …');
}

// Run the milestone check now
if (isset($_POST['check_badges']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	evebb_badges_sweep(true);

	redirect($badges_back, 'Milestones checked. Redirecting …');
}

// Display settings
if (isset($_POST['save_settings']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	evebb_badges_save_conf('o_badges_showposts', isset($_POST['badges_showposts']) ? '1' : '0');

	$cap = (int) ($_POST['badges_postcap'] ?? 5);
	if ($cap < 1)
		$cap = 1;
	else if ($cap > 10)
		$cap = 10;
	evebb_badges_save_conf('o_badges_postcap', (string) $cap);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect($badges_back, 'Settings saved. Redirecting …');
}

// Remove award rows whose users or badges no longer exist
if (isset($_POST['purge_badges']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DELETE FROM '.$db->prefix.'user_badges WHERE user_id NOT IN (SELECT id FROM '.$db->prefix.'users)') or error('Unable to purge awards', __FILE__, __LINE__, $db->error());
	$db->query('DELETE FROM '.$db->prefix.'user_badges WHERE badge_id NOT IN (SELECT id FROM '.$db->prefix.'badges)') or error('Unable to purge awards', __FILE__, __LINE__, $db->error());

	redirect($badges_back, 'Orphaned award rows purged. Redirecting …');
}

// Remove ALL plugin data (before uninstalling)
if (isset($_POST['nuke_badges']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect($badges_back, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('user_badges');
	$db->drop_table('badges');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN (\'o_badges_db_rev\', \'o_badges_last_check\', \'o_badges_showposts\', \'o_badges_postcap\')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());

	unset($pun_config['o_badges_db_rev'], $pun_config['o_badges_last_check'], $pun_config['o_badges_showposts'], $pun_config['o_badges_postcap']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Badges & Milestones data removed. You can now deactivate and delete the plugin. Redirecting …');
}

$all_badges = evebb_badges_all();

// Per-badge award counts
$counts = array();
$result = $db->query('SELECT badge_id, COUNT(user_id) AS n FROM '.$db->prefix.'user_badges GROUP BY badge_id') or error('Unable to count awards', __FILE__, __LINE__, $db->error());
while ($row = $db->fetch_assoc($result))
	$counts[(int) $row['badge_id']] = (int) $row['n'];

$badges_showposts = evebb_badges_conf('o_badges_showposts', '1') == '1';
$badges_postcap   = (int) evebb_badges_conf('o_badges_postcap', '5');
$badges_last      = (int) evebb_badges_conf('o_badges_last_check', '0');

function evebb_badges_select($name, $all_badges, $manual_only = false)
{
	$html = '<select name="'.$name.'">';
	foreach ($all_badges as $cur_badge)
	{
		if ($manual_only && $cur_badge['rule_type'] != 'manual')
			continue;
		$html .= '<option value="'.(int) $cur_badge['id'].'">'.pun_htmlspecialchars($cur_badge['name']).'</option>';
	}

	return $html.'</select>';
}

function evebb_badges_rule_select($name, $selected)
{
	$html = '<select name="'.$name.'">';
	foreach (array('manual' => 'staff-awarded', 'posts' => 'posts reach', 'years' => 'years member') as $val => $label)
		$html .= '<option value="'.$val.'"'.($selected == $val ? ' selected="selected"' : '').'>'.$label.'</option>';

	return $html.'</select>';
}

?>
		<div class="inform">
			<fieldset>
				<legend>Your badges</legend>
				<div class="infldset">
					<p>Milestone badges (posts / years) are awarded automatically by an hourly check<?php if ($badges_last) echo ' (last ran '.format_time($badges_last).')' ?>; staff-awarded badges are handed out below. Badges show under poster names on topic pages and in a panel on member profiles.</p>
<?php if (empty($all_badges)): ?>
					<p><em>No badges yet — add the starter set or your first badge below.</em></p>
					<p><input type="submit" name="seed_badges" value="Add the starter set" /></p>
<?php else: ?>
<?php foreach ($all_badges as $cur_badge): $bid = (int) $cur_badge['id']; ?>
					<p>
						<span style="display:inline-block;min-width:1.5em;padding:.05em .3em;border-radius:.75em;color:#fff;text-align:center;background-color:<?php echo pun_htmlspecialchars(evebb_badges_color($cur_badge['color'])) ?>;"><?php echo pun_htmlspecialchars($cur_badge['glyph']) ?></span>
						<strong><?php echo pun_htmlspecialchars($cur_badge['name']) ?></strong>
						(<?php echo isset($counts[$bid]) ? $counts[$bid] : 0 ?> holders) &mdash;
						name <input type="text" name="b_name_<?php echo $bid ?>" size="14" maxlength="40" value="<?php echo pun_htmlspecialchars($cur_badge['name']) ?>" />
						glyph <input type="text" name="b_glyph_<?php echo $bid ?>" size="2" maxlength="4" value="<?php echo pun_htmlspecialchars($cur_badge['glyph']) ?>" />
						colour <input type="color" name="b_color_<?php echo $bid ?>" value="<?php echo pun_htmlspecialchars(evebb_badges_color($cur_badge['color'])) ?>" />
						rule <?php echo evebb_badges_rule_select('b_rule_'.$bid, $cur_badge['rule_type']) ?>
						<input type="text" name="b_value_<?php echo $bid ?>" size="4" maxlength="6" value="<?php echo (int) $cur_badge['rule_value'] ?>" />
						position <input type="text" name="b_pos_<?php echo $bid ?>" size="3" maxlength="4" value="<?php echo (int) $cur_badge['disp_position'] ?>" />
						<br />description <input type="text" name="b_descr_<?php echo $bid ?>" size="60" maxlength="255" value="<?php echo pun_htmlspecialchars($cur_badge['descr']) ?>" />
						<input type="submit" name="bdel_<?php echo $bid ?>" value="Delete" />
					</p>
<?php endforeach; ?>
					<p class="topspace"><input type="submit" name="save_badges" value="Save badge changes" /> <input type="submit" name="seed_badges" value="Add missing starter badges" /> <input type="submit" name="check_badges" value="Run milestone check now" /></p>
<?php endif; ?>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Add a badge</legend>
				<div class="infldset">
					<p>
						name <input type="text" name="b_new_name" size="14" maxlength="40" value="" />
						glyph <input type="text" name="b_new_glyph" size="2" maxlength="4" value="★" />
						colour <input type="color" name="b_new_color" value="#4a6d8c" />
						rule <?php echo evebb_badges_rule_select('b_new_rule', 'manual') ?>
						<input type="text" name="b_new_value" size="4" maxlength="6" value="0" />
						position <input type="text" name="b_new_pos" size="3" maxlength="4" value="0" />
						<br />description <input type="text" name="b_new_descr" size="60" maxlength="255" value="" />
						<input type="submit" name="add_badge" value="Add badge" />
					</p>
					<p>The rule value is the threshold: posts reach <em>N</em>, or <em>N</em> years a member. Staff-awarded badges ignore the value. Lower positions sort first.</p>
				</div>
			</fieldset>
		</div>
<?php if (!empty($all_badges)): ?>
		<div class="inform">
			<fieldset>
				<legend>Award and revoke</legend>
				<div class="infldset">
					<p>Award <?php echo evebb_badges_select('award_which', $all_badges, true) ?> to member <input type="text" name="award_user" size="20" maxlength="25" /> <input type="submit" name="award_badge" value="Award" /> <em>(staff-awarded badges only; exact username)</em></p>
					<p>Revoke <?php echo evebb_badges_select('revoke_which', $all_badges) ?> from member <input type="text" name="revoke_user" size="20" maxlength="25" /> <input type="submit" name="revoke_badge" value="Revoke" /> <em>(a milestone badge returns on the next check if the member still qualifies)</em></p>
				</div>
			</fieldset>
		</div>
<?php endif; ?>
		<div class="inform">
			<fieldset>
				<legend>Display</legend>
				<div class="infldset">
					<label><input type="checkbox" name="badges_showposts" value="1"<?php if ($badges_showposts) echo ' checked="checked"' ?> /> Show badge pills under poster names on topic pages</label>
					<label>Maximum pills shown under a poster's name (1&ndash;10; the profile always shows all)
						<br /><input type="text" name="badges_postcap" size="4" maxlength="2" value="<?php echo $badges_postcap ?>" />
					</label>
					<p class="topspace"><input type="submit" name="save_settings" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Maintenance</legend>
				<div class="infldset">
					<p>Deleting a member does not remove their award rows. Purging clears rows for deleted members (and any stray rows for deleted badges).</p>
					<p><input type="submit" name="purge_badges" value="Purge orphaned award rows" /></p>
					<p class="topspace">To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the badges and user_badges tables and the plugin's settings.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently deletes every badge and every award</label></p>
					<p><input type="submit" name="nuke_badges" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
