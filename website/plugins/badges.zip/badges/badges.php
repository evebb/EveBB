<?php

/**
 * Badges & Milestones - the addon.
 *
 * Members earn badges automatically (post-count and years-of-membership
 * milestones, awarded by an hourly set-based sweep) and by hand from the
 * staff (manual badges, given out on the settings page). Badges render as
 * small coloured glyph pills under the poster's name on topic pages
 * (capped, with the full name + description in the tooltip) and as a
 * panel with award dates on profile pages.
 *
 * Wiring: everything hangs off header_head_end. The sweep is time-gated
 * (once an hour) and claimed with a compare-and-set on a config row so
 * concurrent requests never double-run it; the awards themselves are
 * INSERT ... SELECT ... WHERE NOT EXISTS, so a sweep costs one statement
 * per rule badge regardless of member count. Page decoration is DOM-built
 * JS with a config blob (the solved-plugin pattern); the profile panel
 * only attaches when #viewprofile exists (viewing your OWN profile shows
 * the edit page - a known gotcha).
 *
 * State: badges (id, name, descr, glyph, color, rule_type
 * manual|posts|years, rule_value, disp_position) and user_badges
 * (user_id+badge_id PK, awarded_at, awarded_by; 0 = automatic).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_badges extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		// The hook can fire twice in one request when core re-includes
		// header.php (e.g. message() rendering an error page). Act once.
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		evebb_badges_ensure_schema();
		evebb_badges_sweep();

		$page = isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : '';

		if ($page == 'viewtopic.php')
			$this->head_viewtopic();
		else if ($page == 'profile.php')
			$this->head_profile();
	}


	//
	// viewtopic.php: emit a username => badges map for this topic's
	// posters (badge pills render under the poster name)
	//
	function head_viewtopic()
	{
		global $db, $cur_topic, $id;

		// Defensive: these are set by viewtopic.php before header.php runs
		if (!isset($cur_topic) || !isset($id))
			return;

		if (evebb_badges_conf('o_badges_showposts', '1') != '1')
			return;

		$cap = (int) evebb_badges_conf('o_badges_postcap', '5');
		if ($cap < 1)
			$cap = 1;

		$result = $db->query('SELECT u.username, b.name, b.descr, b.glyph, b.color FROM '.$db->prefix.'user_badges AS ub INNER JOIN '.$db->prefix.'users AS u ON u.id=ub.user_id INNER JOIN '.$db->prefix.'badges AS b ON b.id=ub.badge_id WHERE ub.user_id IN (SELECT poster_id FROM '.$db->prefix.'posts WHERE topic_id='.(int) $id.' AND poster_id>1) ORDER BY ub.awarded_at, b.disp_position, b.name') or error('Unable to fetch poster badges', __FILE__, __LINE__, $db->error());

		$map = array();
		while ($row = $db->fetch_assoc($result))
		{
			if (!isset($map[$row['username']]))
				$map[$row['username']] = array();
			if (count($map[$row['username']]) < $cap)
				$map[$row['username']][] = array('n' => $row['name'], 'd' => $row['descr'], 'g' => $row['glyph'], 'c' => $row['color']);
		}

		if (empty($map))
			return;

		$this->emit(array(
			'page' => 'topic',
			'map'  => $map
		));
	}


	//
	// profile.php: emit the viewed member's badges for the profile panel.
	// The JS only attaches when #viewprofile exists, so the edit variants
	// of profile.php stay untouched.
	//
	function head_profile()
	{
		global $db, $id;

		if (!isset($id) || (int) $id < 2)
			return;

		$result = $db->query('SELECT b.name, b.descr, b.glyph, b.color, ub.awarded_at, ub.awarded_by FROM '.$db->prefix.'user_badges AS ub INNER JOIN '.$db->prefix.'badges AS b ON b.id=ub.badge_id WHERE ub.user_id='.(int) $id.' ORDER BY ub.awarded_at, b.disp_position, b.name') or error('Unable to fetch profile badges', __FILE__, __LINE__, $db->error());

		$badges = array();
		while ($row = $db->fetch_assoc($result))
			$badges[] = array(
				'n'  => $row['name'],
				'd'  => $row['descr'],
				'g'  => $row['glyph'],
				'c'  => $row['color'],
				'at' => format_time($row['awarded_at'])
			);

		if (empty($badges))
			return;

		$this->emit(array(
			'page'   => 'profile',
			'badges' => $badges,
			'text'   => array('title' => 'Badges', 'awarded' => 'awarded')
		));
	}


	//
	// Emit the shared CSS plus the page JS with its config blob into <head>
	//
	function emit($cfg)
	{
		$json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

		echo '<style>'
			.'.badgepill{display:inline-block;min-width:1.5em;padding:.05em .3em;border-radius:.75em;color:#fff;font-size:.85em;text-align:center;margin:0 .2em .15em 0;cursor:default}'
			.'dd.badgesrow{margin-top:.35em;line-height:1.6}'
			.'#badgespanel .badgecard{margin:.35em 0;display:flex;align-items:baseline;gap:.6em}'
			.'#badgespanel .badgecard .badgepill{font-size:1em}'
			.'#badgespanel .badgecard .badgename{font-weight:bold}'
			.'#badgespanel .badgecard .badgemeta{font-size:.9em;opacity:.8}'
			.'</style>'."\n";

		echo '<script>/* Badges & Milestones plugin */'."\n".'(function(){'."\n"
			.'var cfg = '.$json.';'."\n"
			.<<<'EOJS'
function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

function el(tag, cls, text) {
	var e = document.createElement(tag);
	if (cls) e.className = cls;
	if (text) e.textContent = text;
	return e;
}

function pill(b) {
	var s = el('span', 'badgepill', b.g);
	s.style.backgroundColor = b.c;
	s.title = b.n + (b.d ? ' — ' + b.d : '');
	return s;
}

// ---- viewtopic: pill rows under poster names -------------------------------
function topicPage() {
	var lists = document.querySelectorAll('div.blockpost .postleft dl');
	for (var i = 0; i < lists.length; i++) {
		var dt = lists[i].querySelector('dt');
		if (!dt) continue;
		var name = dt.textContent.replace(/^\s+|\s+$/g, '');
		var badges = cfg.map[name];
		if (!badges) continue;
		var dd = el('dd', 'badgesrow');
		for (var j = 0; j < badges.length; j++) dd.appendChild(pill(badges[j]));
		lists[i].appendChild(dd);
	}
}

// ---- profile: a Badges block after the profile ------------------------------
function profilePage() {
	var vp = document.getElementById('viewprofile');
	if (!vp) return; // the edit variants of profile.php

	var block = el('div', 'block');
	block.id = 'badgespanel';
	var h2 = el('h2');
	h2.appendChild(el('span', null, cfg.text.title));
	block.appendChild(h2);
	var box = el('div', 'box');
	var inbox = el('div', 'inbox');

	for (var i = 0; i < cfg.badges.length; i++) {
		var b = cfg.badges[i];
		var card = el('div', 'badgecard');
		card.appendChild(pill(b));
		card.appendChild(el('span', 'badgename', b.n));
		card.appendChild(el('span', 'badgemeta', (b.d ? b.d + ' — ' : '') + cfg.text.awarded + ' ' + b.at));
		inbox.appendChild(card);
	}

	box.appendChild(inbox);
	block.appendChild(box);
	vp.parentNode.insertBefore(block, vp.nextSibling);
}

ready(function () { if (cfg.page === 'topic') topicPage(); else profilePage(); });
EOJS
			."\n".'})();</script>'."\n";
	}
}
