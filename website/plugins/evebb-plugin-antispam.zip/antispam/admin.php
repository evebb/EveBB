<?php

/**
 * Anti-spam Pack - settings page (shown inside the plugin manager).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

$antispam_fields = array(
	'o_antispam_honeypot'			=> '1',
	'o_antispam_timetrap'			=> '1',
	'o_antispam_timetrap_seconds'	=> '3',
	'o_antispam_sfs'				=> '1',
	'o_antispam_sfs_confidence'		=> '80',
	'o_antispam_ts_sitekey'			=> '',
	'o_antispam_ts_secret'			=> '',
);

// Save
if (isset($_POST['save_antispam']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$new = array(
		'o_antispam_honeypot'			=> isset($_POST['honeypot']) ? '1' : '0',
		'o_antispam_timetrap'			=> isset($_POST['timetrap']) ? '1' : '0',
		'o_antispam_timetrap_seconds'	=> (string) max(1, min(60, intval($_POST['timetrap_seconds'] ?? 3))),
		'o_antispam_sfs'				=> isset($_POST['sfs']) ? '1' : '0',
		'o_antispam_sfs_confidence'		=> (string) max(1, min(100, intval($_POST['sfs_confidence'] ?? 80))),
		'o_antispam_ts_sitekey'			=> pun_trim($_POST['ts_sitekey'] ?? ''),
		'o_antispam_ts_secret'			=> pun_trim($_POST['ts_secret'] ?? ''),
	);

	foreach ($new as $key => $value)
	{
		if (isset($pun_config[$key]))
			$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($key).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
		else
			$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($key).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());
	}

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Anti-spam settings saved. Redirecting …');
}

// Current values (with defaults)
$cur = array();
foreach ($antispam_fields as $key => $default)
	$cur[$key] = isset($pun_config[$key]) ? $pun_config[$key] : $default;

?>
<div class="blockform">
	<h2><span>Anti-spam Pack</span></h2>
	<div class="box">
		<form method="post" action="admin_plugins.php?action=settings&amp;plugin=<?php echo pun_htmlspecialchars($plugin_slug) ?>">
			<input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token() ?>" />
			<div class="inform">
				<fieldset>
					<legend>Invisible defences (no impact on humans)</legend>
					<div class="infldset">
						<div class="rbox">
							<label><input type="checkbox" name="honeypot" value="1"<?php if ($cur['o_antispam_honeypot'] == '1') echo ' checked="checked"' ?> />Honeypot field — an invisible input that bots fill in and humans never see.<br /></label>
							<label><input type="checkbox" name="timetrap" value="1"<?php if ($cur['o_antispam_timetrap'] == '1') echo ' checked="checked"' ?> />Time trap — reject registrations submitted faster than a human could complete the form.<br /></label>
						</div>
						<label>Minimum seconds for the time trap<br />
						<input type="text" name="timetrap_seconds" size="4" maxlength="2" value="<?php echo pun_htmlspecialchars($cur['o_antispam_timetrap_seconds']) ?>" /><br /></label>
					</div>
				</fieldset>
			</div>
			<div class="inform">
				<fieldset>
					<legend>StopForumSpam reputation check</legend>
					<div class="infldset">
						<div class="rbox">
							<label><input type="checkbox" name="sfs" value="1"<?php if ($cur['o_antispam_sfs'] == '1') echo ' checked="checked"' ?> />Check the registrant's IP address and email against the stopforumspam.org database of known spam sources.<br /></label>
						</div>
						<label>Confidence threshold (1–100; reject at or above)<br />
						<input type="text" name="sfs_confidence" size="4" maxlength="3" value="<?php echo pun_htmlspecialchars($cur['o_antispam_sfs_confidence']) ?>" /><br /></label>
						<p>Privacy note: enabling this sends each registrant's IP address and email address to stopforumspam.org for checking. A network failure never blocks registration — the check simply passes.</p>
					</div>
				</fieldset>
			</div>
			<div class="inform">
				<fieldset>
					<legend>Cloudflare Turnstile (optional)</legend>
					<div class="infldset">
						<label>Site key<br />
						<input type="text" name="ts_sitekey" size="50" maxlength="100" value="<?php echo pun_htmlspecialchars($cur['o_antispam_ts_sitekey']) ?>" /><br /></label>
						<label>Secret key<br />
						<input type="text" name="ts_secret" size="50" maxlength="100" value="<?php echo pun_htmlspecialchars($cur['o_antispam_ts_secret']) ?>" /><br /></label>
						<p>Leave both blank to disable. With keys set, the Turnstile widget appears on the registration form and is verified server-side. Get free keys at dash.cloudflare.com under Turnstile. You may then want to switch off the built-in image CAPTCHA (Administration → Options → Registration CAPTCHA) to avoid asking humans twice.</p>
					</div>
				</fieldset>
			</div>
			<p class="submitend"><input type="submit" name="save_antispam" value="Save settings" /></p>
		</form>
	</div>
</div>
