<?php

/**
 * Anti-spam Pack - an eveBB plugin.
 *
 * Layered defence for the registration form, cheapest checks first:
 *
 *   1. Honeypot - an extra text field invisible to humans (hidden with
 *      CSS) that bots reliably fill in. Filled = rejected.
 *   2. Time trap - the form carries a signed timestamp; a submission
 *      arriving faster than a human could possibly read and complete
 *      the form is rejected. The timestamp is HMAC-signed with the
 *      board's cookie_seed, so it cannot be forged or reused stale.
 *   3. StopForumSpam - the registrant's IP and email are checked
 *      against the stopforumspam.org database of known spam sources.
 *      Network failure fails OPEN (registration proceeds) so an API
 *      outage can never lock humans out.
 *   4. Cloudflare Turnstile (optional) - when site/secret keys are
 *      configured, the Turnstile widget is rendered and verified
 *      server-side. Runs alongside or instead of eveBB's built-in
 *      image CAPTCHA, as you prefer.
 *
 * All settings live under Administration -> Plugins -> Anti-spam Pack.
 * Endpoints can be overridden via constants (ANTISPAM_SFS_API,
 * ANTISPAM_TURNSTILE_API) in config.php - used by the test suite.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_antispam extends flux_addon
{
	function register($manager)
	{
		$manager->bind('register_before_submit', array($this, 'render_defences'));
		$manager->bind('register_before_validation', array($this, 'check_defences'));
	}

	// ---------------------------------------------------------------
	// Settings, with safe defaults (honeypot + time trap on, SFS on,
	// Turnstile off until keys are supplied)
	// ---------------------------------------------------------------

	function conf($key, $default)
	{
		global $pun_config;

		return isset($pun_config['o_antispam_'.$key]) ? $pun_config['o_antispam_'.$key] : $default;
	}

	function turnstile_configured()
	{
		return $this->conf('ts_sitekey', '') != '' && $this->conf('ts_secret', '') != '';
	}

	// ---------------------------------------------------------------
	// Form side: emitted inside the registration <form>
	// ---------------------------------------------------------------

	function render_defences()
	{
		if ($this->conf('honeypot', '1') == '1')
		{
			// A field humans never see; its name is chosen to look
			// irresistible to form-filling bots. aria-hidden + tabindex
			// keep it away from screen readers and keyboards too.
			echo "\t\t\t".'<div style="position:absolute;left:-9999px;top:-9999px" aria-hidden="true">'
				.'<label>Website <input type="text" name="req_website" value="" size="25" tabindex="-1" autocomplete="off" /></label>'
				.'</div>'."\n";
		}

		if ($this->conf('timetrap', '1') == '1')
			echo "\t\t\t".'<input type="hidden" name="antispam_ts" value="'.pun_htmlspecialchars($this->timetrap_token()).'" />'."\n";

		if ($this->turnstile_configured())
		{
			echo "\t\t\t".'<div class="inform"><fieldset><legend>Human check</legend><div class="infldset">'
				.'<div class="cf-turnstile" data-sitekey="'.pun_htmlspecialchars($this->conf('ts_sitekey', '')).'"></div>'
				.'</div></fieldset></div>'."\n";
			echo "\t\t\t".'<script src="https://challenges.cloudflare.com/turnstile/api.js" async defer></script>'."\n";
		}
	}

	// ---------------------------------------------------------------
	// Validation side: runs at the top of the registration POST
	// ---------------------------------------------------------------

	function check_defences()
	{
		global $lang_common;

		// 1. Honeypot: any content in the invisible field = bot
		if ($this->conf('honeypot', '1') == '1' && isset($_POST['req_website']) && trim($_POST['req_website']) !== '')
			$this->reject('honeypot');

		// 2. Time trap
		if ($this->conf('timetrap', '1') == '1')
		{
			$min = (int) $this->conf('timetrap_seconds', '3');
			$age = $this->timetrap_age(isset($_POST['antispam_ts']) ? $_POST['antispam_ts'] : '');

			// Missing/forged token, or submitted implausibly fast
			if ($age === false || $age < $min)
				$this->reject('timetrap');

			// Or absurdly stale (over 6 hours): token replay
			if ($age > 21600)
				$this->reject('timetrap-stale');
		}

		// 3. Turnstile (when configured): verify before spending an
		// external lookup on the request
		if ($this->turnstile_configured())
		{
			$response = isset($_POST['cf-turnstile-response']) ? $_POST['cf-turnstile-response'] : '';
			if (!$this->turnstile_verify($response))
				$this->reject('turnstile');
		}

		// 4. StopForumSpam reputation
		if ($this->conf('sfs', '1') == '1')
		{
			$email = isset($_POST['req_email1']) ? strtolower(trim($_POST['req_email1'])) : '';
			if ($this->sfs_is_spammer(get_remote_address(), $email))
				$this->reject('stopforumspam');
		}
	}

	//
	// Uniform rejection. Deliberately vague to give bots nothing to
	// learn from; the reason is appended as an HTML comment for the
	// admin reading the page source.
	//
	function reject($reason)
	{
		message('Your registration could not be accepted. If you believe this is a mistake, please contact the board administrator.'
			.'<!-- antispam: '.pun_htmlspecialchars($reason).' -->');
	}

	// ---------------------------------------------------------------
	// Time trap token: "<timestamp>-<hmac>"
	// ---------------------------------------------------------------

	function timetrap_token()
	{
		global $cookie_seed;

		$ts = time();
		return $ts.'-'.hash_hmac('sha256', 'antispam|'.$ts, $cookie_seed.'|antispam');
	}

	//
	// Returns the token's age in seconds, or false if missing/forged
	//
	function timetrap_age($token)
	{
		global $cookie_seed;

		if (!is_string($token) || !preg_match('/^(\d{9,11})-([a-f0-9]{64})$/', $token, $m))
			return false;

		$expected = hash_hmac('sha256', 'antispam|'.$m[1], $cookie_seed.'|antispam');
		if (!hash_equals($expected, $m[2]))
			return false;

		return time() - (int) $m[1];
	}

	// ---------------------------------------------------------------
	// External services (short timeouts, fail open)
	// ---------------------------------------------------------------

	function http($url, $post = null, $timeout = 4)
	{
		if (function_exists('curl_init'))
		{
			$ch = curl_init($url);
			curl_setopt_array($ch, array(
				CURLOPT_RETURNTRANSFER	=> true,
				CURLOPT_TIMEOUT			=> $timeout,
				CURLOPT_CONNECTTIMEOUT	=> $timeout,
				CURLOPT_USERAGENT		=> 'eveBB-antispam/1.0',
			));
			if ($post !== null)
			{
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
			}
			$body = curl_exec($ch);
			$status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);

			return ($body !== false && $status >= 200 && $status < 300) ? $body : false;
		}

		$context = stream_context_create(array('http' => array(
			'timeout'	=> $timeout,
			'method'	=> ($post !== null) ? 'POST' : 'GET',
			'header'	=> ($post !== null) ? "Content-Type: application/x-www-form-urlencoded\r\n" : '',
			'content'	=> ($post !== null) ? http_build_query($post) : null,
		)));

		$body = @file_get_contents($url, false, $context);
		return ($body !== false) ? $body : false;
	}

	//
	// True only when StopForumSpam positively identifies a spammer.
	// Any failure (network, parse) returns false: fail open.
	//
	function sfs_is_spammer($ip, $email)
	{
		$api = defined('ANTISPAM_SFS_API') ? ANTISPAM_SFS_API : 'https://api.stopforumspam.org/api';
		$url = $api.'?json&ip='.urlencode($ip).($email != '' ? '&email='.urlencode($email) : '');

		$body = $this->http($url);
		if ($body === false)
			return false;

		$data = json_decode($body, true);
		if (!is_array($data) || empty($data['success']))
			return false;

		$threshold = (float) $this->conf('sfs_confidence', '80');

		foreach (array('ip', 'email') as $part)
		{
			if (isset($data[$part]['appears']) && $data[$part]['appears']
				&& isset($data[$part]['confidence']) && (float) $data[$part]['confidence'] >= $threshold)
				return true;
		}

		return false;
	}

	//
	// True when Turnstile confirms the response token. Fails CLOSED
	// (rejects) on missing token, but fails OPEN on network error -
	// a Cloudflare outage should not close registration.
	//
	function turnstile_verify($response)
	{
		if ($response == '')
			return false;

		$api = defined('ANTISPAM_TURNSTILE_API') ? ANTISPAM_TURNSTILE_API : 'https://challenges.cloudflare.com/turnstile/v0/siteverify';

		$body = $this->http($api, array(
			'secret'	=> $this->conf('ts_secret', ''),
			'response'	=> $response,
			'remoteip'	=> get_remote_address(),
		));

		if ($body === false)
			return true; // fail open on network trouble

		$data = json_decode($body, true);
		return is_array($data) && !empty($data['success']);
	}
}
