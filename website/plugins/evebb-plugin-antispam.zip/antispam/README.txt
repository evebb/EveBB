Anti-spam Pack - an eveBB plugin
================================

Layered registration spam defence. Cheapest checks run first; every
layer can be switched off individually.

  1. Honeypot        - invisible field bots fill in (on by default)
  2. Time trap       - submissions faster than a human are rejected
                       (on by default, signed timestamps, no storage)
  3. StopForumSpam   - IP/email reputation check against
                       stopforumspam.org (on by default; fails open on
                       network trouble; see the privacy note in
                       settings)
  4. Turnstile       - optional Cloudflare Turnstile widget; enabled by
                       entering your site/secret keys in settings

INSTALL
  Administration -> Plugins -> upload this zip -> Activate.
  Settings live behind the plugin's "Settings" link in the same page.

Nothing is written to the database except the settings themselves.
Works alongside eveBB's built-in registration CAPTCHA; boards using
Turnstile may prefer to switch the built-in CAPTCHA off to avoid
challenging humans twice.

License: GPL v2 or later, same as eveBB. Built for eveBB 2.0.0-beta.1+.
