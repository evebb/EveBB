<?php

/**
 * Share Buttons - shared library.
 *
 * Network registry, config helpers and the guest-readable check. Used by
 * the addon (sharebuttons.php) and the settings page (admin.php).
 *
 * No tables: this plugin stores nothing but config values and emits pure
 * share-intent links - no counters, no tracking, no third-party scripts.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


//
// The share targets this plugin can offer, in display order.
// label = button text, color = brand background. The share-intent URL
// patterns live in the page JavaScript (the addon), keyed by these names.
// Instagram is absent by design: it has no web share URL.
//
function evebb_sharebuttons_networks()
{
	return array(
		'facebook' => array('label' => 'Facebook', 'color' => '#1877f2'),
		'x'        => array('label' => 'X',        'color' => '#000000'),
		'linkedin' => array('label' => 'LinkedIn', 'color' => '#0a66c2'),
		'reddit'   => array('label' => 'Reddit',   'color' => '#ff4500'),
		'bluesky'  => array('label' => 'Bluesky',  'color' => '#0085ff'),
		'whatsapp' => array('label' => 'WhatsApp', 'color' => '#25d366'),
		'telegram' => array('label' => 'Telegram', 'color' => '#26a5e4'),
		'email'    => array('label' => 'Email',    'color' => '#6b7280')
	);
}


//
// Read a plugin config value with a default
//
function evebb_sharebuttons_conf($name, $default = '')
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Insert or update a config value (caller refreshes the cache)
//
function evebb_sharebuttons_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


// Every config key this plugin owns (used by uninstall)
function evebb_sharebuttons_conf_names()
{
	return array(
		'o_sharebuttons_networks', 'o_sharebuttons_forums',
		'o_sharebuttons_heading', 'o_sharebuttons_copy',
		'o_sharebuttons_native', 'o_sharebuttons_guestgate'
	);
}


//
// Enabled networks, in registry order. Stored '' = all (including any
// added in future versions); otherwise a comma list of keys.
//
function evebb_sharebuttons_enabled()
{
	$all = evebb_sharebuttons_networks();
	$list = trim(evebb_sharebuttons_conf('o_sharebuttons_networks'));

	if ($list === '')
		return $all;

	$wanted = array_map('trim', explode(',', $list));
	$out = array();
	foreach ($all as $key => $net)
	{
		if (in_array($key, $wanted, true))
			$out[$key] = $net;
	}
	return $out;
}


//
// Forums the share row appears in. '' = every forum; otherwise ids.
//
function evebb_sharebuttons_forum_enabled($forum_id)
{
	$list = trim(evebb_sharebuttons_conf('o_sharebuttons_forums'));
	if ($list === '')
		return true;

	return in_array((int) $forum_id, array_map('intval', explode(',', $list)), true);
}


//
// Can a guest read this forum? Sharing a topic from a members-only forum
// hands out a link the recipient cannot open, so by default the share row
// only appears where guests can read. Mirrors core's forum_perms check:
// a missing row means readable.
//
function evebb_sharebuttons_guest_can_read($forum_id)
{
	global $db;

	$forum_id = (int) $forum_id;
	if ($forum_id < 1)
		return false;

	$result = $db->query('SELECT read_forum FROM '.$db->prefix.'forum_perms WHERE forum_id='.$forum_id.' AND group_id='.PUN_GUEST) or error('Unable to check forum permissions', __FILE__, __LINE__, $db->error());

	if (!$db->has_rows($result))
		return true; // no explicit deny

	return (int) $db->result($result) == 1;
}
