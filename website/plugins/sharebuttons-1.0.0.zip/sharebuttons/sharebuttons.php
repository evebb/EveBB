<?php

/**
 * Share Buttons - the addon.
 *
 * On topic pages, appends a "Share this topic" row of buttons under the
 * last post (inside .postlinksb) so visitors can share the topic to their
 * own accounts. Everything is a plain share-intent link built client-side
 * from a small config blob - no network SDKs, no iframes, no cookies, no
 * requests to anyone until a visitor actually clicks a button.
 *
 * The row only appears in forums a guest could read (configurable):
 * sharing a members-only topic hands out a link the recipient cannot open.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_sharebuttons extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}


	function head()
	{
		global $pun_config, $cur_topic, $id;

		// The hook can fire twice in one request when core re-includes
		// header.php (e.g. message() rendering an error page). Act once.
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		$page = isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : '';
		if ($page != 'viewtopic.php' || !isset($cur_topic) || !isset($id))
			return;

		if (!evebb_sharebuttons_forum_enabled($cur_topic['forum_id']))
			return;

		if (evebb_sharebuttons_conf('o_sharebuttons_guestgate', '1') == '1'
			&& !evebb_sharebuttons_guest_can_read($cur_topic['forum_id']))
			return;

		$networks = evebb_sharebuttons_enabled();
		$copy   = evebb_sharebuttons_conf('o_sharebuttons_copy', '1') == '1';
		$native = evebb_sharebuttons_conf('o_sharebuttons_native', '1') == '1';

		if (empty($networks) && !$copy && !$native)
			return;

		$nets = array();
		foreach ($networks as $key => $net)
			$nets[] = array('k' => $key, 'l' => $net['label'], 'c' => $net['color']);

		$cfg = array(
			'url'     => get_base_url(true).'/viewtopic.php?id='.(int) $id,
			'text'    => $cur_topic['subject'],
			'heading' => evebb_sharebuttons_conf('o_sharebuttons_heading', 'Share this topic'),
			'nets'    => $nets,
			'copy'    => $copy,
			'native'  => $native
		);

		$json = json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

?>
<style type="text/css">
.sharebuttons-row { margin: 0.8em 0 0.2em 0; clear: both; }
.sharebuttons-row .sharebuttons-head { margin-right: 0.6em; font-weight: bold; }
.sharebuttons-row a.sharebuttons-btn, .sharebuttons-row button.sharebuttons-btn {
	display: inline-block; margin: 0 0.35em 0.4em 0; padding: 0.28em 0.85em;
	border: 0; border-radius: 999px; font: inherit; font-size: 0.9em;
	color: #fff !important; text-decoration: none; cursor: pointer;
	line-height: 1.5; vertical-align: middle;
}
.sharebuttons-row .sharebuttons-btn:hover { opacity: 0.85; text-decoration: none; }
.sharebuttons-row button.sharebuttons-copy { background: #4b5563; }
.sharebuttons-row button.sharebuttons-native { background: #374151; }
</style>
<script type="text/javascript">
(function () {
	var cfg = <?php echo $json ?>;

	var PATTERNS = {
		facebook: function (u, t) { return 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(u); },
		x:        function (u, t) { return 'https://x.com/intent/post?url=' + encodeURIComponent(u) + '&text=' + encodeURIComponent(t); },
		linkedin: function (u, t) { return 'https://www.linkedin.com/sharing/share-offsite/?url=' + encodeURIComponent(u); },
		reddit:   function (u, t) { return 'https://www.reddit.com/submit?url=' + encodeURIComponent(u) + '&title=' + encodeURIComponent(t); },
		bluesky:  function (u, t) { return 'https://bsky.app/intent/compose?text=' + encodeURIComponent(t + ' ' + u); },
		whatsapp: function (u, t) { return 'https://wa.me/?text=' + encodeURIComponent(t + ' ' + u); },
		telegram: function (u, t) { return 'https://t.me/share/url?url=' + encodeURIComponent(u) + '&text=' + encodeURIComponent(t); },
		email:    function (u, t) { return 'mailto:?subject=' + encodeURIComponent(t) + '&body=' + encodeURIComponent(u); }
	};
	// Networks whose share pages behave nicely in a small popup window
	var POPUP = { facebook: 1, x: 1, linkedin: 1, reddit: 1, bluesky: 1, telegram: 1 };

	function build() {
		var box = document.querySelector('.postlinksb .inbox');
		if (!box) return;

		var row = document.createElement('p');
		row.className = 'sharebuttons-row';

		var head = document.createElement('span');
		head.className = 'sharebuttons-head';
		head.appendChild(document.createTextNode(cfg.heading));
		row.appendChild(head);

		for (var i = 0; i < cfg.nets.length; i++) (function (net) {
			if (!PATTERNS[net.k]) return;
			var href = PATTERNS[net.k](cfg.url, cfg.text);
			var a = document.createElement('a');
			a.className = 'sharebuttons-btn sharebuttons-' + net.k;
			a.style.backgroundColor = net.c;
			a.href = href;
			a.rel = 'noopener nofollow';
			if (net.k !== 'email') a.target = '_blank';
			a.appendChild(document.createTextNode(net.l));
			if (POPUP[net.k]) {
				a.addEventListener('click', function (e) {
					if (e.ctrlKey || e.metaKey || e.shiftKey) return;
					e.preventDefault();
					window.open(href, 'sharebuttons', 'noopener,width=640,height=560,menubar=no,toolbar=no');
				});
			}
			row.appendChild(a);
		})(cfg.nets[i]);

		if (cfg.copy) {
			var btn = document.createElement('button');
			btn.type = 'button';
			btn.className = 'sharebuttons-btn sharebuttons-copy';
			btn.appendChild(document.createTextNode('Copy link'));
			btn.addEventListener('click', function () {
				function done() {
					btn.firstChild.nodeValue = 'Copied!';
					setTimeout(function () { btn.firstChild.nodeValue = 'Copy link'; }, 1500);
				}
				if (navigator.clipboard && navigator.clipboard.writeText)
					navigator.clipboard.writeText(cfg.url).then(done, fallback);
				else
					fallback();
				function fallback() {
					var ta = document.createElement('textarea');
					ta.value = cfg.url;
					ta.style.position = 'fixed'; ta.style.opacity = '0';
					document.body.appendChild(ta);
					ta.select();
					try { document.execCommand('copy'); done(); } catch (err) {}
					document.body.removeChild(ta);
				}
			});
			row.appendChild(btn);
		}

		if (cfg.native && navigator.share) {
			var nb = document.createElement('button');
			nb.type = 'button';
			nb.className = 'sharebuttons-btn sharebuttons-native';
			nb.appendChild(document.createTextNode('Share…'));
			nb.addEventListener('click', function () {
				navigator.share({ title: cfg.text, url: cfg.url })['catch'](function () {});
			});
			row.appendChild(nb);
		}

		box.appendChild(row);
	}

	if (document.readyState === 'loading')
		document.addEventListener('DOMContentLoaded', build);
	else
		build();
})();
</script>
<?php
	}
}
