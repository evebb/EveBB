<?php

/**
 * Share Buttons - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome and inside a single
 * POST form (footer.php injects the CSRF token). $db, $pun_config and
 * $plugin_slug are available.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

$all_networks = evebb_sharebuttons_networks();
$net_total = count($all_networks);
$redir = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

// ---- Save settings ---------------------------------------------------------
if (isset($_POST['save_sharebuttons']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	// Networks: none or all ticked -> '' (= all, incl. future additions)
	$chosen = array();
	if (isset($_POST['networks']) && is_array($_POST['networks']))
	{
		foreach ($_POST['networks'] as $key)
		{
			if (isset($all_networks[$key]))
				$chosen[$key] = true;
		}
	}
	$n = count($chosen);
	evebb_sharebuttons_save_conf('o_sharebuttons_networks', ($n === 0 || $n === $net_total) ? '' : implode(',', array_keys($chosen)));

	// Forums: none ticked -> '' (= every forum)
	$forums = array();
	if (isset($_POST['forums']) && is_array($_POST['forums']))
	{
		foreach ($_POST['forums'] as $fid)
		{
			$fid = (int) $fid;
			if ($fid > 0)
				$forums[] = $fid;
		}
	}
	evebb_sharebuttons_save_conf('o_sharebuttons_forums', implode(',', $forums));

	$heading = pun_trim($_POST['heading'] ?? '');
	if (pun_strlen($heading) > 60)
		$heading = '';
	evebb_sharebuttons_save_conf('o_sharebuttons_heading', $heading !== '' ? $heading : 'Share this topic');

	evebb_sharebuttons_save_conf('o_sharebuttons_copy', isset($_POST['copy']) ? '1' : '0');
	evebb_sharebuttons_save_conf('o_sharebuttons_native', isset($_POST['native']) ? '1' : '0');
	evebb_sharebuttons_save_conf('o_sharebuttons_guestgate', isset($_POST['guestgate']) ? '1' : '0');

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect($redir, 'Settings saved. Redirecting …');
}

// ---- Remove all plugin data ------------------------------------------------
if (isset($_POST['nuke_sharebuttons']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$names = array();
	foreach (evebb_sharebuttons_conf_names() as $n)
	{
		$names[] = '\''.$db->escape($n).'\'';
		unset($pun_config[$n]);
	}
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN ('.implode(', ', $names).')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Share Buttons settings removed. You can now deactivate and delete the plugin. Redirecting …');
}

// ---- Read current state ----------------------------------------------------
$enabled   = evebb_sharebuttons_enabled();
$heading   = evebb_sharebuttons_conf('o_sharebuttons_heading', 'Share this topic');
$copy      = evebb_sharebuttons_conf('o_sharebuttons_copy', '1') == '1';
$native    = evebb_sharebuttons_conf('o_sharebuttons_native', '1') == '1';
$guestgate = evebb_sharebuttons_conf('o_sharebuttons_guestgate', '1') == '1';

$sel_forums = trim(evebb_sharebuttons_conf('o_sharebuttons_forums'));
$sel_forums = $sel_forums === '' ? array() : array_map('intval', explode(',', $sel_forums));

// Forum tree for the picker
$forum_tree = array();
$result = $db->query('SELECT c.cat_name, f.id, f.forum_name FROM '.$db->prefix.'categories AS c INNER JOIN '.$db->prefix.'forums AS f ON f.cat_id=c.id ORDER BY c.disp_position, c.id, f.disp_position') or error('Unable to fetch forum list', __FILE__, __LINE__, $db->error());
while ($row = $db->fetch_assoc($result))
	$forum_tree[$row['cat_name']][] = $row;

?>
		<div class="inform">
			<fieldset>
				<legend>Share Buttons</legend>
				<div class="infldset">
					<p>Adds a row of share buttons at the bottom of every topic page so visitors can share topics to <strong>their own</strong> social media accounts. The buttons are plain share links &mdash; no tracking scripts, no cookies, and no request leaves the visitor's browser until they actually click one. Instagram is not offered because it has no web share URL.</p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Buttons</legend>
				<div class="infldset">
					<p>Offer these share targets (untick every box, or tick them all, to offer <em>all</em> of them, including any added in future versions):</p>
<?php foreach ($all_networks as $key => $net): ?>
					<label style="display:inline-block;margin-right:1em"><input type="checkbox" name="networks[]" value="<?php echo $key ?>"<?php if (isset($enabled[$key])) echo ' checked="checked"' ?> /> <?php echo pun_htmlspecialchars($net['label']) ?></label>
<?php endforeach; ?>
					<p class="topspace">Extras:</p>
					<label style="display:inline-block;margin-right:1em"><input type="checkbox" name="copy" value="1"<?php if ($copy) echo ' checked="checked"' ?> /> Copy link button</label>
					<label style="display:inline-block"><input type="checkbox" name="native" value="1"<?php if ($native) echo ' checked="checked"' ?> /> Native share button (the device's own share sheet &mdash; phones and tablets; only shown where the browser supports it)</label>
					<label class="topspace">Row heading<br /><input type="text" name="heading" size="30" maxlength="60" value="<?php echo pun_htmlspecialchars($heading) ?>" /></label>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Where</legend>
				<div class="infldset">
					<p>Show the share row in these forums (tick none for <em>every</em> forum):</p>
<?php foreach ($forum_tree as $cat => $forums): ?>
					<p style="margin-bottom:.2em"><strong><?php echo pun_htmlspecialchars($cat) ?></strong></p>
<?php foreach ($forums as $f): ?>
					<label style="display:inline-block;margin:0 1em .2em 1em"><input type="checkbox" name="forums[]" value="<?php echo (int) $f['id'] ?>"<?php if (in_array((int) $f['id'], $sel_forums, true)) echo ' checked="checked"' ?> /> <?php echo pun_htmlspecialchars($f['forum_name']) ?></label>
<?php endforeach; ?>
					<br />
<?php endforeach; ?>
					<label class="topspace"><input type="checkbox" name="guestgate" value="1"<?php if ($guestgate) echo ' checked="checked"' ?> /> Only show the row in forums guests can read (recommended &mdash; a shared link into a private forum can't be opened by the people it's shared with)</label>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Save</legend>
				<div class="infldset">
					<p><input type="submit" name="save_sharebuttons" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Uninstall</legend>
				<div class="infldset">
					<p>This plugin keeps no data of its own beyond these settings. Remove them below, then deactivate and delete the plugin on the plugins page.</p>
					<p><input type="submit" name="nuke_sharebuttons" value="Remove all plugin settings" /></p>
				</div>
			</fieldset>
		</div>
<?php
