# Share Buttons for eveBB

Lets your visitors share topics to **their own** social media accounts.
A tidy row of brand-coloured buttons appears at the bottom of every
topic page: **Facebook, X, LinkedIn, Reddit, Bluesky, WhatsApp,
Telegram, Email**, plus a **Copy link** button and — on phones and
tablets — a **Share…** button that opens the device's native share
sheet (so anything installed on the visitor's phone is a target,
including apps with no web share URL).

## Privacy by design

Every button is a plain share-intent link built in the visitor's
browser. The plugin loads **no third-party JavaScript, no SDKs, no
iframes, no tracking pixels and sets no cookies** — no request leaves
the visitor's browser until they actually click a button. That also
means no consent banner implications and nothing for the board admin
to sign up for.

Instagram is not offered because Instagram has no web share URL.

## Installation

1. Upload the `sharebuttons` folder to your board's `plugins/`
   directory (or upload the zip via Administration → Plugins).
2. Activate it. The share row appears immediately with every button
   enabled and the heading "Share this topic".
3. Optionally open its settings to choose networks, restrict it to
   certain forums, toggle the Copy-link / native-share buttons, or
   change the heading.

Requires eveBB 2.0+ (or FluxBB 1.5 with the eveBB plugin manager).

## Behaviour notes

* By default the row only appears in forums **guests can read**:
  sharing a members-only topic would hand out a link the recipients
  cannot open. A settings toggle disables this gate if you want the
  row everywhere.
* Desktop clicks on Facebook/X/LinkedIn/Reddit/Bluesky/Telegram open
  a small share popup; Ctrl/Cmd-click still opens a normal tab.
  WhatsApp opens in a new tab and Email uses the visitor's mail app.
* The shared link is the topic's canonical `viewtopic.php?id=` URL
  built from the board's Base URL — make sure that is `https://` on
  an https board.
* Uninstall cleanly from the settings page (removes the config
  values; the plugin has no tables), then deactivate and delete.

## License

GPL version 2 or higher, like eveBB itself.
