<?php

/**
 * GitHub Sign-in - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome and inside a single
 * POST form (footer.php injects the CSRF token). $db, $pun_config and
 * $plugin_slug are available.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

githubauth_bootstrap();

$redir = 'admin_plugins.php?action=settings&plugin='.$plugin_slug;

if (isset($_POST['save_githubauth']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	githubauth_save_config('o_githubauth_client_id', pun_trim($_POST['gh_client_id'] ?? ''));
	githubauth_save_config('o_githubauth_client_secret', pun_trim($_POST['gh_client_secret'] ?? ''));
	githubauth_save_config('o_githubauth_link_by_email', isset($_POST['gh_link_by_email']) ? '1' : '0');

	redirect($redir, 'Settings saved. Redirecting …');
}

if (isset($_POST['nuke_githubauth']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect($redir, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('githubauth_users');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN (\'o_githubauth_db_rev\', \'o_githubauth_client_id\', \'o_githubauth_client_secret\', \'o_githubauth_link_by_email\')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());
	unset($pun_config['o_githubauth_db_rev'], $pun_config['o_githubauth_client_id'], $pun_config['o_githubauth_client_secret'], $pun_config['o_githubauth_link_by_email']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All GitHub Sign-in data removed. You can now deactivate and delete the plugin. Redirecting …');
}

$client_id     = githubauth_conf('o_githubauth_client_id', '');
$client_secret = githubauth_conf('o_githubauth_client_secret', '');
$link_by_email = githubauth_conf('o_githubauth_link_by_email', '1') == '1';
$callback      = githubauth_callback_url();

$result = $db->query('SELECT COUNT(*) FROM '.$db->prefix.'githubauth_users') or error('Unable to count linked accounts', __FILE__, __LINE__, $db->error());
$linked = (int) $db->result($result);

?>
		<div class="inform">
			<fieldset>
				<legend>GitHub OAuth application</legend>
				<div class="infldset">
					<p>Create an OAuth app at <strong>GitHub → Settings → Developer settings → OAuth Apps → New OAuth App</strong>, then paste its Client ID and a Client Secret below. Set the app's <strong>Authorization callback URL</strong> to exactly:</p>
					<p><code><?php echo pun_htmlspecialchars($callback) ?></code></p>
					<label>Client ID<br /><input type="text" name="gh_client_id" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($client_id) ?>" /></label>
					<label>Client Secret<br /><input type="text" name="gh_client_secret" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($client_secret) ?>" /></label>
					<p><?php if (githubauth_configured()): ?><strong>Status:</strong> configured. A &quot;Sign in with GitHub&quot; button now appears on the login and registration pages.<?php else: ?><strong>Status:</strong> not configured yet.<?php endif; ?> Linked accounts: <strong><?php echo $linked ?></strong>.</p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Account matching</legend>
				<div class="infldset">
					<label><input type="checkbox" name="gh_link_by_email" value="1"<?php if ($link_by_email) echo ' checked="checked"' ?> /> Link a GitHub sign-in to an existing member when one of the GitHub account's <em>verified</em> email addresses matches that member's email</label>
					<p>With this off, GitHub sign-ins only ever log in accounts already linked, or create brand-new ones. Only email addresses GitHub has verified are ever used for matching.</p>
					<p class="topspace"><input type="submit" name="save_githubauth" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>How it works</legend>
				<div class="infldset">
					<p>New sign-ins take the GitHub username as the forum username (deconflicted if taken) and a verified GitHub email as the account email. If GitHub provides no usable verified email, the visitor is asked to confirm one before the account is created. Accounts made this way get a random unusable password; members who want a password login as well can set one through the normal &quot;forgotten password&quot; flow.</p>
				</div>
			</fieldset>
		</div>

		<div class="inform">
			<fieldset>
				<legend>Uninstall</legend>
				<div class="infldset">
					<p>To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the githubauth_users table (the account links, not the accounts) and this plugin's settings.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently removes all GitHub account links</label></p>
					<p><input type="submit" name="nuke_githubauth" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
