<?php

/**
 * GitHub Sign-in - shared library.
 *
 * The OAuth2 flow, account matching/creation, and small helpers used by the
 * addon (githubauth.php), the endpoint (auth.php) and the settings page
 * (admin.php).
 *
 * Base URLs are overridable via the GITHUBAUTH_OAUTH_BASE / GITHUBAUTH_API_BASE
 * constants so the test suite can point them at a local mock.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

if (!defined('GITHUBAUTH_DB_REV'))
	define('GITHUBAUTH_DB_REV', 1);


function githubauth_oauth_base()
{
	return defined('GITHUBAUTH_OAUTH_BASE') ? GITHUBAUTH_OAUTH_BASE : 'https://github.com';
}

function githubauth_api_base()
{
	return defined('GITHUBAUTH_API_BASE') ? GITHUBAUTH_API_BASE : 'https://api.github.com';
}


//
// Configured once an OAuth app's client id + secret are set.
//
function githubauth_configured()
{
	global $pun_config;

	return !empty($pun_config['o_githubauth_client_id'])
		&& !empty($pun_config['o_githubauth_client_secret']);
}


//
// The callback URL to register in the GitHub OAuth app settings.
//
function githubauth_callback_url()
{
	return get_base_url().'/plugins/githubauth/auth.php';
}


//
// Read a plugin config value with a default.
//
function githubauth_conf($name, $default)
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Fetch a URL. HTTPS-only for remote hosts (loopback may be plain HTTP for
// the test mocks). $post may be a string. Returns body or false.
//
function githubauth_http($url, $post = null, $headers = array(), $timeout = 15)
{
	$host = parse_url($url, PHP_URL_HOST);
	$is_loopback = in_array($host, array('127.0.0.1', '::1', 'localhost'), true);
	if (!$is_loopback && stripos($url, 'https://') !== 0)
		return false;

	$headers[] = 'User-Agent: eveBB-githubauth/1.0 (+'.get_base_url().')';

	if (function_exists('curl_init'))
	{
		$ch = curl_init($url);
		curl_setopt_array($ch, array(
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_MAXREDIRS      => 3,
			CURLOPT_TIMEOUT        => $timeout,
			CURLOPT_CONNECTTIMEOUT => 10,
			CURLOPT_HTTPHEADER     => $headers,
			CURLOPT_SSL_VERIFYPEER => true,
			CURLOPT_SSL_VERIFYHOST => 2,
			CURLOPT_PROTOCOLS      => CURLPROTO_HTTPS | CURLPROTO_HTTP,
			CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS
		));
		if ($post !== null)
		{
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		$body = curl_exec($ch);
		$status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
		curl_close($ch);

		return ($body !== false && $status >= 200 && $status < 300) ? $body : false;
	}

	if (ini_get('allow_url_fopen'))
	{
		$http = array(
			'timeout'         => $timeout,
			'follow_location' => 1,
			'max_redirects'   => 3,
			'protocol_version'=> 1.1,
			'ignore_errors'   => false,
			'header'          => implode("\r\n", $headers)."\r\n"
		);
		if ($post !== null)
		{
			$http['method'] = 'POST';
			$http['content'] = $post;
		}
		$context = stream_context_create(array('http' => $http, 'ssl' => array('verify_peer' => true, 'verify_peer_name' => true)));
		$body = @file_get_contents($url, false, $context);

		return ($body !== false) ? $body : false;
	}

	return false;
}

function githubauth_http_json($url, $post = null, $headers = array(), $timeout = 15)
{
	$body = githubauth_http($url, $post, $headers, $timeout);
	if ($body === false)
		return false;
	$data = json_decode($body, true);
	return is_array($data) ? $data : false;
}


// ---------------------------------------------------------------------------
// Sealed tokens (stateless, HMAC-signed with the board's cookie seed)
// ---------------------------------------------------------------------------

function githubauth_b64url_encode($data)
{
	return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function githubauth_b64url_decode($data)
{
	return base64_decode(strtr($data, '-_', '+/'));
}

function githubauth_seal($data)
{
	global $cookie_seed;

	$data['_t'] = time();
	$payload = githubauth_b64url_encode(json_encode($data));

	return $payload.'.'.forum_hmac($payload, $cookie_seed.'_githubauth');
}

function githubauth_unseal($token, $max_age = 1800)
{
	global $cookie_seed;

	if (!is_string($token) || substr_count($token, '.') != 1)
		return false;

	list($payload, $mac) = explode('.', $token);
	if (!hash_equals(forum_hmac($payload, $cookie_seed.'_githubauth'), $mac))
		return false;

	$data = json_decode(githubauth_b64url_decode($payload), true);
	if (!is_array($data) || !isset($data['_t']))
		return false;

	$age = time() - (int) $data['_t'];
	if ($age < 0 || $age > $max_age)
		return false;

	return $data;
}


// ---------------------------------------------------------------------------
// OAuth flow
// ---------------------------------------------------------------------------

//
// The GitHub authorize URL for this board. A state nonce is dropped in a
// short-lived cookie so the callback can confirm the flow started in this
// same browser (login-CSRF protection on top of the HMAC).
//
function githubauth_authorize_url($intent)
{
	global $pun_config;

	$nonce = random_key(12, true);
	forum_setcookie('githubauth_state', $nonce, time() + 900);

	$state = githubauth_seal(array('n' => $nonce, 'i' => $intent));

	return githubauth_oauth_base().'/login/oauth/authorize?'.http_build_query(array(
		'client_id'    => $pun_config['o_githubauth_client_id'],
		'redirect_uri' => githubauth_callback_url(),
		'scope'        => 'read:user user:email',
		'state'        => $state,
		'allow_signup' => 'false'
	));
}

//
// Exchange an authorization code for an access token. Returns the token
// string or false.
//
function githubauth_exchange_code($code)
{
	global $pun_config;

	$data = githubauth_http_json(githubauth_oauth_base().'/login/oauth/access_token',
		http_build_query(array(
			'client_id'     => $pun_config['o_githubauth_client_id'],
			'client_secret' => $pun_config['o_githubauth_client_secret'],
			'code'          => $code,
			'redirect_uri'  => githubauth_callback_url()
		)),
		array('Accept: application/json', 'Content-Type: application/x-www-form-urlencoded'));

	if ($data === false || empty($data['access_token']))
		return false;

	return (string) $data['access_token'];
}

//
// The verified GitHub identity behind an access token:
//   array('id' =>, 'login' =>, 'name' =>, 'avatar_url' =>,
//         'email' => primary-verified-or-'', 'verified_emails' => array())
// or false.
//
function githubauth_identity($token)
{
	$auth = array('Authorization: Bearer '.$token, 'Accept: application/vnd.github+json');

	$user = githubauth_http_json(githubauth_api_base().'/user', null, $auth);
	if ($user === false || empty($user['id']) || empty($user['login']))
		return false;

	$verified = array();
	$primary = '';
	$emails = githubauth_http_json(githubauth_api_base().'/user/emails', null, $auth);
	if (is_array($emails))
	{
		foreach ($emails as $e)
		{
			if (empty($e['email']) || empty($e['verified']))
				continue;
			$addr = strtolower(trim($e['email']));
			$verified[] = $addr;
			if (!empty($e['primary']))
				$primary = $addr;
		}
		if ($primary === '' && !empty($verified))
			$primary = $verified[0];
	}

	return array(
		'id'              => (int) $user['id'],
		'login'           => (string) $user['login'],
		'name'            => isset($user['name']) ? (string) $user['name'] : '',
		'avatar_url'      => isset($user['avatar_url']) ? (string) $user['avatar_url'] : '',
		'email'           => $primary,
		'verified_emails' => $verified
	);
}


// ---------------------------------------------------------------------------
// Schema + config
// ---------------------------------------------------------------------------

function githubauth_save_config($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// First-run bootstrap: the link table + default settings. Guarded by
// o_githubauth_db_rev.
//
function githubauth_bootstrap()
{
	global $db, $pun_config;

	if (isset($pun_config['o_githubauth_db_rev']) && (int) $pun_config['o_githubauth_db_rev'] >= GITHUBAUTH_DB_REV)
		return;

	if (!$db->table_exists('githubauth_users'))
	{
		$schema = array(
			'FIELDS' => array(
				'user_id' => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'github_id' => array('datatype' => 'BIGINT(20) UNSIGNED', 'allow_null' => false, 'default' => '0'),
				'github_login' => array('datatype' => 'VARCHAR(64)', 'allow_null' => false, 'default' => '\'\''),
				'avatar_url' => array('datatype' => 'VARCHAR(255)', 'allow_null' => false, 'default' => '\'\''),
				'linked_at' => array('datatype' => 'INT(10) UNSIGNED', 'allow_null' => false, 'default' => '0')
			),
			'PRIMARY KEY' => array('user_id'),
			'UNIQUE KEYS' => array('github_id_idx' => array('github_id'))
		);

		$db->create_table('githubauth_users', $schema) or error('Unable to create githubauth_users table', __FILE__, __LINE__, $db->error());
	}

	if (!isset($pun_config['o_githubauth_link_by_email']))
		githubauth_save_config('o_githubauth_link_by_email', '1');

	githubauth_save_config('o_githubauth_db_rev', (string) GITHUBAUTH_DB_REV);
}


// ---------------------------------------------------------------------------
// Account matching / creation / login
// ---------------------------------------------------------------------------

//
// The forum user row bound to a GitHub id, or null.
//
function githubauth_user_by_github($github_id)
{
	global $db;

	$result = $db->query('SELECT u.*, g.github_id, g.github_login FROM '.$db->prefix.'githubauth_users AS g INNER JOIN '.$db->prefix.'users AS u ON u.id=g.user_id WHERE g.github_id='.(int) $github_id) or error('Unable to fetch GitHub user', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? $db->fetch_assoc($result) : null;
}

//
// A real (non-guest) forum user row whose email matches, that is NOT already
// bound to some other GitHub account. Null if none.
//
function githubauth_user_by_email($email)
{
	global $db;

	$email = strtolower(trim($email));
	if ($email === '')
		return null;

	$result = $db->query('SELECT u.* FROM '.$db->prefix.'users AS u LEFT JOIN '.$db->prefix.'githubauth_users AS g ON g.user_id=u.id WHERE u.id>1 AND g.user_id IS NULL AND LOWER(u.email)=\''.$db->escape($email).'\' ORDER BY u.id LIMIT 1') or error('Unable to fetch user by email', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? $db->fetch_assoc($result) : null;
}

//
// Bind a GitHub identity to an existing forum user.
//
function githubauth_link($user_id, $gh)
{
	global $db;

	$db->query('INSERT INTO '.$db->prefix.'githubauth_users (user_id, github_id, github_login, avatar_url, linked_at) VALUES('.(int) $user_id.', '.(int) $gh['id'].', \''.$db->escape($gh['login']).'\', \''.$db->escape($gh['avatar_url']).'\', '.time().')') or error('Unable to link GitHub account', __FILE__, __LINE__, $db->error());
}

//
// Turn a GitHub login into a valid, unique forum username. Uses core's
// check_username() rules (length, reserved words, bans, dupes) and appends a
// numeric suffix on collision. Returns a username string, or '' if no usable
// candidate could be formed.
//
function githubauth_pick_username($login, $name)
{
	global $errors;

	$candidates = array();

	$base = pun_trim(preg_replace('%\s+%', ' ', $login));
	if ($base !== '')
		$candidates[] = $base;

	$nm = pun_trim(preg_replace('%\s+%', ' ', $name));
	if ($nm !== '')
		$candidates[] = $nm;

	foreach ($candidates as $cand)
	{
		if (pun_strlen($cand) > 25)
			$cand = pun_trim(utf8_substr($cand, 0, 25));

		for ($i = 0; $i <= 99; $i++)
		{
			$try = ($i === 0) ? $cand : (pun_trim(utf8_substr($cand, 0, 22)).$i);

			$saved = $errors;
			$errors = array();
			check_username($try);
			$ok = empty($errors);
			$errors = $saved;

			if ($ok)
				return $try;
		}
	}

	return '';
}

//
// Create a forum account for a verified GitHub identity, linked to it.
// Returns the new user id (int) or a string error key:
//   'closed', 'email', 'banned_email', 'dupe_email', 'username'
//
function githubauth_create_user($gh, $email)
{
	global $db, $pun_config;

	if ($pun_config['o_regs_allow'] == '0')
		return 'closed';

	require_once PUN_ROOT.'include/email.php';

	$email = strtolower(pun_trim($email));
	if (!is_valid_email($email))
		return 'email';

	if (is_banned_email($email) && $pun_config['p_allow_banned_email'] == '0')
		return 'banned_email';

	if ($pun_config['p_allow_dupe_email'] == '0')
	{
		$result = $db->query('SELECT 1 FROM '.$db->prefix.'users WHERE email=\''.$db->escape($email).'\'') or error('Unable to fetch user info', __FILE__, __LINE__, $db->error());
		if ($db->has_rows($result))
			return 'dupe_email';
	}

	$username = githubauth_pick_username($gh['login'], $gh['name']);
	if ($username === '')
		return 'username';

	$now = time();
	$group_id = intval($pun_config['o_default_user_group']);
	$password_hash = flux_password_hash(random_pass(24));

	$db->query('INSERT INTO '.$db->prefix.'users (username, group_id, password, email, email_setting, timezone, dst, language, style, registered, registration_ip, last_visit) VALUES(\''.$db->escape($username).'\', '.$group_id.', \''.$db->escape($password_hash).'\', \''.$db->escape($email).'\', '.intval($pun_config['o_default_email_setting']).', '.floatval($pun_config['o_default_timezone']).', '.intval($pun_config['o_default_dst']).', \''.$db->escape($pun_config['o_default_lang']).'\', \''.$db->escape($pun_config['o_default_style']).'\', '.$now.', \''.$db->escape(get_remote_address()).'\', '.$now.')') or error('Unable to create user', __FILE__, __LINE__, $db->error());
	$new_uid = (int) $db->insert_id();

	githubauth_link($new_uid, $gh);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_users_info_cache();

	return $new_uid;
}

//
// Log a user row in (mirrors login.php's success path).
//
function githubauth_login_user($cur_user)
{
	global $db, $pun_config;

	$db->query('DELETE FROM '.$db->prefix.'online WHERE ident=\''.$db->escape(get_remote_address()).'\'') or error('Unable to delete from online list', __FILE__, __LINE__, $db->error());

	pun_setcookie($cur_user['id'], $cur_user['password'], time() + $pun_config['o_timeout_visit']);
	set_tracked_topics(null);
}
