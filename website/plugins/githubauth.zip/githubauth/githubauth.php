<?php

/**
 * GitHub Sign-in - the addon.
 *
 * Adds a "Sign in with GitHub" panel to the login and registration pages
 * (guests only), leaving the normal password form in place as an equal
 * option. The OAuth flow itself lives in auth.php (the callback URL).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_githubauth extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		global $pun_user;

		// message() re-includes header.php - never run twice
		static $busy;
		if ($busy)
			return;
		$busy = true;

		require_once dirname(__FILE__).'/lib.php';

		githubauth_bootstrap();

		if (githubauth_configured() && $pun_user['is_guest'])
		{
			$page = basename($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '');
			if ($page == 'login.php')
				$this->inject('#login', 'Sign in with GitHub to access this board. You can also use the password form below.', 'login', true);
			else if ($page == 'register.php')
				$this->inject('#regform', 'Create your account by signing in with GitHub - no separate password needed. You can also register with the form below.', 'register', false);
		}

		$busy = false;
	}

	//
	// Emit a script that builds the GitHub panel and drops it at the top of
	// the target form's box. All dynamic strings go through json_encode and
	// the DOM is built with createElement (no innerHTML), so nothing can
	// break out. The "Octocat" mark is an inline SVG data URI.
	//
	function inject($host_selector, $blurb, $intent, $inside_login)
	{
		$data = array(
			'go'    => githubauth_callback_url().'?a=go&intent='.$intent,
			'blurb' => $blurb,
			'label' => 'Sign in with GitHub'
		);

		echo '<script>/* GitHub Sign-in */'."\n"
			.'document.addEventListener("DOMContentLoaded",function(){'
			.'var d='.json_encode($data, JSON_UNESCAPED_SLASHES).';'
			.'var host=document.querySelector('.json_encode($host_selector).');if(!host)return;'
			.'var box=host.querySelector(".box")||host;'
			.'var wrap=document.createElement("div");wrap.className="inform";'
			.'var fs=document.createElement("fieldset");'
			.'var lg=document.createElement("legend");lg.textContent="GitHub";fs.appendChild(lg);'
			.'var inner=document.createElement("div");inner.className="infldset";'
			.'var p=document.createElement("p");p.textContent=d.blurb;inner.appendChild(p);'
			.'var a=document.createElement("a");a.href=d.go;'
			.'a.style.cssText="display:inline-block;margin:8px 0 4px;padding:9px 16px;background:#24292f;color:#fff;border:1px solid #1b1f23;border-radius:6px;font-weight:bold;text-decoration:none;";'
			.'var svg=\'<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="#fff" style="vertical-align:text-bottom;margin-right:8px;"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.01 8.01 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>\';'
			.'var ic=document.createElement("span");ic.innerHTML=svg;a.appendChild(ic.firstChild);'
			.'a.appendChild(document.createTextNode(d.label));'
			.'var wp=document.createElement("p");wp.style.cssText="clear:both;";wp.appendChild(a);inner.appendChild(wp);'
			.'fs.appendChild(inner);wrap.appendChild(fs);'
			.($inside_login
				? 'var f=host.querySelector("form");if(f){f.insertBefore(wrap,f.firstChild);}else{box.insertBefore(wrap,box.firstChild);}'
				: 'box.insertBefore(wrap,box.firstChild);')
			.'});</script>'."\n";
	}
}
