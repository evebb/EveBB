<?php

/**
 * GitHub Sign-in - the OAuth endpoint.
 *
 * This is the "Authorization callback URL" registered in the GitHub OAuth
 * app:  <board>/plugins/githubauth/auth.php
 *
 * Actions (?a=):
 *   go       redirect the guest to the GitHub authorize page
 *   (none)   OAuth callback: ?code=...&state=... - the verified GitHub
 *            identity comes back here; a linked account is logged in, a
 *            matching account (verified email) is linked and logged in,
 *            otherwise a new account is created (an email is requested
 *            first if GitHub gave us no usable verified address)
 *   create   POST from the email confirmation form: create the account
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

//
// This page lives under plugins/githubauth/ but the forum chrome links its
// assets relative to the forum root. Absolutize relative href/src on the way
// out so the page renders and navigates like a root page.
//
function githubauth_absolutize($html)
{
	$base = get_base_url().'/';
	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('githubauth_absolutize');

if (!in_array('githubauth', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

githubauth_bootstrap();

if (!githubauth_configured())
	message('GitHub Sign-in is not configured yet. An administrator must finish the plugin setup first.');

if (!$pun_user['is_guest'])
{
	$db->end_transaction();
	header('Location: '.get_base_url().'/index.php');
	exit;
}

$action = isset($_GET['a']) ? $_GET['a'] : null;


// ---------------------------------------------------------------------------
// go: hand the guest to GitHub
// ---------------------------------------------------------------------------
if ($action == 'go')
{
	$intent = (isset($_GET['intent']) && $_GET['intent'] == 'login') ? 'login' : 'register';
	$url = githubauth_authorize_url($intent);

	$db->end_transaction();
	header('Location: '.$url);
	exit;
}


// ---------------------------------------------------------------------------
// create: POST from the email confirmation form
// ---------------------------------------------------------------------------
else if ($action == 'create')
{
	if (!isset($_POST['form_sent']))
		message($lang_common['Bad request'], false, '404 Not Found');

	check_csrf($_POST['csrf_token'] ?? null);

	$gh = githubauth_unseal($_POST['githubauth_tok'] ?? '');
	if ($gh === false || empty($gh['id']) || empty($gh['login']))
		message('Your GitHub sign-in has expired. Please <a href="'.pun_htmlspecialchars(githubauth_callback_url()).'?a=go">start again</a>.');

	// They may have completed sign-in in another tab meanwhile
	$existing = githubauth_user_by_github($gh['id']);
	if ($existing !== null)
	{
		githubauth_login_user($existing);
		redirect('index.php', $lang_common['Redirecting']);
	}

	$result = githubauth_create_user($gh, $_POST['req_email'] ?? '');

	if (is_int($result))
	{
		$new_user = githubauth_user_by_github($gh['id']);
		if ($new_user !== null)
			githubauth_login_user($new_user);

		redirect('index.php', 'Welcome to '.pun_htmlspecialchars($pun_config['o_board_title']).'. Registration complete.');
	}

	$errmap = array(
		'closed'       => 'This board is not accepting new registrations at the moment.',
		'email'        => 'The email address you entered is invalid.',
		'banned_email' => 'The email address you entered is not allowed on this board.',
		'dupe_email'   => 'Someone has already registered with that email address.',
		'username'     => 'A usable username could not be derived from your GitHub account. Please contact the board administrator.'
	);
	$githubauth_error = isset($errmap[$result]) ? $errmap[$result] : 'Registration failed. Please try again.';

	if ($result == 'closed' || $result == 'username')
		message($githubauth_error);

	// Re-render the form
	$githubauth_gh = $gh;
	$githubauth_tok = githubauth_seal(array_diff_key($gh, array('_t' => 1)));
	$githubauth_email = pun_trim($_POST['req_email'] ?? '');
}


// ---------------------------------------------------------------------------
// callback: ?code=...&state=...
// ---------------------------------------------------------------------------
else if (isset($_GET['code']))
{
	$state = githubauth_unseal($_GET['state'] ?? '', 900);
	if ($state === false || empty($state['n']) || !isset($_COOKIE['githubauth_state']) || !hash_equals($state['n'], (string) $_COOKIE['githubauth_state']))
		message('Your GitHub sign-in could not be verified (the state check failed). Please <a href="'.pun_htmlspecialchars(githubauth_callback_url()).'?a=go">try again</a>.');

	forum_setcookie('githubauth_state', '', 1); // spend the nonce

	$token = githubauth_exchange_code($_GET['code']);
	if ($token === false)
		message('GitHub did not confirm your sign-in. Please try again in a moment.');

	$gh = githubauth_identity($token);
	if ($gh === false)
		message('Could not read your GitHub profile. Please try again in a moment.');

	// 1) Already linked -> log in.
	$existing = githubauth_user_by_github($gh['id']);
	if ($existing !== null)
	{
		githubauth_login_user($existing);
		redirect('index.php', $lang_common['Redirecting']);
	}

	// 2) Match an existing account by a verified email (opt-out setting).
	if (githubauth_conf('o_githubauth_link_by_email', '1') == '1' && !empty($gh['verified_emails']))
	{
		foreach ($gh['verified_emails'] as $addr)
		{
			$match = githubauth_user_by_email($addr);
			if ($match !== null)
			{
				githubauth_link($match['id'], $gh);
				githubauth_login_user($match);
				redirect('index.php', 'Your GitHub account has been linked. '.$lang_common['Redirecting']);
			}
		}
	}

	// 3) New account.
	if ($pun_config['o_regs_allow'] == '0')
		message('This board is not accepting new registrations at the moment.');

	// If GitHub gave us a usable verified primary email, create straight away.
	if ($gh['email'] !== '')
	{
		$result = githubauth_create_user($gh, $gh['email']);
		if (is_int($result))
		{
			$new_user = githubauth_user_by_github($gh['id']);
			if ($new_user !== null)
				githubauth_login_user($new_user);
			redirect('index.php', 'Welcome to '.pun_htmlspecialchars($pun_config['o_board_title']).'. Registration complete.');
		}
		// email problem (dupe/banned) -> fall through to the form to fix it
		$githubauth_prefill_error = ($result == 'dupe_email') ? 'An account already uses that GitHub email. Enter a different address to finish, or contact the administrator to link your existing account.' : null;
	}

	$githubauth_gh = $gh;
	$githubauth_tok = githubauth_seal($gh);
	$githubauth_email = ($gh['email'] !== '' && empty($githubauth_prefill_error)) ? $gh['email'] : '';
	$githubauth_error = isset($githubauth_prefill_error) ? $githubauth_prefill_error : null;
}

else
{
	$db->end_transaction();
	header('Location: '.get_base_url().'/login.php');
	exit;
}


// ---------------------------------------------------------------------------
// Render the email confirmation form
// ---------------------------------------------------------------------------
$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), 'GitHub registration');
$required_fields = array('req_email' => $lang_common['Email']);
$focus_element = array('githubauth_confirm', 'req_email');

define('PUN_ACTIVE_PAGE', 'register');
require PUN_ROOT.'header.php';

$avatar = ($githubauth_gh['avatar_url'] !== '' && preg_match('%^https://%i', $githubauth_gh['avatar_url'])) ? $githubauth_gh['avatar_url'] : '';

if (!empty($githubauth_error))
{
?>
<div id="posterror" class="block">
	<h2><span>Registration errors</span></h2>
	<div class="box">
		<div class="inbox error-info">
			<ul class="error-list">
				<li><strong><?php echo $githubauth_error ?></strong></li>
			</ul>
		</div>
	</div>
</div>
<?php
}
?>
<div id="regform" class="blockform">
	<h2><span>GitHub registration</span></h2>
	<div class="box">
		<form id="githubauth_confirm" method="post" action="<?php echo pun_htmlspecialchars(githubauth_callback_url()) ?>?a=create" onsubmit="return process_form(this)">
			<div class="inform">
				<div class="forminfo">
					<h3>GitHub account verified</h3>
					<p>You have signed in with GitHub as the account below. Confirm an email address to finish creating your forum account.</p>
				</div>
				<fieldset>
					<legend>Your GitHub account</legend>
					<div class="infldset">
						<input type="hidden" name="form_sent" value="1" />
						<input type="hidden" name="githubauth_tok" value="<?php echo pun_htmlspecialchars($githubauth_tok) ?>" />
						<p id="githubauth-acct">
							<?php if ($avatar != ''): ?><img src="<?php echo pun_htmlspecialchars($avatar) ?>" width="64" height="64" alt="" style="float: left; margin: 0 12px 8px 0; border-radius: 4px;" /><?php endif; ?>
							<strong><?php echo pun_htmlspecialchars($githubauth_gh['login']) ?></strong>
							<?php if ($githubauth_gh['name'] != ''): ?><br /><?php echo pun_htmlspecialchars($githubauth_gh['name']) ?><?php endif; ?>
						</p>
						<p class="clearb">Your forum username will be based on your GitHub username.</p>
					</div>
				</fieldset>
			</div>
			<div class="inform">
				<fieldset>
					<legend>Enter a valid email address</legend>
					<div class="infldset">
						<p>The board uses your email only for password recovery and any notifications you opt into. It is never shown publicly.</p>
						<label class="required"><strong><?php echo $lang_common['Email'] ?> <span><?php echo $lang_common['Required'] ?></span></strong><br />
						<input type="text" name="req_email" value="<?php echo pun_htmlspecialchars($githubauth_email) ?>" size="50" maxlength="80" /><br /></label>
					</div>
				</fieldset>
			</div>
			<p class="buttons"><input type="submit" name="register" value="Complete registration" /></p>
		</form>
	</div>
</div>
<?php

require PUN_ROOT.'footer.php';
