# GitHub Sign-in

An unofficial eveBB plugin that adds a **Sign in with GitHub** button to the
login and registration pages. It works *alongside* the normal password login
rather than replacing it, so existing members and admins keep their password
form.

## What it does

- New visitors sign in with GitHub and get a forum account created from their
  GitHub profile — username from their GitHub login (deconflicted if taken),
  email from a **verified** GitHub email address.
- If GitHub gives no usable verified email, the visitor confirms one before
  the account is created.
- Existing members can be matched automatically: if one of the GitHub
  account's **verified** emails equals a member's forum email, the GitHub
  sign-in is linked to that account and logs them in. (Optional — can be
  turned off.)
- A returning GitHub user is recognised by their GitHub account id and logged
  straight in.

## Setup

1. On GitHub, go to **Settings → Developer settings → OAuth Apps → New OAuth
   App**.
2. Set the **Authorization callback URL** to exactly (shown on the plugin's
   settings page):

   ```
   https://your-board/plugins/githubauth/auth.php
   ```

3. Copy the **Client ID** and generate a **Client Secret**.
4. On the board, open **Admin → Plugins → GitHub Sign-in** and paste them in.

The scopes requested are `read:user user:email` (profile plus email
addresses, read-only).

## Security

- The OAuth `state` parameter is an HMAC-signed token (keyed with the board's
  cookie seed) *and* is cross-checked against a short-lived nonce cookie, so a
  forged or replayed callback is rejected.
- Only **verified** GitHub emails are ever used to match or create accounts.
- Accounts created through GitHub get a random, unusable password. A member
  who also wants a password login can set one through the normal
  "forgotten password" flow.

## Uninstall

Use **Remove all plugin data** on the settings page (drops the
`githubauth_users` link table — the forum accounts themselves are untouched —
and this plugin's settings), then deactivate and delete the plugin.

## License

GPL version 2 or higher — http://www.gnu.org/licenses/gpl.html
