# Showcase Directory for eveBB

A browsable gallery built from your release topics — an extensions
directory that maintains itself.

## What it does

Map one or more forums (say, Styles & Themes and Plugins &
Modifications) and the plugin renders a gallery page at
`<board>/plugins/showcase/`, one card per release:

- **A topic becomes a card when its first post contains a download
  link** — a `.zip`, or any link with `/downloads/` in its path.
  Question and discussion topics never appear. Nothing is entered
  twice: post an announcement like you already do and the catalogue
  updates itself.
- The card takes its **name from the topic subject**, its
  **description from the opening text** (BBCode stripped), and its
  **thumbnail from the first image in the post** (cards without an
  image get a clean monogram tile). Each card has a Download button and
  a Discussion link into the topic.
- **Permission-aware**: visitors only see sections for forums their
  group can read — same rules as the rest of the board.
- **Approved badges**: administrators get an *Approve* link on every
  card; approved entries carry a green **✓ Approved** badge so visitors
  can tell at a glance which releases the board staff have checked.
  Everything stays listed either way — the badge is a trust signal, not
  a gate.
- A **Showcase link** is added to the board navigation (or untick that
  and add the URL via Administration → Options → Additional menu items
  for a no-JavaScript nav).

## Install

Upload the zip through Administration → Plugins, activate, then enter
the forum IDs to showcase on the settings page. One small table stores
the approval marks (created automatically); the settings page has a
one-click data removal for clean uninstalls.

Tip: give each release topic a screenshot in its first post and the
gallery turns properly visual, especially for styles.

License: GPL v2 or higher, same as eveBB.
