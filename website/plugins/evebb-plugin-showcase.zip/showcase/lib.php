<?php

/**
 * Showcase Directory - shared library.
 *
 * Entries are derived live from topics in the mapped forums: a topic
 * whose FIRST post contains a download link (a .zip, or anything under
 * a /downloads/ path) is a release and becomes a card. The first
 * [img] in that post becomes the thumbnail; the BBCode-stripped opening
 * text becomes the excerpt. Nothing is stored - the forum stays the
 * single source of truth.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

define('SHOWCASE_DB_REV', 1);

//
// Upsert a config value + refresh the cache
//
function showcase_save_config($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}

function showcase_page_url()
{
	return get_base_url(true).'/plugins/showcase/';
}

//
// First-run bootstrap: the approvals table (guarded by config key, same
// pattern as the solved plugin)
//
function showcase_bootstrap()
{
	global $db, $pun_config;

	if (isset($pun_config['o_showcase_db_rev']) && intval($pun_config['o_showcase_db_rev']) >= SHOWCASE_DB_REV)
		return;

	$db->query('CREATE TABLE IF NOT EXISTS '.$db->prefix.'showcase_approved (
		topic_id INT NOT NULL,
		approved_by INT NOT NULL DEFAULT 0,
		approved_at INT NOT NULL DEFAULT 0,
		PRIMARY KEY (topic_id)
	)') or error('Unable to create showcase_approved table', __FILE__, __LINE__, $db->error());

	showcase_save_config('o_showcase_db_rev', (string) SHOWCASE_DB_REV);
}

//
// Which of these topic IDs carry the staff Approved mark?
// Returns topic_id => true.
//
function showcase_approved_set($topic_ids)
{
	global $db;

	$topic_ids = array_values(array_map('intval', $topic_ids));
	if (empty($topic_ids))
		return array();

	$result = $db->query('SELECT topic_id FROM '.$db->prefix.'showcase_approved WHERE topic_id IN('.implode(',', $topic_ids).')') or error('Unable to fetch approvals', __FILE__, __LINE__, $db->error());

	$set = array();
	while ($row = $db->fetch_assoc($result))
		$set[(int) $row['topic_id']] = true;

	return $set;
}

//
// Set/clear the Approved mark on a topic (caller has already verified
// the actor is an administrator and the topic is showcased)
//
function showcase_set_approved($topic_id, $approve, $user_id)
{
	global $db;

	$db->query('DELETE FROM '.$db->prefix.'showcase_approved WHERE topic_id='.intval($topic_id)) or error('Unable to clear approval', __FILE__, __LINE__, $db->error());
	if ($approve)
		$db->query('INSERT INTO '.$db->prefix.'showcase_approved (topic_id, approved_by, approved_at) VALUES('.intval($topic_id).', '.intval($user_id).', '.time().')') or error('Unable to save approval', __FILE__, __LINE__, $db->error());
}

//
// The mapped forum IDs (setting), in the order the admin listed them
//
function showcase_forum_ids()
{
	global $pun_config;

	$ids = array();
	foreach (explode(',', $pun_config['o_showcase_forums'] ?? '') as $bit)
	{
		if (intval(trim($bit)) > 0)
			$ids[] = intval(trim($bit));
	}

	return array_unique($ids);
}

//
// Find the download link in a first post's BBCode source.
// Returns the URL or null. A download link is a .zip, or any URL with
// /downloads/ in its path.
//
function showcase_download_link($message)
{
	$urls = array();

	// [url=X]... and [url]X[/url]
	if (preg_match_all('%\[url=([^\]\s]+)\]%i', $message, $m))
		$urls = array_merge($urls, $m[1]);
	if (preg_match_all('%\[url\]([^\[\s]+)\[/url\]%i', $message, $m))
		$urls = array_merge($urls, $m[1]);
	// bare URLs
	if (preg_match_all('%https?://[^\s\[\]<>"\']+%i', $message, $m))
		$urls = array_merge($urls, $m[0]);

	foreach ($urls as $url)
	{
		$path = parse_url($url, PHP_URL_PATH);
		if ($path === null || $path === false)
			continue;
		if (preg_match('%\.zip$%i', $path) || stripos($path, '/downloads/') !== false)
			return $url;
	}

	return null;
}

//
// First [img] URL in a first post's BBCode source, or null
//
function showcase_thumbnail($message)
{
	if (preg_match('%\[img(?:=[^\]]*)?\]\s*(https?://[^\[\s]+)\s*\[/img\]%i', $message, $m))
		return $m[1];

	return null;
}

//
// Plain-text excerpt of a BBCode message
//
function showcase_excerpt($message, $length = 190)
{
	// Drop quote/code blocks entirely - they're rarely descriptive
	$text = preg_replace('%\[(quote|code)(?:=[^\]]*)?\].*?\[/\1\]%is', ' ', $message);
	// Drop img tags with their contents
	$text = preg_replace('%\[img(?:=[^\]]*)?\][^\[]*\[/img\]%i', ' ', $text);
	// Strip remaining BBCode tags, keep their inner text
	$text = preg_replace('%\[/?[a-z*]+(?:=[^\]]*)?\]%i', '', $text);
	// Bare URLs read badly in an excerpt - the card has its own buttons
	$text = preg_replace('%https?://[^\s]+%i', '', $text);
	// Collapse whitespace and orphaned punctuation left by removals
	$text = pun_trim(preg_replace('%\s+%', ' ', $text));
	$text = pun_trim(preg_replace('%\s+([.,;:!?])%', '$1', $text));

	if (pun_strlen($text) > $length)
		$text = pun_trim(utf8_substr($text, 0, $length)).' …';

	return $text;
}

//
// The mapped forums the current user may read, as forum_id => forum_name,
// in the admin's listed order (used by the sections builder and by the
// search form's section dropdown).
//
function showcase_readable_forums()
{
	global $db, $pun_user;

	$forum_ids = showcase_forum_ids();
	if (empty($forum_ids))
		return array();

	$result = $db->query('SELECT f.id, f.forum_name FROM '.$db->prefix.'forums AS f LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.$pun_user['g_id'].') WHERE f.id IN('.implode(',', $forum_ids).') AND (fp.read_forum IS NULL OR fp.read_forum=1)') or error('Unable to fetch forums', __FILE__, __LINE__, $db->error());

	$names = array();
	while ($row = $db->fetch_assoc($result))
		$names[(int) $row['id']] = $row['forum_name'];

	$ordered = array();
	foreach ($forum_ids as $forum_id)
		if (isset($names[$forum_id]))
			$ordered[$forum_id] = $names[$forum_id];

	return $ordered;
}

//
// Escape a user search term for use inside a LIKE pattern. '!' is the
// escape character (declared with ESCAPE '!') because it is quoting-safe
// across MySQL, SQLite and PostgreSQL, unlike backslash.
//
function showcase_like_escape($term)
{
	return str_replace(array('!', '%', '_'), array('!!', '!%', '!_'), $term);
}

//
// The showcase content for the current user: array of sections, each
// array('forum_id', 'forum_name', 'entries' => [...]). Forums the
// viewing user cannot read are silently absent (same forum_perms
// pattern as search.php).
//
// $search filters by topic subject (case-insensitive substring; applied
// in SQL so it reaches entries older than the normal newest-first scan
// window). $only_forum restricts to one mapped section (0 = all).
//
function showcase_sections($search = '', $only_forum = 0)
{
	global $db, $pun_user, $pun_config;

	$names = showcase_readable_forums();
	if (empty($names))
		return array();

	$max = max(1, min(200, intval($pun_config['o_showcase_max'] ?? 50)));

	$search_sql = '';
	if ($search !== '')
	{
		$pattern = '%'.showcase_like_escape(utf8_strtolower($search)).'%';
		$search_sql = ' AND LOWER(t.subject) LIKE \''.$db->escape($pattern).'\' ESCAPE \'!\'';
	}

	$sections = array();
	foreach ($names as $forum_id => $forum_name)
	{
		if ($only_forum > 0 && $forum_id != $only_forum)
			continue;

		$result = $db->query('SELECT t.id, t.subject, t.poster, t.posted, t.num_replies, p.message FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'posts AS p ON p.id=t.first_post_id WHERE t.forum_id='.$forum_id.' AND t.moved_to IS NULL'.$search_sql.' ORDER BY t.posted DESC LIMIT '.($max * 3)) or error('Unable to fetch topics', __FILE__, __LINE__, $db->error());

		$entries = array();
		while (count($entries) < $max && ($row = $db->fetch_assoc($result)))
		{
			$download = showcase_download_link($row['message']);
			if ($download === null)
				continue;   // not a release topic

			$entries[] = array(
				'topic_id'	=> (int) $row['id'],
				'subject'	=> $row['subject'],
				'poster'	=> $row['poster'],
				'posted'	=> (int) $row['posted'],
				'replies'	=> (int) $row['num_replies'],
				'download'	=> $download,
				'thumb'		=> showcase_thumbnail($row['message']),
				'excerpt'	=> showcase_excerpt($row['message']),
			);
		}

		if (!empty($entries))
			$sections[] = array('forum_id' => $forum_id, 'forum_name' => $forum_name, 'entries' => $entries);
	}

	return $sections;
}
