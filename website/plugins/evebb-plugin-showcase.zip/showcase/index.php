<?php

/**
 * Showcase Directory - the gallery page.
 *
 * Standalone page rendered inside the full forum chrome (same pattern
 * as eveauth's sso.php: relative asset/nav URLs are absolutized on the
 * way out because this file lives under plugins/).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

//
// Absolutize relative href/src so forum chrome works from /plugins/showcase/
//
function showcase_absolutize($html)
{
	$base = get_base_url(true).'/';

	return preg_replace_callback(
		'%\b(href|src)=(["\'])(?!https?:|//|/|\#|mailto:|data:|javascript:)([^"\']*)\2%i',
		function ($m) use ($base) { return $m[1].'='.$m[2].$base.$m[3].$m[2]; },
		$html
	);
}
ob_start('showcase_absolutize');

if (!in_array('showcase', evebb_active_plugins()))
	message($lang_common['Bad request'], false, '404 Not Found');

showcase_bootstrap();

$sc_is_admin = ($pun_user['g_id'] == PUN_ADMIN);

// Administrators only: toggle the Approved mark on a showcased topic
if ($sc_is_admin && isset($_GET['sc_approve']))
{
	check_csrf($_GET['csrf_token'] ?? null);

	$topic_id = intval($_GET['sc_approve']);
	$state = (($_GET['state'] ?? '') == '1');

	// Re-validate server-side: the topic must live in a mapped forum
	$mapped = showcase_forum_ids();
	if ($topic_id > 0 && !empty($mapped))
	{
		$result = $db->query('SELECT 1 FROM '.$db->prefix.'topics WHERE id='.$topic_id.' AND moved_to IS NULL AND forum_id IN('.implode(',', $mapped).')') or error('Unable to fetch topic', __FILE__, __LINE__, $db->error());
		if ($db->has_rows($result))
			showcase_set_approved($topic_id, $state, $pun_user['id']);
	}

	redirect(showcase_page_url(), 'Saved. Redirecting …');
}

$sections = showcase_sections();

// Approval badges (one query across every listed topic)
$sc_all_ids = array();
foreach ($sections as $section)
	foreach ($section['entries'] as $entry)
		$sc_all_ids[] = $entry['topic_id'];
$sc_approved = showcase_approved_set($sc_all_ids);

$page_title = array(pun_htmlspecialchars($pun_config['o_board_title']), 'Showcase');
define('PUN_ACTIVE_PAGE', 'index');
define('PUN_ALLOW_INDEX', 1);
require PUN_ROOT.'header.php';

?>
<style>
.showcase-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 14px; padding: 6px 0; }
.showcase-card { border: 1px solid rgba(128,128,128,.35); border-radius: 5px; overflow: hidden; display: flex; flex-direction: column; background: rgba(128,128,128,.06); }
.showcase-thumb { aspect-ratio: 16/9; background: linear-gradient(135deg, rgba(230,115,0,.25), rgba(51,55,59,.4)) center/cover no-repeat; display: flex; align-items: center; justify-content: center; font-size: 34px; font-weight: bold; opacity: .95; }
.showcase-body { padding: 10px 12px 12px; display: flex; flex-direction: column; flex: 1; }
.showcase-body h4 { margin: 0 0 6px; font-size: 14px; }
.showcase-body p.sc-excerpt { font-size: 12px; margin: 0 0 8px; flex: 1; }
.showcase-body p.sc-meta { font-size: 11px; opacity: .75; margin: 0 0 10px; }
.showcase-actions a.sc-dl { display: inline-block; padding: 5px 12px; background: #e67300; color: #fff; border-radius: 3px; font-weight: bold; font-size: 12px; text-decoration: none; }
.showcase-actions a.sc-topic { font-size: 12px; margin-left: 10px; }
.sc-approved { display: inline-block; padding: 1px 8px; background: #2e7d32; color: #fff; border-radius: 10px; font-size: 11px; font-weight: bold; margin-left: 6px; vertical-align: 2px; white-space: nowrap; }
.sc-adminact { font-size: 11px; margin: 6px 0 0; opacity: .85; }
</style>
<div class="block">
	<h2><span>Showcase</span></h2>
	<div class="box">
		<div class="inbox">
<?php

if (empty($sections))
{
	if (empty(showcase_forum_ids()))
		echo "\t\t\t".'<p>The showcase has not been configured yet — an administrator needs to map one or more forums on the plugin settings page.</p>'."\n";
	else
		echo "\t\t\t".'<p>Nothing to show yet — releases appear here automatically once topics with download links are posted.</p>'."\n";
}

foreach ($sections as $section)
{
	echo "\t\t\t".'<h3 style="margin: 12px 0 2px;">'.pun_htmlspecialchars($section['forum_name']).' <span style="font-weight: normal; font-size: 12px; opacity: .7;">(<a href="'.get_base_url(true).'/viewforum.php?id='.$section['forum_id'].'">forum</a>)</span></h3>'."\n";
	echo "\t\t\t".'<div class="showcase-grid">'."\n";

	foreach ($section['entries'] as $entry)
	{
		$topic_url = get_base_url(true).'/viewtopic.php?id='.$entry['topic_id'];

		echo "\t\t\t\t".'<div class="showcase-card">'."\n";
		if ($entry['thumb'] !== null)
			echo "\t\t\t\t\t".'<a href="'.pun_htmlspecialchars($topic_url).'"><div class="showcase-thumb" style="background-image: url('.pun_htmlspecialchars($entry['thumb']).')"></div></a>'."\n";
		else
			echo "\t\t\t\t\t".'<a href="'.pun_htmlspecialchars($topic_url).'" style="text-decoration: none;"><div class="showcase-thumb">'.pun_htmlspecialchars(utf8_substr(pun_trim($entry['subject']), 0, 1)).'</div></a>'."\n";
		$is_approved = isset($sc_approved[$entry['topic_id']]);

		echo "\t\t\t\t\t".'<div class="showcase-body">'."\n";
		echo "\t\t\t\t\t\t".'<h4><a href="'.pun_htmlspecialchars($topic_url).'">'.pun_htmlspecialchars($entry['subject']).'</a>'.($is_approved ? '<span class="sc-approved" title="Checked and approved by the board staff">&#10003; Approved</span>' : '').'</h4>'."\n";
		if ($entry['excerpt'] != '')
			echo "\t\t\t\t\t\t".'<p class="sc-excerpt">'.pun_htmlspecialchars($entry['excerpt']).'</p>'."\n";
		echo "\t\t\t\t\t\t".'<p class="sc-meta">'.pun_htmlspecialchars($entry['poster']).' &middot; '.format_time($entry['posted'], true).' &middot; '.forum_number_format($entry['replies']).' '.($entry['replies'] == 1 ? 'reply' : 'replies').'</p>'."\n";
		echo "\t\t\t\t\t\t".'<p class="showcase-actions"><a class="sc-dl" href="'.pun_htmlspecialchars($entry['download']).'">Download</a><a class="sc-topic" href="'.pun_htmlspecialchars($topic_url).'">Discussion &raquo;</a></p>'."\n";
		if ($sc_is_admin)
			echo "\t\t\t\t\t\t".'<p class="sc-adminact"><a href="'.pun_htmlspecialchars(showcase_page_url().'?sc_approve='.$entry['topic_id'].'&state='.($is_approved ? '0' : '1').'&csrf_token='.pun_csrf_token()).'">'.($is_approved ? 'Remove approval' : 'Approve').'</a></p>'."\n";
		echo "\t\t\t\t\t".'</div>'."\n";
		echo "\t\t\t\t".'</div>'."\n";
	}

	echo "\t\t\t".'</div>'."\n";
}

?>
		</div>
	</div>
</div>
<?php

require PUN_ROOT.'footer.php';
