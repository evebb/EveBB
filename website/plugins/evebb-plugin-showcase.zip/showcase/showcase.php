<?php

/**
 * Showcase Directory - the addon.
 *
 * Adds the "Showcase" link to the board navigation (JS-injected;
 * boards that prefer server-side nav can instead add the URL through
 * Administration → Options → Additional menu items and untick the
 * setting). The gallery itself is index.php in this folder.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_showcase extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'nav_link'));
	}

	function nav_link()
	{
		global $pun_config;

		if (($pun_config['o_showcase_navlink'] ?? '1') != '1')
			return;

		require_once dirname(__FILE__).'/lib.php';

		echo '<script>document.addEventListener("DOMContentLoaded",function(){'
			.'var m=document.querySelector("#brdmenu ul");if(!m)return;'
			.'if(document.getElementById("navshowcase"))return;'
			.'var li=document.createElement("li");li.id="navshowcase";'
			.'var a=document.createElement("a");a.href='.json_encode(showcase_page_url(), JSON_UNESCAPED_SLASHES).';a.textContent="Showcase";'
			.'li.appendChild(a);'
			.'var ref=document.getElementById("navsearch")||document.getElementById("navuserlist");'
			.'if(ref&&ref.parentNode===m){m.insertBefore(li,ref);}else{m.appendChild(li);}'
			.'});</script>'."\n";
	}
}
