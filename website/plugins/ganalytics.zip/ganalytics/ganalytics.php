<?php

/**
 * Google Analytics - the addon.
 *
 * Emits the Google Analytics 4 (gtag.js) tag into <head> on board pages.
 * The measurement ID is set on the plugin's settings page; until it is,
 * the plugin emits nothing at all.
 *
 * Consent integration: when the Cookie Consent plugin is active and in
 * consent mode, the tag is only emitted for visitors who accepted all
 * cookies. Everyone else gets a tiny stub that subscribes to the consent
 * API instead - if the visitor clicks "Accept all", Analytics loads live
 * in that same page view; if they later switch to "Essential only", the
 * stub expires Google's _ga* cookies (best effort).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


class plugin_ganalytics extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
	}

	function head()
	{
		global $pun_config, $pun_user;

		// One emission per request (message() can re-include header.php)
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		// Never track the admin console
		if (defined('PUN_ADMIN_CONSOLE'))
			return;

		// A valid measurement ID is the on/off switch
		$ga_id = isset($pun_config['o_ga_id']) ? $pun_config['o_ga_id'] : '';
		if (preg_match('%^(G|GT)-[A-Z0-9]{4,20}$%', $ga_id) !== 1)
			return;

		// Optionally leave staff out of the numbers
		if (isset($pun_config['o_ga_skip_staff']) && $pun_config['o_ga_skip_staff'] == '1')
		{
			if ($pun_user['g_id'] == PUN_ADMIN || $pun_user['g_moderator'] == '1')
				return;
		}

		// Consent gating: only when the Cookie Consent plugin is active AND
		// running in consent mode. Its addon is loaded whenever it is
		// active, so its helpers exist; the function_exists guard covers
		// unusual contexts. Without it (or in notice mode) the tag loads
		// for everyone.
		$gated = function_exists('evebb_plugin_is_active') && evebb_plugin_is_active('cookieconsent')
			&& isset($pun_config['o_cconsent_mode']) && $pun_config['o_cconsent_mode'] == 'consent';

		$allowed = !$gated || (function_exists('evebb_cconsent_status') && evebb_cconsent_status() == 'all');

		$cfg = array(
			'id'     => $ga_id,
			'gaMode' => $allowed ? 'direct' : 'deferred'
		);

		$json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

		echo '<script type="text/javascript">/* Google Analytics plugin */'."\n".'(function(){'."\n"
			.'var cfg = '.$json.';'."\n"
			.<<<'EOJS'
function load() {
	if (window.__evebbGaLoaded) return;
	window.__evebbGaLoaded = true;
	window.dataLayer = window.dataLayer || [];
	window.gtag = window.gtag || function () { dataLayer.push(arguments); };
	gtag('js', new Date());
	gtag('config', cfg.id);
	var s = document.createElement('script');
	s.async = true;
	s.src = 'https://www.googletagmanager.com/gtag/js?id=' + cfg.id;
	(document.head || document.documentElement).appendChild(s);
}

// Best effort removal of Google's cookies when consent is withdrawn
function expireGaCookies() {
	var names = document.cookie.split(';');
	for (var i = 0; i < names.length; i++) {
		var name = names[i].split('=')[0].replace(/^\s+/, '');
		if (name.indexOf('_ga') !== 0) continue;
		var kill = name + '=; max-age=0; path=/';
		document.cookie = kill;
		document.cookie = kill + '; domain=' + location.hostname;
		document.cookie = kill + '; domain=.' + location.hostname;
	}
}

if (cfg.gaMode === 'direct')
	load();

// Always listen for consent changes: a deferred page loads Analytics live
// on "Accept all", and ANY page (direct included) cleans up Google's
// cookies the moment the visitor withdraws to "Essential only".
var cb = function (status) {
	if (status === 'all') load();
	else if (status === 'essential') expireGaCookies();
};
if (window.evebbConsent && window.evebbConsent.subscribe)
	window.evebbConsent.subscribe(cb);
else
	(window.evebbConsentQ = window.evebbConsentQ || []).push(cb);
EOJS
			."\n".'})();</script>'."\n";
	}
}
