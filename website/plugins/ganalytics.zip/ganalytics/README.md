# Google Analytics — official eveBB plugin

Adds the Google Analytics 4 tag (gtag.js) to every board page.

- Set your **GA4 measurement ID** (`G-XXXXXXXXXX`, from Admin → Data
  streams in Google Analytics) on the settings page. With no ID set the
  plugin emits nothing at all.
- Optionally **exclude administrators and moderators** so staff activity
  doesn't skew your numbers.
- The **admin console is never tracked**.

## Cookie consent (recommended)

Analytics cookies need prior consent under UK PECR / GDPR-style rules.
Run this plugin together with the **Cookie Consent** plugin in *consent*
mode:

- Visitors who haven't accepted optional cookies get no Analytics tag at
  all — just a ~½ KB stub.
- The moment a visitor clicks "Accept all", Analytics loads live in that
  same page view (no reload needed).
- If a visitor later switches to "Essential only" via the footer's
  "Cookie preferences" link, the stub expires Google's `_ga*` cookies on a
  best-effort basis.

Without Cookie Consent (or with it in notice mode) the tag simply loads
for everyone; the settings page shows a compliance reminder in that case.
After enabling Analytics on an established board, use Cookie Consent's
"Bump policy version" button so existing visitors are asked again.

## Installation

1. Administration → Plugins → upload `ganalytics.zip`.
2. Activate **Google Analytics**.
3. Open **Settings** and paste your measurement ID.

No database changes; configuration lives in the board config values
`o_ga_id` and `o_ga_skip_staff`. Uninstalling is just deactivate + delete.

## Notes

- GA4 only. Universal Analytics (`UA-…`) was shut down by Google in 2023
  and is not supported.
- The measurement ID is validated (`G-`/`GT-` followed by 4–20
  letters/digits), so nothing unexpected can be injected into pages.
- Google's script is loaded from `www.googletagmanager.com`; if a
  visitor blocks it, the board works exactly as normal.

## License

GPL v2 or later, same as eveBB.
