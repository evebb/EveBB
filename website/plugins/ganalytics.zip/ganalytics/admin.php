<?php

/**
 * Google Analytics - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome (and inside a POST
 * form that footer.php injects the CSRF token into). $db, $pun_config and
 * $plugin_slug are available here.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

//
// Local config upsert (this plugin has no lib of its own)
//
function evebb_ga_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}

// Save settings
if (isset($_POST['save_ga']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$ga_id = strtoupper(pun_trim($_POST['ga_id'] ?? ''));
	if ($ga_id != '' && preg_match('%^(G|GT)-[A-Z0-9]{4,20}$%', $ga_id) !== 1)
	{
		// Reject junk outright rather than silently tracking nothing
		redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'That does not look like a GA4 measurement ID (expected G-XXXXXXXXXX). Nothing saved. Redirecting …');
	}

	evebb_ga_save_conf('o_ga_id', $ga_id);
	evebb_ga_save_conf('o_ga_skip_staff', isset($_POST['ga_skip_staff']) ? '1' : '0');

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}

$ga_id         = isset($pun_config['o_ga_id']) ? $pun_config['o_ga_id'] : '';
$ga_skip_staff = isset($pun_config['o_ga_skip_staff']) && $pun_config['o_ga_skip_staff'] == '1';

$cc_active = function_exists('evebb_plugin_is_active') && evebb_plugin_is_active('cookieconsent');
$cc_consent_mode = $cc_active && isset($pun_config['o_cconsent_mode']) && $pun_config['o_cconsent_mode'] == 'consent';

?>
		<div class="inform">
			<fieldset>
				<legend>Google Analytics settings</legend>
				<div class="infldset">
					<p>Adds the Google Analytics 4 tag (gtag.js) to every board page. Leave the measurement ID empty to switch tracking off — the plugin then emits nothing at all. The admin console is never tracked.</p>
					<label>GA4 measurement ID (looks like <code>G-XXXXXXXXXX</code>; find it under Admin → Data streams in Google Analytics)
						<br /><input type="text" name="ga_id" size="25" maxlength="25" value="<?php echo pun_htmlspecialchars($ga_id) ?>" />
					</label>
					<label><input type="checkbox" name="ga_skip_staff" value="1"<?php if ($ga_skip_staff) echo ' checked="checked"' ?> /> Don't track administrators and moderators (keeps staff activity out of your numbers)</label>
					<p class="topspace"><input type="submit" name="save_ga" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Cookie consent</legend>
				<div class="infldset">
<?php if ($cc_consent_mode): ?>
					<p><strong>Good:</strong> the Cookie Consent plugin is active in consent mode. Analytics only loads for visitors who choose “Accept all” (and loads live the moment they do). If a visitor later switches to “Essential only”, Google's <code>_ga</code> cookies are expired on a best-effort basis.</p>
<?php elseif ($cc_active): ?>
					<p><strong>Heads up:</strong> the Cookie Consent plugin is active but in <em>notice</em> mode, so Analytics cookies are currently set without asking. Under UK PECR / GDPR-style rules analytics cookies need prior consent — switch Cookie Consent to consent mode on its settings page.</p>
<?php else: ?>
					<p><strong>Heads up:</strong> the Cookie Consent plugin is not active, so Analytics cookies are set without asking. Under UK PECR / GDPR-style rules analytics cookies need prior consent — install and activate Cookie Consent in consent mode alongside this plugin.</p>
<?php endif; ?>
				</div>
			</fieldset>
		</div>
<?php
