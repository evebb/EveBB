<?php

/**
 * Release Autoposter - settings page.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

$relpost = new plugin_relpost();
$relpost_status = '';

if (isset($_POST['save_relpost']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$relpost->set_conf('enabled', isset($_POST['enabled']) ? '1' : '0');
	$relpost->set_conf('feed', pun_trim($_POST['feed'] ?? ''));
	$relpost->set_conf('subject', pun_trim($_POST['subject'] ?? ''));
	$relpost->set_conf('forum', pun_trim($_POST['forum'] ?? 'Announcements & Releases'));
	$relpost->set_conf('poster', pun_trim($_POST['poster'] ?? ''));
	$relpost->set_conf('interval_hours', (string) max(1, min(168, intval($_POST['interval_hours'] ?? 6))));
	$relpost->set_conf('template', pun_trim($_POST['template'] ?? ''));

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Autoposter settings saved. Redirecting …');
}

if (isset($_POST['check_now']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$relpost_status = $relpost->check_and_post();
	// Reset the gate so the next scheduled check counts from now
	$relpost->set_conf('next_check', (string) (time() + max(1, (int) $relpost->conf('interval_hours', '6')) * 3600));
}

$cur = array(
	'enabled'		=> $relpost->conf('enabled', '0'),
	'feed'			=> $relpost->conf('feed', ''),
	'subject'		=> $relpost->conf('subject', ''),
	'forum'			=> $relpost->conf('forum', 'Announcements & Releases'),
	'poster'		=> $relpost->conf('poster', ''),
	'interval'		=> $relpost->conf('interval_hours', '6'),
	'template'		=> $relpost->conf('template', ''),
	'last_version'	=> $relpost->conf('last_version', ''),
	'next_check'	=> (int) $relpost->conf('next_check', '0'),
);
if (trim($cur['template']) == '')
	$cur['template'] = plugin_relpost::default_template();
if (trim($cur['feed']) == '')
	$cur['feed'] = plugin_relpost::default_feed();
if (trim($cur['subject']) == '')
	$cur['subject'] = plugin_relpost::default_subject();

?>
<div class="blockform">
	<h2><span>Release Autoposter</span></h2>
	<div class="box">
<?php if ($relpost_status != ''): ?>
		<div class="inbox">
			<p><strong><?php echo pun_htmlspecialchars($relpost_status) ?></strong></p>
		</div>
<?php endif; ?>
		<form method="post" action="admin_plugins.php?action=settings&amp;plugin=<?php echo pun_htmlspecialchars($plugin_slug) ?>">
			<input type="hidden" name="csrf_token" value="<?php echo pun_csrf_token() ?>" />
			<div class="inform">
				<fieldset>
					<legend>Autoposting</legend>
					<div class="infldset">
						<div class="rbox">
							<label><input type="checkbox" name="enabled" value="1"<?php if ($cur['enabled'] == '1') echo ' checked="checked"' ?> />Enabled — check the release feed and post new releases automatically.<br /></label>
						</div>
						<label>Releases feed (any repository's GitHub releases API URL)<br />
						<input type="text" name="feed" size="70" maxlength="255" value="<?php echo pun_htmlspecialchars($cur['feed']) ?>" /><br /></label>
						<p>Format: https://api.github.com/repos/OWNER/REPO/releases?per_page=10 — point this at your own project's repository to announce your releases instead of eveBB's. Remote feeds must be HTTPS.</p>
						<label>Topic subject (%VERSION% is replaced)<br />
						<input type="text" name="subject" size="50" maxlength="70" value="<?php echo pun_htmlspecialchars($cur['subject']) ?>" /><br /></label>
						<label>Forum to post in (by name)<br />
						<input type="text" name="forum" size="40" maxlength="80" value="<?php echo pun_htmlspecialchars($cur['forum']) ?>" /><br /></label>
						<label>Post as user (username; blank = first administrator)<br />
						<input type="text" name="poster" size="25" maxlength="25" value="<?php echo pun_htmlspecialchars($cur['poster']) ?>" /><br /></label>
						<label>Check interval in hours (1–168)<br />
						<input type="text" name="interval_hours" size="4" maxlength="3" value="<?php echo pun_htmlspecialchars($cur['interval']) ?>" /><br /></label>
						<p>Checks ride on ordinary page views, at most once per interval — no cron job needed. The feed fetch has a 5-second timeout and simply retries next interval on failure.</p>
<?php if ($cur['last_version'] != ''): ?>
						<p>Last posted release: <strong><?php echo pun_htmlspecialchars($cur['last_version']) ?></strong><?php if ($cur['next_check'] > 0) echo ' &middot; next check after '.gmdate('Y-m-d H:i', $cur['next_check']).' UTC' ?>.</p>
<?php endif; ?>
					</div>
				</fieldset>
			</div>
			<div class="inform">
				<fieldset>
					<legend>Post template</legend>
					<div class="infldset">
						<label>BBCode template — placeholders: %VERSION%, %URL% (release page), %DOWNLOAD% (package)<br />
						<textarea name="template" rows="7" cols="70"><?php echo pun_htmlspecialchars($cur['template']) ?></textarea><br /></label>
						<p>The topic subject template is set above; both subject and body accept %VERSION%.</p>
					</div>
				</fieldset>
			</div>
			<p class="submitend">
				<input type="submit" name="save_relpost" value="Save settings" />
				<input type="submit" name="check_now" value="Check now" />
			</p>
		</form>
	</div>
</div>
