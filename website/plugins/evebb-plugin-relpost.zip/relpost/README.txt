Release Autoposter - an eveBB plugin
====================================

Watches a GitHub releases feed and posts each new release as a topic in
a forum of your choice. The feed defaults to eveBB's own releases, but
point it at ANY repository's releases API URL
(https://api.github.com/repos/OWNER/REPO/releases?per_page=10) and your
board announces YOUR project's releases - ideal for projects that run
their community on eveBB. The topic subject and post body are
templates, with %VERSION%, %URL% and %DOWNLOAD% placeholders.

INSTALL
  Administration -> Plugins -> upload this zip -> Activate, then open
  the plugin's Settings: tick Enabled, check the forum name and posting
  user, adjust the template if you like, and press "Check now" to post
  the current release immediately.

HOW IT RUNS
  Checks piggyback on ordinary page views, at most once per interval
  (default 6 hours) - no cron job required. A short-timeout feed fetch
  that fails simply retries next interval. Each release is posted
  exactly once (deduplicated by version), the post is search-indexed,
  and forum counters update properly.

License: GPL v2 or later, same as eveBB. Built for eveBB 2.0.0-beta.1+.
