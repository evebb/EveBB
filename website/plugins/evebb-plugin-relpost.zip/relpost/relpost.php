<?php

/**
 * Release Autoposter - an eveBB plugin.
 *
 * Watches a GitHub releases feed and posts each new release as a topic
 * in a forum of your choice. The feed defaults to eveBB's own releases
 * (as used on the official community board) but can be pointed at ANY
 * repository's releases API in settings - so a project that runs its
 * community on eveBB gets automatic release announcements for its own
 * software.
 *
 * There is no cron dependency: the check rides on ordinary page views,
 * time-gated so it runs at most once per configured interval, with a
 * cache-directory lock so concurrent requests can't double-post. The
 * feed fetch has a short timeout and any failure simply waits for the
 * next interval.
 *
 * A release is posted once: the last posted version is remembered in
 * config, and only strictly newer versions (per version_compare, the
 * ordering the updater itself uses) are announced.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_relpost extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'maybe_check'));
	}

	function conf($key, $default)
	{
		global $pun_config;

		return isset($pun_config['o_relpost_'.$key]) ? $pun_config['o_relpost_'.$key] : $default;
	}

	function set_conf($key, $value)
	{
		global $db, $pun_config;

		$key = 'o_relpost_'.$key;
		if (isset($pun_config[$key]))
			$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($key).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
		else
			$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($key).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());
		$pun_config[$key] = $value;

		if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
			require PUN_ROOT.'include/cache.php';
		generate_config_cache();
	}

	static function default_feed()
	{
		return 'https://api.github.com/repos/evebb/EveBB/releases?per_page=10';
	}

	//
	// Fetch the newest non-draft release from a GitHub-format releases
	// feed (stable preferred over prereleases). Same parsing the eveBB
	// updater uses; transport via evebb_http_get, which enforces HTTPS
	// (with certificate verification) for any non-loopback host.
	//
	function fetch_latest_release($url, $timeout = 5)
	{
		if (!function_exists('evebb_http_get'))
			require PUN_ROOT.'include/update.php';

		$body = evebb_http_get($url, $timeout);
		if ($body === false)
			return false;

		$releases = json_decode($body, true);
		if (!is_array($releases))
			return false;

		if (isset($releases['tag_name']))
			$releases = array($releases);

		$stable = $fallback = null;
		foreach ($releases as $release)
		{
			if (!is_array($release) || !isset($release['tag_name']) || !empty($release['draft']))
				continue;
			if ($fallback === null)
				$fallback = $release;
			if (empty($release['prerelease']))
			{
				$stable = $release;
				break;
			}
		}

		$release = ($stable !== null) ? $stable : $fallback;
		if ($release === null)
			return false;

		$zip_url = isset($release['zipball_url']) ? $release['zipball_url'] : '';
		if (isset($release['assets']) && is_array($release['assets']))
		{
			foreach ($release['assets'] as $asset)
			{
				if (isset($asset['name'], $asset['browser_download_url']) && preg_match('%\.zip$%i', $asset['name']))
				{
					$zip_url = $asset['browser_download_url'];
					break;
				}
			}
		}

		return array(
			'version'	=> ltrim((string) $release['tag_name'], 'vV'),
			'url'		=> isset($release['html_url']) ? $release['html_url'] : '',
			'zip_url'	=> $zip_url,
		);
	}

	static function default_subject()
	{
		return 'eveBB %VERSION% released';
	}

	static function default_template()
	{
		return "eveBB %VERSION% is out.\n\n"
			."Release notes: %URL%\n\n"
			."Boards update themselves from Administration -> Maintenance (the package is verified against its published SHA-256 checksum before installing), or download from [url=https://evebb.net]evebb.net[/url].";
	}

	//
	// Page-view entry point: cheap gate, then the real check
	//
	function maybe_check()
	{
		if ($this->conf('enabled', '0') != '1')
			return;

		$next = (int) $this->conf('next_check', '0');
		if (time() < $next)
			return;

		// Push the gate forward FIRST so a slow/failed fetch is not
		// retried by every following request
		$interval = max(1, (int) $this->conf('interval_hours', '6'));
		$this->set_conf('next_check', (string) (time() + $interval * 3600));

		$this->check_and_post();
	}

	//
	// Fetch the feed and post if a new release appeared. Returns a
	// human-readable status string (used by the settings page).
	//
	function check_and_post()
	{
		global $db, $pun_config;

		// One check at a time
		$lock = FORUM_CACHE_DIR.'relpost.lock';
		$fh = @fopen($lock, 'x');
		if ($fh === false)
		{
			// A stale lock (crashed request) older than 10 minutes is broken
			if (is_file($lock) && time() - filemtime($lock) > 600)
				@unlink($lock);
			return 'Another check is already running.';
		}
		fclose($fh);

		$status = $this->locked_check_and_post();

		@unlink($lock);
		return $status;
	}

	function locked_check_and_post()
	{
		global $db;

		$feed = trim($this->conf('feed', ''));
		if ($feed == '')
			$feed = self::default_feed();

		$release = $this->fetch_latest_release($feed, 5);
		if ($release === false)
			return 'The release feed could not be reached; will retry next interval.';

		$version = $release['version'];

		$last = $this->conf('last_version', '');
		if ($last != '' && version_compare($version, $last, '<='))
			return 'Newest release ('.$version.') is already posted.';

		// Find the announcements forum by name
		$forum_name = $this->conf('forum', 'Announcements & Releases');
		$result = $db->query('SELECT id FROM '.$db->prefix.'forums WHERE forum_name=\''.$db->escape($forum_name).'\'') or error('Unable to fetch forum', __FILE__, __LINE__, $db->error());
		if (!$db->has_rows($result))
			return 'Forum "'.$forum_name.'" was not found - nothing posted.';
		$fid = (int) $db->result($result);

		// Find the posting user
		$poster = $this->conf('poster', '');
		$result = $db->query('SELECT id, username FROM '.$db->prefix.'users WHERE username=\''.$db->escape($poster).'\'') or error('Unable to fetch user', __FILE__, __LINE__, $db->error());
		if (!$db->has_rows($result))
		{
			// Fall back to the first administrator
			$result = $db->query('SELECT id, username FROM '.$db->prefix.'users WHERE group_id='.PUN_ADMIN.' ORDER BY id LIMIT 1') or error('Unable to fetch user', __FILE__, __LINE__, $db->error());
			if (!$db->has_rows($result))
				return 'No posting user found - nothing posted.';
		}
		$user = $db->fetch_assoc($result);

		// Compose
		$subject_tpl = $this->conf('subject', '');
		if (trim($subject_tpl) == '')
			$subject_tpl = self::default_subject();
		$subject = str_replace('%VERSION%', $version, $subject_tpl);
		$template = $this->conf('template', '');
		if (trim($template) == '')
			$template = self::default_template();
		$message = str_replace(
			array('%VERSION%', '%URL%', '%DOWNLOAD%'),
			array($version, $release['url'], ($release['zip_url'] != '' ? $release['zip_url'] : $release['url'])),
			$template
		);

		// Remember the version BEFORE inserting: if two requests race
		// past the lock somehow, the second finds it already recorded
		$this->set_conf('last_version', $version);

		// Post (same sequence post.php uses for a new topic)
		$now = time();
		$uid = (int) $user['id'];
		$uname = $user['username'];

		$db->query('INSERT INTO '.$db->prefix.'topics (poster, subject, posted, last_post, last_poster, forum_id) VALUES(\''.$db->escape($uname).'\', \''.$db->escape($subject).'\', '.$now.', '.$now.', \''.$db->escape($uname).'\', '.$fid.')') or error('Unable to create topic', __FILE__, __LINE__, $db->error());
		$tid = (int) $db->insert_id();

		$db->query('INSERT INTO '.$db->prefix.'posts (poster, poster_id, poster_ip, message, hide_smilies, posted, topic_id) VALUES(\''.$db->escape($uname).'\', '.$uid.', \'127.0.0.1\', \''.$db->escape($message).'\', 0, '.$now.', '.$tid.')') or error('Unable to create post', __FILE__, __LINE__, $db->error());
		$pid = (int) $db->insert_id();

		$db->query('UPDATE '.$db->prefix.'topics SET first_post_id='.$pid.', last_post_id='.$pid.' WHERE id='.$tid) or error('Unable to update topic', __FILE__, __LINE__, $db->error());

		if (!defined('FORUM_SEARCH_IDX_FUNCTIONS_LOADED') && !function_exists('update_search_index'))
			require PUN_ROOT.'include/search_idx.php';
		update_search_index('post', $pid, $message, $subject);

		update_forum($fid);

		return 'Posted "'.$subject.'" (topic #'.$tid.') in "'.$forum_name.'".';
	}
}
