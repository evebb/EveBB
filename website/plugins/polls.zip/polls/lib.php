<?php

/**
 * Polls - shared library.
 *
 * Schema management and small helpers used by both the addon (polls.php)
 * and the settings page (admin.php).
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;


//
// Create the poll tables on first use. Guarded by the o_polls_db_rev
// config key so the check is free on every later request.
//
function evebb_polls_ensure_schema()
{
	global $db, $pun_config;

	if (isset($pun_config['o_polls_db_rev']))
		return;

	if (!$db->table_exists('polls'))
	{
		$schema = array(
			'FIELDS' => array(
				'topic_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'question' => array(
					'datatype'   => 'VARCHAR(255)',
					'allow_null' => false,
					'default'    => '\'\''
				),
				'max_choices' => array(
					'datatype'   => 'SMALLINT(6)',
					'allow_null' => false,
					'default'    => '1'
				),
				'close_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'closed' => array(
					'datatype'   => 'SMALLINT(6)',
					'allow_null' => false,
					'default'    => '0'
				),
				'created_by' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'created_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('topic_id')
		);

		$db->create_table('polls', $schema) or error('Unable to create the polls table', __FILE__, __LINE__, $db->error());
	}

	if (!$db->table_exists('poll_options'))
	{
		$schema = array(
			'FIELDS' => array(
				'topic_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'opt_id' => array(
					'datatype'   => 'SMALLINT(6)',
					'allow_null' => false,
					'default'    => '0'
				),
				'body' => array(
					'datatype'   => 'VARCHAR(255)',
					'allow_null' => false,
					'default'    => '\'\''
				)
			),
			'PRIMARY KEY' => array('topic_id', 'opt_id')
		);

		$db->create_table('poll_options', $schema) or error('Unable to create the poll_options table', __FILE__, __LINE__, $db->error());
	}

	if (!$db->table_exists('poll_votes'))
	{
		$schema = array(
			'FIELDS' => array(
				'topic_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'user_id' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				),
				'opt_id' => array(
					'datatype'   => 'SMALLINT(6)',
					'allow_null' => false,
					'default'    => '0'
				),
				'voted_at' => array(
					'datatype'   => 'INT(10) UNSIGNED',
					'allow_null' => false,
					'default'    => '0'
				)
			),
			'PRIMARY KEY' => array('topic_id', 'user_id', 'opt_id')
		);

		$db->create_table('poll_votes', $schema) or error('Unable to create the poll_votes table', __FILE__, __LINE__, $db->error());
	}

	// Record the schema revision. No or-error here: if two requests race,
	// the loser's duplicate insert may fail and that is fine.
	$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\'o_polls_db_rev\', \'1\')');
	$pun_config['o_polls_db_rev'] = '1';

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}


//
// Read a plugin config value with a default
//
function evebb_polls_conf($name, $default)
{
	global $pun_config;

	return isset($pun_config[$name]) ? $pun_config[$name] : $default;
}


//
// Insert or update a config value and refresh the config cache
//
function evebb_polls_save_conf($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;
}


//
// Is the plugin enabled in this forum? o_polls_forums holds a
// comma-separated list of forum IDs; blank means every forum.
//
function evebb_polls_forum_enabled($forum_id)
{
	$list = trim(evebb_polls_conf('o_polls_forums', ''));

	if ($list === '')
		return true;

	$ids = array_map('intval', explode(',', $list));

	return in_array((int) $forum_id, $ids, true);
}


//
// Fetch a topic's poll row, or null
//
function evebb_polls_fetch($topic_id)
{
	global $db;

	$result = $db->query('SELECT topic_id, question, max_choices, close_at, closed, created_by, created_at FROM '.$db->prefix.'polls WHERE topic_id='.(int) $topic_id) or error('Unable to fetch poll', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) ? $db->fetch_assoc($result) : null;
}


//
// Is this poll currently open for voting?
//
function evebb_polls_is_open($poll)
{
	if ((int) $poll['closed'] == 1)
		return false;

	$close_at = (int) $poll['close_at'];

	return $close_at == 0 || $close_at > time();
}
