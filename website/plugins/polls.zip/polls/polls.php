<?php

/**
 * Polls - the addon.
 *
 * Lets members attach a poll when starting a new topic: single or multiple
 * choice, an optional closing date, vote changing while the poll is open,
 * and results that stay hidden until the viewer has voted (guests can be
 * shown results, since they can never vote). Topics with a poll get a
 * "Poll:" marker in forum topic lists. Moderators and administrators can
 * close, reopen or remove a poll from the topic page.
 *
 * How it works: the creation fields are rendered server-side into the
 * new-topic form through the post_before_submit hook, validated through
 * post_after_validation (errors join the normal post-error list), and the
 * poll itself is written by a shutdown callback once post.php has created
 * the topic and redirected (that is the only moment the new topic id
 * exists; the request's DB handle is closed by then, so the callback opens
 * a fresh one). Everything else hangs off header_head_end, exactly like
 * the Solved Topics plugin: on viewtopic.php the plugin handles vote and
 * moderation actions server-side and emits a config blob plus CSS/JS into
 * <head>; the JS builds the poll panel under the first post. On
 * viewforum.php it emits the ids of topics that carry a poll.
 *
 * State lives in three tables - polls (topic_id PK), poll_options
 * (topic_id, opt_id PK) and poll_votes (topic_id, user_id, opt_id PK) -
 * created automatically on first use. Vote counts are always computed
 * live from poll_votes, so there is no denormalised counter to drift.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';


class plugin_polls extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head'));
		$manager->bind('post_before_submit', array($this, 'post_form'));
		$manager->bind('post_after_validation', array($this, 'post_validate'));
	}

	function head()
	{
		// The hook can fire twice in one request when core re-includes
		// header.php (e.g. message() rendering an error page). Act once.
		static $ran = false;
		if ($ran)
			return;
		$ran = true;

		evebb_polls_ensure_schema();

		$page = isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : '';

		if ($page == 'viewtopic.php')
			$this->head_viewtopic();
		else if ($page == 'viewforum.php')
			$this->head_viewforum();
	}


	//
	// post.php (new topic only): render the optional poll fields inside the
	// form. post_before_submit fires between the last core fieldset and the
	// submit buttons, so a whole inform block fits cleanly. Values re-fill
	// from $_POST on preview or validation errors.
	//
	function post_form()
	{
		global $fid, $pun_user;

		if (empty($fid) || $pun_user['is_guest'] || !evebb_polls_forum_enabled($fid))
			return;

		$max_opts = (int) evebb_polls_conf('o_polls_maxopts', '10');

		$question = isset($_POST['polls_question']) ? pun_htmlspecialchars(pun_trim($_POST['polls_question'])) : '';
		$options  = isset($_POST['polls_options']) ? pun_htmlspecialchars($_POST['polls_options']) : '';
		$max      = isset($_POST['polls_max']) ? (int) $_POST['polls_max'] : 1;
		$close    = isset($_POST['polls_close']) ? (int) $_POST['polls_close'] : 0;

		if ($max < 1)
			$max = 1;
		if ($close < 0)
			$close = 0;

?>
				<div class="inform">
					<fieldset>
						<legend>Add a poll (optional)</legend>
						<div class="infldset">
							<p>To attach a poll to this topic, enter a question and at least two answer options. Leave both blank for no poll. The poll cannot be edited after posting.</p>
							<label>Poll question<br /><input class="longinput" type="text" name="polls_question" value="<?php echo $question ?>" size="80" maxlength="255" /><br /></label>
							<label>Answer options &mdash; one per line (2 to <?php echo $max_opts ?>)<br /><textarea name="polls_options" rows="6" cols="60"><?php echo $options ?></textarea><br /></label>
							<label>Each voter may choose up to <input type="number" name="polls_max" value="<?php echo $max ?>" min="1" max="<?php echo $max_opts ?>" style="width:4.5em" /> option(s)</label>
							<label>Close voting after <input type="number" name="polls_close" value="<?php echo $close ?>" min="0" max="365" style="width:4.5em" /> day(s) &mdash; 0 means the poll never closes</label>
						</div>
					</fieldset>
				</div>
<?php
	}


	//
	// post.php: validate the poll fields on submit/preview. Problems join
	// the normal post-error list (so the form re-renders with everything
	// intact). On a valid, non-preview new topic the poll is stashed and a
	// shutdown callback saves it once the topic exists.
	//
	function post_validate()
	{
		global $errors, $fid, $pun_user;

		if (empty($fid) || $pun_user['is_guest'] || !evebb_polls_forum_enabled($fid))
			return;

		$question = isset($_POST['polls_question']) ? pun_trim($_POST['polls_question']) : '';

		$options = array();
		$seen = array();
		$duplicate = false;
		foreach (preg_split('%\r\n|\n|\r%', isset($_POST['polls_options']) ? (string) $_POST['polls_options'] : '') as $line)
		{
			$line = pun_trim($line);
			if ($line === '')
				continue;

			$key = utf8_strtolower($line);
			if (isset($seen[$key]))
				$duplicate = true;
			$seen[$key] = true;

			$options[] = $line;
		}

		// No poll at all
		if ($question === '' && empty($options))
			return;

		$max_opts = (int) evebb_polls_conf('o_polls_maxopts', '10');

		if ($question === '')
			$errors[] = 'You entered poll options but no poll question.';
		else if (pun_strlen($question) > 255)
			$errors[] = 'The poll question must not exceed 255 characters.';

		if (count($options) < 2)
			$errors[] = 'A poll needs at least two answer options (one per line).';
		else if (count($options) > $max_opts)
			$errors[] = 'A poll may have at most '.$max_opts.' answer options.';

		if ($duplicate)
			$errors[] = 'Poll options must not repeat.';

		foreach ($options as $option)
		{
			if (pun_strlen($option) > 255)
			{
				$errors[] = 'Each poll option must not exceed 255 characters.';
				break;
			}
		}

		$max = isset($_POST['polls_max']) ? (int) $_POST['polls_max'] : 1;
		if ($max < 1)
			$max = 1;
		if (!empty($options) && $max > count($options))
			$max = count($options);

		$close_days = isset($_POST['polls_close']) ? (int) $_POST['polls_close'] : 0;
		if ($close_days < 0 || $close_days > 365)
		{
			$errors[] = 'Poll closing time must be between 0 and 365 days.';
			$close_days = 0;
		}

		if (!empty($errors) || isset($_POST['preview']))
			return;

		// The tables normally exist long before the first submission (the
		// header hook creates them on any page view), but be certain before
		// promising a shutdown-time insert.
		evebb_polls_ensure_schema();

		$GLOBALS['evebb_polls_pending'] = array(
			'question' => $question,
			'options'  => $options,
			'max'      => $max,
			'close_at' => $close_days > 0 ? time() + $close_days * 86400 : 0,
			'by'       => (int) $pun_user['id']
		);

		register_shutdown_function(array('plugin_polls', 'save_pending'));
	}


	//
	// Shutdown callback: post.php has created the topic ($new_tid, set in
	// global scope) and exited through redirect(), which closed the request's
	// DB handle - so open a fresh connection and write the poll. If the post
	// failed for any other reason $new_tid is never set and nothing happens.
	//
	static function save_pending()
	{
		if (!isset($GLOBALS['evebb_polls_pending']) || !isset($GLOBALS['new_tid']))
			return;

		$tid = (int) $GLOBALS['new_tid'];
		$poll = $GLOBALS['evebb_polls_pending'];

		if ($tid < 1 || !is_array($poll))
			return;

		// Re-run the core DB bootstrap for a fresh handle ($db becomes a
		// local here; the driver classes are already loaded via require_once)
		global $db_type, $db_host, $db_username, $db_password, $db_name, $db_prefix, $p_connect;
		$db = null;
		require PUN_ROOT.'include/dblayer/common_db.php';

		if (!is_object($db))
			return;

		$db->start_transaction();

		$db->query('INSERT INTO '.$db->prefix.'polls (topic_id, question, max_choices, close_at, closed, created_by, created_at) VALUES('.$tid.', \''.$db->escape($poll['question']).'\', '.(int) $poll['max'].', '.(int) $poll['close_at'].', 0, '.(int) $poll['by'].', '.time().')') or error_log('eveBB polls plugin: unable to save poll for topic '.$tid);

		$opt_id = 0;
		foreach ($poll['options'] as $body)
		{
			$opt_id++;
			$db->query('INSERT INTO '.$db->prefix.'poll_options (topic_id, opt_id, body) VALUES('.$tid.', '.$opt_id.', \''.$db->escape($body).'\')') or error_log('eveBB polls plugin: unable to save poll option for topic '.$tid);
		}

		$db->end_transaction();
		$db->close();
	}


	//
	// viewtopic.php: handle vote and moderation actions, then describe the
	// poll (and the viewer's powers) to the page JS
	//
	function head_viewtopic()
	{
		global $db, $pun_user, $cur_topic, $id, $is_admmod;

		// Defensive: these are set by viewtopic.php before header.php runs
		if (!isset($cur_topic) || !isset($id))
			return;

		if (!evebb_polls_forum_enabled($cur_topic['forum_id']))
			return;

		$poll = evebb_polls_fetch($id);
		if ($poll === null)
			return;

		$is_open = evebb_polls_is_open($poll);

		// A vote? (POST - the global CSRF gate in common.php has already
		// validated the token.) Exits on every well-formed request.
		if (isset($_POST['polls_action']) && $_POST['polls_action'] === 'vote')
			$this->handle_vote($poll, $is_open);

		// A moderator action? (GET + csrf_token, solved-plugin pattern.)
		if (!empty($is_admmod) && isset($_GET['polls_action']))
			$this->handle_mod_action($poll);

		// ---- Display state ----

		$options = array();
		$result = $db->query('SELECT opt_id, body FROM '.$db->prefix.'poll_options WHERE topic_id='.(int) $id.' ORDER BY opt_id') or error('Unable to fetch poll options', __FILE__, __LINE__, $db->error());
		while ($row = $db->fetch_assoc($result))
			$options[(int) $row['opt_id']] = array('id' => (int) $row['opt_id'], 'body' => $row['body'], 'votes' => 0, 'mine' => false);

		if (empty($options))
			return;

		$result = $db->query('SELECT opt_id, COUNT(user_id) AS num FROM '.$db->prefix.'poll_votes WHERE topic_id='.(int) $id.' GROUP BY opt_id') or error('Unable to fetch poll votes', __FILE__, __LINE__, $db->error());
		while ($row = $db->fetch_assoc($result))
		{
			if (isset($options[(int) $row['opt_id']]))
				$options[(int) $row['opt_id']]['votes'] = (int) $row['num'];
		}

		$result = $db->query('SELECT COUNT(DISTINCT user_id) FROM '.$db->prefix.'poll_votes WHERE topic_id='.(int) $id) or error('Unable to count poll voters', __FILE__, __LINE__, $db->error());
		$total_voters = (int) $db->result($result);

		$has_voted = false;
		if (!$pun_user['is_guest'])
		{
			$result = $db->query('SELECT opt_id FROM '.$db->prefix.'poll_votes WHERE topic_id='.(int) $id.' AND user_id='.(int) $pun_user['id']) or error('Unable to fetch own poll votes', __FILE__, __LINE__, $db->error());
			while ($row = $db->fetch_row($result))
			{
				$has_voted = true;
				if (isset($options[(int) $row[0]]))
					$options[(int) $row[0]]['mine'] = true;
			}
		}

		$allow_change = evebb_polls_conf('o_polls_allowchange', '1') == '1';
		$can_vote = !$pun_user['is_guest'] && $is_open && (!$has_voted || $allow_change);

		// Results are shown once you have voted, once the poll is over, to
		// guests when the board allows it (they can never vote), and to
		// staff always
		$show_results = $has_voted || !$is_open || !empty($is_admmod)
			|| ($pun_user['is_guest'] && evebb_polls_conf('o_polls_guestresults', '1') == '1');

		if (!$show_results)
		{
			foreach ($options as &$option)
				$option['votes'] = null;
			unset($option);
		}

		$cfg = array(
			'page'        => 'topic',
			'topic'       => (int) $id,
			'first'       => (int) $cur_topic['first_post_id'],
			'question'    => $poll['question'],
			'maxChoices'  => (int) $poll['max_choices'],
			'isOpen'      => $is_open,
			'closesAt'    => ((int) $poll['closed'] == 0 && (int) $poll['close_at'] > 0) ? format_time($poll['close_at']) : null,
			'canVote'     => $can_vote,
			'hasVoted'    => $has_voted,
			'showResults' => (bool) $show_results,
			'totalVoters' => $total_voters,
			'isGuest'     => (bool) $pun_user['is_guest'],
			'canMod'      => !empty($is_admmod),
			'token'       => ($can_vote || !empty($is_admmod)) ? pun_csrf_token() : '',
			'options'     => array_values($options),
			'text'        => array(
				'poll'       => 'Poll',
				'closed'     => 'Voting is closed.',
				'closes'     => 'Voting closes',
				'votes'      => 'votes',
				'vote1'      => 'vote',
				'sofar'      => 'so far',
				'chooseUpTo' => 'Choose up to',
				'options'    => 'options.',
				'vote'       => 'Vote',
				'change'     => 'Change your vote',
				'yours'      => 'your vote',
				'loginNote'  => 'Log in to vote.',
				'votedNote'  => 'You have voted in this poll.',
				'close'      => 'Close poll',
				'reopen'     => 'Reopen poll',
				'remove'     => 'Remove poll',
				'confirmRm'  => 'Remove this poll and all of its votes? This cannot be undone.',
				'pollMark'   => 'This topic has a poll'
			)
		);

		$this->emit($cfg);
	}


	//
	// Validate and record a member's vote, then redirect. Every path exits.
	// Output so far is still buffered (we are inside header.php), so it is
	// safe to throw it away; redirect() ends the DB transaction itself.
	//
	function handle_vote($poll, $is_open)
	{
		global $db, $pun_user, $id;

		$tid = (int) $id;

		// From here on every path exits, so pending page output is discarded
		while (ob_get_level() > 0)
			ob_end_clean();

		// No message() here: header.php has already begun rendering, and
		// message() would re-include it (re-firing this hook). A bad request
		// simply bounces back to the topic with nothing done.
		if ($pun_user['is_guest'] || !$is_open)
			redirect('viewtopic.php?id='.$tid, 'This poll is not open to you. Redirecting …');

		$allow_change = evebb_polls_conf('o_polls_allowchange', '1') == '1';

		$result = $db->query('SELECT 1 FROM '.$db->prefix.'poll_votes WHERE topic_id='.$tid.' AND user_id='.(int) $pun_user['id'].' LIMIT 1') or error('Unable to check poll votes', __FILE__, __LINE__, $db->error());
		if ($db->has_rows($result) && !$allow_change)
			redirect('viewtopic.php?id='.$tid, 'You have already voted in this poll. Redirecting …');

		// Requested options: unique positive ints, within the choice limit,
		// and every one of them must belong to this poll
		$opts = isset($_POST['polls_opt']) ? (array) $_POST['polls_opt'] : array();
		$opts = array_values(array_unique(array_filter(array_map('intval', $opts), function ($v) { return $v > 0; })));

		if (empty($opts) || count($opts) > (int) $poll['max_choices'])
			redirect('viewtopic.php?id='.$tid, 'Bad request. Redirecting …');

		$result = $db->query('SELECT COUNT(opt_id) FROM '.$db->prefix.'poll_options WHERE topic_id='.$tid.' AND opt_id IN ('.implode(',', $opts).')') or error('Unable to verify poll options', __FILE__, __LINE__, $db->error());
		if ((int) $db->result($result) != count($opts))
			redirect('viewtopic.php?id='.$tid, 'Bad request. Redirecting …');

		$db->query('DELETE FROM '.$db->prefix.'poll_votes WHERE topic_id='.$tid.' AND user_id='.(int) $pun_user['id']) or error('Unable to clear poll votes', __FILE__, __LINE__, $db->error());

		$now = time();
		foreach ($opts as $opt_id)
			$db->query('INSERT INTO '.$db->prefix.'poll_votes (topic_id, user_id, opt_id, voted_at) VALUES('.$tid.', '.(int) $pun_user['id'].', '.$opt_id.', '.$now.')') or error('Unable to record poll vote', __FILE__, __LINE__, $db->error());

		redirect('viewtopic.php?id='.$tid, 'Your vote has been saved. Redirecting …');
	}


	//
	// Close, reopen or remove the poll (moderators/administrators of this
	// forum only - $is_admmod was checked by the caller). Exits on every
	// well-formed request.
	//
	function handle_mod_action($poll)
	{
		global $db, $id;

		$action = $_GET['polls_action'];
		if ($action != 'close' && $action != 'reopen' && $action != 'remove')
			return;

		$tid = (int) $id;

		// From here on every path exits, so pending page output is discarded
		while (ob_get_level() > 0)
			ob_end_clean();

		$token = isset($_GET['csrf_token']) ? $_GET['csrf_token'] : null;
		if (!is_string($token) || !hash_equals(pun_csrf_token(), $token))
			redirect('viewtopic.php?id='.$tid, 'Bad request. Redirecting …');

		if ($action == 'close')
		{
			$db->query('UPDATE '.$db->prefix.'polls SET closed=1 WHERE topic_id='.$tid) or error('Unable to close poll', __FILE__, __LINE__, $db->error());
			redirect('viewtopic.php?id='.$tid, 'Poll closed. Redirecting …');
		}

		if ($action == 'reopen')
		{
			// Reopening a poll whose deadline has already passed also clears
			// the deadline - otherwise it would close itself again instantly
			$clear_deadline = ((int) $poll['close_at'] > 0 && (int) $poll['close_at'] <= time()) ? ', close_at=0' : '';
			$db->query('UPDATE '.$db->prefix.'polls SET closed=0'.$clear_deadline.' WHERE topic_id='.$tid) or error('Unable to reopen poll', __FILE__, __LINE__, $db->error());
			redirect('viewtopic.php?id='.$tid, 'Poll reopened. Redirecting …');
		}

		// remove
		$db->query('DELETE FROM '.$db->prefix.'poll_votes WHERE topic_id='.$tid) or error('Unable to remove poll votes', __FILE__, __LINE__, $db->error());
		$db->query('DELETE FROM '.$db->prefix.'poll_options WHERE topic_id='.$tid) or error('Unable to remove poll options', __FILE__, __LINE__, $db->error());
		$db->query('DELETE FROM '.$db->prefix.'polls WHERE topic_id='.$tid) or error('Unable to remove poll', __FILE__, __LINE__, $db->error());

		redirect('viewtopic.php?id='.$tid, 'Poll removed. Redirecting …');
	}


	//
	// viewforum.php: emit the ids of this forum's topics that carry a poll
	//
	function head_viewforum()
	{
		global $db, $id;

		if (!isset($id))
			return;

		if (evebb_polls_conf('o_polls_listmark', '1') != '1')
			return;

		if (!evebb_polls_forum_enabled($id))
			return;

		$result = $db->query('SELECT p.topic_id FROM '.$db->prefix.'polls AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id WHERE t.forum_id='.(int) $id) or error('Unable to fetch poll topics', __FILE__, __LINE__, $db->error());

		$ids = array();
		while ($row = $db->fetch_row($result))
			$ids[] = (int) $row[0];

		if (empty($ids))
			return;

		$this->emit(array(
			'page' => 'forum',
			'ids'  => $ids,
			'text' => array('pollMark' => 'This topic has a poll', 'poll' => 'Poll')
		));
	}


	//
	// Emit the shared CSS plus the page JS with its config blob into <head>
	//
	function emit($cfg)
	{
		$json = json_encode($cfg, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

		echo '<style>'
			.'.pollsbox{margin:1em 0;padding:.8em 1em;border:1px solid rgba(110,130,150,.45);background:rgba(110,130,150,.08);border-radius:4px}'
			.'.pollsbox h3{margin:0 0 .3em;font-size:1.05em}'
			.'.pollsstatus{font-size:.95em;opacity:.85;margin:0 0 .6em}'
			.'.pollsrow{margin:.5em 0}'
			.'.pollslabel span.pollsnum{float:right;margin-left:1em}'
			.'.pollsbar{height:.55em;background:rgba(110,130,150,.18);border-radius:3px;overflow:hidden;margin-top:.2em;clear:both}'
			.'.pollsbarfill{height:100%;background:rgba(82,126,180,.85)}'
			.'.pollsmine{color:#2f9e5f;font-weight:bold;margin-left:.4em}'
			.'.pollsvoteform label{display:block;margin:.3em 0}'
			.'.pollsvoteform p.pollshint{font-size:.9em;opacity:.85;margin:.2em 0 .5em}'
			.'.pollsactions{margin-top:.7em;font-size:.95em;border-top:1px solid rgba(110,130,150,.25);padding-top:.5em}'
			.'.pollsactions a{margin-right:1em}'
			.'.pollsnote{font-size:.95em;opacity:.85;margin:.4em 0 0}'
			.'.pollmark{color:#527eb4;font-weight:bold}'
			.'</style>'."\n";

		echo '<script>/* Polls plugin */'."\n".'(function(){'."\n"
			.'var cfg = '.$json.';'."\n"
			.<<<'EOJS'
function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

function el(tag, cls, text) {
	var e = document.createElement(tag);
	if (cls) e.className = cls;
	if (text) e.textContent = text;
	return e;
}

function forumPage() {
	var ids = {};
	for (var i = 0; i < cfg.ids.length; i++) ids[cfg.ids[i]] = true;

	var links = document.querySelectorAll('#vf div.tclcon a');
	for (var j = 0; j < links.length; j++) {
		var m = /^viewtopic\.php\?id=(\d+)$/.exec(links[j].getAttribute('href') || '');
		if (!m || !ids[m[1]]) continue;
		var mark = el('span', 'pollmark', cfg.text.poll + ': ');
		mark.title = cfg.text.pollMark;
		links[j].parentNode.insertBefore(mark, links[j]);
		delete ids[m[1]]; // one mark per topic
	}
}

function modUrl(action) {
	return 'viewtopic.php?id=' + cfg.topic + '&polls_action=' + action + '&csrf_token=' + encodeURIComponent(cfg.token);
}

function voteCount() {
	var n = cfg.totalVoters;
	return n + ' ' + (n === 1 ? cfg.text.vote1 : cfg.text.votes);
}

function resultsView() {
	var wrap = el('div', 'pollsresults');
	for (var i = 0; i < cfg.options.length; i++) {
		var o = cfg.options[i];
		var row = el('div', 'pollsrow');
		var label = el('div', 'pollslabel');
		var pct = cfg.totalVoters > 0 ? Math.round(o.votes * 100 / cfg.totalVoters) : 0;
		var num = el('span', 'pollsnum', o.votes + ' (' + pct + '%)');
		label.appendChild(num);
		label.appendChild(document.createTextNode(o.body));
		if (o.mine) {
			var mine = el('span', 'pollsmine', '✓ ' + cfg.text.yours);
			label.appendChild(mine);
		}
		row.appendChild(label);
		var bar = el('div', 'pollsbar');
		var fill = el('div', 'pollsbarfill');
		fill.style.width = pct + '%';
		bar.appendChild(fill);
		row.appendChild(bar);
		wrap.appendChild(row);
	}
	return wrap;
}

function formView() {
	var form = document.createElement('form');
	form.className = 'pollsvoteform';
	form.method = 'post';
	form.action = 'viewtopic.php?id=' + cfg.topic;

	var hidden = document.createElement('input');
	hidden.type = 'hidden'; hidden.name = 'polls_action'; hidden.value = 'vote';
	form.appendChild(hidden);
	var token = document.createElement('input');
	token.type = 'hidden'; token.name = 'csrf_token'; token.value = cfg.token;
	form.appendChild(token);

	var multi = cfg.maxChoices > 1;
	if (multi)
		form.appendChild(el('p', 'pollshint', cfg.text.chooseUpTo + ' ' + cfg.maxChoices + ' ' + cfg.text.options));

	for (var i = 0; i < cfg.options.length; i++) {
		var o = cfg.options[i];
		var label = document.createElement('label');
		var input = document.createElement('input');
		input.type = multi ? 'checkbox' : 'radio';
		input.name = 'polls_opt[]';
		input.value = o.id;
		if (o.mine) input.checked = true;
		if (multi) input.addEventListener('change', enforceLimit);
		label.appendChild(input);
		label.appendChild(document.createTextNode(' ' + o.body));
		form.appendChild(label);
	}

	var submit = document.createElement('input');
	submit.type = 'submit';
	submit.value = cfg.text.vote;
	var p = document.createElement('p');
	p.appendChild(submit);
	form.appendChild(p);

	function enforceLimit() {
		var boxes = form.querySelectorAll('input[type=checkbox]');
		var checked = 0;
		for (var i = 0; i < boxes.length; i++) if (boxes[i].checked) checked++;
		for (var j = 0; j < boxes.length; j++)
			boxes[j].disabled = (!boxes[j].checked && checked >= cfg.maxChoices);
	}
	if (multi) enforceLimit();

	return form;
}

function topicPage() {
	var box = el('div', 'pollsbox');
	box.id = 'pollsbox';

	box.appendChild(el('h3', null, cfg.question));

	var status = cfg.isOpen
		? (cfg.closesAt ? cfg.text.closes + ' ' + cfg.closesAt + ' · ' : '') + voteCount() + ' ' + cfg.text.sofar
		: cfg.text.closed + ' · ' + voteCount();
	box.appendChild(el('p', 'pollsstatus', status));

	var form = cfg.canVote ? formView() : null;

	if (cfg.showResults) {
		box.appendChild(resultsView());
		if (form) {
			if (cfg.hasVoted) {
				// Results first; the form appears on request
				form.style.display = 'none';
				var change = el('p', 'pollsnote');
				var a = document.createElement('a');
				a.href = '#';
				a.textContent = cfg.text.change;
				a.addEventListener('click', function (e) {
					e.preventDefault();
					form.style.display = '';
					change.style.display = 'none';
				});
				change.appendChild(a);
				box.appendChild(change);
			}
			box.appendChild(form);
		}
	}
	else if (form)
		box.appendChild(form);

	if (cfg.isGuest && cfg.isOpen)
		box.appendChild(el('p', 'pollsnote', cfg.text.loginNote));
	else if (!cfg.canVote && cfg.hasVoted && cfg.isOpen)
		box.appendChild(el('p', 'pollsnote', cfg.text.votedNote));

	if (cfg.canMod) {
		var actions = el('div', 'pollsactions');
		var toggle = document.createElement('a');
		toggle.href = modUrl(cfg.isOpen ? 'close' : 'reopen');
		toggle.textContent = cfg.isOpen ? cfg.text.close : cfg.text.reopen;
		actions.appendChild(toggle);
		var rm = document.createElement('a');
		rm.href = modUrl('remove');
		rm.textContent = cfg.text.remove;
		rm.addEventListener('click', function (e) {
			if (!window.confirm(cfg.text.confirmRm)) e.preventDefault();
		});
		actions.appendChild(rm);
		box.appendChild(actions);
	}

	// Under the first post; atop the page when the first post is on an
	// earlier page (same placement rule as the Solved Topics banner)
	var first = document.getElementById('p' + cfg.first);
	if (first)
		first.parentNode.insertBefore(box, first.nextSibling);
	else {
		var top = document.querySelector('div.blockpost');
		if (top) top.parentNode.insertBefore(box, top);
	}
}

ready(function() { if (cfg.page === 'forum') forumPage(); else topicPage(); });
EOJS
			."\n".'})();</script>'."\n";
	}
}
