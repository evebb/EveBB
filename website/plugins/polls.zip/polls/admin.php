<?php

/**
 * Polls - settings page.
 *
 * Included by admin_plugins.php inside the admin chrome (and inside a POST
 * form that footer.php injects the CSRF token into). $db, $pun_config and
 * $plugin_slug are available here.
 *
 * This is an unofficial eveBB plugin.
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

// The addon normally creates the tables on first page view, but make sure
// they exist even if the settings page is visited before that
evebb_polls_ensure_schema();

// Save settings
if (isset($_POST['save_polls']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	evebb_polls_save_conf('o_polls_listmark', isset($_POST['polls_listmark']) ? '1' : '0');
	evebb_polls_save_conf('o_polls_guestresults', isset($_POST['polls_guestresults']) ? '1' : '0');
	evebb_polls_save_conf('o_polls_allowchange', isset($_POST['polls_allowchange']) ? '1' : '0');

	$max_opts = isset($_POST['polls_maxopts']) ? (int) $_POST['polls_maxopts'] : 10;
	if ($max_opts < 2)
		$max_opts = 2;
	else if ($max_opts > 20)
		$max_opts = 20;
	evebb_polls_save_conf('o_polls_maxopts', (string) $max_opts);

	// Forum list: keep only digits and commas, normalise
	$forums_raw = pun_trim($_POST['polls_forums'] ?? '');
	$forum_ids = array();
	foreach (explode(',', $forums_raw) as $part)
	{
		$part = (int) trim($part);
		if ($part > 0 && !in_array($part, $forum_ids))
			$forum_ids[] = $part;
	}
	evebb_polls_save_conf('o_polls_forums', implode(',', $forum_ids));

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}

// Remove polls whose topics no longer exist
if (isset($_POST['purge_polls']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$db->query('DELETE FROM '.$db->prefix.'poll_votes WHERE topic_id NOT IN (SELECT id FROM '.$db->prefix.'topics)') or error('Unable to purge poll votes', __FILE__, __LINE__, $db->error());
	$db->query('DELETE FROM '.$db->prefix.'poll_options WHERE topic_id NOT IN (SELECT id FROM '.$db->prefix.'topics)') or error('Unable to purge poll options', __FILE__, __LINE__, $db->error());
	$db->query('DELETE FROM '.$db->prefix.'polls WHERE topic_id NOT IN (SELECT id FROM '.$db->prefix.'topics)') or error('Unable to purge polls', __FILE__, __LINE__, $db->error());

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Orphaned polls purged. Redirecting …');
}

// Remove ALL plugin data (before uninstalling)
if (isset($_POST['nuke_polls']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	if (!isset($_POST['nuke_confirm']))
		redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Tick the confirmation box to remove plugin data. Redirecting …');

	$db->drop_table('poll_votes');
	$db->drop_table('poll_options');
	$db->drop_table('polls');
	$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name IN (\'o_polls_db_rev\', \'o_polls_maxopts\', \'o_polls_listmark\', \'o_polls_guestresults\', \'o_polls_allowchange\', \'o_polls_forums\')') or error('Unable to remove plugin settings', __FILE__, __LINE__, $db->error());

	unset($pun_config['o_polls_db_rev'], $pun_config['o_polls_maxopts'], $pun_config['o_polls_listmark'], $pun_config['o_polls_guestresults'], $pun_config['o_polls_allowchange'], $pun_config['o_polls_forums']);

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();

	redirect('admin_plugins.php', 'All Polls data removed. You can now deactivate and delete the plugin. Redirecting …');
}

$polls_listmark     = evebb_polls_conf('o_polls_listmark', '1') == '1';
$polls_guestresults = evebb_polls_conf('o_polls_guestresults', '1') == '1';
$polls_allowchange  = evebb_polls_conf('o_polls_allowchange', '1') == '1';
$polls_maxopts      = (int) evebb_polls_conf('o_polls_maxopts', '10');
$polls_forums       = evebb_polls_conf('o_polls_forums', '');

// How many polls and votes are there?
$result = $db->query('SELECT COUNT(topic_id) FROM '.$db->prefix.'polls') or error('Unable to count polls', __FILE__, __LINE__, $db->error());
$poll_count = (int) $db->result($result);

$result = $db->query('SELECT COUNT(user_id) FROM '.$db->prefix.'poll_votes') or error('Unable to count poll votes', __FILE__, __LINE__, $db->error());
$vote_count = (int) $db->result($result);

// Forum reference list for the restriction field
$result = $db->query('SELECT f.id, f.forum_name, c.cat_name FROM '.$db->prefix.'forums AS f INNER JOIN '.$db->prefix.'categories AS c ON c.id=f.cat_id ORDER BY c.disp_position, c.id, f.disp_position') or error('Unable to fetch forum list', __FILE__, __LINE__, $db->error());
$forum_list = array();
while ($cur_forum = $db->fetch_assoc($result))
	$forum_list[] = $cur_forum;

?>
		<div class="inform">
			<fieldset>
				<legend>Polls settings</legend>
				<div class="infldset">
					<p>Polls on this board: <strong><?php echo $poll_count ?></strong> (<?php echo $vote_count ?> votes cast). Any registered member can attach a poll while starting a new topic in the forums where the plugin is enabled; results stay hidden from members until they have voted. Moderators and administrators can always see results and can close, reopen or remove a poll from its topic page.</p>
					<label><input type="checkbox" name="polls_listmark" value="1"<?php if ($polls_listmark) echo ' checked="checked"' ?> /> Show a &quot;Poll:&quot; marker before topics with a poll in forum topic lists</label>
					<label><input type="checkbox" name="polls_guestresults" value="1"<?php if ($polls_guestresults) echo ' checked="checked"' ?> /> Let guests see the results of open polls (guests can never vote)</label>
					<label><input type="checkbox" name="polls_allowchange" value="1"<?php if ($polls_allowchange) echo ' checked="checked"' ?> /> Let members change their vote while a poll is open</label>
					<label>Maximum number of answer options per poll (2&ndash;20)
						<br /><input type="text" name="polls_maxopts" size="4" maxlength="2" value="<?php echo $polls_maxopts ?>" />
					</label>
					<label>Only enable in these forums (comma-separated forum IDs; leave blank for all forums)
						<br /><input type="text" name="polls_forums" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($polls_forums) ?>" />
					</label>
<?php if (count($forum_list)): ?>
					<p>For reference, your forums are:</p>
					<ul>
<?php foreach ($forum_list as $cur_forum): ?>
						<li><span><strong><?php echo (int) $cur_forum['id'] ?></strong> &mdash; <?php echo pun_htmlspecialchars($cur_forum['cat_name']) ?> / <?php echo pun_htmlspecialchars($cur_forum['forum_name']) ?></span></li>
<?php endforeach; ?>
					</ul>
<?php endif; ?>
					<p class="topspace"><input type="submit" name="save_polls" value="Save settings" /></p>
				</div>
			</fieldset>
		</div>
		<div class="inform">
			<fieldset>
				<legend>Maintenance</legend>
				<div class="infldset">
					<p>Deleting a topic does not remove its poll (the poll is simply never shown again). Purging clears those leftover rows.</p>
					<p><input type="submit" name="purge_polls" value="Purge orphaned polls" /></p>
					<p class="topspace">To uninstall cleanly: remove the plugin's data below first, then deactivate and delete the plugin on the plugins page. This drops the polls, poll_options and poll_votes tables and all of this plugin's settings.</p>
					<p><label><input type="checkbox" name="nuke_confirm" value="1" /> I understand this permanently deletes every poll and every vote</label></p>
					<p><input type="submit" name="nuke_polls" value="Remove all plugin data" /></p>
				</div>
			</fieldset>
		</div>
<?php
