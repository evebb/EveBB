# Polls

An unofficial [eveBB](https://evebb.net) plugin that lets members attach a
poll when starting a new topic.

## Features

- Any registered member can add a poll while composing a new topic: a
  question, two or more answer options (one per line), how many options
  each voter may choose (single or multiple choice), and an optional
  closing time in days.
- Results stay hidden from members until they have voted — non-voters just
  see how many votes have been cast so far. Once a poll closes, everyone
  sees the results.
- Guests can be shown the results of open polls (they can never vote);
  this can be switched off, in which case guests only see that the poll
  exists.
- Members can change their vote while the poll is open (can be switched
  off).
- Topics with a poll get a "Poll:" marker in forum topic lists.
- Moderators and administrators always see results and can close, reopen
  or remove a poll from its topic page. Reopening a poll whose deadline
  has passed clears the deadline.
- Works without JavaScript in the sense that nothing breaks: the poll
  panel is built client-side, so JS-less visitors simply see the plain
  topic.

## Installation

Upload `polls.zip` through **Administration → Plugins → Upload plugin**,
then activate it. The plugin creates its three database tables
(`polls`, `poll_options`, `poll_votes`) automatically on first use.

## Settings

**Administration → Plugins → Polls → Settings**

- Show a "Poll:" marker in forum topic lists (default on)
- Let guests see the results of open polls (default on)
- Let members change their vote while a poll is open (default on)
- Maximum number of answer options per poll, 2–20 (default 10)
- Only enable in certain forums (comma-separated forum IDs; blank = all)

## Notes

- Polls can only be attached when a topic is created; they cannot be
  added to or edited on existing topics. Staff can remove a poll at any
  time.
- Voting requires an account. One recorded vote per member (a changed
  vote replaces the previous one).
- Vote counts are computed live from the votes table, so there is no
  counter to drift out of sync.
- Deleting a topic leaves orphaned poll rows behind (harmless); the
  settings page has a purge button for them, plus a full data-removal
  button for a clean uninstall.

## License

GPL version 2 or higher, like eveBB itself.
