<?php

/**
 * Topic SEO Tags - an eveBB plugin.
 *
 * Search engines and social platforms describe pages from their <head>
 * metadata; a stock forum offers them nothing beyond a <title>. This
 * plugin injects, per page:
 *
 *   - a meta description (topic: an excerpt of the first post with
 *     BBCode stripped; forum: the forum description; index: the board
 *     description)
 *   - a canonical URL (with the page number preserved past page 1, so
 *     paginated topics don't compete with themselves)
 *   - Open Graph tags (og:title/description/url/type/site_name/image)
 *     and a Twitter summary card, so shared links unfurl properly
 *
 * Everything is computed at render time from data the page has already
 * loaded (plus one indexed query for the topic's first post). Nothing
 * is stored; deactivate and the head is stock again.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_seotags extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'emit'));
	}

	function emit()
	{
		global $pun_config, $cur_topic, $cur_forum;

		$page = basename($_SERVER['SCRIPT_NAME'], '.php');
		$base = rtrim($pun_config['o_base_url'], '/');

		if ($page == 'viewtopic' && isset($cur_topic) && is_array($cur_topic))
		{
			$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
			if ($id < 1)
				return;

			$url = $base.'/viewtopic.php?id='.$id;
			$p = isset($_GET['p']) ? (int) $_GET['p'] : 1;
			if ($p > 1)
				$url .= '&p='.$p;

			$this->tags(
				$cur_topic['subject'],
				$this->first_post_excerpt($cur_topic),
				$url,
				'article'
			);
		}
		else if ($page == 'viewforum' && isset($cur_forum) && is_array($cur_forum))
		{
			$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
			if ($id < 1)
				return;

			$url = $base.'/viewforum.php?id='.$id;
			$p = isset($_GET['p']) ? (int) $_GET['p'] : 1;
			if ($p > 1)
				$url .= '&p='.$p;

			$desc = isset($cur_forum['forum_desc']) ? $this->clean(strip_tags((string) $cur_forum['forum_desc'])) : '';

			$this->tags($cur_forum['forum_name'], $desc, $url, 'website');
		}
		else if ($page == 'index')
		{
			$desc = $this->clean(strip_tags((string) $pun_config['o_board_desc']));
			$this->tags($pun_config['o_board_title'], $desc, $base.'/index.php', 'website');
		}
	}

	//
	// Fetch and clean an excerpt of the topic's first post
	//
	function first_post_excerpt($cur_topic)
	{
		global $db;

		if (empty($cur_topic['first_post_id']))
			return '';

		$result = $db->query('SELECT message FROM '.$db->prefix.'posts WHERE id='.(int) $cur_topic['first_post_id']) or error('Unable to fetch post', __FILE__, __LINE__, $db->error());
		if (!$db->has_rows($result))
			return '';

		return $this->clean($this->strip_bbcode((string) $db->result($result)));
	}

	//
	// Reduce BBCode source to plain prose: quoted/code material is
	// someone else's words or noise, so those blocks go entirely;
	// remaining tags are unwrapped to their inner text.
	//
	function strip_bbcode($text)
	{
		// Remove [quote]...[/quote] and [code]...[/code] blocks wholesale
		// (repeat for nesting, bounded)
		for ($i = 0; $i < 5; $i++)
		{
			$before = $text;
			$text = preg_replace('%\[(quote|code)(?:=[^\]]*)?\](?:(?!\[(?:quote|code)).)*?\[/\1\]%is', ' ', $text);
			if ($text === null || $text === $before)
				break;
		}
		if ($text === null)
			$text = '';

		// [img=...]alt[/img] and [img]url[/img] vanish
		$text = preg_replace('%\[img[^\]]*\].*?\[/img\]%is', ' ', $text) ?: $text;

		// Remaining [tags] unwrap to their inner text ([url=X]label[/url]
		// keeps the label, [b]bold[/b] keeps bold, and so on)
		$text = preg_replace('%\[/?[a-z\*]+(?:=[^\]]*)?\]%i', '', $text) ?: $text;

		return $text;
	}

	//
	// Collapse whitespace and truncate to a search-snippet length
	//
	function clean($text)
	{
		$text = trim(preg_replace('%\s+%s', ' ', (string) $text));

		$max = 200;
		if (function_exists('utf8_strlen') && function_exists('utf8_substr'))
		{
			if (utf8_strlen($text) > $max)
				$text = rtrim(utf8_substr($text, 0, $max - 1)).'…';
		}
		else if (strlen($text) > $max)
			$text = rtrim(substr($text, 0, $max - 1)).'…';

		return $text;
	}

	//
	// Emit the tag block
	//
	function tags($title, $desc, $url, $type)
	{
		global $pun_config;

		$e = 'pun_htmlspecialchars';

		$image = isset($pun_config['o_logo_url']) && $pun_config['o_logo_url'] != ''
			? $pun_config['o_logo_url']
			: rtrim($pun_config['o_base_url'], '/').'/img/evebb-logo.png';

		echo "\n".'<link rel="canonical" href="'.$e($url).'" />'."\n";
		if ($desc != '')
			echo '<meta name="description" content="'.$e($desc).'" />'."\n";
		echo '<meta property="og:site_name" content="'.$e($pun_config['o_board_title']).'" />'."\n";
		echo '<meta property="og:type" content="'.$e($type).'" />'."\n";
		echo '<meta property="og:title" content="'.$e($title).'" />'."\n";
		if ($desc != '')
			echo '<meta property="og:description" content="'.$e($desc).'" />'."\n";
		echo '<meta property="og:url" content="'.$e($url).'" />'."\n";
		echo '<meta property="og:image" content="'.$e($image).'" />'."\n";
		echo '<meta name="twitter:card" content="summary" />'."\n";
	}
}
