Topic SEO Tags - an eveBB plugin
================================

Gives search engines and social platforms something to work with:

  - meta descriptions (topics: an excerpt of the first post with BBCode
    stripped; forums: the forum description; index: the board
    description)
  - canonical URLs, page numbers preserved past page 1
  - Open Graph + Twitter card tags, so shared topic links unfurl with
    the topic title and excerpt instead of a bare URL

INSTALL
  Administration -> Plugins -> upload this zip -> Activate. That's all -
  there is nothing to configure. The board logo (or the default eveBB
  logo) is used as the share image.

Everything is computed at render time; nothing is stored. Deactivate
and the page head is exactly stock again.

License: GPL v2 or later, same as eveBB. Built for eveBB 2.0.0-beta.1+.
