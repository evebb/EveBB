<?php

/**
 * XML Sitemap - shared library.
 *
 * Builds the sitemap into the forum cache directory (atomic renames)
 * and serves it from there; rebuilds are time-gated. Only content a
 * GUEST can read is ever listed - the sitemap is public by definition,
 * so hidden forums must never leak through it.
 *
 * config.php may define SITEMAP_PAGE_SIZE to override the URLs-per-file
 * split (used by the test suite; the protocol limit is 50,000).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

//
// URLs per sitemap file before splitting into a sitemap index
//
function sitemap_page_size()
{
	if (defined('SITEMAP_PAGE_SIZE'))
		return max(2, (int) SITEMAP_PAGE_SIZE);

	return 40000;
}

function sitemap_endpoint_url()
{
	return get_base_url().'/plugins/sitemap/xml.php';
}

function sitemap_meta_file()
{
	return FORUM_CACHE_DIR.'cache_sitemap.php';
}

function sitemap_page_file($page)
{
	return FORUM_CACHE_DIR.'cache_sitemap_p'.intval($page).'.xml';
}

//
// Upsert a config value + refresh the cache
//
function sitemap_save_config($name, $value)
{
	global $db, $pun_config;

	if (isset($pun_config[$name]))
		$db->query('UPDATE '.$db->prefix.'config SET conf_value=\''.$db->escape($value).'\' WHERE conf_name=\''.$db->escape($name).'\'') or error('Unable to update board config', __FILE__, __LINE__, $db->error());
	else
		$db->query('INSERT INTO '.$db->prefix.'config (conf_name, conf_value) VALUES(\''.$db->escape($name).'\', \''.$db->escape($value).'\')') or error('Unable to insert into board config', __FILE__, __LINE__, $db->error());

	$pun_config[$name] = $value;

	if (!defined('FORUM_CACHE_FUNCTIONS_LOADED'))
		require PUN_ROOT.'include/cache.php';
	generate_config_cache();
}

//
// Can guests read the board at all? A members-only board must publish
// nothing.
//
function sitemap_guests_allowed()
{
	global $db;

	$result = $db->query('SELECT g_read_board FROM '.$db->prefix.'groups WHERE g_id='.PUN_GUEST) or error('Unable to fetch guest group', __FILE__, __LINE__, $db->error());

	return $db->has_rows($result) && intval($db->result($result)) == 1;
}

//
// Forums a guest may read, minus the admin's exclusion list.
// Returns id => last_post (may be null).
//
function sitemap_public_forums()
{
	global $db, $pun_config;

	$excluded = array();
	foreach (explode(',', $pun_config['o_sitemap_exclude'] ?? '') as $bit)
	{
		if (intval(trim($bit)) > 0)
			$excluded[] = intval(trim($bit));
	}

	$result = $db->query('SELECT f.id, f.last_post FROM '.$db->prefix.'forums AS f LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.PUN_GUEST.') WHERE (fp.read_forum IS NULL OR fp.read_forum=1) ORDER BY f.id') or error('Unable to fetch forums', __FILE__, __LINE__, $db->error());

	$forums = array();
	while ($row = $db->fetch_assoc($result))
	{
		if (!in_array((int) $row['id'], $excluded, true))
			$forums[(int) $row['id']] = ($row['last_post'] !== null) ? (int) $row['last_post'] : null;
	}

	return $forums;
}

//
// One <url> entry
//
function sitemap_entry($loc, $lastmod)
{
	$xml = "\t<url>\n\t\t<loc>".htmlspecialchars($loc, ENT_XML1)."</loc>\n";
	if ($lastmod)
		$xml .= "\t\t<lastmod>".gmdate('Y-m-d\TH:i:s\Z', $lastmod)."</lastmod>\n";

	return $xml."\t</url>\n";
}

//
// Rebuild the whole sitemap into the cache (atomic). Returns the meta
// array, or false when guests can't read the board (an empty sitemap is
// written so the endpoint still serves valid XML).
//
function sitemap_rebuild()
{
	global $db;

	$base = get_base_url();
	$page_size = sitemap_page_size();
	$open = '<?xml version="1.0" encoding="UTF-8"?>'."\n".'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
	$close = '</urlset>'."\n";

	$pages = array();      // page number => tmp file path
	$page = 0;
	$count = 0;
	$total = 0;
	$handle = null;

	$flush_page = function () use (&$handle, $close) {
		if ($handle !== null)
		{
			fwrite($handle, $close);
			fclose($handle);
			$handle = null;
		}
	};
	$add = function ($entry) use (&$handle, &$page, &$count, &$total, &$pages, $open, $page_size, $flush_page) {
		if ($handle === null || $count >= $page_size)
		{
			$flush_page();
			$page++;
			$count = 0;
			$tmp = sitemap_page_file($page).'.tmp';
			$handle = fopen($tmp, 'wb');
			$pages[$page] = $tmp;
			fwrite($handle, $open);
		}
		fwrite($handle, $entry);
		$count++;
		$total++;
	};

	if (sitemap_guests_allowed())
	{
		$forums = sitemap_public_forums();

		// Board index: lastmod = newest activity in any public forum
		$board_last = 0;
		foreach ($forums as $last_post)
			$board_last = max($board_last, (int) $last_post);
		$add(sitemap_entry($base.'/index.php', $board_last ?: null));

		foreach ($forums as $forum_id => $last_post)
			$add(sitemap_entry($base.'/viewforum.php?id='.$forum_id, $last_post));

		if (!empty($forums))
		{
			$result = $db->query('SELECT id, last_post FROM '.$db->prefix.'topics WHERE moved_to IS NULL AND forum_id IN('.implode(',', array_keys($forums)).') ORDER BY id') or error('Unable to fetch topics', __FILE__, __LINE__, $db->error());
			while ($row = $db->fetch_assoc($result))
				$add(sitemap_entry($base.'/viewtopic.php?id='.$row['id'], (int) $row['last_post']));
		}
	}

	$flush_page();

	// A members-only board (or one with nothing public) still gets a
	// valid, empty sitemap
	if ($total == 0)
	{
		$tmp = sitemap_page_file(1).'.tmp';
		file_put_contents($tmp, $open.$close);
		$pages[1] = $tmp;
	}

	// Atomic swap: rename every tmp into place, then drop stale pages
	foreach ($pages as $number => $tmp)
		rename($tmp, sitemap_page_file($number));
	for ($stale = count($pages) + 1; file_exists(sitemap_page_file($stale)); $stale++)
		@unlink(sitemap_page_file($stale));

	$meta = array('built' => time(), 'pages' => count($pages), 'urls' => $total);
	$tmp = sitemap_meta_file().'.tmp';
	file_put_contents($tmp, '<?php'."\n".'return '.var_export($meta, true).';'."\n");
	rename($tmp, sitemap_meta_file());

	return $meta;
}

//
// Current meta, rebuilding first if the cache is stale or missing
//
function sitemap_ensure()
{
	global $pun_config;

	$meta = @include sitemap_meta_file();
	$hours = max(1, min(168, intval($pun_config['o_sitemap_hours'] ?? 12)));

	if (!is_array($meta) || !isset($meta['built'], $meta['pages'])
		|| time() - (int) $meta['built'] > $hours * 3600
		|| !file_exists(sitemap_page_file(1)))
		$meta = sitemap_rebuild();

	return $meta;
}
