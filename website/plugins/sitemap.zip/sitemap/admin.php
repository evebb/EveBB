<?php

/**
 * XML Sitemap - settings page (shown inside the plugin manager).
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

require_once dirname(__FILE__).'/lib.php';

$sitemap_notice = '';

if (isset($_POST['save_sitemap']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	sitemap_save_config('o_sitemap_hours', (string) max(1, min(168, intval($_POST['rebuild_hours'] ?? 12))));

	$excluded = array();
	foreach (explode(',', $_POST['exclude'] ?? '') as $bit)
	{
		if (intval(trim($bit)) > 0)
			$excluded[] = intval(trim($bit));
	}
	sitemap_save_config('o_sitemap_exclude', implode(',', array_unique($excluded)));

	// Settings change what the sitemap contains - rebuild immediately
	sitemap_rebuild();

	redirect('admin_plugins.php?action=settings&plugin='.$plugin_slug, 'Settings saved. Redirecting …');
}
else if (isset($_POST['rebuild_sitemap']))
{
	confirm_referrer('admin_plugins.php');
	check_csrf($_POST['csrf_token'] ?? null);

	$meta = sitemap_rebuild();
	$sitemap_notice = 'Sitemap rebuilt: '.forum_number_format($meta['urls']).' URL(s) in '.$meta['pages'].' file(s).';
}

$sm_hours = intval($pun_config['o_sitemap_hours'] ?? 12);
$sm_exclude = $pun_config['o_sitemap_exclude'] ?? '';
$sm_meta = @include sitemap_meta_file();
$sm_guests = sitemap_guests_allowed();

$result = $db->query('SELECT id, forum_name FROM '.$db->prefix.'forums ORDER BY id') or error('Unable to fetch forums', __FILE__, __LINE__, $db->error());
$forum_legend = array();
while ($row = $db->fetch_assoc($result))
	$forum_legend[] = $row['id'].' = '.pun_htmlspecialchars($row['forum_name']);

?>
<?php if ($sitemap_notice != ''): ?>	<div class="inform">
		<div class="forminfo">
			<p><strong><?php echo $sitemap_notice ?></strong></p>
		</div>
	</div>
<?php endif; ?>	<div class="inform">
		<fieldset>
			<legend>Status</legend>
			<div class="infldset">
<?php if (!$sm_guests): ?>				<p><strong>This board is not readable by guests</strong>, so the sitemap is published empty — a public sitemap must never reveal members-only content. It will fill itself automatically if you ever open the board up.</p>
<?php elseif (is_array($sm_meta)): ?>				<p>Sitemap last built <strong><?php echo format_time($sm_meta['built']) ?></strong> — <?php echo forum_number_format($sm_meta['urls']) ?> URL(s) in <?php echo (int) $sm_meta['pages'] ?> file(s)<?php if ((int) $sm_meta['pages'] > 1) echo ' (served behind a sitemap index)' ?>. It rebuilds itself when older than <?php echo $sm_hours ?> hour(s).</p>
<?php else: ?>				<p>The sitemap has not been built yet — it will build itself on the first visit to the URL below, or use the button at the bottom of this page.</p>
<?php endif; ?>				<p>Your sitemap lives at:</p>
				<p><code><?php echo pun_htmlspecialchars(sitemap_endpoint_url()) ?></code></p>
				<p>Add this line to the <code>robots.txt</code> at your site root (this both announces the sitemap to crawlers and satisfies the sitemap protocol's location rule), and optionally submit the same URL in Google Search Console and Bing Webmaster Tools:</p>
				<p><code>Sitemap: <?php echo pun_htmlspecialchars(sitemap_endpoint_url()) ?></code></p>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>XML Sitemap settings</legend>
			<div class="infldset">
				<p>The sitemap lists the board index, every forum guests can read, and every topic in them, each with its real last-activity date. Forums hidden from guests are always excluded automatically.</p>
				<label>Rebuild when older than (1–168 hours)
					<br /><input type="text" name="rebuild_hours" size="4" maxlength="3" value="<?php echo $sm_hours ?>" />
				</label>
				<label>Also exclude these forums (comma-separated forum IDs; leave blank for none)
					<br /><input type="text" name="exclude" size="50" maxlength="255" value="<?php echo pun_htmlspecialchars($sm_exclude) ?>" />
				</label>
<?php if (!empty($forum_legend)): ?>				<p><?php echo implode('; &#160; ', $forum_legend) ?></p>
<?php endif; ?>				<p class="topspace"><input type="submit" name="save_sitemap" value="Save settings" /></p>
			</div>
		</fieldset>
	</div>
	<div class="inform">
		<fieldset>
			<legend>Maintenance</legend>
			<div class="infldset">
				<p><input type="submit" name="rebuild_sitemap" value="Rebuild sitemap now" /> Regenerate immediately instead of waiting for the age gate.</p>
			</div>
		</fieldset>
	</div>
<?php
