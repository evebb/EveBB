# XML Sitemap for eveBB

Serves an XML sitemap of your board's public content — the index, every
guest-readable forum, and every topic, each with its real last-activity
date — so search engines find and refresh every thread, not just the
ones near the front page.

## What it does

- **Complete coverage with honest dates.** Topics carry `lastmod` from
  their last post, which is the one signal modern crawlers actually use.
- **Guest-permission filtered.** A sitemap is public by definition, so
  only forums guests can read are ever listed — hidden and staff forums
  can't leak through it. On a members-only board the sitemap is
  published valid-but-empty.
- **Cached and cheap.** The sitemap is built into the forum's cache
  directory and served as a static file; it rebuilds itself when older
  than a configurable age (default 12 hours) or on demand from the
  settings page. Nothing runs in the background.
- **Scales automatically.** Past the URLs-per-file limit the plugin
  splits into numbered files behind a standard sitemap index — nothing
  to configure.
- A `<link rel="sitemap">` tag is added to every page's head.

## Setup

1. Upload the zip through Administration → Plugins and activate it.
2. The settings page shows your sitemap URL
   (`https://your-board/plugins/sitemap/xml.php`). Add the line it gives
   you to the `robots.txt` at your site root:

       Sitemap: https://your-board/plugins/sitemap/xml.php

   The robots.txt reference both announces the sitemap and satisfies the
   sitemap protocol's location rule for sitemaps living below the root.
3. Optionally submit the same URL in Google Search Console and Bing
   Webmaster Tools.

Settings: rebuild age (1–168 hours) and an optional list of additional
forums to exclude. No database changes at all — a couple of config
values and cache files, gone on deactivation.

Pairs naturally with the seotags plugin (per-page metas + discovery).

License: GPL v2 or higher, same as eveBB.
