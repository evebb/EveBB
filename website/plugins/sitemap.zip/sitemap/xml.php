<?php

/**
 * XML Sitemap - the endpoint.
 *
 *   <board>/plugins/sitemap/xml.php          the sitemap (or, on large
 *                                            boards, a sitemap index)
 *   <board>/plugins/sitemap/xml.php?page=N   one page of a split sitemap
 *
 * Reference it from robots.txt:
 *   Sitemap: https://your-board/plugins/sitemap/xml.php
 * (a robots.txt reference also lifts the sitemaps-protocol path
 * restriction for sitemaps living below the root)
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

define('PUN_ROOT', dirname(__FILE__).'/../../');
require PUN_ROOT.'include/common.php';

require_once PUN_ROOT.'include/plugins.php';
require_once dirname(__FILE__).'/lib.php';

if (!in_array('sitemap', evebb_active_plugins()))
{
	$db->end_transaction();
	header('HTTP/1.1 404 Not Found');
	header('Content-Type: text/plain; charset=utf-8');
	exit('Not found.');
}

$meta = sitemap_ensure();
$page = intval($_GET['page'] ?? 0);

$db->end_transaction();
header('Content-Type: application/xml; charset=utf-8');
header('X-Robots-Tag: noindex');   // the sitemap file itself shouldn't be indexed

// Split sitemap and no specific page requested: serve the sitemap index
if ($meta['pages'] > 1 && $page < 1)
{
	$endpoint = sitemap_endpoint_url();
	echo '<?xml version="1.0" encoding="UTF-8"?>'."\n".'<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
	for ($i = 1; $i <= $meta['pages']; $i++)
	{
		echo "\t<sitemap>\n\t\t<loc>".htmlspecialchars($endpoint.'?page='.$i, ENT_XML1)."</loc>\n\t\t<lastmod>".gmdate('Y-m-d\TH:i:s\Z', $meta['built'])."</lastmod>\n\t</sitemap>\n";
	}
	echo '</sitemapindex>'."\n";
	exit;
}

$page = ($page < 1) ? 1 : $page;
if ($page > $meta['pages'] || !file_exists(sitemap_page_file($page)))
{
	header('HTTP/1.1 404 Not Found');
	header('Content-Type: text/plain; charset=utf-8');
	exit('No such sitemap page.');
}

readfile(sitemap_page_file($page));
