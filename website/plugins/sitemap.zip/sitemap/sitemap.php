<?php

/**
 * XML Sitemap - the addon.
 *
 * The only front-end job is advertising the sitemap with a <link> tag
 * in every page's head; building and serving happen in xml.php.
 *
 * License: http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 */

if (!defined('PUN'))
	exit;

class plugin_sitemap extends flux_addon
{
	function register($manager)
	{
		$manager->bind('header_head_end', array($this, 'head_link'));
	}

	function head_link()
	{
		require_once dirname(__FILE__).'/lib.php';

		echo '<link rel="sitemap" type="application/xml" title="Sitemap" href="'.pun_htmlspecialchars(sitemap_endpoint_url()).'" />'."\n";
	}
}
