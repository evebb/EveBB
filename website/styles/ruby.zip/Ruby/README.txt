Ruby - an eveBB style
=====================

A light theme with deep ruby-red accents, based on the Carbon style that ships with eveBB.

INSTALL (built-in style installer)
  Administration -> Styles -> upload this zip. Done. Then set it as the
  board default there, or let each member pick it in Profile -> Display.

INSTALL (manual, if you prefer FTP)
  Copy Ruby.css from inside this folder to style/Ruby.css on your server and
  the rest of this folder to style/Ruby/.

MATCHING LOGO (optional)
  logo/ contains an eveBB logo recoloured to match this style (PNG ready
  to use, SVG source for editing). Upload the PNG over img/evebb-logo.png,
  or set it in Administration -> Options. It carries the "COMMUNITY FORUM"
  tagline - edit the SVG text for your own wording.


License: GPL v2 or later, same as eveBB. Built for eveBB 2.0.0-beta.1+.
